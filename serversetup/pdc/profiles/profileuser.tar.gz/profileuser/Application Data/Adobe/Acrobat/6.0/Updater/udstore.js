try{eval((new String("updater.store.perUser=({nextCheckDate:\"Thu, 29 Apr 2004 02:52:26 GMT\", viewedMessages:{}})")).valueOf());}catch(e){updater.console.println("eval store exception:"+e);}
