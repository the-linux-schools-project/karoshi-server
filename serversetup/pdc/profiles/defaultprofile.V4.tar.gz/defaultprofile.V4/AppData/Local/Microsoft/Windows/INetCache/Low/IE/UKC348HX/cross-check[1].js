window._taboola = window._taboola || [];
window._taboola.push({
 "throttle_pub" : { "mangareader-mangapanda" : 10, "mangareader-mangareader" : 10, "mangareader-network" : 10}
});
