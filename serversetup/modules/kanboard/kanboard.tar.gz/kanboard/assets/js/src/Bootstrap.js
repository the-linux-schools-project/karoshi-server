var _KB = null;

jQuery(document).ready(function() {
    _KB = new Kanboard.App();
    _KB.execute();
});
