<?php

// Auto-refresh frequency in seconds for the public board view (60 seconds by default)
define('BOARD_PUBLIC_CHECK_INTERVAL', 60);

// Board refresh frequency in seconds (the value 0 disable this feature, 10 seconds by default)
define('BOARD_CHECK_INTERVAL', 10);

// Database driver: sqlite or mysql (sqlite by default)
define('DB_DRIVER', 'mysql');

// Mysql username
define('DB_USERNAME', 'kanboard_user');

// Mysql password
define('DB_PASSWORD', 'CHANGETHISPASS');

// Mysql hostname
define('DB_HOSTNAME', '127.0.0.1');

// Mysql database name
define('DB_NAME', 'kanboard');

// Enable LDAP authentication (false by default)
define('LDAP_AUTH', 'true');

// LDAP server hostname
define('LDAP_SERVER', 'CHANGETHISSERVER');
define('LDAP_PORT', 389);
define('LDAP_SSL_VERIFY', false);

// Credentials to be allowed to browse the LDAP directory
define('LDAP_BIND_TYPE', 'anonymous');
define('LDAP_USERNAME', null);
define('LDAP_PASSWORD', null);

// LDAP properties
define('LDAP_ACCOUNT_BASE', 'OU=personnel,CHANGETHISLDAPPATH');
define('LDAP_USER_BASE_DN', 'OU=personnel,CHANGETHISLDAPPATH');
define('LDAP_USER_FILTER', '(&(objectClass=user)(sAMAccountName=%s))');
define('LDAP_USER_ATTRIBUTE_USERNAME', 'samaccountname');
define('LDAP_USER_ATTRIBUTE_FULLNAME', 'displayname');
define('LDAP_USER_ATTRIBUTE_EMAIL', 'mail');
define('LDAP_USER_ATTRIBUTE_GROUPS', 'memberof');
define('LDAP_USER_CREATION', true);
define('LDAP_ACCOUNT_EMAIL', 'mail');
define('LDAP_GROUP_ADMIN_DN', 'CN=itadmin,OU=Groups,CHANGETHISLDAPPATH');
define('LDAP_GROUP_MANAGER_DN', 'CN=staff,OU=Groups,CHANGETHISLDAPPATH');
define('LDAP_GROUP_PROVIDER', true);
define('LDAP_GROUP_BASE_DN', 'OU=Groups,CHANGETHISLDAPPATH');
define('LDAP_GROUP_FILTER', '(&(objectClass=group)(sAMAccountName=%s*))');
define('LDAP_GROUP_USER_FILTER', '(&(objectClass=posixGroup)(memberUid=%s)))');
define('LDAP_GROUP_ATTRIBUTE_NAME', 'cn');

// Enable/disable Google authentication
define('GOOGLE_AUTH', false);

// Google client id (Get this value from the Google developer console)
define('GOOGLE_CLIENT_ID', '');

// Google client secret key (Get this value from the Google developer console)
define('GOOGLE_CLIENT_SECRET', '');

// Enable captcha after 3 authentication failure
define('BRUTEFORCE_CAPTCHA', 3);

// Lock the account after 6 authentication failure
define('BRUTEFORCE_LOCKDOWN', 6);

// Lock account duration in minute
define('BRUTEFORCE_LOCKDOWN_DURATION', 15);

