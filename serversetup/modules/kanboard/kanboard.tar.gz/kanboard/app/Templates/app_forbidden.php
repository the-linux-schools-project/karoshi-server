<section id="main">
    <div class="page-header">
        <h2><?= t('Forbidden') ?></h2>
    </div>

    <p class="alert alert-error">
        <?= t('Access Forbidden') ?>
    </p>
</section>