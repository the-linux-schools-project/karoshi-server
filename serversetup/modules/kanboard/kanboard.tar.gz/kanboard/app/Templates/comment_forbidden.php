<section id="main">
    <div class="page-header">
        <h2><?= t('Forbidden') ?></h2>
    </div>

    <p class="alert alert-error">
        <?= t('Only administrators or the creator of the comment can access to this page.') ?>
    </p>
</section>