<section id="main">
    <div class="page-header">
        <h2><?= t('Page not found') ?></h2>
    </div>

    <p class="alert alert-error">
        <?= t('Sorry, I didn\'t found this information in my database!') ?>
    </p>
</section>