<?php

namespace Kanboard\Subscriber;

use Kanboard\Core\Base;

/**
 * Base class for subscribers
 *
 * @package subscriber
 * @author  Frederic Guillot
 */
class BaseSubscriber extends Base
{
}
