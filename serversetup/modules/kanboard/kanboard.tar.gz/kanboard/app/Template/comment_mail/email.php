<?= $this->text->markdown($email['comment'], true) ?>
