Description of phpCAS 1.3.5 library import

* downloaded from http://downloads.jasig.org/cas-clients/php/current/
* applied patch https://github.com/apereo/phpCAS/pull/247 for PHP 7.2 compatibility (MDL-60280)