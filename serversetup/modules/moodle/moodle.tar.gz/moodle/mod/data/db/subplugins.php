<?php

$subplugins = array('datafield'  => 'mod/data/field',
                    'datapreset' => 'mod/data/preset');
