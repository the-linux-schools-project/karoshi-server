<?php

$plugin->version = 2013041103;
$plugin->requires = 2012010100;
$plugin->component = 'foolish_hippo';
$plugin->dependencies = array('foolish_frog' => ANY_VERSION);
