<?php

$plugin->version = 2013041103;
$plugin->requires = 2013010100;
$plugin->component = 'quxcat_one';
$plugin->dependencies = array('bazmeg_one' => 2013010100);
