<?php

$plugin->version = 2013041103;
$plugin->requires = 2013010100;
$plugin->component = 'bazmeg_one';
