<?php

$plugin->version = 2013041103;
$plugin->requires = 2013010100;
$plugin->component = 'foolish_frog';
$plugin->dependencies = array('mod_foo' => 2012030500);
