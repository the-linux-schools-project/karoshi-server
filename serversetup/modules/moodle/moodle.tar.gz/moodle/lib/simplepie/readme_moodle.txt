Description of SimplePie v1.3dev library import into Moodle

Obtained from http://github.com/simplepie/simplepie/commit/798f4674468316b8cc70fe8de73034c072dbdc15

Changes:
  * None. This import contains _NO_CHANGES_ to the simplepie.inc file, changes are
    controlled through OO extension of the classes instead.

Dan Poltawski <talktodan@gmail.com>
Petr Skoda
