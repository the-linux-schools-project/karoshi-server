Description of Typo3 libraries (v 4.7.15) import into Moodle

Changes:
1/ hacked relative include of class.t3lib_utility_debug.php

Procedure:
1/ download latest version form http://typo3.org/download/
2/ copy csconvtbl/*, unidata/* and all other necessary files we use
3/ run our phpunit tests with and without mbstring PHP extension

skodak, stronk7, moodler
