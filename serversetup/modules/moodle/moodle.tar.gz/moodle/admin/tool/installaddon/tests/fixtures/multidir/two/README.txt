Only one dir is allowed
