<?php

$plugin->version = 2013031900;
$plugin->component = 'local_greenbar';
