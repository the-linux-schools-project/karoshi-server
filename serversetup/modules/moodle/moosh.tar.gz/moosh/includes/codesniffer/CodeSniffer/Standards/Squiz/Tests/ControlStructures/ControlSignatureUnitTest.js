// do ... while
i = 0;
do {
    i = 0;
} while (i > 0);

do
{
    i = 0;
} while (i > 0);

do
{
    i = 0;
}
while (i > 0);

do { i = 0; } while (i > 0);

do{
    i = 0;
}while(i > 0);

// while
while (i < 1) {
    i = 0;
}

while(i < 1){
    i = 0;
}

while (i < 1) { i = 0; }

// for
for (i = 1; i < 1; i++) {
    i = 0;
}

for(i = 1; i < 1; i++){
    i = 0;
}

for (i = 1; i < 1; i++) { i = 0; }

// if
if (i == 0) {
    i = 1;
}

if(i == 0){
    i = 1;
}

if (i == 0) { i = 1; }

// else
if (i == 0) {
    i = 1;
} else {
    i = 0;
}

if (i == 0) {
    i = 1;
}else{
    i = 0;
}

if (i == 0) { i = 1; } else { i = 0; }

// else
if (i == 0) {
    i = 1;
} else {
    i = 0;
}

// else if
if (i == 0) {
    i = 1;
} else if (i == 2) {
    i = 0;
}

if (i == 0) {
    i = 1;
}else if(i == 2){
    i = 0;
}

if (i == 0) { i = 1; } else if (i == 2) { i = 0; }

if (i == 0) { // comments are not allowed
    i = 1;
}

if (i == 0) {// comments are not allowed
    i = 1;
}

if (i == 0) { /* comments are not allowed*/
    i = 1;
}

if (i == 0)
{ // this is not ok
    i = 1;
}

if (i == 0) /* this is not ok */ {
}

try {
    code = 'this';
} catch (e) {
    // Caught!
}

try { code = 'this'; } catch (e) {
    // Caught!
}

do { i = 0;
} while (i > 0);