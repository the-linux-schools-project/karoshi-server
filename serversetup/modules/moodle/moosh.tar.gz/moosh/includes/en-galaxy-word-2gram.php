<?php

global $table, $n, $separator;

$n = 2;
$separator = ' ';
$table = array (
  'Douglas' => 
  array (
    'Adams' => 1,
  ),
  'Adams' => 
  array (
    'The' => 1,
  ),
  'The' => 
  array (
    'Hitch' => 17,
    'house' => 1,
    'only' => 4,
    '' => 33,
    'word' => 3,
    'bulldozer' => 1,
    'pub,' => 1,
    'first' => 1,
    'information' => 1,
    'policemen' => 1,
    'reason' => 2,
    'Earth' => 1,
    'sun' => 1,
    'game' => 2,
    'bottle' => 1,
    'mere' => 2,
    'Guide' => 2,
    'barman' => 7,
    'man' => 7,
    'world\'s' => 1,
    'planet' => 3,
    'contents' => 1,
    'other' => 6,
    'pub' => 1,
    'huge' => 2,
    'great' => 1,
    'ships' => 1,
    'PA' => 3,
    'terror' => 1,
    'Vogon' => 9,
    'boat' => 3,
    'term' => 1,
    'President' => 2,
    'island' => 1,
    'crowd' => 2,
    'three' => 1,
    'robot' => 3,
    'bubble' => 1,
    'Arabs' => 1,
    'next' => 3,
    'Heart' => 2,
    'fact' => 1,
    'owner' => 1,
    'whole' => 4,
    'Dentrassis' => 1,
    'shape' => 1,
    'guard' => 3,
    'report' => 1,
    'Hitchhiker\'s' => 1,
    'words' => 1,
    'best' => 1,
    'noise' => 1,
    'room' => 2,
    'Babel' => 2,
    'practical' => 1,
    'speech' => 1,
    'argument' => 1,
    'Earth.' => 2,
    'dollar,' => 1,
    'screen' => 1,
    'Dentrassi?' => 1,
    'second' => 1,
    'very' => 1,
    'prisoners' => 1,
    'sweat' => 1,
    'captain' => 2,
    'long' => 1,
    'leather?' => 1,
    'machismo?' => 1,
    'introduction' => 1,
    'simple' => 1,
    'record' => 1,
    'nothingth' => 1,
    'real' => 1,
    'highest' => 1,
    'Universe' => 1,
    'point' => 1,
    'voice' => 8,
    'Infinite' => 1,
    'principle' => 1,
    'Improbability-proof' => 1,
    'cabin' => 1,
    'truth' => 1,
    'ship' => 3,
    'Encyclopaedia' => 1,
    'marketing' => 1,
    'pink' => 1,
    'panel' => 1,
    'irony' => 1,
    'others' => 2,
    'machine' => 1,
    'couple' => 1,
    'ticker' => 1,
    'computer' => 3,
    'number' => 1,
    'peculiar' => 1,
    'ship\'s' => 1,
    'home' => 1,
    'planet\'s' => 1,
    'surface' => 1,
    'moment' => 1,
    'fires' => 1,
    'suns' => 2,
    'immensity' => 1,
    'suspense' => 1,
    'deadly' => 1,
    'way' => 1,
    'commercial' => 1,
    'menace' => 1,
    'suddenness' => 1,
    'lever' => 1,
    'crew' => 1,
    'safety' => 1,
    'ship,' => 1,
    'two' => 8,
    'missiles' => 1,
    'wind' => 1,
    'silence' => 1,
    'ground' => 1,
    'walls' => 1,
    'computers' => 1,
    'strangeness' => 1,
    'old' => 3,
    'aircar' => 4,
    'last' => 2,
    'sense' => 1,
    'colossal' => 1,
    'insane' => 1,
    'car' => 1,
    'wall.' => 1,
    'wall' => 3,
    'flash' => 1,
    'Earth...' => 1,
    'mice' => 4,
    'subtlest' => 1,
    'Milliard' => 1,
    'Great' => 1,
    'answer?' => 1,
    'answer' => 1,
    'Universe!' => 1,
    'hum' => 1,
    'instant' => 1,
    'narrower' => 1,
    'Day' => 1,
    'ultramahagony' => 1,
    'time' => 1,
    'Universe!..' => 1,
    'tension' => 1,
    'Answer' => 1,
    'Ultimate' => 2,
    'Computer' => 1,
    'sea' => 1,
    'beach' => 1,
    'mountains' => 1,
    'Arcturan' => 1,
    'scene' => 1,
    'air' => 1,
    'creature' => 1,
    'lighting' => 1,
    'fusillade' => 1,
    'heat' => 1,
    'front' => 1,
    'four' => 1,
    'cop' => 1,
    'tiny' => 1,
    'note' => 1,
    'History' => 1,
  ),
  'Hitch' => 
  array (
    'Hiker\'s' => 17,
    '' => 1,
  ),
  'Hiker\'s' => 
  array (
    'Guide' => 16,
    '' => 2,
  ),
  'Guide' => 
  array (
    'to' => 17,
    '' => 2,
    'also' => 1,
    'even' => 1,
    'on' => 1,
  ),
  'to' => 
  array (
    'the' => 88,
    'a' => 18,
    '' => 216,
    'people' => 1,
    'get' => 18,
    'anything.' => 1,
    'tell' => 10,
    'come' => 10,
    'be' => 63,
    'worry' => 1,
    'knock' => 3,
    'wash.' => 1,
    'find' => 11,
    'put' => 5,
    'connect' => 2,
    'drink' => 2,
    'suspect' => 3,
    'have' => 22,
    'stand' => 2,
    'see' => 23,
    'accept' => 1,
    'build' => 3,
    'drive' => 1,
    'point' => 2,
    'wonder' => 1,
    'be.' => 2,
    'God' => 1,
    'make' => 14,
    'clean' => 1,
    'demolish' => 1,
    'them' => 3,
    'go' => 8,
    'like' => 5,
    'choose' => 2,
    'say' => 12,
    'him' => 6,
    'water' => 1,
    'her' => 2,
    'baby,' => 1,
    'flag' => 1,
    'lie' => 6,
    'tackle' => 1,
    'sit' => 4,
    'their' => 2,
    'dry' => 1,
    'notice' => 2,
    'ignore' => 1,
    'talk,' => 1,
    'me' => 6,
    'need' => 1,
    'weaken.' => 1,
    'play' => 3,
    'tip' => 1,
    'lose' => 1,
    'depress' => 1,
    'lose.' => 1,
    'think' => 11,
    'Mr.' => 1,
    'build...' => 1,
    'some' => 2,
    'his' => 11,
    'doing' => 1,
    'take' => 9,
    'reassure.' => 1,
    'pop' => 1,
    'do' => 24,
    'stop' => 5,
    'himself,' => 8,
    'Arthur.' => 7,
    'him,' => 3,
    'Prosser' => 1,
    'speculate,' => 1,
    'explain' => 4,
    'himself.' => 6,
    'fell' => 1,
    'pay' => 1,
    'help' => 3,
    'melt' => 1,
    'end.' => 5,
    'watch' => 2,
    'Ford' => 4,
    'spend' => 2,
    'walk' => 1,
    'ford' => 1,
    'notice?' => 1,
    'explain.' => 3,
    'say?' => 2,
    'carry' => 2,
    'sail' => 1,
    'ward' => 1,
    'avoid' => 1,
    'wink' => 1,
    'keep' => 2,
    'end?' => 1,
    'Ford.' => 1,
    'end' => 1,
    'go.' => 1,
    'loathe' => 2,
    'know' => 8,
    'sink' => 1,
    'move' => 2,
    'do,' => 1,
    'shut' => 2,
    'flatten' => 1,
    'do.' => 2,
    'encompass' => 1,
    'flee' => 1,
    'lodge' => 1,
    'start' => 2,
    'plead' => 1,
    'Alpha' => 1,
    'lunch.' => 2,
    'run' => 3,
    'act' => 1,
    'display' => 1,
    'wield' => 1,
    'draw' => 1,
    'understand' => 3,
    'himself' => 2,
    'exist' => 1,
    'and' => 1,
    'meet' => 3,
    'touch' => 1,
    'rest' => 1,
    'die' => 4,
    'press' => 1,
    'seven' => 1,
    'break' => 2,
    'exist,' => 1,
    'her.' => 1,
    'read' => 5,
    'steal' => 3,
    'form.' => 1,
    'survive' => 2,
    'themselves,' => 1,
    'acquire' => 2,
    'bits' => 1,
    'collapse' => 2,
    'employing' => 1,
    'themselves.' => 1,
    'account' => 1,
    'service.' => 1,
    'life' => 3,
    'flicker' => 1,
    'undulate' => 1,
    'speak' => 2,
    'public' => 1,
    'stick' => 1,
    'include' => 1,
    'feel' => 4,
    'believe' => 1,
    'roll' => 2,
    'do?' => 4,
    'charge' => 1,
    'jump' => 1,
    'Barnard\'s' => 1,
    'leave' => 1,
    'marry' => 1,
    'prepare' => 1,
    'leak' => 1,
    'nourish' => 1,
    'you' => 1,
    'prove' => 1,
    'communication' => 1,
    'extend' => 1,
    'rectify' => 1,
    'transmit' => 1,
    'trim' => 1,
    'throw' => 4,
    'space.' => 1,
    'embark' => 1,
    'save' => 1,
    'remember' => 1,
    'change.' => 1,
    'me!' => 1,
    'him.' => 1,
    'stare' => 1,
    'counterpoint' => 1,
    'sublimate' => 1,
    'write' => 1,
    'heaven' => 1,
    'think,' => 1,
    'be,' => 3,
    'look' => 9,
    'reach' => 3,
    'speak.' => 1,
    'add' => 2,
    'that,' => 1,
    'me.' => 1,
    'it' => 2,
    'you,' => 2,
    'my' => 4,
    'thirty' => 1,
    'hum' => 1,
    'die.' => 2,
    'an' => 2,
    'consider' => 1,
    'realize' => 2,
    'journey' => 1,
    'arrive' => 1,
    'one' => 11,
    'reflect' => 2,
    'itself' => 1,
    'copy' => 1,
    'cause' => 1,
    'hear' => 3,
    'one,' => 2,
    'operate' => 1,
    'hold' => 1,
    'talk' => 6,
    'us' => 1,
    'those' => 1,
    'construct' => 1,
    'sweep' => 1,
    'work' => 4,
    'discover' => 1,
    'create' => 2,
    'one...' => 2,
    'face' => 1,
    'pick' => 1,
    'let' => 2,
    'its' => 3,
    'occupy' => 1,
    'number' => 1,
    'convey' => 1,
    'enjoy' => 1,
    'fall' => 1,
    'open' => 2,
    'close' => 1,
    'it.' => 2,
    'entangle' => 1,
    'brush' => 1,
    'fit' => 1,
    'all' => 3,
    'everyone' => 1,
    'bang' => 2,
    'you?' => 4,
    'Trillian' => 3,
    'argue' => 1,
    'what' => 2,
    'show' => 4,
    'know.' => 2,
    'first' => 1,
    'remind' => 1,
    'Zaphod.' => 2,
    'myself' => 1,
    'happen' => 1,
    'retire' => 1,
    'separate' => 1,
    'rationalize' => 1,
    'give' => 3,
    'sleep.' => 2,
    'compose' => 1,
    'recognize' => 1,
    'boldly' => 1,
    'imagine' => 1,
    'form' => 1,
    'expect.' => 1,
    'abject' => 1,
    'grow' => 1,
    'become' => 3,
    'restore' => 1,
    'impose' => 1,
    'manufacture' => 1,
    'reassemble' => 1,
    'ask' => 1,
    'you...' => 1,
    'them.' => 2,
    'assure' => 1,
    'select' => 1,
    'leave.' => 1,
    'your' => 3,
    'kill' => 1,
    'something!' => 1,
    'relax.' => 1,
    'assert' => 1,
    'push' => 1,
    'move.' => 1,
    'anyone' => 1,
    'listen' => 1,
    'impress' => 1,
    'sing.' => 1,
    'that' => 1,
    'land.' => 1,
    'terms' => 1,
    'count' => 1,
    'ten.' => 1,
    'bother' => 1,
    'sight' => 1,
    'turn' => 2,
    'bury' => 1,
    'stamp' => 1,
    'hide' => 1,
    'time' => 1,
    'anything' => 1,
    'see.' => 1,
    'crawl.' => 1,
    'pour' => 1,
    'while' => 1,
    'biro' => 1,
    'than' => 1,
    'try' => 3,
    'Arthur\'s' => 1,
    'visit' => 1,
    'rush' => 1,
    'relieve' => 1,
    'revive' => 1,
    'afford' => 1,
    'behave' => 1,
    'Marvin' => 1,
    'these' => 1,
    'engage' => 1,
    'gauge' => 1,
    'judge,' => 1,
    'focus' => 1,
    'pass' => 2,
    'detect' => 1,
    'our' => 3,
    'support' => 1,
    'perform' => 2,
    'settle' => 1,
    'countenance' => 1,
    'follow' => 1,
    'ring' => 1,
    'learn' => 1,
    'admire' => 1,
    'disguise' => 1,
    'this' => 1,
    'calculate,' => 1,
    'design.' => 1,
    'Lunkwill.' => 1,
    'wait.' => 1,
    'what?' => 1,
    'bar' => 1,
    'check' => 1,
    'say,' => 2,
    'calculating' => 1,
    'run.' => 1,
    'invite' => 1,
    'lay' => 1,
    'clear' => 2,
    'work?' => 1,
    'assimilate' => 1,
    'speak!' => 1,
    'us?' => 1,
    'crawl' => 1,
    'calculate' => 1,
    'navigate' => 1,
    'kick' => 1,
    'sleep' => 1,
    'deal' => 1,
    'guess.' => 1,
    'Galactic' => 1,
    'cross' => 1,
    'gaze' => 1,
    'follow.' => 1,
    'unleash' => 1,
    'wage' => 1,
    'launch' => 1,
    'prevent' => 1,
    'us.' => 1,
    'lunch,' => 1,
    'say.' => 1,
    'business.' => 1,
    'Magrathea' => 1,
    'Life,' => 1,
    'admit' => 1,
    'Arthur,' => 1,
    'buy' => 1,
    'buy.' => 1,
    'program' => 1,
    'shoot' => 2,
    'cope!' => 1,
    'fry' => 1,
    'this,' => 1,
    'needless' => 1,
    'disintegrate.' => 1,
    'happen.' => 1,
    'Slartibartfast.' => 1,
    'part' => 1,
    'press.' => 1,
    'circumstances,' => 1,
    'where' => 1,
    'examine' => 1,
    'me,' => 1,
    'somebody' => 1,
    'it?' => 3,
    'it,' => 1,
    'live' => 1,
  ),
  'the' => 
  array (
    'Galaxy' => 30,
    'uncharted' => 1,
    'unfashionable' => 1,
    'western' => 1,
    'people' => 4,
    'time.' => 4,
    'movements' => 1,
    'whole' => 8,
    'small' => 3,
    'problem' => 3,
    'ones' => 2,
    'opinion' => 1,
    'trees' => 2,
    'first' => 16,
    'oceans.' => 1,
    'world' => 8,
    'idea' => 1,
    'story' => 7,
    'terrible' => 2,
    'most' => 11,
    'great' => 6,
    'Celestial' => 1,
    'more' => 4,
    'Outer' => 1,
    'Galaxy,' => 4,
    'Hitch' => 1,
    '' => 410,
    'standard' => 1,
    'older,' => 1,
    'edge' => 3,
    'village.' => 2,
    'eye.' => 1,
    'house' => 2,
    'one' => 6,
    'fact' => 3,
    'council' => 2,
    'bathroom' => 2,
    'brush' => 1,
    'ceiling.' => 2,
    'kitchen' => 2,
    'night' => 9,
    'shaving' => 1,
    'bedroom.' => 1,
    'pipeline' => 1,
    'wardrobe' => 1,
    'local' => 1,
    'only' => 10,
    'tum' => 1,
    'way' => 7,
    'day' => 4,
    'bulldozer' => 4,
    'mud' => 3,
    'top' => 8,
    'hell' => 4,
    'door,' => 3,
    'nearest' => 2,
    'derisive' => 1,
    'appropriate' => 1,
    'windows' => 1,
    'house.' => 1,
    'plans' => 3,
    'last' => 5,
    'cellar' => 1,
    'display' => 1,
    'lights' => 1,
    'stairs.' => 1,
    'notice' => 1,
    'bottom' => 4,
    'door' => 17,
    'Leopard.' => 1,
    'cold' => 2,
    'bypass.' => 1,
    'blazing' => 1,
    'ape-descendant' => 1,
    'vicinity' => 3,
    'planet' => 25,
    'name' => 1,
    'temples.' => 2,
    'nose.' => 1,
    'unnerving' => 1,
    'friends' => 1,
    'sky' => 13,
    'colour' => 2,
    'traditional' => 1,
    'Betelgeuse' => 1,
    'Earth.' => 4,
    'Marvels' => 1,
    'Universe' => 14,
    'Galaxy.' => 8,
    'environs' => 1,
    'occasional' => 2,
    'For' => 1,
    'Public' => 1,
    'March' => 1,
    'They' => 1,
    'situation' => 3,
    'shadow.' => 1,
    'sun' => 3,
    'pub' => 7,
    'matter' => 3,
    'matter.' => 1,
    'saloon' => 1,
    'Horse' => 3,
    'madranite' => 1,
    'star' => 4,
    'Earth' => 10,
    'two' => 11,
    'bottle' => 1,
    'effects' => 1,
    'bulldozers?' => 1,
    'moment,' => 1,
    'time' => 3,
    'bulldozers' => 1,
    'sole' => 1,
    'bulldozer?' => 1,
    'mud.' => 2,
    'pub?' => 1,
    'man' => 5,
    'mighty' => 1,
    'end' => 5,
    'Earth,' => 2,
    'Encyclopedia' => 2,
    'fermentation' => 1,
    'best' => 3,
    'Pan' => 1,
    'effect' => 3,
    'juice' => 1,
    'seas' => 3,
    'benzine' => 1,
    'back' => 2,
    'heady' => 2,
    'dark' => 2,
    'fires' => 1,
    'Algolian' => 1,
    'heart' => 4,
    'drink.' => 1,
    'barman' => 4,
    'world\'s' => 3,
    'window,' => 2,
    'match' => 3,
    'window.' => 2,
    'barman.' => 2,
    'rest' => 4,
    'bar' => 1,
    'six' => 1,
    'bar.' => 1,
    'change.' => 2,
    'Reader\'s' => 1,
    'sort' => 5,
    'hang' => 1,
    'ionosphere' => 1,
    'surface' => 8,
    'planet;' => 1,
    'darkness' => 1,
    'top.' => 1,
    'Sub-Etha' => 2,
    'snug' => 1,
    'words' => 4,
    'form' => 1,
    'subject' => 3,
    'brilliant' => 2,
    'stars' => 3,
    'desert' => 1,
    'slow' => 2,
    'strag' => 2,
    'length' => 2,
    'towel' => 1,
    'huge' => 2,
    'dull' => 1,
    'low' => 2,
    'jukebox,' => 1,
    'sound' => 3,
    'whisky' => 1,
    'pub,' => 1,
    'window' => 1,
    'same' => 13,
    'barman,' => 1,
    'packets' => 1,
    'bar,' => 1,
    'place' => 3,
    'near' => 1,
    'pub.' => 1,
    'conversation' => 1,
    'sensation' => 1,
    'peanuts' => 1,
    'hushed' => 1,
    'army,' => 1,
    'man,' => 2,
    'long' => 2,
    'raucous' => 1,
    'moment' => 7,
    'lane,' => 1,
    'sudden' => 4,
    'caterpillar' => 1,
    'rubble' => 1,
    'little' => 3,
    'men' => 3,
    'clouds.' => 1,
    'hell\'s' => 1,
    'gaping' => 1,
    'noise.' => 2,
    'noise' => 1,
    'sky,' => 2,
    'dead' => 2,
    'signal' => 1,
    'races' => 1,
    'Vogons.' => 2,
    'Vogon' => 10,
    'air' => 13,
    'Amazing' => 1,
    'greatest' => 3,
    'Galactic' => 8,
    'voice' => 7,
    'outlying' => 2,
    'building' => 1,
    'watching' => 1,
    'gathered' => 1,
    'Vogons' => 12,
    'planning' => 1,
    'planet.' => 2,
    'reply.' => 1,
    'demolition' => 1,
    'hatchways.' => 1,
    'inky' => 1,
    'opposite' => 3,
    'Imperial' => 2,
    'Damogran' => 2,
    'hot;' => 1,
    'remote;' => 1,
    'Heart' => 15,
    'water.' => 1,
    'sea,' => 1,
    'sea' => 5,
    'main' => 3,
    'tiny' => 3,
    'side' => 2,
    'project,' => 1,
    'sake' => 2,
    'Zaphod' => 1,
    'President?' => 1,
    'boat' => 1,
    'entire' => 5,
    'ideal' => 1,
    'Emperor' => 1,
    'government,' => 1,
    'qualities' => 1,
    'President' => 4,
    'Government' => 1,
    'others' => 1,
    'ultimate' => 1,
    'sun.' => 2,
    'day;' => 1,
    'seat' => 1,
    'middle,' => 2,
    'sweep' => 1,
    'inner' => 2,
    'crescent' => 1,
    'cliff' => 3,
    'land' => 1,
    'cliffs' => 1,
    'engineers' => 1,
    'color' => 2,
    'Hooloovoo' => 2,
    'occasion.' => 1,
    'furthest' => 3,
    'fundamental' => 2,
    'laws' => 1,
    'job' => 1,
    'headland' => 1,
    'bay.' => 3,
    'water' => 4,
    'air,' => 2,
    'boat\'s' => 1,
    'wheel' => 1,
    'rocking' => 1,
    'deck' => 1,
    'eyes' => 1,
    'extra' => 2,
    'globe' => 3,
    'sofa' => 1,
    'wall' => 7,
    'sofa.' => 1,
    'cliff.' => 1,
    'jet,' => 1,
    'light.' => 1,
    'applause' => 1,
    'notion' => 1,
    'spider.' => 1,
    'crowd.' => 3,
    'press' => 1,
    'quotes.' => 1,
    'officials' => 1,
    'party' => 1,
    'deliciously' => 1,
    'switch' => 1,
    'remote' => 1,
    'ground.' => 6,
    'history' => 4,
    'ship' => 11,
    'press.' => 1,
    'newsmen' => 1,
    'bomb' => 1,
    'ground' => 1,
    'game' => 1,
    'sluggish' => 1,
    'planet\'s' => 2,
    'bright' => 1,
    'forces' => 1,
    'grosser' => 1,
    'natural' => 1,
    'crab' => 1,
    'unhappy' => 1,
    'principles' => 1,
    'political' => 1,
    'Great' => 5,
    'ancient' => 1,
    'language' => 1,
    'strict' => 1,
    'Dentrassis' => 2,
    'hardest' => 1,
    'light' => 3,
    'floor.' => 3,
    'things' => 2,
    'obvious,' => 1,
    'darkness.' => 2,
    'spaceships' => 1,
    'word' => 2,
    'Basingstoke' => 1,
    'Thumb\'s' => 1,
    'roundabout\'s' => 1,
    'bug-eyed' => 1,
    'control' => 3,
    'hope' => 1,
    'bridge' => 7,
    'grubby' => 1,
    'cramped' => 1,
    'Dentrassi' => 1,
    'ship,' => 2,
    'cooks,' => 1,
    'mattresses' => 1,
    'book' => 6,
    'cover,' => 1,
    'screen' => 2,
    'index.' => 1,
    'surface.' => 1,
    'screen.' => 3,
    'entry' => 2,
    'Ravenous' => 2,
    'point,' => 1,
    'Dentrassi?' => 1,
    'company,' => 1,
    'marvels' => 2,
    'other' => 13,
    'mattress' => 1,
    'Earth?' => 2,
    'book!' => 1,
    'T\'annoy.' => 1,
    'fish' => 1,
    'aural' => 1,
    'figure' => 1,
    'howling' => 1,
    'semblance' => 1,
    'floor' => 4,
    'jump.' => 1,
    'oddest' => 2,
    'Universe.' => 7,
    'mind' => 1,
    'conscious' => 1,
    'speech' => 1,
    'brain' => 3,
    'brainwave' => 1,
    'final' => 1,
    'non-existence' => 1,
    'next' => 2,
    'central' => 1,
    'kick' => 1,
    'impact' => 1,
    'queue' => 1,
    'supermarket' => 1,
    'actual' => 2,
    'original' => 1,
    'relevant' => 1,
    'screen,' => 1,
    'book\'s' => 1,
    'sounds' => 2,
    'door.' => 3,
    'third' => 4,
    'Azagoths' => 1,
    'Flatulent' => 1,
    'Mid-Galactic' => 1,
    'destruction' => 1,
    'regard' => 1,
    'electrodes' => 1,
    'experience' => 1,
    'poem' => 2,
    'poet\'s' => 2,
    'gobberwarts' => 1,
    'electronic' => 1,
    'vacuum' => 1,
    'smile' => 1,
    'Vogon.' => 1,
    'surrealism' => 2,
    'underlying' => 1,
    'medium' => 1,
    'verse' => 1,
    'coup' => 1,
    'corner' => 6,
    'quality' => 1,
    'bridge.' => 6,
    'captain' => 1,
    'feeble' => 1,
    'guard.' => 3,
    'dog...' => 1,
    'smoking' => 1,
    'Earth!' => 1,
    'culture' => 1,
    'guard' => 3,
    'hours' => 2,
    'murky' => 1,
    'ceiling' => 2,
    'mindless' => 2,
    'guard,' => 5,
    'uniform,' => 1,
    'lowslung' => 1,
    'conclusion' => 1,
    'unpleasant' => 1,
    'rumblings,' => 1,
    'alternative?' => 1,
    'airlock.' => 1,
    'airlock' => 2,
    'hatchway' => 5,
    'reclosing' => 1,
    'faint' => 1,
    'ship\'s' => 9,
    'curved' => 1,
    'curve' => 2,
    'details' => 1,
    'chamber' => 3,
    'tune' => 1,
    'outer' => 1,
    'road' => 3,
    'style' => 2,
    'amount' => 2,
    'lavatory' => 1,
    'sheer' => 2,
    'stars,' => 1,
    'human' => 1,
    'stars.' => 1,
    'way.' => 1,
    'total' => 1,
    'chances' => 2,
    'telephone' => 1,
    'Islington' => 1,
    'faminestruck' => 1,
    'Pansel' => 1,
    'deeply' => 1,
    'empty' => 1,
    'patterns)' => 1,
    'pavement' => 3,
    'Third' => 1,
    'Unknown,' => 1,
    'pit' => 1,
    'five' => 1,
    'elderberry' => 1,
    'sand' => 1,
    'Uncertain' => 1,
    'wind,' => 1,
    'power' => 8,
    'custard?' => 1,
    'measurement' => 1,
    'first-class' => 1,
    'fabric' => 2,
    'sunset...' => 1,
    'voice.' => 3,
    'point!' => 1,
    'distance.' => 1,
    'Starship' => 1,
    'Infinite' => 1,
    'cubicle,' => 1,
    'cracks,' => 1,
    'logic' => 1,
    'ice' => 1,
    'molecules' => 1,
    'hostess\'s' => 1,
    'left,' => 1,
    'Theory' => 1,
    'infinite' => 2,
    'mind-paralysing' => 1,
    'lab' => 1,
    'finite' => 1,
    'size' => 3,
    'angles' => 1,
    'cabin' => 2,
    'designers' => 1,
    'convex' => 1,
    'various' => 1,
    'cabin,' => 1,
    'Tannoy' => 1,
    'run' => 1,
    'trouble' => 1,
    'controls,' => 1,
    'aliens.' => 1,
    'corner,' => 1,
    'robot\'s' => 1,
    'tolling' => 1,
    'lilt' => 1,
    'cabin.' => 2,
    'work' => 1,
    'marketing' => 1,
    'Sirius' => 2,
    'revolution' => 2,
    'editors' => 1,
    'post' => 1,
    'Encyclopaedia' => 1,
    'good' => 3,
    'future' => 1,
    'embarkation' => 1,
    'ship.' => 4,
    'age' => 1,
    'pages' => 1,
    'envy' => 1,
    'years' => 1,
    'vast' => 1,
    'sales' => 2,
    'doorway.' => 1,
    'doors' => 1,
    'knowledge' => 1,
    'concept' => 1,
    'point?' => 2,
    'molecular' => 1,
    'humanoids\'' => 1,
    'surrounding' => 1,
    'hated' => 1,
    'intolerable' => 1,
    'robot,' => 1,
    'sub-etha' => 1,
    'technology' => 1,
    'panels' => 1,
    'general' => 1,
    'components' => 1,
    'channel' => 1,
    'rhythms' => 1,
    'music.' => 1,
    'galaxy' => 1,
    'clock,' => 1,
    'secret' => 1,
    'rocks' => 1,
    'big' => 2,
    'new' => 2,
    'question' => 8,
    'Best' => 1,
    'Wort' => 1,
    'seventh' => 1,
    'pencil.' => 1,
    'Z' => 1,
    'time,' => 2,
    'act.' => 1,
    'visiscreen' => 1,
    'inside' => 3,
    'middle' => 2,
    'Horsehead' => 3,
    'Universe,' => 3,
    'record.' => 1,
    'computer,' => 9,
    'console.' => 3,
    'computer' => 12,
    'Improbability' => 4,
    'buttons' => 1,
    'corridor,' => 2,
    'diodes' => 1,
    'entrance' => 1,
    'aliens' => 1,
    'teeth' => 2,
    'left-hand' => 1,
    'introductions' => 1,
    'fast' => 1,
    'affairs' => 1,
    'lady?' => 1,
    'dole' => 1,
    'relationships' => 1,
    'mice' => 4,
    'void.' => 1,
    'manner' => 1,
    'post.' => 1,
    'attempt' => 1,
    'Guide' => 1,
    'instruments.' => 1,
    'exact' => 1,
    'computer.' => 6,
    'screens.' => 1,
    'consoles' => 1,
    'external' => 1,
    'picture' => 1,
    'deep' => 2,
    'mists' => 1,
    'former' => 2,
    'stakes' => 1,
    'Empire' => 2,
    'climate' => 1,
    'later' => 1,
    'afternoon,' => 1,
    'wrong' => 2,
    'conditions' => 1,
    'exacting' => 1,
    'Galaxy\'s' => 1,
    'richest' => 1,
    'system' => 1,
    'pen' => 1,
    'value' => 1,
    'obscurity' => 1,
    'daylight' => 1,
    'spectacular' => 1,
    'utter' => 1,
    'black' => 2,
    'horizon' => 1,
    'thin' => 3,
    'pitch' => 1,
    'bridge:' => 1,
    'spectacle' => 1,
    'excitement' => 1,
    'scene' => 2,
    'legends' => 1,
    'Magratheans' => 2,
    'screens' => 3,
    'pyrotechnics' => 1,
    'common' => 1,
    'distant' => 1,
    'grey' => 1,
    'surface,' => 1,
    'curiosity,' => 1,
    'fame' => 1,
    'money...' => 1,
    'faintest' => 1,
    'look' => 1,
    'following' => 1,
    'legendary' => 1,
    'bruising' => 1,
    'untimely' => 1,
    'bruise.' => 1,
    'day,' => 1,
    'shellshocked' => 1,
    'Drink' => 1,
    'subject\'s' => 3,
    'neural' => 1,
    'taste' => 1,
    'major' => 2,
    'liquid' => 1,
    'photon' => 1,
    'moment.' => 2,
    'voice,' => 2,
    'address' => 1,
    'tone.' => 1,
    'fanfare' => 2,
    'nervous' => 1,
    'atmosphere' => 3,
    'guided' => 1,
    'missiles?' => 2,
    'shoulder' => 1,
    'distance' => 4,
    'sky.' => 1,
    'image' => 1,
    'warheads,' => 1,
    'controls' => 1,
    'oncoming' => 1,
    'walls' => 2,
    'guidance' => 2,
    'combined' => 1,
    'guide' => 1,
    'deadly' => 1,
    'crew' => 3,
    'bloody' => 1,
    'engines' => 1,
    'missiles' => 1,
    'storm...' => 2,
    'dark!' => 1,
    'erratically' => 1,
    'sweet' => 1,
    'wind...' => 1,
    'rain...' => 1,
    'excitingly' => 1,
    'centre' => 2,
    'illusion' => 1,
    'periphery' => 1,
    'conservatory' => 1,
    'polished' => 1,
    'marble' => 1,
    'correct' => 1,
    'required' => 1,
    'mirrors' => 1,
    'mirrors.' => 1,
    'proofing' => 1,
    'world,' => 2,
    'wind?' => 1,
    'rest,' => 1,
    'bowl' => 2,
    'nature' => 1,
    'universe' => 1,
    'blighted' => 2,
    'Paranoid' => 1,
    'answer.' => 4,
    'second.' => 1,
    'hatch.' => 1,
    'exit' => 1,
    'equivalent' => 1,
    'ramp' => 1,
    'barren' => 1,
    'stale' => 1,
    'thing' => 1,
    'ridge' => 2,
    'thinnish' => 1,
    'wind.' => 1,
    'outside' => 1,
    'crater' => 1,
    'crater\'s' => 1,
    'crater.' => 7,
    'exploded' => 1,
    'slight' => 1,
    'interior' => 1,
    'planet!' => 1,
    'whale\'s' => 1,
    'incline' => 1,
    'crater,' => 2,
    'dusty' => 1,
    'legends,' => 1,
    'live' => 1,
    'passageway.' => 1,
    'dirt' => 1,
    'tile' => 1,
    'London' => 1,
    'tiles' => 1,
    'cheques.' => 1,
    'encephelographic' => 1,
    'tests' => 1,
    'results' => 2,
    'superimposed' => 1,
    'trading' => 1,
    'bastard' => 1,
    'chamber.' => 1,
    'experiences' => 1,
    'biros' => 1,
    'past' => 1,
    'public' => 1,
    'cosmos,' => 1,
    'planets' => 1,
    'biro' => 1,
    'spatial' => 1,
    'mysterious' => 1,
    'robot' => 1,
    'old' => 26,
    'horizon.' => 1,
    'source' => 3,
    'bowels' => 2,
    'ages' => 1,
    'monotony.' => 1,
    'man\'s' => 1,
    'act' => 1,
    'room,' => 4,
    'weather' => 1,
    'economic' => 1,
    'coastlines' => 1,
    'recession' => 1,
    'computers' => 1,
    'economy' => 1,
    'slope' => 1,
    'dark.' => 1,
    'late' => 1,
    'craft' => 2,
    'silent' => 1,
    'instrument' => 1,
    'way?' => 1,
    'night.' => 1,
    'wheel,' => 1,
    'dolphins' => 1,
    '"Star' => 1,
    'message' => 1,
    'fish.' => 1,
    'aircar' => 5,
    'speed' => 1,
    'blackness' => 1,
    'glow' => 1,
    'ground,' => 1,
    'mouth' => 1,
    'tunnel.' => 1,
    'circular' => 1,
    'tunnel' => 1,
    'farther' => 1,
    'eyes,' => 1,
    'willies' => 1,
    'circle' => 1,
    'impression' => 1,
    'immense' => 1,
    'gateway' => 1,
    'shimmering' => 1,
    'imagination' => 1,
    'reach' => 1,
    'aircar,' => 1,
    'mindboggling' => 1,
    'space.' => 1,
    'floating' => 1,
    'many' => 1,
    'patterns' => 1,
    'shapes' => 2,
    'furniture' => 1,
    'purpose' => 1,
    'cheese' => 2,
    'protrusion' => 1,
    'squeaking' => 1,
    'cumulative' => 1,
    'intervening' => 1,
    'constant' => 1,
    'meaning' => 1,
    'existence' => 1,
    'principal' => 1,
    'desk,' => 1,
    'massive' => 1,
    'second' => 6,
    'Milliard' => 1,
    'atoms' => 2,
    'Googleplex' => 1,
    'Seventh' => 1,
    'very' => 2,
    'Magic' => 1,
    'r\'s,' => 1,
    'problem?' => 2,
    'second?' => 2,
    'Pondermatic?' => 1,
    'computer\'s' => 1,
    'question?' => 2,
    'task' => 1,
    'moment:' => 1,
    'coarse' => 1,
    'younger' => 2,
    'throat.' => 1,
    'older' => 2,
    'room' => 4,
    'devil' => 1,
    'programmers.' => 1,
    'problem!' => 2,
    'machines' => 1,
    'eternal' => 1,
    'Quest' => 1,
    'inalienable' => 1,
    'room.' => 3,
    'answer' => 3,
    'programme' => 1,
    'popular' => 1,
    'gravy' => 1,
    'salient' => 1,
    'Answer,' => 1,
    'events' => 1,
    'artificial' => 1,
    'crust' => 1,
    'Tertiary' => 1,
    'Cenozoic' => 1,
    'same.' => 1,
    'mind-numbing' => 1,
    'life-support' => 1,
    'bodies,' => 1,
    'rib' => 2,
    'eye' => 2,
    'worse' => 1,
    'trees,' => 1,
    'odd' => 1,
    'streets' => 1,
    'spirit' => 1,
    'air.' => 3,
    'square' => 2,
    'crowd' => 2,
    'Shadow' => 1,
    'Greatest' => 1,
    'cheer' => 1,
    'Answer!' => 1,
    'ecstatic' => 1,
    'morning' => 1,
    'plain' => 1,
    'large' => 1,
    'solid' => 2,
    'carpet' => 1,
    'desk\'s' => 1,
    'front' => 1,
    'communication' => 1,
    'answer,' => 1,
    'problem,' => 1,
    'Question?' => 1,
    'console,' => 1,
    'part' => 1,
    'recording' => 1,
    'Question' => 1,
    'Ultimate' => 3,
    'tape,' => 1,
    'gas,' => 1,
    'ground?' => 1,
    'horizon,' => 1,
    'gold' => 1,
    'land.' => 2,
    'catalogue' => 1,
    'scenes' => 1,
    'government' => 1,
    'death' => 1,
    'Arcturan' => 1,
    'markets' => 1,
    'Dordellis' => 1,
    'megafreighters' => 1,
    'ride' => 1,
    'shadows.' => 1,
    'launching' => 1,
    'appalling' => 2,
    'program' => 1,
    'sense' => 2,
    'sweaty' => 1,
    'full' => 2,
    'space-time' => 1,
    'conference' => 2,
    'Vl\'hurgs,' => 1,
    'G\'Gugvuntt' => 1,
    'vile' => 1,
    'Vl\'hurg' => 1,
    'offending' => 1,
    'complex' => 1,
    'car' => 1,
    'table!' => 1,
    'table.' => 1,
    'silence' => 1,
    'mice.' => 1,
    'point' => 1,
    'prospect' => 1,
    'screaming' => 1,
    'merest' => 1,
    'woods,' => 1,
    'Answer' => 1,
    'show\'s' => 1,
    'dignity' => 1,
    'pursuit' => 1,
    'money' => 1,
    'exercise,' => 1,
    'finger,' => 1,
    'penultimate' => 1,
    'structure' => 1,
    'table' => 1,
    'difference?' => 1,
    'difference,' => 1,
    'charm' => 1,
    'table,' => 1,
    'arm' => 1,
    'heavy' => 1,
    'medical' => 1,
    'klaxons' => 1,
    'punters\'' => 1,
    'phrase' => 1,
    'head' => 1,
    'right' => 1,
    'wall.' => 2,
    'four' => 2,
    'gangway' => 1,
    'figure.' => 1,
    'loud' => 2,
    'cops' => 1,
    'echoes' => 1,
    'cops.' => 2,
    'cop,' => 2,
    'other:' => 1,
    'end.' => 1,
    'barrage' => 1,
    'wit.' => 1,
    'others.' => 2,
    'thick' => 1,
    'burning' => 1,
    'open.' => 1,
    'space-suited' => 1,
    'sub-etha.' => 1,
    'controls.' => 1,
    'steel' => 1,
    'grip' => 1,
    'direction' => 1,
    'Blagulon' => 2,
    'police' => 1,
    'dust?' => 1,
    'shape' => 1,
    'policecraft.' => 1,
    'place,' => 1,
    'How,' => 1,
    'Restaurant' => 1,
    'End' => 1,
  ),
  'Galaxy' => 
  array (
    'Book' => 1,
    'lies' => 1,
    '-' => 6,
    'also' => 1,
    'sells' => 1,
    'has' => 2,
    'who' => 1,
    'require' => 1,
    '' => 4,
    'was' => 3,
    'traditionally' => 1,
    'actually' => 1,
    'knew' => 1,
    'had' => 2,
    'and' => 1,
    'quietly,' => 1,
    'is' => 2,
    'says' => 1,
    'after' => 1,
    'defines' => 1,
    'as' => 1,
    'smashed' => 1,
    'you' => 1,
    'to' => 1,
    'isn\'t' => 1,
    'just' => 1,
    'where' => 1,
  ),
  'Book' => 
  array (
    1 => 1,
  ),
  1 => 
  array (
    'for' => 1,
    'The' => 1,
  ),
  'for' => 
  array (
    'Jonny' => 1,
    '' => 41,
    'pretty' => 1,
    'this' => 5,
    'saying' => 1,
    'a' => 50,
    'though' => 1,
    'whom' => 1,
    'about' => 1,
    'months' => 1,
    'the' => 27,
    'little' => 1,
    'all' => 5,
    'you.' => 4,
    'any' => 2,
    'their' => 3,
    'flying' => 1,
    'less' => 2,
    'half' => 1,
    'you' => 1,
    'which' => 3,
    'proving' => 1,
    'one' => 3,
    'it,' => 2,
    'Arsenal' => 1,
    'people' => 1,
    'plays' => 1,
    'stuffed' => 1,
    'warmth' => 1,
    'that,' => 1,
    'four' => 1,
    'every' => 1,
    'development' => 1,
    'fifty' => 1,
    'Zaphod' => 1,
    'many' => 1,
    'fraud.' => 1,
    'effect' => 3,
    'fun,' => 1,
    'him,' => 3,
    'him' => 3,
    'them' => 3,
    'and' => 1,
    'planets' => 1,
    'him.' => 2,
    'an' => 1,
    'ever.' => 2,
    'his' => 1,
    'God\'s' => 2,
    'breath.' => 2,
    'them,' => 1,
    'taking' => 1,
    'up' => 1,
    'instance,' => 1,
    'hitch' => 1,
    'no' => 2,
    'it.' => 2,
    'ten' => 1,
    'Hamlet' => 1,
    'Extreme' => 1,
    'soon.' => 1,
    'style,' => 1,
    'good' => 1,
    'measuring' => 1,
    'you,' => 3,
    'breathing,' => 1,
    'news' => 1,
    'being' => 1,
    'wanting' => 1,
    'long' => 1,
    'me.' => 1,
    'making' => 1,
    'species.' => 1,
    'fifteen' => 1,
    'anything' => 1,
    'century' => 1,
    'five' => 2,
    'your' => 1,
    'business.' => 1,
    'landing.' => 1,
    'breath,' => 2,
    'things' => 1,
    'it' => 5,
    'later' => 1,
    'safety,' => 1,
    'sure.' => 1,
    'them.' => 1,
    'Magrathea,' => 1,
    'that' => 1,
    'Presidency' => 1,
    'me' => 1,
    'those' => 1,
    'precisely' => 1,
    'tidbits,' => 1,
    'very...' => 1,
    'effect.' => 1,
    'all.' => 1,
    'Ultimate' => 1,
    'nearly' => 1,
    'wear' => 1,
    'you?' => 1,
    'seven' => 1,
    'another' => 1,
    'President?' => 1,
    'stratosphere' => 1,
    'Norway.' => 1,
    'Arthur' => 1,
    'centuries.' => 1,
    'hours' => 1,
    'several' => 1,
    'is' => 1,
  ),
  'Jonny' => 
  array (
    'Brock' => 1,
  ),
  'Brock' => 
  array (
    'and' => 1,
  ),
  'and' => 
  array (
    'Clare' => 1,
    '' => 223,
    'that' => 5,
    'she' => 2,
    'happy' => 1,
    'no' => 5,
    'the' => 46,
    'until' => 1,
    'Who' => 1,
    'wisdom,' => 1,
    'secondly' => 1,
    'looked' => 10,
    'had' => 5,
    'proportion' => 1,
    'irritable.' => 1,
    'never' => 1,
    'build' => 1,
    'stomped' => 2,
    'another.' => 1,
    'thought.' => 1,
    'lying' => 2,
    'shabby' => 1,
    'worked' => 1,
    'a' => 18,
    'worried' => 1,
    'squelched' => 1,
    'rolling' => 3,
    'it\'s' => 1,
    'what\'s' => 1,
    'for' => 4,
    'C.' => 1,
    'spend' => 1,
    'he' => 14,
    'charged' => 1,
    'closed' => 3,
    'Arthur' => 14,
    'they' => 9,
    'then' => 30,
    'not' => 3,
    'when' => 2,
    'gave' => 5,
    'start' => 1,
    'grin.' => 1,
    'ask' => 3,
    'explain' => 1,
    'get' => 5,
    'threats;' => 1,
    'it' => 15,
    'experimenting' => 1,
    'squinting' => 1,
    'things' => 2,
    'Ford' => 4,
    'stared' => 1,
    'drink.' => 1,
    'I\'ve' => 2,
    'Groom.' => 2,
    'was' => 10,
    'I' => 10,
    'attempt' => 1,
    'Groom' => 1,
    'how' => 3,
    'slightly' => 2,
    'rolled' => 2,
    'lie' => 2,
    'take' => 2,
    'stopped.' => 1,
    'let' => 4,
    'whether' => 1,
    'his' => 6,
    'oozed' => 1,
    'put' => 4,
    'whimpered.' => 1,
    'an' => 2,
    'also' => 1,
    'what' => 4,
    'mystic.' => 1,
    'blinked' => 1,
    'said' => 2,
    'started' => 4,
    'shrugged' => 1,
    'none' => 1,
    'grinned' => 2,
    'nodded' => 1,
    'Jodrell' => 1,
    'would' => 2,
    'matt' => 1,
    'dials' => 1,
    'this' => 3,
    'Spencer.' => 1,
    'of' => 3,
    'relaxed.' => 1,
    'ran' => 3,
    'told' => 2,
    'carbon' => 2,
    'to' => 2,
    'then...' => 1,
    'fell' => 1,
    'leapt' => 1,
    'did' => 2,
    'valleys,' => 1,
    'oceans,' => 1,
    'watched' => 4,
    'rubber' => 1,
    'woken' => 1,
    'squeezed' => 1,
    'demolition' => 1,
    'its' => 2,
    'broadcasted' => 1,
    'flashing' => 1,
    'skipped' => 1,
    'light' => 2,
    'has' => 1,
    'effectively' => 1,
    'spread' => 1,
    'crescent' => 1,
    'curve' => 1,
    'researchers' => 1,
    'there' => 4,
    'between' => 1,
    'beyond' => 1,
    'broken' => 1,
    'seemanship,' => 1,
    'shone' => 1,
    'sank' => 1,
    'dropped' => 1,
    'waved' => 1,
    'six' => 1,
    'third' => 1,
    'bobbing,' => 1,
    'rolled,' => 1,
    'relaxed' => 1,
    'with' => 3,
    'riddled' => 1,
    'attempted' => 1,
    'two' => 2,
    'ridiculously' => 1,
    'her' => 1,
    'smiled' => 1,
    'slowly' => 1,
    'mindboggingly' => 1,
    'widened' => 1,
    'thought' => 2,
    'play' => 1,
    'waterproof' => 1,
    'heaving' => 1,
    'then,' => 2,
    'written' => 1,
    'unfortunate' => 1,
    'colour' => 1,
    'burned' => 1,
    'dewy' => 1,
    'sit' => 1,
    'uncled' => 1,
    'leaped' => 1,
    'took' => 2,
    'groaned' => 1,
    'observation' => 1,
    'decided' => 2,
    'loomed' => 1,
    'hugged' => 1,
    'some' => 2,
    'said,' => 3,
    'found' => 4,
    'turned' => 1,
    'tell' => 1,
    'feel' => 1,
    'give' => 2,
    'unidentifiable' => 1,
    'rummaged' => 1,
    'dried' => 1,
    'characters' => 1,
    'words' => 1,
    'recycled' => 1,
    'one' => 2,
    'frowned' => 1,
    'buzz' => 1,
    'down' => 3,
    'making' => 1,
    'seemed' => 1,
    'have' => 3,
    'recognizable' => 2,
    'offering' => 1,
    'suddenly' => 4,
    'pay' => 1,
    'as' => 3,
    'left' => 4,
    'leech-like,' => 1,
    'probably' => 1,
    'without' => 1,
    'gets' => 1,
    'cultures,' => 1,
    'bloddier' => 1,
    'you' => 5,
    'tried' => 4,
    'resolved' => 1,
    'saw' => 2,
    'civilization,' => 1,
    'throttled' => 1,
    'ready' => 2,
    'cultured' => 1,
    'slid' => 1,
    'simile' => 1,
    'make' => 2,
    'quivered.' => 1,
    'threw' => 1,
    'wouldn\'t' => 2,
    'moaned.' => 1,
    'gaped.' => 1,
    'er...' => 1,
    'come' => 1,
    'throw' => 1,
    'yanked' => 1,
    'mused' => 1,
    'I\'m' => 2,
    'bellowed,' => 1,
    'understand' => 1,
    'art' => 1,
    'non-pushing-people-about' => 1,
    'weight' => 1,
    'flung' => 1,
    'all' => 4,
    'ten' => 2,
    'slumped' => 2,
    'asphyxicate.' => 1,
    'carried' => 2,
    'about' => 2,
    'recompiled' => 1,
    'under' => 1,
    'researchers.' => 1,
    'so' => 4,
    'four' => 1,
    'sixty-seven' => 2,
    'nine' => 2,
    'met' => 1,
    'close' => 1,
    'quite' => 2,
    'party' => 1,
    'drifted' => 1,
    'died,' => 1,
    'thirty-nine' => 1,
    'made' => 1,
    'went' => 9,
    'spewed' => 1,
    'hid' => 1,
    'down?' => 1,
    'span' => 3,
    'licentious' => 1,
    'strings' => 1,
    'falling,' => 2,
    'bending' => 1,
    'falling.' => 2,
    'is' => 1,
    'my' => 1,
    'seventy-six' => 2,
    'we' => 6,
    'in' => 2,
    'turn' => 1,
    'corners' => 1,
    'more' => 2,
    'guidance' => 1,
    'polished' => 1,
    'giggling' => 1,
    'falling...' => 2,
    'continued:' => 1,
    'shrugged.' => 1,
    'everything,' => 1,
    'could' => 1,
    'successful' => 1,
    'bring' => 2,
    'hopeless.' => 1,
    'keep' => 1,
    'timbre' => 1,
    'horror' => 1,
    'lifted' => 1,
    'everything' => 1,
    'lugged' => 1,
    'showed' => 1,
    'pressed' => 1,
    'hopeless' => 1,
    'accompanied' => 1,
    'sunny' => 1,
    'their' => 2,
    'tinkered' => 1,
    'walked' => 3,
    'Marvin' => 1,
    'whirrs.' => 1,
    'trudged' => 1,
    'distinct' => 1,
    'amazement' => 1,
    'hope.' => 1,
    'we\'ll' => 2,
    'glared' => 1,
    'shot' => 1,
    'blinked.' => 1,
    'wanted' => 1,
    'punched' => 1,
    'simultaneously' => 1,
    'snatching' => 1,
    'Trillian' => 2,
    'nicer' => 1,
    'nicer...' => 1,
    'work' => 2,
    'humming' => 1,
    'held' => 1,
    'rust,' => 1,
    'jabbed' => 1,
    'Zaphod.' => 1,
    'says' => 1,
    'trying' => 1,
    'another' => 1,
    'molecules.' => 1,
    'try' => 1,
    'only' => 2,
    'unreal' => 1,
    'running' => 1,
    'figures' => 1,
    'naive' => 1,
    'keyboard.' => 1,
    'show' => 1,
    'reflected' => 1,
    'don\'t' => 1,
    'glorious' => 1,
    'largely' => 1,
    'reward' => 1,
    'small' => 1,
    'thus' => 1,
    'nothing' => 2,
    'within' => 1,
    'Rahm!..' => 1,
    'Rahm!' => 1,
    'asked' => 1,
    'forbidding' => 1,
    'cold' => 1,
    'blur' => 1,
    'nervous' => 1,
    'sudden' => 1,
    'manufactured' => 1,
    'insubstantial.' => 1,
    'prepare' => 1,
    'pointed' => 1,
    'balls' => 1,
    'squirming' => 2,
    'pushed' => 1,
    'finally' => 2,
    'rocketed' => 1,
    'very' => 2,
    'headed' => 3,
    'plunged' => 1,
    'blown...' => 1,
    'light.' => 1,
    'blue.' => 1,
    'next' => 1,
    'mirrors' => 1,
    'astounding' => 1,
    'twenty-eight' => 1,
    'flat' => 1,
    'round,' => 1,
    'even' => 2,
    'concern' => 1,
    'disappeared' => 1,
    'warm,' => 1,
    'reprogram' => 1,
    'considered' => 1,
    'saying' => 1,
    'stepped' => 1,
    'covered' => 1,
    'ears,' => 1,
    'picked' => 2,
    'frowned.' => 1,
    'unexpected' => 1,
    'silent,' => 2,
    'waving' => 1,
    'join' => 1,
    'fifty' => 1,
    'red' => 1,
    'that\'s' => 1,
    'passages,' => 1,
    'entrails.' => 1,
    'guard' => 1,
    'Ford.' => 1,
    'were' => 2,
    'hurried' => 2,
    'look' => 2,
    'electronically' => 1,
    'felt' => 1,
    'contains' => 1,
    'eventually' => 1,
    'superintelligent' => 1,
    'generally' => 1,
    'ninety-seven' => 1,
    'because' => 1,
    'dressed' => 1,
    'distinguished,' => 1,
    'simply' => 1,
    'leaves' => 1,
    'seeing' => 1,
    'continued.' => 1,
    'trudging' => 1,
    'popular' => 1,
    'thanks' => 1,
    'subtle' => 2,
    'slight' => 1,
    'weaving' => 1,
    'at' => 2,
    'regarded' => 1,
    'added,' => 1,
    'uninteresting.' => 1,
    'therefore' => 1,
    'span,' => 1,
    'sheer' => 1,
    'flooded' => 1,
    'revealed' => 1,
    'run' => 1,
    'we\'ve' => 1,
    'women' => 1,
    'know' => 1,
    'solve' => 1,
    'income' => 1,
    'stately' => 1,
    'quietly' => 1,
    'Fook.' => 1,
    'touched' => 1,
    'deep.' => 1,
    'Space' => 1,
    'Fook' => 2,
    'such' => 1,
    'Ingenuity' => 1,
    'Indefatigable?' => 1,
    'Time.' => 1,
    'muttered,' => 1,
    'yet' => 2,
    'see' => 1,
    'glanced' => 1,
    'Other' => 1,
    'actually' => 1,
    'we\'re' => 1,
    'gives' => 1,
    'uncertainty!' => 1,
    'Everything' => 1,
    'who' => 1,
    'slagging' => 1,
    'into' => 1,
    'mice' => 1,
    'things.' => 1,
    'Quarternary' => 1,
    'drawing' => 1,
    'passed' => 1,
    'totally' => 1,
    'Majikthise,' => 1,
    'frantically' => 1,
    'Hopefully' => 1,
    'think' => 1,
    'go' => 2,
    'Everything!' => 2,
    'waited.' => 2,
    'off' => 1,
    'settled' => 2,
    'Everything?' => 2,
    'Everything...' => 1,
    'paused.' => 1,
    'calm.' => 1,
    'wiping' => 1,
    'great' => 1,
    'cracked,' => 1,
    'crumbled' => 1,
    'hard.' => 1,
    'solid.' => 1,
    'knees' => 1,
    'staring' => 1,
    'special' => 1,
    'yelled' => 1,
    'changed,' => 1,
    'green' => 1,
    'silver' => 1,
    'huge.' => 1,
    'didn\'t' => 1,
    'demanded' => 1,
    'mucked' => 1,
    'doubts' => 1,
    'design' => 1,
    'perfunctory' => 1,
    'tired,' => 1,
    'pulled' => 1,
    'stood' => 2,
    'warlike' => 1,
    'Zaphod' => 4,
    'bizarre' => 1,
    'zapping' => 1,
    'being' => 1,
    'lecture' => 1,
    'Everything,' => 1,
    'on' => 1,
    'running,' => 1,
    'Trillian.' => 1,
    'backing' => 1,
    'swung' => 1,
    'about,' => 1,
    'fake' => 1,
    'dangerous?' => 1,
    'spacesuited' => 1,
    'ducked' => 1,
    'humane!' => 1,
    'possibly' => 1,
    'everything!' => 1,
    'noise' => 1,
    'thick' => 1,
    'waited' => 1,
    'thuds.' => 1,
    'continued' => 1,
    'rushed' => 1,
    'unfriendliness.' => 1,
    'where' => 1,
    'shivering,' => 1,
    'explained' => 1,
    'stalked' => 1,
    'matters' => 1,
    'Sophistication,' => 1,
    'Where' => 1,
  ),
  'Clare' => 
  array (
    'Gorst' => 1,
  ),
  'Gorst' => 
  array (
    'and' => 1,
  ),
  '' => 
  array (
    'all' => 42,
    'other' => 14,
    '' => 97,
    'Arlingtonians' => 1,
    'tea,' => 1,
    'a' => 229,
    'of' => 281,
    'the' => 476,
    'planet' => 15,
    'whose' => 5,
    'apedescended' => 1,
    'life' => 5,
    'solutions' => 1,
    'concerned' => 1,
    'and' => 215,
    'most' => 15,
    'they\'d' => 4,
    'made' => 9,
    'big' => 4,
    'And' => 9,
    'some' => 12,
    'said' => 34,
    'have' => 25,
    'man' => 8,
    'had' => 62,
    'would' => 15,
    'be' => 30,
    'to' => 220,
    'nice' => 1,
    'her' => 4,
    'own' => 8,
    'in' => 108,
    'small' => 17,
    'cafe' => 1,
    'good' => 6,
    'about' => 25,
    'ever' => 6,
    'wholly' => 2,
    'remarkable' => 1,
    'book,' => 2,
    'it' => 83,
    'is' => 46,
    'also' => 4,
    'highly' => 3,
    'than' => 13,
    'Fifty' => 1,
    'More' => 2,
    'Things' => 1,
    'do' => 9,
    'Zero' => 1,
    'Gravity,' => 1,
    'more' => 10,
    'Guide' => 2,
    'has' => 8,
    'already' => 4,
    'supplanted' => 1,
    'great' => 4,
    'knowledge' => 1,
    'many' => 4,
    'omissions' => 1,
    'contains' => 1,
    'much' => 7,
    'that' => 91,
    'words' => 3,
    'Don\'t' => 1,
    'story' => 1,
    'its' => 16,
    'these' => 5,
    'consequences' => 1,
    'are' => 15,
    'It' => 20,
    'farmland.' => 1,
    'was' => 105,
    'thirty' => 5,
    'years' => 9,
    'old,' => 1,
    'front' => 4,
    'please' => 2,
    'Arthur' => 21,
    'He' => 30,
    'he' => 73,
    'moved' => 3,
    'out' => 28,
    'as' => 37,
    'himself.' => 2,
    'The' => 36,
    'thing' => 7,
    'used' => 2,
    'ask' => 1,
    'him' => 13,
    'radio' => 1,
    'which' => 28,
    'lot' => 2,
    'interesting' => 4,
    'they' => 41,
    'blearily' => 1,
    'round' => 7,
    'his' => 66,
    'room,' => 1,
    'opened' => 4,
    'slippers,' => 1,
    'stomped' => 2,
    'off' => 11,
    'moment' => 8,
    'through' => 20,
    'bathroom' => 1,
    'window.' => 1,
    'Properly' => 1,
    'search' => 3,
    'bedroom' => 1,
    'get' => 7,
    'over?' => 1,
    'thought.' => 1,
    'Oh' => 3,
    'dear,' => 1,
    'pub.' => 1,
    'remembered' => 1,
    'being' => 5,
    'angry,' => 1,
    'angry' => 2,
    'something' => 7,
    'seemed' => 5,
    'at' => 37,
    'no' => 18,
    'one' => 19,
    'swig' => 1,
    'water.' => 2,
    'council' => 1,
    'looked' => 11,
    'tongue.' => 1,
    '"Yellow,"' => 1,
    'specifically' => 1,
    'enough,' => 2,
    'direct' => 1,
    'male-line' => 1,
    'descendant' => 1,
    'racial' => 1,
    'mixing' => 1,
    'so' => 16,
    'discernible' => 1,
    'Mongoloid' => 1,
    'characteristics,' => 1,
    'worried' => 4,
    'Dent\'s' => 3,
    'win' => 1,
    'you' => 53,
    'know.' => 2,
    'You' => 5,
    'make' => 3,
    'Mr.' => 2,
    'Prosser' => 3,
    'head,' => 1,
    '-' => 162,
    'this' => 27,
    'why\'s' => 1,
    'going' => 14,
    'put' => 3,
    'said.' => 4,
    'It\'s' => 3,
    'point' => 4,
    'A' => 6,
    'very' => 21,
    'directly' => 1,
    'between,' => 1,
    'B' => 1,
    'wish' => 1,
    'D.' => 1,
    'Point' => 1,
    'D' => 1,
    'wasn\'t' => 6,
    'anywhere' => 1,
    'from' => 25,
    'points' => 1,
    'but' => 40,
    'hotly' => 1,
    'weight' => 1,
    'foot' => 2,
    'foot,' => 1,
    'equally' => 4,
    'I' => 56,
    'local' => 2,
    'planning' => 2,
    'them,' => 4,
    'your' => 8,
    'way' => 8,
    'call' => 3,
    'you?' => 1,
    'mean' => 5,
    'like' => 17,
    'actually' => 4,
    'telling' => 1,
    'anybody' => 1,
    'or' => 7,
    'sign' => 1,
    'on' => 53,
    'lay' => 3,
    'cast' => 1,
    'shadow' => 1,
    'over' => 14,
    'go' => 3,
    'away,' => 3,
    'take' => 7,
    'stand' => 1,
    'times' => 3,
    'while' => 2,
    'inexplicable' => 2,
    'terribly' => 2,
    'attractive' => 1,
    'hefty' => 1,
    'spears' => 1,
    'all,' => 3,
    'Prosser,' => 1,
    'stormed' => 2,
    'nervously' => 1,
    'thousand' => 3,
    'hairy' => 1,
    'horsemen' => 1,
    'suspicion' => 1,
    'hard' => 1,
    'blend' => 1,
    'himself' => 4,
    'into' => 38,
    'Earth' => 2,
    'spent' => 1,
    'work' => 4,
    'actor,' => 1,
    'led' => 1,
    'were' => 33,
    'striking' => 1,
    'not' => 22,
    'hair' => 2,
    'wiry' => 1,
    'gingerish' => 1,
    'brushed' => 3,
    'pulled' => 2,
    'backwards' => 2,
    'him,' => 3,
    'eyes' => 9,
    'didn\'t' => 12,
    'blink' => 1,
    'smiled' => 3,
    'an' => 40,
    'eccentric,' => 1,
    'unruly' => 1,
    'boozer' => 1,
    'with' => 60,
    'oddish' => 1,
    'habits.' => 1,
    'For' => 5,
    'got' => 10,
    'thrown' => 2,
    'stare' => 2,
    'doing.' => 1,
    'everyone' => 1,
    'buy' => 1,
    'enormous' => 1,
    'flying' => 1,
    'saucers' => 1,
    'knew' => 7,
    'Betelgeuse.' => 1,
    'trying' => 3,
    'to,' => 1,
    'what' => 26,
    'Ford' => 16,
    'invariably' => 1,
    'fact' => 10,
    'really' => 8,
    'looking' => 6,
    'for' => 39,
    'when' => 14,
    'stared' => 5,
    'space' => 7,
    'livery' => 1,
    'long' => 6,
    'time' => 8,
    'stranded' => 1,
    'anywhere,' => 1,
    'because' => 13,
    'how' => 6,
    'Altairan' => 2,
    'dollars' => 1,
    'Prefect' => 6,
    'roving' => 1,
    'researcher' => 1,
    'adaptors,' => 1,
    'by' => 25,
    'lunchtime' => 1,
    'steady' => 3,
    'routine.' => 1,
    'mud' => 3,
    'making' => 3,
    'occasional' => 1,
    'such' => 5,
    'My' => 1,
    'Know,' => 1,
    'Never' => 1,
    'Looked' => 1,
    'Back' => 1,
    'talk' => 3,
    'various' => 1,
    'I\'ve' => 5,
    'just' => 13,
    'knock' => 1,
    'my' => 9,
    'house' => 3,
    'failed' => 1,
    'Then' => 4,
    'suddenly' => 6,
    'understand?' => 1,
    'shouted' => 2,
    'Arthur.' => 4,
    'pointed' => 1,
    'find' => 4,
    'hyperspace' => 1,
    'ports' => 1,
    'Wrestling,' => 1,
    'glass' => 4,
    'pour' => 1,
    'spirit' => 1,
    'played' => 3,
    'again.' => 7,
    'been' => 15,
    'consumed,' => 1,
    'final' => 1,
    'perform' => 1,
    'forfeit,' => 1,
    'usually' => 2,
    'obscenely' => 1,
    'wicked' => 1,
    'thought' => 9,
    'spokesman' => 1,
    'bulldozer' => 1,
    'Dent' => 2,
    'constituted' => 1,
    'mental' => 3,
    'health' => 2,
    'Ford,' => 6,
    'he\'s' => 4,
    'standing' => 3,
    'around' => 9,
    'day' => 5,
    'doing' => 3,
    'don\'t' => 5,
    'read' => 1,
    'hour.' => 1,
    'How' => 2,
    'yourself' => 2,
    'later' => 4,
    'on,' => 4,
    'kind...' => 1,
    'hold' => 2,
    'could' => 19,
    'myself' => 2,
    'fully' => 3,
    'they?' => 1,
    'Or' => 2,
    'will' => 7,
    'come' => 7,
    'loser' => 1,
    'down' => 15,
    'mud.' => 1,
    'kind' => 2,
    'dream' => 1,
    'sometimes' => 1,
    'folded' => 1,
    'whilst' => 2,
    'hadn\'t' => 3,
    'even' => 10,
    'begun' => 1,
    'back,' => 1,
    'merest' => 1,
    'representative' => 1,
    'approaching' => 1,
    'marshal' => 1,
    'now' => 10,
    'constitute' => 1,
    'smoke,' => 1,
    'stench' => 1,
    'blood.' => 1,
    'This' => 6,
    'always' => 6,
    'able' => 5,
    'water' => 1,
    'behind' => 6,
    'eyelids.' => 1,
    'cock-ups,' => 1,
    'men' => 1,
    'lying' => 2,
    'mud,' => 1,
    'indecipherable' => 1,
    'unidentified' => 1,
    'army' => 1,
    'alcohol.' => 1,
    'alcohol' => 1,
    'colourless' => 1,
    'volatile' => 1,
    'liquid' => 1,
    'formed' => 3,
    'certain' => 2,
    'says' => 1,
    'Galactic' => 9,
    'Gargle' => 2,
    'Blaster' => 1,
    'large' => 7,
    'planets' => 2,
    'best' => 4,
    'Pan' => 3,
    'mixture' => 1,
    '(it' => 1,
    'gas' => 2,
    'bubble' => 1,
    'it,' => 8,
    'Marshes' => 1,
    'silver' => 2,
    'spoon' => 1,
    'float' => 1,
    'measure' => 1,
    'Qualactin' => 2,
    'tooth' => 1,
    'Algolian' => 1,
    'Suntiger.' => 1,
    'Watch' => 1,
    'dissolve,' => 1,
    'better' => 4,
    'Horse' => 1,
    'Groom' => 1,
    'deserve' => 1,
    'sort' => 5,
    'nose' => 1,
    'ignored' => 2,
    'barman,' => 1,
    'them' => 14,
    'understand' => 2,
    'men,' => 2,
    'arrived' => 1,
    'giving' => 3,
    'look' => 4,
    'hell' => 1,
    'somewhere' => 2,
    'Why' => 1,
    'moment,' => 2,
    'rest' => 2,
    'mind' => 8,
    'somethings' => 2,
    'slablike' => 1,
    'somethings,' => 1,
    'huge' => 4,
    'They' => 10,
    'soared' => 1,
    'ease,' => 1,
    'basking' => 1,
    'star' => 2,
    'Sol,' => 1,
    'biding' => 1,
    'their' => 13,
    'time,' => 3,
    'grouping,' => 1,
    'almost' => 8,
    'perfectly' => 5,
    'oblivious' => 1,
    'moment.' => 3,
    'Goonhilly,' => 1,
    'passed' => 3,
    'Cape' => 1,
    'black' => 4,
    'device' => 4,
    'quietly' => 5,
    'itself.' => 1,
    'wore' => 1,
    'Prefect\'s' => 1,
    'satchel' => 1,
    'physicist\'s' => 1,
    'keeping' => 1,
    'scripts' => 1,
    'electronic' => 2,
    'calculator.' => 1,
    'square' => 3,
    'reasons' => 2,
    'why' => 2,
    'Hiker\'s' => 1,
    'sub' => 1,
    'meson' => 1,
    'book' => 3,
    'form,' => 1,
    'hitch' => 5,
    'hiker' => 5,
    'require' => 1,
    'several' => 6,
    'inconveniently' => 2,
    'notepad,' => 1,
    'massively' => 1,
    'useful' => 2,
    'value' => 1,
    'cold' => 3,
    'moons' => 1,
    'marble-sanded' => 1,
    'beaches' => 1,
    'under' => 5,
    'Kakrafoon;' => 1,
    'use' => 2,
    'noxious' => 1,
    'fumes' => 1,
    'gaze' => 1,
    'Ravenous' => 1,
    'Bugblatter' => 1,
    'Beast' => 1,
    'Traal' => 2,
    '(a' => 2,
    'towel' => 1,
    'biscuits,' => 1,
    'flask,' => 1,
    'weather' => 1,
    'gear,' => 1,
    'suit' => 1,
    'dozen' => 1,
    'items' => 1,
    'might' => 3,
    'any' => 7,
    'who' => 10,
    'breadth' => 1,
    'galaxy,' => 2,
    'rough' => 1,
    'slum' => 1,
    'still' => 9,
    'knows' => 1,
    'where' => 5,
    'satchel,' => 1,
    'surface' => 1,
    'fan' => 1,
    'out.' => 3,
    'At' => 4,
    'Jodrell' => 1,
    'surprised,' => 1,
    'sound' => 3,
    'rumbling' => 1,
    'crash' => 1,
    'outside' => 3,
    'pub,' => 1,
    'hiccupping' => 1,
    'knocked' => 2,
    'down,' => 1,
    'broken.' => 1,
    'let' => 2,
    'pub' => 1,
    'half' => 2,
    'barman' => 1,
    'note' => 1,
    'then' => 9,
    'before.' => 1,
    'tiny' => 6,
    'simply' => 1,
    'communicates' => 1,
    'exact' => 1,
    'birth.' => 1,
    'On' => 3,
    'signals' => 2,
    'too' => 5,
    'stress,' => 1,
    'shocking,' => 1,
    'incomprehensible' => 2,
    'having,' => 1,
    'stupid' => 1,
    'me,' => 4,
    'longer,' => 1,
    'then,' => 3,
    'embarrassingly' => 1,
    'girl' => 1,
    'satisfaction' => 1,
    'evaporate' => 1,
    'monoxide.' => 1,
    'However,' => 1,
    'notice' => 2,
    'wind,' => 1,
    'squall' => 1,
    'rain.' => 2,
    'hung,' => 1,
    'drawn' => 1,
    'quartered!' => 1,
    'whipped!' => 1,
    'again!' => 1,
    'yelled' => 2,
    'bulldozers;' => 1,
    'hectically' => 1,
    'sky.' => 1,
    'noticed' => 1,
    'yellow' => 4,
    'jumping' => 1,
    'Arthur,' => 7,
    'think' => 11,
    'anything' => 6,
    'landed' => 1,
    'flat' => 2,
    'on.' => 2,
    'His' => 5,
    'finger' => 5,
    'shot' => 1,
    'monstrous' => 1,
    'yellowness,' => 1,
    'tore' => 2,
    'distance' => 2,
    'ears' => 1,
    'know' => 8,
    'running' => 3,
    'houses,' => 1,
    'All' => 2,
    'each' => 2,
    'wave' => 4,
    'hills' => 1,
    'terrible' => 4,
    'sadness' => 2,
    'ears.' => 2,
    'exactly' => 2,
    'Sens-OMatic' => 1,
    'started' => 2,
    'deciphered' => 1,
    'room' => 3,
    'coldness' => 1,
    'Galaxy' => 8,
    'Earth,' => 3,
    'thought,' => 1,
    'threw' => 3,
    'away' => 8,
    'copy' => 2,
    'ready,' => 1,
    'worse' => 1,
    'air,' => 1,
    'every' => 11,
    'nation' => 1,
    'blasphemy' => 1,
    'tried' => 4,
    'whisper' => 1,
    'open' => 4,
    'sound.' => 1,
    'Every' => 2,
    'hi' => 1,
    'fi' => 1,
    'set' => 3,
    'world,' => 1,
    'radio,' => 1,
    'tweeter,' => 1,
    'car,' => 1,
    'wine' => 1,
    'became' => 6,
    'activated' => 1,
    'acoustically' => 1,
    'address' => 2,
    'system' => 2,
    'music,' => 2,
    'fanfare,' => 1,
    'simple' => 5,
    'Planning' => 1,
    'regrettably' => 1,
    'demolition.' => 1,
    'process' => 3,
    'Earth.' => 1,
    'crowds' => 1,
    'if' => 20,
    'iron' => 1,
    'them.' => 5,
    'Panic' => 1,
    'it\'s' => 5,
    'far' => 6,
    'late' => 1,
    'across' => 6,
    'land.' => 1,
    'underside' => 1,
    'back' => 12,
    'voice' => 7,
    'heaven\'s' => 1,
    'PA,' => 1,
    'apathetic' => 1,
    'bloody' => 2,
    'arm' => 3,
    'Galaxy,' => 4,
    'five' => 8,
    'hundred' => 5,
    'Beeblebrox,' => 2,
    'President' => 6,
    'Damogran,' => 1,
    'totally' => 2,
    'before' => 8,
    'destination' => 1,
    'Damogran' => 4,
    'nothing' => 4,
    'middling' => 1,
    'desert' => 1,
    'remained' => 1,
    'Imperial' => 2,
    'Government' => 1,
    'chose' => 1,
    'between' => 5,
    'whole' => 6,
    '(the' => 1,
    'name' => 3,
    'entirely' => 5,
    'meaningless' => 1,
    'coincidence' => 3,
    'Heart' => 4,
    'Gold' => 4,
    'today,' => 2,
    'marvelling' => 1,
    'first' => 6,
    'decided' => 4,
    'run' => 2,
    'Presidency,' => 1,
    'astonishment' => 1,
    'throughout' => 2,
    'known' => 2,
    'timer,' => 1,
    '(crook?' => 1,
    'quite' => 9,
    'personal' => 1,
    'relationships,' => 1,
    'understood' => 4,
    'principle' => 2,
    'Zaphod' => 11,
    'Beeblebrox' => 1,
    'hereditary' => 1,
    'centuries.' => 1,
    'In' => 4,
    'last' => 5,
    'dead,' => 1,
    'drastic' => 1,
    'political' => 1,
    'upheaval,' => 1,
    'power' => 5,
    'ladder,' => 1,
    'advisers' => 1,
    'elected' => 1,
    'those' => 4,
    'reason' => 1,
    'it.' => 7,
    'successful' => 1,
    'Presidents' => 1,
    'ten' => 2,
    'Presidential' => 2,
    'few' => 6,
    'Most' => 2,
    'realize' => 2,
    'Presidency' => 1,
    'be.' => 1,
    'back.' => 2,
    'steered' => 1,
    'help' => 2,
    'miles' => 4,
    'steep' => 1,
    'physucturalist' => 1,
    'two' => 10,
    'Hooloovoo' => 2,
    'limits' => 1,
    'impossibility,' => 1,
    'orange' => 1,
    'wield' => 1,
    'attract' => 1,
    'sharply,' => 2,
    'boat' => 1,
    'slewed' => 1,
    'wild' => 5,
    'lightly' => 2,
    'robot' => 4,
    'tri-D' => 1,
    'antics' => 1,
    'fair' => 1,
    'tousled' => 1,
    'stuck' => 3,
    'directions,' => 1,
    'blue' => 2,
    'glinted' => 1,
    'completely' => 2,
    'transparent' => 1,
    'globe' => 1,
    'floated' => 1,
    'next' => 2,
    'boat,' => 1,
    'third' => 2,
    'feet' => 3,
    'bubble,' => 2,
    'seethed' => 1,
    'spouted.' => 1,
    'surged' => 1,
    'beneath' => 2,
    'crashing' => 1,
    'sea' => 4,
    'raised' => 2,
    'hands' => 6,
    'original' => 3,
    'Crested' => 2,
    'Eagle' => 1,
    'become' => 2,
    'incorporated' => 1,
    'eagle' => 1,
    'invented.' => 1,
    'Frond' => 1,
    'species' => 1,
    'wanted' => 2,
    'gently' => 1,
    'picked' => 2,
    'up' => 12,
    'slim,' => 1,
    'full' => 3,
    'mouth,' => 1,
    'odd' => 2,
    'scarf' => 1,
    'she' => 7,
    'light' => 8,
    'Damogran.' => 1,
    'One' => 1,
    'control' => 4,
    'itself' => 5,
    'starship,' => 1,
    'fifty' => 1,
    'sleek' => 2,
    'shoe,' => 1,
    'white' => 3,
    'box' => 1,
    'Gold.' => 1,
    'There' => 2,
    'winked' => 1,
    'amazing.' => 1,
    'crowd' => 1,
    'punched' => 2,
    'buttons' => 1,
    'sky,' => 1,
    'pleasant' => 3,
    'sight,' => 1,
    'ill' => 1,
    'ago' => 3,
    'Vogsphere,' => 1,
    'sun' => 1,
    'shone' => 1,
    'never' => 3,
    'thick-willed' => 1,
    'rectify' => 1,
    'forces' => 2,
    'Vogsphere' => 1,
    'forth' => 1,
    'Vogons' => 4,
    'ate,' => 1,
    'smashing' => 1,
    'tall' => 1,
    'aspiring' => 1,
    'trees' => 1,
    'breathtaking' => 1,
    'meat' => 1,
    'transport' => 1,
    'Vogon' => 5,
    'migrated' => 1,
    'Megabrantis' => 1,
    'immensely' => 1,
    'attempted' => 1,
    'social' => 2,
    'grace,' => 1,
    'modern' => 1,
    'little' => 7,
    'different' => 1,
    'forebears.' => 1,
    'year' => 1,
    'import' => 1,
    'twenty-seven' => 1,
    'deep' => 4,
    'intestines' => 1,
    'match' => 2,
    'flared' => 1,
    'nervously.' => 1,
    'only' => 5,
    'pronuncible' => 1,
    'obscure' => 1,
    'since' => 1,
    'Great' => 2,
    'Collapsing' => 1,
    'wiped' => 1,
    'old' => 8,
    'satisfactorily' => 1,
    'clouds' => 1,
    'came' => 3,
    'live' => 1,
    'say' => 4,
    'name,' => 1,
    'father' => 1,
    'parts' => 2,
    'Ix,' => 1,
    'Betelgeuse' => 2,
    'Five' => 1,
    'translates' => 1,
    '"boy' => 1,
    'should' => 6,
    'choose' => 1,
    'cabin' => 3,
    'see' => 11,
    'little;' => 1,
    'strange' => 4,
    'flickering' => 1,
    'flame,' => 1,
    'thank' => 1,
    'Dentrassis.' => 1,
    'bunch' => 1,
    'keep' => 5,
    'themselves' => 4,
    'loved' => 1,
    'money,' => 1,
    'loathed' => 1,
    'saw' => 2,
    'heavy' => 1,
    'floor.' => 1,
    'Quickly' => 1,
    'shook' => 2,
    'out,' => 1,
    'shaking' => 1,
    'packet' => 1,
    'again,' => 4,
    'matter' => 2,
    'transference' => 1,
    'beam' => 2,
    'you\'ve' => 2,
    'salt' => 1,
    'protein.' => 1,
    'beer' => 1,
    'stating' => 1,
    'repeating' => 1,
    'dear' => 1,
    'alright?' => 1,
    'If' => 2,
    'human' => 2,
    'abandoned' => 2,
    'helped' => 1,
    'bits' => 2,
    'me' => 5,
    'weakly,' => 1,
    'usage' => 1,
    'switch.' => 1,
    'throng' => 1,
    'kept' => 1,
    'brain' => 1,
    'head' => 6,
    'hop' => 1,
    'right' => 2,
    'in.' => 2,
    'can' => 11,
    'signalling' => 1,
    'Star' => 1,
    'six' => 5,
    'interior' => 1,
    'green' => 2,
    'body' => 3,
    'bridge.' => 4,
    'felt' => 4,
    'vaguely' => 1,
    'irritable' => 1,
    'after' => 8,
    'demolishing' => 1,
    'flopped' => 1,
    'rather' => 7,
    'relieved.' => 1,
    'report' => 1,
    'wonderful' => 2,
    'unveiled' => 1,
    'henceforth' => 1,
    'shout' => 1,
    'galley' => 1,
    'quarters' => 1,
    'Dentrassis' => 1,
    'lunch' => 1,
    'tray.' => 1,
    'Dentrassi' => 2,
    'mattress' => 1,
    'about,' => 2,
    'mattresses' => 1,
    'grown' => 1,
    'swamps' => 1,
    'helpful' => 1,
    'enter' => 1,
    'so.' => 1,
    'officious' => 1,
    'callous.' => 1,
    'wouldn\'t' => 3,
    'lift' => 1,
    'save' => 1,
    'without' => 3,
    'orders' => 1,
    'subjected' => 1,
    'finally' => 1,
    'buried' => 1,
    'soft' => 3,
    'peat' => 1,
    'irritate' => 1,
    'feed' => 2,
    'sliding' => 1,
    'field' => 2,
    'research' => 3,
    'New' => 1,
    'cooks' => 1,
    'wet' => 1,
    'slap' => 1,
    'else.' => 1,
    'partly' => 3,
    'Which' => 1,
    'you\'re' => 4,
    'impoverished' => 1,
    'longer' => 1,
    'week' => 1,
    'fifteen' => 1,
    'do.' => 1,
    'contact' => 1,
    'enjoying' => 1,
    'isolated' => 1,
    'spot' => 1,
    'poor' => 3,
    'soul' => 2,
    'whom' => 1,
    'Rather' => 1,
    'Galaxy\'s' => 1,
    'of.' => 2,
    'safe' => 1,
    'alongside' => 1,
    'underwear,' => 1,
    'piles' => 1,
    'gargle' => 1,
    'Arthur\'s' => 1,
    'ear,' => 1,
    'second' => 3,
    'picture' => 1,
    'silhouetted' => 1,
    'candlestick.' => 1,
    'piece' => 1,
    'paper' => 1,
    'optician' => 1,
    'slurrp' => 1,
    'uuuurgh' => 1,
    'stop' => 2,
    'our' => 11,
    'aboard.' => 1,
    'Hello' => 1,
    'wherever' => 1,
    'am' => 3,
    'taxi' => 1,
    'sent' => 1,
    'ship.' => 2,
    'journey' => 1,
    'seventy-two' => 1,
    'hour' => 1,
    'time.' => 2,
    'repeat,' => 1,
    'unhappy' => 1,
    'love' => 1,
    'affair,' => 2,
    'daughter' => 1,
    'sex' => 1,
    'appeal' => 1,
    'uncurl' => 1,
    'jump' => 1,
    'hyperspace.' => 2,
    'curled' => 2,
    'absorbs' => 1,
    'unconscious' => 1,
    'frequencies' => 1,
    'centres' => 1,
    'evolved' => 1,
    'purely' => 1,
    'chance' => 2,
    'clinching' => 1,
    'proof' => 2,
    'God,' => 1,
    'denies' => 1,
    'therefore,' => 1,
    'that,' => 4,
    'promptly' => 1,
    'prove' => 1,
    'argument' => 1,
    'load' => 1,
    'Oolon' => 1,
    'Colluphid' => 1,
    'Well' => 1,
    'Babel' => 1,
    'fish,' => 1,
    'effectively' => 2,
    'removing' => 1,
    'discover' => 2,
    'having' => 5,
    'supermarket' => 1,
    'gone,' => 1,
    'everything' => 1,
    'gone.' => 2,
    'outcry.' => 1,
    'From' => 4,
    'couldn\'t' => 3,
    'grasp' => 1,
    'found' => 4,
    'sitting' => 2,
    'corner' => 1,
    'humming' => 1,
    'shaking.' => 1,
    'flashed' => 1,
    'swirled' => 2,
    'bottom' => 2,
    'triple-breasted' => 1,
    'whore' => 1,
    'editor.' => 1,
    'grimly,' => 1,
    'captain' => 1,
    'threat' => 1,
    'poetry' => 2,
    'To' => 2,
    'Small' => 1,
    'Morning"' => 1,
    'four' => 5,
    '"disappointed"' => 1,
    'poem\'s' => 1,
    'twelvebook' => 1,
    'epic' => 1,
    'creator' => 1,
    'Paula' => 1,
    'sequence' => 1,
    'muscle' => 1,
    'early' => 3,
    'attempts' => 3,
    'composition' => 1,
    'part' => 3,
    'bludgeoning' => 1,
    'race,' => 1,
    'battery' => 1,
    'equipment' => 1,
    'imagery' => 1,
    'intensifiers,' => 1,
    'rhythmic' => 2,
    'modulators,' => 1,
    'designed' => 4,
    'heighten' => 1,
    'plurdled' => 1,
    'gabbleblotchits' => 1,
    'thee,' => 1,
    'continued' => 3,
    'merciless' => 1,
    'Vogon,' => 1,
    'line' => 1,
    'present' => 2,
    'choice!' => 1,
    'paused' => 1,
    'melodramatic' => 1,
    'seat' => 1,
    'dusty' => 2,
    'tongue' => 2,
    'obscured' => 1,
    'metaphysical' => 1,
    'bareface' => 1,
    'devices' => 1,
    'too,' => 1,
    'terms' => 3,
    'other,' => 1,
    '(he' => 1,
    'reaching' => 2,
    'left' => 6,
    'profound' => 1,
    'vivid' => 1,
    'Out' => 1,
    'took' => 2,
    'know...' => 1,
    'I\'m' => 8,
    'Take' => 1,
    'prisoners' => 1,
    'number' => 4,
    'we\'re' => 5,
    'him.' => 2,
    'headache!' => 1,
    'headache,' => 1,
    'I\'d' => 3,
    'cross' => 4,
    'both' => 1,
    'firmly' => 1,
    'neck,' => 1,
    'bowing' => 1,
    'underlying' => 1,
    'closed' => 3,
    'Let' => 1,
    'I\'ll' => 1,
    'something.' => 1,
    'talking' => 1,
    'positive' => 1,
    'today.' => 1,
    'afternoon' => 1,
    'gurgled' => 1,
    'snapped' => 1,
    'settled' => 2,
    'till' => 2,
    'slowly' => 4,
    'satisfying' => 1,
    'OK?' => 1,
    'moiled' => 1,
    'mention' => 1,
    'Except...' => 1,
    'shouting' => 2,
    'girls?' => 1,
    'career' => 1,
    'holster,' => 1,
    'half-throttled' => 1,
    'stamping' => 1,
    'around,' => 3,
    'throwing' => 1,
    'people' => 3,
    'blubbery' => 1,
    'clamped' => 1,
    'doesn\'t' => 2,
    'feeble' => 2,
    'course!' => 1,
    'start' => 3,
    'see,' => 5,
    'renewed' => 1,
    'grip' => 1,
    'eventually' => 2,
    'promoted' => 1,
    'Senior' => 1,
    'Shouting' => 1,
    'vacancies' => 1,
    'non-shouting' => 1,
    'skin' => 1,
    'craft.' => 1,
    'guard.' => 1,
    'Bye' => 1,
    'chamber' => 2,
    'bar' => 1,
    'lost.' => 1,
    'hatchway' => 2,
    'hum' => 1,
    'Ford.' => 1,
    'kicked' => 1,
    'hatch' => 1,
    'we' => 14,
    'shoot' => 1,
    'expect' => 2,
    'Betelgeusian' => 1,
    'battle' => 2,
    'minute!' => 1,
    'vision.' => 1,
    'die' => 1,
    'this,' => 2,
    'listened' => 1,
    'Nelson\'s' => 1,
    'Column' => 1,
    'Mostly' => 1,
    'Harmless.' => 1,
    'blackness' => 1,
    'studded' => 1,
    'impossibly' => 1,
    'chemist,' => 1,
    'that\'s' => 1,
    'peanuts' => 1,
    'space.' => 2,
    'need' => 2,
    'know,' => 1,
    'fabulously' => 1,
    'cumulative' => 1,
    'net' => 1,
    'imbalance' => 1,
    'Guide\'s' => 1,
    'walnut' => 1,
    'Johannesburg,' => 1,
    'thousands' => 2,
    'nearest' => 1,
    'stellar' => 1,
    'reach' => 1,
    'years,' => 1,
    'vacuum' => 1,
    'getting' => 2,
    'another' => 3,
    'ship' => 5,
    'telephone' => 2,
    'twenty-nine' => 1,
    'seconds' => 2,
    'airlock' => 1,
    'million' => 4,
    'universe.' => 1,
    'team' => 2,
    'seven' => 2,
    'threefoot-high' => 1,
    'asphyxication,' => 1,
    'land' => 1,
    'hole' => 2,
    'existed' => 1,
    'reverberated' => 1,
    'forwards' => 2,
    'improbable' => 2,
    'fashion.' => 1,
    'past' => 1,
    'seriously' => 2,
    'traumatized' => 1,
    'extraordinarily' => 2,
    'unlikely' => 1,
    'patterns.' => 1,
    'to.' => 1,
    'That' => 2,
    'began' => 4,
    'gulping' => 1,
    'fingerhold' => 1,
    'arched' => 1,
    'sickeningly' => 1,
    'Various' => 1,
    'silently' => 1,
    'by,' => 1,
    'mountain' => 1,
    'goats.' => 1,
    'Primal' => 1,
    'splattering' => 1,
    'space-time' => 1,
    'gobbets' => 1,
    'junket.' => 1,
    'Time' => 2,
    'chances' => 1,
    'against' => 5,
    'eternity' => 1,
    'quivered' => 1,
    'splayed' => 1,
    'considerable' => 1,
    'unease' => 1,
    'horses' => 1,
    'thundered' => 2,
    'fresh' => 2,
    'supplies' => 1,
    'reinforced' => 1,
    'railings' => 1,
    'stays' => 1,
    'buildings' => 2,
    'too.' => 1,
    'fish' => 2,
    'walls' => 2,
    'sound,' => 2,
    'mountains' => 1,
    'archaic' => 1,
    'footling' => 1,
    'bats' => 1,
    'Two' => 1,
    'sounded' => 1,
    'against.' => 1,
    'upended' => 1,
    'assume,' => 1,
    'drifting' => 1,
    'him:' => 1,
    'seventy-five' => 1,
    'What\'s' => 2,
    'falling,' => 1,
    'lolloped' => 1,
    'hear' => 2,
    'effects' => 1,
    'possibly' => 1,
    'level' => 2,
    'restoring' => 1,
    'anyway.' => 1,
    'Thank' => 1,
    'you.' => 3,
    'incredible!' => 1,
    'denied,' => 1,
    'Improbability' => 7,
    'Drive!' => 1,
    'fitting.' => 1,
    'Tiny' => 1,
    'furry' => 2,
    'fingers' => 1,
    'inkstained;' => 1,
    'monkeys' => 2,
    'Drive' => 2,
    'new' => 4,
    'method' => 1,
    'mere' => 1,
    'nothingth' => 1,
    'second,' => 1,
    'lucky' => 4,
    'chance,' => 1,
    'developed' => 1,
    '(say' => 1,
    'tea)' => 1,
    'course' => 2,
    'well' => 2,
    'mostly' => 1,
    'perpetual' => 1,
    'failure' => 1,
    'machine' => 1,
    'generate' => 1,
    'needed' => 1,
    'flip' => 2,
    'spaceship' => 2,
    'cup' => 1,
    'managed' => 2,
    'Infinite' => 1,
    'generator' => 1,
    'plastic' => 2,
    'practical' => 1,
    'miserable.' => 1,
    'As' => 2,
    'panels' => 2,
    'concave' => 1,
    'wall,' => 1,
    'banks' => 3,
    'gleaming' => 2,
    'fairly' => 1,
    'new,' => 1,
    'though' => 3,
    'beautifully' => 2,
    'fitted' => 1,
    'suggested' => 1,
    'said,' => 2,
    'turned' => 4,
    'slight' => 2,
    'smile' => 1,
    'therefore' => 1,
    'space,' => 1,
    'sweet' => 1,
    'Trillian,' => 2,
    'complained' => 2,
    'circumstances?' => 1,
    'police' => 1,
    'OK,' => 2,
    'thinking,' => 1,
    'qualities' => 1,
    'mechanically' => 1,
    'inept' => 1,
    'extravagant' => 1,
    'gesture.' => 1,
    'Trillian' => 6,
    'significance' => 1,
    'unprotected' => 1,
    'problem' => 2,
    'wobbled' => 1,
    'was,' => 1,
    'room.' => 1,
    'bright' => 1,
    'compassionate' => 1,
    'tone,' => 1,
    'here\'s' => 1,
    'exceptionally' => 1,
    'aliens' => 1,
    'here' => 4,
    'offence' => 1,
    'Marvin' => 4,
    'flat-topped' => 1,
    'triangular' => 1,
    'red' => 4,
    'growled' => 1,
    'division' => 4,
    'Sirius' => 5,
    'footnote' => 1,
    'welcome' => 1,
    'applications' => 1,
    'anyone' => 2,
    'defined' => 2,
    'marketing' => 2,
    'Cybernetics' => 4,
    'sunk' => 1,
    'Wow,' => 1,
    'technical' => 1,
    'specs' => 1,
    'ship,' => 2,
    'wander,' => 1,
    'bank,' => 1,
    'button' => 3,
    'nearby' => 1,
    'press' => 1,
    'generation' => 1,
    'computers,' => 1,
    'GPP' => 1,
    'abject' => 1,
    'steel' => 1,
    'Just' => 1,
    'stepping' => 1,
    'mimicked' => 1,
    'indeed' => 1,
    'loathing' => 1,
    'logic' => 1,
    'circuits' => 2,
    'involved' => 1,
    'Further' => 1,
    'amused' => 1,
    'measured' => 1,
    'shut' => 1,
    'robot\'s' => 1,
    'government' => 2,
    'place' => 1,
    'curved' => 1,
    'me.' => 3,
    'happened' => 3,
    'Ford\'s' => 2,
    'face.' => 1,
    'least' => 1,
    'dragging' => 1,
    'anyway' => 1,
    'difficult' => 1,
    'operate.' => 1,
    'radios' => 1,
    'turning' => 1,
    'dials;' => 1,
    'sophisticated' => 1,
    'controls' => 2,
    'fingers;' => 1,
    'infuriatingly' => 1,
    'announcement.' => 1,
    'news' => 1,
    'brought' => 2,
    'sub-etha' => 1,
    'band,' => 1,
    'forms' => 2,
    'everywhere...' => 1,
    'together,' => 1,
    'sensational' => 1,
    'theft' => 1,
    'invented' => 1,
    'Blaster,' => 1,
    'ex-confidence' => 1,
    'trickster,' => 1,
    'once' => 4,
    'described' => 1,
    'Big' => 2,
    'One,' => 1,
    'recently' => 1,
    'Known' => 1,
    'Universe' => 5,
    'music' => 2,
    'dived' => 2,
    'Halfrunt.' => 1,
    'said:' => 1,
    'Vell,' => 1,
    'electric' => 1,
    'radio\'s' => 1,
    'on/off' => 1,
    'sensitive' => 1,
    'want' => 5,
    'major' => 2,
    'difficulties' => 1,
    'experienced' => 1,
    'learning' => 2,
    'distinguish' => 1,
    'hide' => 1,
    'amazingly' => 1,
    'clever' => 2,
    'hence' => 1,
    'We' => 5,
    'zapped' => 1,
    'Corporation' => 2,
    'Shipboard' => 1,
    'Computer' => 1,
    'permeated' => 1,
    'particle' => 1,
    'switched' => 1,
    'brash' => 1,
    'cheery' => 1,
    'selling' => 1,
    'message' => 1,
    'figures' => 2,
    'figures.' => 1,
    'showed' => 2,
    'tow-to-the' => 1,
    '(an' => 1,
    'irrational' => 1,
    'whack' => 1,
    'accounted' => 1,
    'for.' => 1,
    'balance' => 1,
    'sheet' => 1,
    'pencil' => 1,
    'gritted' => 1,
    'probability' => 1,
    'computer' => 15,
    'continued.' => 1,
    'Here\'s' => 1,
    'faces' => 1,
    'Did' => 1,
    'replaced' => 1,
    'corridor.' => 1,
    'Probably' => 1,
    'highest' => 1,
    'shouldn\'t' => 1,
    'towards' => 4,
    'door,' => 1,
    'staring' => 1,
    'shrugging' => 1,
    'shoulders.' => 1,
    'inside' => 3,
    'heard' => 1,
    'astonished' => 1,
    'console' => 1,
    'picking' => 1,
    'hand.' => 1,
    'right-hand' => 1,
    'jaw' => 1,
    'flapped' => 1,
    'appalling' => 1,
    'waving' => 1,
    'lazily' => 1,
    'feeling' => 3,
    'pretty' => 2,
    'pleased' => 1,
    'ugly' => 1,
    'resent' => 1,
    'lumbered' => 1,
    'demanded.' => 1,
    'Martin' => 1,
    'Smith' => 1,
    'haven\'t' => 3,
    'memory' => 2,
    'her.' => 1,
    'though.' => 1,
    'Beautiful,' => 1,
    'foolish.' => 1,
    'called' => 5,
    'Phil,' => 1,
    'planet,' => 1,
    'She' => 2,
    'scrambled' => 1,
    'lift.' => 1,
    'After' => 1,
    'sum' => 1,
    'volition' => 1,
    'curious' => 3,
    'physics' => 1,
    'susceptible' => 1,
    'same' => 2,
    'laws' => 1,
    'grateful' => 1,
    'mice' => 1,
    'reaction' => 1,
    'cage' => 1,
    'treadwheels' => 1,
    'remember' => 1,
    'he\'d' => 2,
    'conform' => 1,
    'pattern' => 1,
    'road' => 1,
    'bit' => 2,
    'faintly' => 1,
    'it?' => 1,
    'art' => 1,
    'form.' => 1,
    'extraordinary' => 1,
    'genius' => 1,
    'robe' => 1,
    'hunched' => 1,
    'excitedly' => 1,
    'flashing' => 1,
    'real' => 2,
    'sociable' => 1,
    'sank.' => 1,
    'Pinpoints' => 1,
    'pairs' => 1,
    'you\'d' => 1,
    'something,' => 1,
    'Zaphod,' => 3,
    'rotate' => 1,
    'angle' => 1,
    'vision' => 1,
    'brightness' => 1,
    'size' => 1,
    'binary' => 1,
    'system.' => 1,
    'glare' => 1,
    'Page' => 1,
    '634784,' => 1,
    'starships' => 1,
    'plied' => 1,
    'exotic' => 1,
    'suns,' => 1,
    'seeking' => 1,
    'dared' => 1,
    'brave' => 1,
    'rich,' => 1,
    'worth' => 2,
    'speaking' => 1,
    'richest' => 1,
    'niggly,' => 1,
    'fault' => 1,
    'worlds' => 1,
    'satisfactory:' => 1,
    'either' => 3,
    'staggering' => 1,
    'form' => 3,
    'hyperspatial' => 1,
    'engineers' => 1,
    'sucked' => 1,
    'gold' => 1,
    'reduced' => 1,
    'night' => 1,
    'smug' => 1,
    'soon' => 1,
    'myth,' => 1,
    'currently' => 1,
    'orbit' => 3,
    'insisted' => 1,
    'tell' => 2,
    'us' => 3,
    'again' => 5,
    'legendary' => 1,
    'personality' => 1,
    'problems' => 2,
    'predicted' => 1,
    'arguing' => 1,
    'anyone,' => 1,
    'screens' => 2,
    'fidgety' => 1,
    'hushed' => 1,
    'us...' => 2,
    'tramp' => 1,
    'can\'t' => 2,
    'light.' => 1,
    'spread' => 1,
    'sideways' => 1,
    'thin' => 1,
    'crescent' => 1,
    'suns' => 2,
    'visible,' => 1,
    'furnaces' => 1,
    'light,' => 1,
    'Fierce' => 1,
    'shafts' => 1,
    'dawn!..' => 1,
    'breathed' => 1,
    'Zaphod.' => 3,
    'twin' => 1,
    'low' => 2,
    'ghostly' => 1,
    'burnt' => 2,
    'believe' => 2,
    'there' => 3,
    'Magrathea' => 2,
    'business' => 2,
    'whispered.' => 1,
    'Apparently' => 1,
    'missing' => 1,
    'grey,' => 1,
    'ravines,' => 1,
    'maybe' => 1,
    'approached' => 1,
    'lines' => 1,
    'planet\'s' => 1,
    'move' => 1,
    'feel' => 1,
    'What' => 3,
    'strong' => 1,
    'impression' => 1,
    'wealth' => 1,
    'afford' => 1,
    'home' => 1,
    'gone' => 2,
    'dust,' => 1,
    'supposing' => 1,
    'vast' => 1,
    'treasures' => 1,
    'revealed' => 1,
    'shortly' => 1,
    'launched' => 1,
    'ancient' => 2,
    'merely' => 2,
    'breakage' => 1,
    'three' => 3,
    'innocent' => 1,
    'preserved,' => 1,
    'concerning' => 1,
    'upper' => 2,
    'sustained' => 1,
    'previous' => 1,
    'provided' => 1,
    'quite,' => 2,
    'pressed' => 1,
    'instant' => 1,
    'detailed' => 1,
    'experimental' => 1,
    'did' => 1,
    'almost,' => 1,
    'unlike' => 1,
    'tea.' => 1,
    'Nutri-Matic' => 1,
    'complaints' => 1,
    'barren' => 1,
    'greyness' => 1,
    'ghosts' => 1,
    'underscored' => 1,
    'afraid' => 3,
    '"OK,' => 1,
    'OK,"' => 1,
    'care' => 1,
    'leave' => 1,
    'contacted,' => 1,
    'kindly' => 1,
    'going.' => 1,
    'Got' => 1,
    'extra' => 1,
    'kick' => 1,
    'fashionable' => 1,
    'magazines' => 1,
    'colour' => 1,
    'we\'d' => 1,
    'we?' => 1,
    'Computer,' => 1,
    'perfunctory,' => 1,
    'distinctly' => 1,
    'enthusiasm' => 1,
    'assure' => 1,
    'special' => 1,
    'courtesy' => 1,
    'detail.' => 1,
    'apply' => 1,
    'us,' => 3,
    'rear' => 1,
    'screen.' => 1,
    'climbing' => 1,
    'magnification' => 1,
    'applying' => 1,
    'missiles' => 1,
    'screen' => 1,
    'evasive' => 1,
    'action' => 1,
    'decisive' => 1,
    'directions' => 1,
    'manual' => 1,
    'consoles' => 1,
    'showering' => 1,
    'crew' => 2,
    'expanded' => 1,
    'cellophane:' => 1,
    'computer,' => 2,
    'impact' => 2,
    'minus' => 1,
    'immediate' => 1,
    'screamed' => 1,
    'simultaneously.' => 1,
    'arc' => 1,
    'headed' => 1,
    'inertial' => 1,
    'held' => 1,
    'struggled' => 1,
    'section' => 2,
    'smuggling' => 1,
    'Antarean' => 1,
    'parakeet' => 1,
    'gland' => 1,
    'cocktail' => 1,
    'delicacy' => 1,
    'idiots' => 1,
    'arm.' => 1,
    'emphasized' => 1,
    'escape' => 1,
    'otherwise' => 1,
    'roar' => 1,
    'flattened' => 1,
    'dive' => 1,
    'din' => 1,
    'yet' => 1,
    'lark...' => 1,
    'Revised' => 1,
    'watching' => 2,
    'thing?' => 1,
    'Without' => 1,
    'proper' => 1,
    'programming' => 1,
    'Drive?' => 1,
    'explosion' => 1,
    'noise' => 1,
    'normally' => 1,
    'fetchingly' => 1,
    'done' => 1,
    'delicate' => 1,
    'flowers' => 1,
    'main' => 1,
    'terminal.' => 1,
    'wide' => 4,
    'stretch' => 1,
    'exquisitely' => 1,
    'manicured' => 1,
    'marble-topped' => 1,
    'vague' => 1,
    'instruments' => 2,
    'materialized' => 1,
    'instantly' => 1,
    'mirrors' => 1,
    'appeared' => 2,
    'clear' => 2,
    'lounging' => 1,
    'spiral' => 1,
    'image' => 1,
    'blighted' => 1,
    'landscape' => 1,
    'changed' => 1,
    'Hey' => 1,
    'kid' => 1,
    'then.' => 1,
    'forgotten' => 1,
    'sensation,' => 1,
    'my...' => 2,
    'shall' => 3,
    'what\'s' => 2,
    'name?' => 1,
    'It\'ll' => 1,
    'do...' => 1,
    'important' => 1,
    'certainly' => 2,
    'This...' => 1,
    'let\'s' => 2,
    'seem' => 3,
    'achieve' => 1,
    'sounding' => 1,
    'no,' => 1,
    'Many' => 1,
    'petunias' => 1,
    'us?' => 1,
    'mirror' => 1,
    'presented' => 1,
    'problems,' => 1,
    'bother' => 1,
    'answer' => 3,
    'instead' => 1,
    '(as' => 1,
    'oddly' => 2,
    'familiar,' => 1,
    'different.' => 1,
    'discovered' => 2,
    'wrapped' => 1,
    'snug' => 1,
    'counting' => 1,
    'humans' => 1,
    'demonstrate' => 1,
    'interrupted' => 1,
    'Eddie.' => 1,
    'wait' => 1,
    'with,' => 1,
    'aggressive' => 1,
    'quietly,' => 1,
    'relationship' => 2,
    'hugged' => 1,
    'warmly' => 1,
    'dullish' => 1,
    'brown,' => 1,
    'less' => 1,
    'thick.' => 1,
    'stalked' => 1,
    'rattled' => 1,
    'fun' => 1,
    'hot' => 1,
    'crossing' => 1,
    'sworn' => 1,
    'caught' => 2,
    'sight' => 1,
    'wide.' => 1,
    'sloping' => 1,
    'ground' => 2,
    'spattered' => 1,
    'wet.' => 1,
    'whale' => 2,
    'force' => 1,
    'go.' => 1,
    'depths' => 1,
    'followed' => 2,
    'unfortunate' => 1,
    'hit' => 2,
    'revealing' => 1,
    'largely' => 1,
    'obstructed' => 1,
    'collapsed' => 1,
    'lived' => 1,
    'peering' => 1,
    'nil' => 1,
    'there\'s' => 1,
    'passage,' => 1,
    'miserable' => 1,
    'whale\'s' => 1,
    'passageway,' => 1,
    'nervous' => 1,
    'hell,' => 1,
    'striding' => 1,
    'purposefully.' => 1,
    'flung' => 1,
    'torch' => 1,
    'touch,' => 1,
    'An' => 2,
    'inhabited' => 1,
    'planet.' => 1,
    'debris' => 1,
    'littered' => 1,
    'Underground,' => 1,
    'mosaics' => 1,
    'stopped' => 1,
    'studied' => 1,
    'sense' => 1,
    'derelict' => 1,
    'guesses.' => 1,
    'quietly.' => 1,
    'reckon' => 1,
    'happens,' => 1,
    'easy.' => 1,
    'keeps' => 1,
    'working' => 1,
    'silence.' => 1,
    'About' => 1,
    'medical' => 2,
    'bay' => 1,
    'plugged' => 2,
    'properly' => 1,
    'ratified.' => 1,
    'inventing' => 1,
    'superimposing' => 1,
    'packed' => 1,
    'filter.' => 1,
    'synapses' => 1,
    'initials' => 1,
    'cauterized' => 1,
    'slammed' => 1,
    'University' => 1,
    'studying' => 1,
    'transformational' => 1,
    'ethics' => 1,
    'harmonic' => 1,
    'theory' => 2,
    'drinking' => 1,
    'bought' => 1,
    'biro' => 1,
    'loss' => 1,
    'galaxy' => 1,
    'along' => 1,
    'uniquely' => 1,
    'lifestyle,' => 1,
    'responding' => 1,
    'biro-oriented' => 1,
    'stimuli,' => 1,
    'until' => 1,
    'Veet' => 1,
    'worked' => 1,
    'driving' => 1,
    'limousine' => 1,
    'family' => 1,
    'cheap' => 1,
    'usual' => 1,
    'fate' => 1,
    'reserved' => 1,
    'coordinates' => 1,
    'account,' => 1,
    'walked' => 2,
    'wildest' => 1,
    'sounds' => 1,
    'sigh,' => 1,
    'rolling' => 1,
    'counted' => 1,
    'circulation' => 1,
    'wall' => 1,
    'moon,' => 1,
    'dark.' => 1,
    'Because' => 1,
    'tallish,' => 1,
    'face' => 2,
    'react' => 1,
    'somewhere,' => 1,
    'stood' => 2,
    'shed' => 1,
    'mind.' => 1,
    'Conversation' => 1,
    'clearly' => 1,
    'sigh.' => 1,
    'Ancient' => 1,
    'beginning' => 1,
    'surprised' => 1,
    'woman\'s' => 1,
    'husband' => 1,
    'idle' => 1,
    'remarks' => 1,
    'expecting' => 1,
    'dead' => 1,
    'man,' => 3,
    'word' => 1,
    'economy' => 1,
    'luxury' => 1,
    'favourite.' => 1,
    'Used' => 1,
    'rebuilt' => 1,
    'voice.' => 1,
    'must' => 2,
    'show' => 2,
    'crater' => 1,
    'tired' => 1,
    'told' => 1,
    'Alright,' => 1,
    'dull' => 1,
    'glow' => 1,
    'dolphins' => 2,
    'conversely,' => 1,
    'impending' => 1,
    'alert' => 1,
    'danger;' => 1,
    'communications' => 1,
    'punch' => 1,
    'footballs' => 1,
    'whistle' => 1,
    'means' => 1,
    'surprisingly' => 1,
    'hoop' => 1,
    'intelligent' => 1,
    'wheels' => 1,
    'conducting' => 1,
    'frighteningly' => 1,
    'man.' => 1,
    'according' => 1,
    'thoughts,' => 1,
    'comfortable' => 1,
    'travelling,' => 1,
    'within' => 1,
    'travelling' => 2,
    'discern' => 1,
    'aircraft' => 1,
    'dipped' => 1,
    'sharply' => 1,
    'collision' => 1,
    'course.' => 1,
    'Their' => 1,
    'draw' => 1,
    'aware' => 2,
    'surround' => 1,
    'twisted' => 1,
    'dwindling' => 1,
    'rapidly' => 1,
    'stationary' => 1,
    'apparently' => 1,
    'tunnel,' => 1,
    'crisscross' => 1,
    'dim' => 1,
    'tricks' => 1,
    'does' => 1,
    'may' => 1,
    'infinity' => 3,
    'fact.' => 1,
    'Infinity' => 1,
    'looks' => 1,
    'speed' => 2,
    'air' => 1,
    'defeated' => 1,
    'top,' => 1,
    'sides' => 1,
    'shock' => 1,
    'vertigo' => 1,
    'finest' => 2,
    'laser' => 1,
    'infinity,' => 1,
    'side,' => 1,
    'speck' => 1,
    'crept' => 1,
    'horror.' => 1,
    'Ranged' => 1,
    'hung' => 1,
    'words,' => 1,
    'we\'ve' => 2,
    'awakened' => 1,
    'pick' => 1,
    'one\'s' => 1,
    'structure' => 2,
    'dark' => 2,
    'images' => 1,
    'rushed' => 1,
    'sensibly' => 1,
    'idea' => 1,
    'abdicated' => 1,
    'responsibility' => 1,
    'control,' => 1,
    'place...' => 1,
    'award' => 2,
    'upset' => 1,
    'much.' => 2,
    'dogs' => 1,
    'cats' => 1,
    'duckbilled' => 1,
    'for,' => 1,
    'completion' => 1,
    'things' => 3,
    'sixties' => 1,
    'sit' => 1,
    'coms' => 1,
    'misunderstanding' => 1,
    'now.' => 1,
    'experiments' => 1,
    'nature' => 1,
    'examined.' => 1,
    'guide' => 1,
    'wrong' => 1,
    'way,' => 1,
    'eating' => 1,
    'Earthman,' => 1,
    'particularly' => 1,
    'beings.' => 1,
    'Your' => 2,
    'matrix' => 1,
    'organic' => 1,
    'tenmillion-year' => 1,
    'millions' => 1,
    'race' => 2,
    'hyperintelligent' => 1,
    'beings' => 2,
    '(whose' => 1,
    'physical' => 1,
    'manifestation' => 1,
    'interrupt' => 1,
    'game' => 1,
    'stupendous' => 1,
    'super' => 1,
    'data' => 1,
    'specially' => 1,
    'executive' => 2,
    'desk' => 1,
    'ultramahagony' => 1,
    'leather.' => 1,
    'carpeting' => 1,
    'discreetly' => 1,
    'pot' => 1,
    'plants' => 1,
    'tastefully' => 1,
    'engraved' => 1,
    'prints' => 1,
    'liberally' => 1,
    'tree-lined' => 1,
    'public' => 1,
    'soberly' => 1,
    'dressed' => 1,
    'programmers' => 1,
    'office.' => 1,
    'entire' => 2,
    'cases' => 1,
    'moments' => 1,
    'sat' => 2,
    'respectful' => 1,
    'silence,' => 1,
    'I,' => 1,
    'Deep' => 4,
    'Thought,' => 2,
    'be,' => 2,
    'greatest' => 2,
    'powerful' => 1,
    'programmers.' => 1,
    'Lunkwill' => 1,
    'Thought' => 1,
    'unconcealed' => 1,
    'Light' => 1,
    'trajectory' => 1,
    'single' => 3,
    'dust' => 1,
    'disputant' => 1,
    'Wrangler' => 1,
    'Ciceronicus' => 1,
    '12,' => 1,
    'Wrangler,' => 1,
    'legs' => 1,
    'persuade' => 1,
    'walk' => 1,
    'magnificent' => 1,
    'ringing' => 1,
    'saying' => 1,
    'thinking' => 1,
    'Multicorticoid' => 1,
    'Perspicutron' => 1,
    'spare' => 1,
    'unit' => 1,
    'cybernetic' => 1,
    'streams' => 1,
    'paused,' => 1,
    '...the' => 1,
    'Universe,' => 1,
    'Everything.' => 1,
    'belts' => 1,
    'Cruxwan' => 1,
    'ineffectual' => 1,
    'flunkies' => 1,
    'elbowing' => 1,
    'out!' => 1,
    'bawled' => 1,
    'younger' => 1,
    'one,' => 1,
    'further' => 2,
    'demand' => 2,
    'desk.' => 1,
    'solid' => 1,
    'fact!' => 1,
    'exclaimed' => 2,
    'Majikthise' => 1,
    'irritation.' => 1,
    'absence' => 1,
    'definitely' => 1,
    'Amalgamated' => 1,
    'Union' => 1,
    'Philosophers,' => 1,
    'Sages,' => 1,
    'off,' => 1,
    'mate,' => 1,
    'Majikthise,' => 1,
    'adding' => 1,
    'up,' => 1,
    'warned' => 1,
    'mate.' => 1,
    'Under' => 1,
    'law' => 1,
    'prerogative' => 1,
    'God' => 1,
    'phone' => 1,
    'rigidly' => 1,
    'agreed' => 1,
    'Majikthise.' => 1,
    'You\'ll' => 1,
    'national' => 1,
    'increased' => 1,
    'ancillary' => 1,
    'mounted' => 1,
    'sedately' => 1,
    'carved' => 1,
    'varnished' => 1,
    'cabinet' => 1,
    'Thought\'s' => 1,
    'Ultimate' => 2,
    'satisfied' => 1,
    'everyone\'s' => 2,
    'attention,' => 1,
    'continuing' => 1,
    'bound' => 1,
    'area' => 1,
    'theories' => 1,
    'capitalize' => 1,
    'media' => 1,
    'market' => 1,
    'yourself?' => 1,
    'So' => 2,
    'life.' => 1,
    'brains' => 1,
    'Sens-O-Tape' => 1,
    'quick' => 2,
    'stroll' => 1,
    'yet,' => 1,
    'Era' => 1,
    'mess,' => 1,
    'results' => 1,
    'diode' => 1,
    'blew' => 1,
    'revive' => 1,
    'cleaning' => 1,
    'staff' => 1,
    'explained' => 1,
    'spacious' => 1,
    'design' => 2,
    'stained' => 1,
    'breeze' => 1,
    'reflect' => 1,
    'building' => 2,
    'known...' => 1,
    'streamers' => 1,
    'wolf' => 1,
    'Does' => 1,
    'really,' => 1,
    'windows' => 1,
    'dais' => 1,
    'speaker' => 1,
    'hardly' => 1,
    'there.' => 1,
    'recorded' => 1,
    'projection' => 1,
    'six-track' => 1,
    'cleaned' => 1,
    'regularly' => 1,
    'edges,' => 1,
    'faded' => 1,
    'now,' => 1,
    'terminal' => 2,
    'man\'s' => 1,
    'neck.' => 1,
    'disappeared' => 1,
    'spoke' => 1,
    'generations' => 1,
    'ago,' => 1,
    'ancestors' => 1,
    'gesture,' => 1,
    'nervously,' => 1,
    'Yes.' => 1,
    'Life,' => 2,
    'lives' => 1,
    'gasping' => 1,
    'silence' => 1,
    'tense' => 1,
    'honest' => 1,
    'suffers' => 1,
    'fools' => 1,
    'Everything...' => 2,
    'offered' => 1,
    'aside' => 2,
    'notebook' => 1,
    'whoever' => 1,
    'regaining' => 1,
    'accustomed' => 1,
    'declamatory' => 1,
    'flickered' => 2,
    'Stop' => 1,
    'bugging' => 1,
    'scanning' => 1,
    'impossible' => 2,
    'gleams' => 1,
    'falling' => 1,
    'prodded' => 1,
    'mark' => 1,
    'shiny,' => 1,
    'peculiar' => 1,
    'yelling' => 1,
    'busy' => 1,
    'platinum.' => 1,
    'Bit' => 1,
    'dull.' => 1,
    'composed' => 1,
    'pebbles' => 1,
    'presumably' => 2,
    'precious' => 1,
    'stones.' => 1,
    'undulating' => 1,
    'peaks.' => 1,
    'mauve' => 1,
    'parasol' => 1,
    'number.' => 1,
    'dropped' => 1,
    'sky' => 1,
    'springtime' => 1,
    'meadow' => 1,
    'detected' => 1,
    'kids' => 1,
    'together' => 1,
    'bulky' => 1,
    'Arcturans' => 1,
    'supply' => 1,
    'science.' => 1,
    'decides' => 1,
    'raid' => 1,
    'one.' => 2,
    'tri-jet' => 1,
    'megafreighter' => 1,
    'how,' => 1,
    'amazing' => 1,
    'guy,' => 1,
    'Yooden' => 1,
    'Vranx,' => 1,
    'incredible' => 1,
    'Into' => 1,
    'maximum' => 1,
    'security' => 1,
    'wing' => 1,
    'gloom.' => 1,
    'Dark' => 1,
    'mists' => 1,
    'elephantine' => 1,
    'shapes' => 1,
    'lurked' => 1,
    'indistinctly' => 1,
    'liked' => 1,
    'this?' => 1,
    'catalogue' => 1,
    'vanished' => 1,
    'glass-top' => 1,
    'tables' => 1,
    'pile' => 1,
    'built' => 1,
    'destroyed' => 1,
    'minutes' => 1,
    'galactic' => 1,
    'unaccountable' => 1,
    'big,' => 1,
    'sinister,' => 1,
    'normal' => 1,
    'paranoia.' => 1,
    'perhaps' => 1,
    'Slartibartfast' => 2,
    'absurdly' => 1,
    'fleeting' => 1,
    'shrug' => 1,
    'tossed' => 1,
    'happen' => 2,
    'lovely' => 1,
    'enough.' => 1,
    'Science' => 1,
    'meet' => 1,
    'mice.' => 1,
    'event' => 1,
    'carelessly.' => 1,
    'Thursday' => 1,
    'lives,' => 1,
    'distant' => 1,
    'brink' => 1,
    'frightful' => 1,
    'commander' => 1,
    'shorts,' => 1,
    'gazed' => 1,
    'cloud' => 1,
    'steam,' => 1,
    'and,' => 1,
    'horribly' => 1,
    'tremendous' => 1,
    'difficulty' => 1,
    'dreadful' => 1,
    'war' => 1,
    'decimated' => 1,
    'mighty' => 1,
    'ships' => 1,
    'empty' => 1,
    'due' => 1,
    'cause' => 1,
    'effect' => 2,
    'Magrathean' => 1,
    'waiting' => 1,
    'perspex' => 1,
    'awards.' => 1,
    'Almost' => 1,
    'immediately,' => 1,
    'side' => 1,
    'decked' => 1,
    'Here,' => 1,
    'glanced' => 2,
    'Trillian.' => 1,
    'Benji' => 3,
    'stroked' => 1,
    'whisky-glass' => 1,
    'tiniest' => 1,
    'Megadonkey?' => 1,
    'slightly' => 1,
    'taken' => 1,
    'mouse.' => 1,
    'longer.' => 1,
    'native' => 1,
    'that!' => 1,
    'skiing' => 1,
    'holiday' => 1,
    'Elegantly' => 1,
    'sculptured' => 1,
    'contours,' => 1,
    'soaring' => 1,
    'pinnacles' => 1,
    'ice,' => 1,
    'Well,' => 1,
    'hope' => 1,
    'lifestyle' => 1,
    'comes' => 2,
    'company' => 1,
    'transports.' => 1,
    'forward' => 1,
    'think,' => 1,
    'manipulated' => 1,
    '5D' => 1,
    'chat' => 1,
    'studio' => 1,
    'research,' => 1,
    'yes' => 1,
    'choice' => 1,
    'configuration' => 1,
    'seen' => 1,
    'vehicle' => 1,
    'first.' => 1,
    'reasonably,' => 1,
    'Where\'s' => 1,
    'tea?' => 1,
    'howled' => 1,
    'pain' => 1,
    'programmed' => 1,
    'chorus,' => 1,
    'stumbled' => 1,
    'blind' => 1,
    'corner,' => 1,
    'utterly' => 1,
    'unable' => 2,
    'cope' => 1,
    'drag' => 1,
    'struggling' => 1,
    'open,' => 1,
    'hypnotized' => 1,
    'airborne' => 1,
    'rodents' => 1,
    'assume' => 1,
    'themselves,' => 1,
    'pretty.' => 1,
    'upon' => 1,
    'Defence' => 1,
    'fragments' => 1,
    'fuss' => 1,
    'pink' => 1,
    'stroking' => 1,
    'multiply' => 1,
    'factual,' => 1,
    'Frankie,' => 1,
    'excellent!' => 1,
    'Sounds' => 1,
    'meaning' => 1,
    'bay.' => 1,
    'others' => 2,
    'fried' => 1,
    'gangway' => 1,
    'gap' => 1,
    'cops' => 2,
    'tight' => 1,
    'well,' => 1,
    'hailer,' => 1,
    'dealing' => 1,
    'dumb' => 1,
    'two-bit' => 1,
    'trigger-pumping' => 1,
    'morons' => 1,
    'conversation,' => 1,
    'couple' => 1,
    'met' => 1,
    'you,' => 1,
    'meeeean' => 1,
    'preferred' => 1,
    'bolt' => 1,
    'quietness' => 1,
    'ad' => 1,
    'intelligent,' => 1,
    'give' => 1,
    'yourselves' => 1,
    'blow' => 1,
    'asked' => 1,
    'peered' => 1,
    'yards' => 2,
    'dimly' => 1,
    'smoke' => 1,
    'reassuringly' => 1,
    'Kill-O-Zap' => 1,
    'gun' => 1,
    'survival' => 1,
    'life-support' => 1,
    'backpack' => 1,
    'Such' => 1,
    'circumstances' => 1,
    'total' => 1,
    'feedback' => 1,
    'prone' => 1,
    'figure,' => 1,
    'look.' => 1,
    'came,' => 1,
    'shared' => 1,
    'whatever' => 1,
    'grabbed' => 1,
    'harmless' => 1,
    'accounting' => 1,
    'nearly' => 1,
    'recognized' => 1,
    'belonging' => 1,
    'infinitely' => 1,
    'variable' => 1,
    'factors' => 1,
    'vary' => 1,
    'tranquility' => 1,
    'equation' => 1,
    'result' => 1,
    'above,' => 1,
    'deposited' => 1,
    'frozen' => 1,
    'bulbous' => 1,
    'sharklike' => 1,
    'smothered' => 1,
    'stencilled' => 1,
    'letters' => 2,
    'informed' => 1,
    'asphyxicated' => 1,
    'smoke-filled' => 1,
    'experience' => 1,
    'bitter' => 1,
    'please,' => 1,
    'hate' => 1,
    'Even' => 1,
    'robots' => 1,
    'resolutely' => 1,
    'facing' => 1,
    'hated' => 1,
    'dejectedly,' => 1,
    'indicating' => 1,
    'talked' => 1,
    'depressed,' => 1,
    'went' => 1,
    'massive' => 1,
    'bed' => 1,
    'finding' => 1,
    'Civilization' => 1,
    'tends' => 1,
    'pass' => 1,
  ),
  'all' => 
  array (
    '' => 38,
    'this' => 5,
    'work' => 1,
    'shouting' => 1,
    'is' => 1,
    'would' => 1,
    'day?' => 1,
    'your' => 1,
    'the' => 22,
    'those' => 1,
    'of' => 4,
    'these' => 3,
    'was' => 2,
    'books' => 1,
    'surprised' => 1,
    'about.' => 1,
    'seemed' => 1,
    'done' => 1,
    'wrong' => 1,
    'hyperspatial' => 1,
    'day.' => 1,
    'welcome.' => 1,
    'planet' => 1,
    'barriers' => 1,
    'it\'s' => 1,
    'perished' => 1,
    'presents' => 1,
    'sound' => 1,
    'that\'s' => 2,
    'that' => 5,
    'now' => 1,
    'things' => 2,
    'officially' => 1,
    'I' => 2,
    'am' => 2,
    'is.' => 1,
    'you' => 1,
    'intelligent' => 1,
    'appeared' => 1,
    'going' => 2,
    'evening.' => 1,
    'there.' => 1,
    'lovingly' => 1,
    'time' => 1,
    'parts' => 1,
    'out' => 1,
    'probability' => 1,
    'end' => 1,
    'vegetation' => 1,
    'she' => 1,
    'hesitated.' => 1,
    'have' => 1,
    'just' => 1,
    'up' => 2,
    'very' => 1,
    'over.' => 2,
    'be' => 1,
    'sorts' => 2,
    'time?' => 1,
    'around' => 1,
    'without' => 1,
    'you\'ve' => 1,
    'cold' => 1,
    'Sens-O-Tape.' => 1,
    'went,' => 1,
    'three' => 1,
    'this?' => 1,
    'my' => 1,
    'fjords' => 1,
    'falls' => 1,
    'its' => 1,
    'it' => 1,
    'find' => 1,
    'about' => 1,
    'melted' => 1,
    'shook' => 1,
  ),
  'other' => 
  array (
    '' => 10,
    'people\'s' => 1,
    'words' => 1,
    'people' => 1,
    'cajoleries' => 1,
    'than' => 3,
    'reason' => 1,
    'Vogons.' => 1,
    'kids' => 1,
    'mattresses.' => 1,
    'bits' => 1,
    'side' => 3,
    'in' => 3,
    'major' => 1,
    'parts' => 1,
    'one.' => 2,
    'and' => 1,
    'way' => 1,
    'end' => 1,
    'lump' => 1,
    'one' => 2,
    'very' => 1,
    'anomalies.' => 1,
    'head.' => 1,
    'robots?' => 1,
    'violently' => 1,
    'man' => 1,
    'two' => 1,
    'illusory' => 1,
    'mouse' => 1,
    'hand' => 1,
    'words,' => 1,
    'cop.' => 2,
    'direction' => 1,
    'three' => 1,
  ),
  'Arlingtonians' => 
  array (
    'for' => 1,
  ),
  'tea,' => 
  array (
    'sympathy,' => 1,
  ),
  'sympathy,' => 
  array (
    'and' => 1,
  ),
  'a' => 
  array (
    'sofa' => 1,
    'small' => 28,
    'distance' => 1,
    'pretty' => 5,
    'problem,' => 1,
    '' => 215,
    'bad' => 1,
    'tree' => 1,
    'change,' => 1,
    'phone' => 1,
    'terribly' => 2,
    'book,' => 1,
    'book' => 1,
    'wholly' => 2,
    'house.' => 1,
    'slight' => 10,
    'broad' => 1,
    'remarkable' => 1,
    'size' => 1,
    'window,' => 1,
    'bulldozer,' => 1,
    'second' => 9,
    'moment' => 11,
    'big' => 7,
    'large' => 7,
    'glint' => 1,
    'new' => 6,
    'bypass,' => 1,
    'leg' => 2,
    'terrible' => 5,
    'carbon-based' => 1,
    'pronounced' => 1,
    'predilection' => 1,
    'great' => 8,
    'nervous' => 2,
    'bit,' => 5,
    'bypass.' => 1,
    'point' => 2,
    'very' => 11,
    'nice' => 5,
    'pleasant' => 2,
    'workman' => 1,
    'couple' => 12,
    'fiver.' => 1,
    'torch.' => 1,
    'locked' => 1,
    'disused' => 1,
    'shadow' => 1,
    'particularly' => 2,
    'curious' => 1,
    'bit' => 10,
    'harmless' => 1,
    'moment,' => 7,
    'wicked' => 1,
    'corner' => 4,
    'flying' => 2,
    'day.' => 4,
    'good' => 10,
    'few' => 26,
    'rabbit' => 1,
    'car.' => 1,
    'table,' => 1,
    'bottle' => 1,
    'predetermined' => 1,
    'lot' => 20,
    'reassuring' => 1,
    'quick' => 5,
    'weight' => 1,
    'dream.' => 1,
    'high' => 1,
    'pair' => 1,
    'drink.' => 1,
    'Pan' => 1,
    'slice' => 1,
    'dignified' => 1,
    'chance?' => 1,
    'swift' => 1,
    'stupid' => 1,
    'five-pound' => 1,
    'fiver?' => 1,
    'bit.' => 3,
    'page' => 2,
    'sudden?' => 1,
    'so-so' => 1,
    'pull' => 1,
    'blip,' => 1,
    'pity' => 1,
    'Sub-Etha' => 1,
    'leather' => 1,
    'short' => 2,
    'largish' => 2,
    'hundred' => 4,
    'screen' => 1,
    'million' => 1,
    'moment\'s' => 4,
    'micro' => 1,
    'mini' => 1,
    'bush,' => 1,
    'distress' => 1,
    'towel' => 2,
    'strag' => 1,
    'toothbrush,' => 1,
    'man' => 7,
    'phrase' => 1,
    'frood' => 1,
    'nearly' => 1,
    'momentary' => 1,
    'paper' => 2,
    'friendly' => 1,
    'wave,' => 1,
    'minute' => 1,
    'half' => 6,
    'whiff' => 2,
    'bang' => 1,
    'tidal' => 1,
    'start.' => 1,
    'while' => 8,
    'sudden' => 6,
    'voice' => 6,
    'brave' => 1,
    'hyperspatial' => 1,
    'sheet' => 1,
    'magnet' => 1,
    'fuss' => 1,
    'hatchway' => 1,
    'radio' => 1,
    'wavelength' => 1,
    'message' => 1,
    'deserted' => 1,
    'decision' => 1,
    'clinching' => 1,
    'fait' => 1,
    'statis' => 1,
    'state' => 1,
    'rung' => 1,
    'body' => 2,
    'figurehead' => 1,
    'controversial' => 1,
    'computer.' => 1,
    'wild' => 3,
    'wonderful' => 1,
    'real' => 1,
    'song' => 1,
    'dog' => 1,
    'means' => 1,
    'huge' => 6,
    'reception' => 1,
    'super-intelligent' => 1,
    'free' => 1,
    'mood' => 2,
    'hazy' => 1,
    'bigger' => 1,
    'close' => 1,
    'wide' => 2,
    'thoroughly' => 1,
    'railed' => 1,
    'halt.' => 1,
    'copy' => 2,
    'newly' => 2,
    'gird' => 1,
    'planet,' => 1,
    'nose' => 1,
    'quote.' => 1,
    'device' => 2,
    'thousand' => 3,
    'happy' => 1,
    'fairly' => 3,
    'Vogon,' => 1,
    'Hrung' => 2,
    'terminal' => 1,
    'silent' => 1,
    'Dentrassi' => 1,
    'thirty-foot' => 1,
    'theory' => 1,
    'military' => 1,
    'low' => 2,
    'lift,' => 1,
    'complaining' => 1,
    'young' => 2,
    'government' => 1,
    'maniac.' => 1,
    'working' => 1,
    'look' => 4,
    'two-week-dead' => 1,
    'still' => 1,
    'lift' => 3,
    'Vogon:' => 1,
    'drink' => 1,
    'Vogon' => 4,
    'strange' => 3,
    'teaser.' => 1,
    'silly' => 1,
    'fun' => 1,
    'violent' => 1,
    'pack' => 1,
    'lightning' => 1,
    'picture' => 1,
    'white' => 1,
    'load' => 1,
    'road' => 1,
    'glass' => 1,
    'Babel' => 2,
    'foetal' => 1,
    'telepathic' => 1,
    'bizarrely' => 1,
    'dead' => 2,
    'puff' => 1,
    'complete' => 2,
    'nasty' => 2,
    'McDonald\'s' => 1,
    'researcher' => 1,
    'limited' => 1,
    'slightly' => 1,
    'sharp' => 1,
    'recitation' => 1,
    'reading' => 1,
    'desperate' => 1,
    'little' => 7,
    'properly' => 1,
    'single' => 4,
    'fetid' => 1,
    'lurgid' => 1,
    'horrible' => 1,
    'surprised' => 1,
    'home' => 1,
    'triumphant' => 1,
    'cat' => 2,
    'book.' => 1,
    'grim' => 1,
    'positive' => 1,
    'rest,' => 1,
    'minute,' => 2,
    'control' => 2,
    'whole' => 2,
    'brightly' => 2,
    'lungful' => 2,
    'deafening' => 1,
    'toy' => 1,
    'year' => 1,
    'receipt.)' => 1,
    'peanut' => 1,
    'totally' => 1,
    'gatecrasher.' => 1,
    'nothingth' => 2,
    'pavement.' => 1,
    'passing' => 2,
    'run' => 1,
    'girl\'s' => 1,
    'sensible' => 1,
    'beam' => 1,
    'source' => 1,
    'measurement' => 1,
    'dustbowl...' => 1,
    'penguin.' => 1,
    'furious' => 1,
    'stewardess' => 1,
    'perfectly' => 3,
    'ship' => 3,
    'governable' => 1,
    'Bambleweeny' => 1,
    'strong' => 1,
    'debasement' => 1,
    'machine' => 2,
    'student' => 1,
    'virtual' => 1,
    'finite' => 1,
    'rampaging' => 1,
    'smartass.' => 1,
    'smallish' => 1,
    'robot' => 3,
    'clump' => 1,
    'heroic' => 1,
    'seat.' => 1,
    'microsecond' => 1,
    'finely' => 1,
    'satisfied' => 2,
    'click' => 1,
    'mechanical' => 1,
    'man.' => 2,
    'time' => 1,
    'better' => 2,
    'cheerful' => 1,
    'job' => 2,
    'planet' => 8,
    'personality' => 1,
    'jumbled' => 1,
    'hand' => 1,
    'background' => 1,
    'news' => 2,
    'voice,' => 1,
    'moment.' => 4,
    'screenful' => 1,
    'moment?' => 1,
    'star' => 3,
    'piece' => 1,
    'waste' => 1,
    'pencil' => 1,
    'hurt' => 1,
    'constant' => 1,
    'conventional' => 1,
    'hand.' => 1,
    'sliding' => 1,
    'hunter' => 1,
    'simple' => 1,
    'chair' => 2,
    'broad,' => 1,
    'loose' => 1,
    'while.' => 2,
    'lazy' => 1,
    'friend' => 1,
    'gum' => 1,
    'party,' => 2,
    'tight-lipped' => 1,
    'guilty' => 1,
    'fancy' => 1,
    'girl...' => 1,
    'different' => 1,
    'ton' => 1,
    'degree' => 1,
    'couch' => 1,
    'vague' => 1,
    'reason' => 2,
    'mixture' => 1,
    'tap' => 1,
    'walk' => 1,
    'noise' => 2,
    'series' => 2,
    'screen.' => 1,
    'clue.' => 1,
    'blank' => 1,
    'dark' => 3,
    'dust' => 1,
    'vast' => 2,
    'long' => 4,
    'billion' => 1,
    'planned' => 1,
    'word' => 2,
    'fairy' => 1,
    'bundle' => 1,
    'view' => 1,
    'sense' => 2,
    'sunrise' => 1,
    'binary' => 1,
    'garden' => 1,
    'crypt.' => 1,
    'presence.' => 1,
    'micecage,' => 1,
    'bowl' => 2,
    'Nutri-Matic' => 1,
    'plastic' => 1,
    'liquid' => 1,
    'spectroscopic' => 1,
    'cupful' => 1,
    'question' => 1,
    'distant' => 1,
    'hollow,' => 1,
    'recorded' => 2,
    'recording,' => 1,
    'sharper' => 1,
    'descent' => 1,
    'direct' => 1,
    'matter' => 1,
    'tight' => 1,
    'savage' => 1,
    'revolting' => 1,
    'stone.' => 1,
    'subtle' => 1,
    'golden' => 1,
    'screeching' => 1,
    'mid-mangling' => 1,
    'spiral' => 1,
    'spray' => 1,
    'stone' => 1,
    'conservatory' => 1,
    'wickerwork' => 1,
    'potted' => 1,
    'nicely' => 1,
    'sperm' => 1,
    'naturally' => 1,
    'whale,' => 1,
    'whale' => 2,
    'grip' => 1,
    'sort' => 3,
    'hell' => 2,
    'tail' => 1,
    'panoramic' => 1,
    'manically' => 3,
    'headache' => 1,
    'matriarchal' => 1,
    'slide' => 1,
    'bulkhead' => 1,
    'computer,' => 1,
    'command' => 1,
    'dried-out' => 1,
    'layer' => 1,
    'mounting' => 1,
    'dump' => 2,
    'castaway?' => 1,
    'cold' => 2,
    'crater' => 1,
    'piece.' => 1,
    'lonely' => 1,
    'way' => 4,
    'network' => 1,
    'start' => 1,
    'torch' => 1,
    'huff,' => 1,
    'doorway' => 1,
    'look.' => 3,
    'possibility' => 1,
    'mind' => 1,
    'lot.' => 1,
    'Galacticredit' => 1,
    'green' => 1,
    'kid?' => 1,
    'pilot' => 1,
    'steel' => 1,
    'quiet' => 2,
    'brilliant' => 1,
    'night' => 1,
    'quaint' => 1,
    'world' => 1,
    'fool' => 1,
    'solitary' => 1,
    'beautiful' => 1,
    'dim' => 1,
    'kind' => 2,
    'wistful' => 1,
    'regular' => 1,
    'thin' => 1,
    'robot,' => 1,
    'note' => 2,
    'double-backwardssomersault' => 1,
    'tiny' => 3,
    'colossal' => 1,
    'tunnel' => 1,
    'length' => 1,
    'gentle' => 1,
    'gateway' => 2,
    'button' => 1,
    'hollow' => 2,
    'sphere' => 1,
    'sublimal' => 1,
    'flash' => 1,
    'pause.' => 1,
    'quite' => 2,
    'front.' => 1,
    'sympathetic' => 1,
    'second,' => 1,
    'maze' => 1,
    'pause' => 1,
    'millisecond?' => 1,
    'greater' => 1,
    'five-week' => 1,
    'more' => 1,
    'significant' => 1,
    'junior' => 1,
    'demand,' => 1,
    'total' => 2,
    'warning' => 1,
    'stentorian' => 1,
    'programme' => 1,
    'lifestyle' => 1,
    'public' => 1,
    'stegosaurus.' => 1,
    'stegosaurus,' => 1,
    'bird' => 1,
    'fresh' => 1,
    'band' => 1,
    'Tannoy.' => 1,
    'cocked' => 1,
    'recording' => 1,
    'businesslike' => 1,
    'preparation' => 1,
    'tough' => 1,
    'dramatic' => 1,
    'computer' => 2,
    'dull' => 1,
    'double' => 1,
    'catalogue.' => 1,
    'huff.' => 1,
    'solid' => 1,
    'frilly' => 1,
    'gas.' => 1,
    'mere' => 1,
    'mad' => 1,
    'year\'s' => 1,
    'cool' => 1,
    'paying' => 1,
    'room' => 1,
    'result' => 1,
    'talker.' => 1,
    'rat.' => 1,
    'plush' => 1,
    'pile,' => 1,
    'pile' => 1,
    'model' => 1,
    'major' => 1,
    'continent.' => 1,
    'freak' => 1,
    'ghastly' => 1,
    'joint' => 1,
    'doorway.' => 1,
    'light' => 1,
    'boneful' => 1,
    'rather' => 1,
    'lump' => 1,
    'bowl,' => 1,
    'touch' => 1,
    'brief' => 1,
    'toast,' => 1,
    'shot.' => 1,
    'product' => 1,
    'bunch' => 1,
    'last' => 1,
    'deal.' => 1,
    'deal,' => 1,
    'question,' => 1,
    'thought.' => 1,
    'little.' => 1,
    'scampering' => 1,
    'mile' => 1,
    'corridor' => 1,
    'Kill-O-Zap' => 1,
    'loud' => 1,
    'crouch.' => 1,
    'guess' => 1,
    'heavily' => 1,
    'vicious' => 1,
    'head' => 1,
    'dangerous' => 1,
    'cop!' => 1,
    'cop.' => 1,
    'bit?' => 1,
    'shrug.' => 1,
    'trap.' => 1,
    'crumpled' => 1,
    'methane-breathing' => 1,
    'system' => 1,
    'velocity' => 1,
    'reasonable' => 1,
    'fixed' => 1,
    'bleached' => 1,
    'muffled' => 1,
  ),
  'sofa' => 
  array (
    'Far' => 1,
    'upholstered' => 1,
    'stayed' => 1,
  ),
  'Far' => 
  array (
    'out' => 1,
    'away' => 1,
    'back' => 1,
  ),
  'out' => 
  array (
    'in' => 3,
    '' => 31,
    'about.' => 1,
    'of' => 48,
    'where' => 1,
    'the' => 3,
    'this' => 1,
    'inexplicable' => 1,
    'by' => 1,
    'into' => 3,
    'to' => 4,
    'onto' => 2,
    'from' => 3,
    'Trillian' => 1,
    'a' => 4,
    'our' => 1,
    'and' => 3,
    'cold' => 1,
    'on' => 3,
    'exactly' => 1,
    'before' => 1,
    'there,' => 1,
    'its' => 1,
    'for' => 1,
    'there.' => 1,
    'more' => 1,
    'you' => 1,
    'at' => 1,
    'had' => 1,
    'upside' => 1,
    'what' => 2,
    'better.' => 1,
    'yet,' => 1,
    'how' => 2,
    'upon' => 1,
    'their' => 1,
    'across' => 1,
    'amongst' => 1,
    'with' => 1,
    'here!' => 1,
    'Ford.' => 1,
    'something' => 1,
  ),
  'in' => 
  array (
    'the' => 129,
    'coming' => 1,
    '' => 96,
    'Rickmansworth' => 1,
    'fact' => 14,
    'two' => 1,
    'large' => 3,
    'any' => 5,
    'it' => 2,
    'local' => 2,
    'advertising.' => 1,
    'his' => 21,
    'search' => 1,
    'front' => 14,
    'Mr.' => 1,
    'particular,' => 3,
    'a' => 56,
    'slurred' => 1,
    'its' => 3,
    'that' => 5,
    'return.' => 1,
    'existence' => 1,
    'memory' => 2,
    'heavily.' => 1,
    'case' => 1,
    'to' => 5,
    'myself' => 1,
    'fact,' => 2,
    'electromagnetic' => 1,
    'normal' => 1,
    'Ford' => 2,
    'hand-tohand-combat;' => 1,
    'emergencies' => 1,
    'possession' => 1,
    '-' => 1,
    'irritation.' => 1,
    'less' => 1,
    'all' => 9,
    'sound' => 1,
    'acting' => 1,
    'your' => 5,
    'Galacticspeke,' => 1,
    'no' => 1,
    'particular' => 1,
    'prison' => 1,
    'their' => 5,
    'wide' => 1,
    'for' => 1,
    'appearance' => 1,
    'random' => 1,
    'glorious' => 1,
    'greeting.' => 1,
    'major' => 1,
    'disgust' => 1,
    'most' => 1,
    'deep' => 2,
    'some' => 3,
    'space,' => 1,
    'It\'s' => 1,
    'favour' => 1,
    'green' => 1,
    'triplicate,' => 1,
    'it.' => 1,
    'terror' => 1,
    'dock' => 1,
    'my' => 2,
    'this' => 4,
    'on' => 1,
    'trouble.' => 1,
    'trouble!' => 1,
    'Poetry' => 1,
    'for,' => 1,
    'considerable' => 3,
    'with' => 1,
    'an' => 6,
    'friendly' => 1,
    'you?' => 1,
    'diameter' => 1,
    'reading' => 1,
    'alarm' => 2,
    'vicious' => 1,
    'lewd' => 1,
    'unusual' => 1,
    'Ford\'s' => 1,
    'avian' => 1,
    'hyperspace.' => 1,
    'accordance' => 1,
    'trying' => 2,
    'order' => 4,
    'excitingly' => 1,
    'annoyance:' => 1,
    'open' => 1,
    'Improbability' => 3,
    'taking' => 1,
    'saying,' => 1,
    'boredom.' => 1,
    'mid' => 1,
    'finding' => 1,
    'sector' => 1,
    'irritation' => 1,
    'Marvin\'s' => 1,
    'would' => 1,
    'nervously' => 1,
    'much' => 1,
    'Peking.' => 1,
    'briefly,' => 1,
    'smoke' => 1,
    'Maths' => 1,
    'astrophysics' => 1,
    'they' => 1,
    'asking' => 1,
    'life' => 1,
    'four' => 1,
    'astonishment.' => 3,
    'space' => 2,
    'but' => 1,
    'silence,' => 1,
    'advance.' => 1,
    'question' => 1,
    'contemporary' => 1,
    'future' => 1,
    'manic' => 1,
    'flattening' => 1,
    'Eddie,' => 1,
    'life?' => 2,
    'what' => 2,
    'through' => 1,
    'puzzlement.' => 1,
    'tears,' => 1,
    'response' => 1,
    'evidence.' => 1,
    'horror.' => 2,
    'where' => 1,
    'there.' => 1,
    'dark' => 1,
    'bright' => 1,
    'surprise.' => 2,
    'horror' => 1,
    'silence' => 1,
    'public.' => 1,
    'fact.' => 1,
    'fjords...' => 1,
    'embarrassment.' => 1,
    'behavioural' => 2,
    'conversation' => 1,
    'size' => 1,
    'terror.' => 1,
    'stark' => 1,
    'stunned' => 1,
    'awkward' => 1,
    'total' => 1,
    'uncomfortable' => 1,
    'chorus.' => 2,
    'general.' => 1,
    'mid-air' => 1,
    'sparkling' => 1,
    'thin' => 1,
    'motion,' => 1,
    'vain.' => 1,
    'despair.' => 1,
    'quite' => 1,
    'fish.' => 1,
    'one' => 1,
    'such' => 1,
    'agreement.' => 1,
    'astonishment' => 1,
    'that?' => 1,
    'time' => 1,
    'Benji.' => 1,
    'our' => 1,
    'section' => 1,
    'thought,' => 1,
    'behind' => 1,
    'seedy' => 1,
    'excess' => 1,
    'colour' => 1,
    'sudden' => 1,
  ),
  'uncharted' => 
  array (
    'backwaters' => 1,
  ),
  'backwaters' => 
  array (
    'of' => 1,
  ),
  'of' => 
  array (
    'the' => 232,
    '' => 244,
    'roughly' => 1,
    'these' => 5,
    'small' => 1,
    'paper,' => 1,
    'paper' => 3,
    'them' => 14,
    'that' => 9,
    'its' => 7,
    'a' => 45,
    'by' => 1,
    'Ursa' => 2,
    'which' => 6,
    'philosophical' => 1,
    'God\'s' => 1,
    'this' => 8,
    'how' => 2,
    'West' => 1,
    'brick,' => 1,
    'London' => 1,
    'his' => 29,
    'something' => 3,
    'water,' => 1,
    'glazed' => 1,
    'Genghis' => 1,
    'it,' => 3,
    'point' => 2,
    'time' => 8,
    'course' => 13,
    'course.' => 5,
    'windows' => 1,
    'Arthur' => 2,
    'Betelgeuse' => 2,
    'any' => 3,
    'flying' => 2,
    'drinks.' => 1,
    'Arthur\'s' => 3,
    'Progress' => 1,
    'because' => 2,
    'an' => 8,
    'Orion' => 1,
    'each' => 2,
    'them.' => 5,
    'Janx' => 2,
    'sense.' => 1,
    'voice,' => 1,
    'Mr.' => 1,
    'crossing' => 2,
    'noise,' => 1,
    'horsemen' => 1,
    'dingo\'s' => 2,
    'sugars' => 1,
    'lemon' => 1,
    'water' => 3,
    'Santraginus' => 2,
    'Arcturan' => 1,
    'Fallian' => 1,
    'all' => 10,
    'pleasure' => 1,
    'Fallia.' => 1,
    'bitter,' => 1,
    'treatment,' => 1,
    'mental' => 1,
    'it' => 15,
    'Betelgeuse?' => 1,
    'way.' => 1,
    'beer.' => 1,
    'thing' => 5,
    'Thursdays.' => 1,
    'dog-eared' => 1,
    'flat' => 1,
    'towels.' => 1,
    'Jaglan' => 1,
    'string,' => 1,
    'tea.' => 1,
    'peanuts.' => 1,
    'great' => 1,
    'Betelgeuse.' => 1,
    'distance.' => 1,
    'respect,' => 1,
    'silencing' => 1,
    'hydrogen,' => 2,
    'sense' => 1,
    'houses,' => 1,
    'night' => 1,
    'Joseph' => 1,
    'Godspell:' => 1,
    'rusty' => 1,
    'Earth,' => 1,
    'those' => 4,
    'your' => 6,
    'board' => 1,
    'Gold.' => 5,
    'ocean.' => 1,
    'Gold' => 12,
    'work' => 1,
    'pretty' => 1,
    'culmination' => 2,
    'unveiling,' => 1,
    'speed.' => 2,
    'perpetual' => 1,
    'leadership' => 1,
    'finely' => 1,
    'Damogran' => 1,
    'France' => 1,
    'defining' => 1,
    'immense' => 2,
    'physical' => 1,
    'matter,' => 1,
    'possibility' => 1,
    'ionized' => 1,
    'light' => 10,
    'feet' => 1,
    'transport,' => 1,
    'nest' => 1,
    'papier' => 1,
    'it.' => 3,
    'survival' => 1,
    'black' => 1,
    'him.' => 1,
    'creatures' => 1,
    'use' => 1,
    'suddenly' => 1,
    'Vogon' => 2,
    'up' => 1,
    'evolution' => 1,
    'tribute' => 1,
    'interstellar' => 1,
    'Prostetnic' => 1,
    'Gal.' => 1,
    'suspicion' => 1,
    'shame,' => 1,
    'gourmands,' => 1,
    'information' => 1,
    'continually' => 1,
    'things' => 5,
    'creak.' => 1,
    'spaceship' => 1,
    'smelly' => 1,
    'Squornshellous' => 2,
    'Traal.' => 1,
    'date' => 1,
    'corn' => 1,
    'wolves.' => 1,
    'looking' => 2,
    'coloured' => 1,
    'money' => 2,
    'glasses.' => 1,
    'perfectly' => 1,
    'hitchhikers' => 1,
    'degenerate' => 1,
    'my' => 5,
    'water.' => 1,
    'existence' => 1,
    'language.' => 1,
    'God.' => 1,
    'logic.' => 1,
    'creation.' => 1,
    'claustrophobia' => 1,
    'space' => 5,
    'print.' => 1,
    'Eroticon' => 1,
    'marching' => 1,
    'Kria.' => 1,
    'Green' => 1,
    'internal' => 1,
    'Greenbridge,' => 1,
    'electronic' => 2,
    'pain' => 1,
    'impassioned' => 1,
    'Betelgeuse,' => 1,
    'space,' => 2,
    'this?' => 1,
    'the...' => 2,
    'their' => 7,
    'verses.' => 1,
    'me' => 3,
    'reading,' => 1,
    'thing?' => 1,
    'spaceships...' => 1,
    'someone' => 1,
    'being' => 6,
    'bemusement' => 1,
    'lugging' => 1,
    'shouting' => 1,
    'massive' => 1,
    'culture' => 1,
    'Beethoven\'s' => 1,
    'anything?' => 1,
    'something.' => 2,
    'something,' => 2,
    'us' => 1,
    'air' => 2,
    'course...' => 1,
    'asphyxication' => 1,
    'rushing' => 1,
    'light.' => 1,
    'travellers' => 1,
    'distances' => 1,
    'years' => 2,
    'surprise.' => 2,
    'Poghril' => 1,
    'cholesterol' => 1,
    'atoms' => 1,
    'unreason' => 1,
    'mine,' => 2,
    'ship' => 1,
    'kippers?' => 1,
    'pipes' => 1,
    'mood' => 1,
    'one' => 5,
    'probability.' => 1,
    'custard' => 1,
    'probability!' => 1,
    'spaceship.' => 1,
    'space-time.' => 1,
    'stopping' => 1,
    'limbs!' => 1,
    'fifty' => 1,
    'two' => 2,
    'twenty-five' => 1,
    'twenty' => 1,
    'propulsion' => 1,
    'generating' => 1,
    'finite' => 1,
    'Indeterminacy.' => 1,
    'science,' => 1,
    'parties.' => 1,
    'really' => 1,
    'thin' => 1,
    'respectable' => 1,
    'computers' => 1,
    'gleaming' => 1,
    'instruments' => 1,
    'guys' => 3,
    'half' => 1,
    'ten' => 1,
    'mind' => 1,
    'anything' => 2,
    'pitch' => 1,
    'life.' => 1,
    'mindless' => 2,
    'robotics' => 1,
    'existence,' => 1,
    'metal?' => 1,
    '`the' => 1,
    'other' => 1,
    'what' => 5,
    'Sirius' => 1,
    'directing' => 1,
    'hydrogen' => 1,
    'despair' => 1,
    'smugness' => 1,
    'shock' => 1,
    'gunk' => 1,
    'pressing' => 1,
    'muscular' => 1,
    'course,' => 6,
    'figures.' => 1,
    'guys...' => 1,
    'guys?' => 1,
    'guys.' => 1,
    'her' => 3,
    'ticker' => 1,
    'paper.' => 1,
    'view' => 1,
    'Zaphod\'s' => 3,
    'course?' => 1,
    'nonchalance' => 1,
    'third' => 1,
    'surprise' => 1,
    'talk' => 1,
    'yours' => 1,
    'bricks' => 1,
    'four' => 1,
    'virtual' => 1,
    'fun,' => 1,
    'ancient' => 1,
    'pink.' => 1,
    'specialist' => 1,
    'earthquakes' => 1,
    'scholars' => 1,
    'legend.' => 1,
    'argument' => 1,
    'kicks' => 1,
    'three' => 1,
    'Magrathea.' => 5,
    'cold' => 1,
    'occasion' => 1,
    'blinding' => 1,
    'colour' => 1,
    'Soulianis' => 1,
    'seeing' => 1,
    'legend' => 1,
    'dawn' => 1,
    'day' => 1,
    'doubt' => 2,
    'adventure,' => 1,
    'exceedingly' => 1,
    'wealth' => 1,
    'somebody\'s' => 1,
    'petunias' => 3,
    'mystery' => 1,
    'suspense' => 1,
    'no' => 2,
    'liquid' => 1,
    'Magrathea' => 3,
    'us,' => 1,
    'our' => 2,
    'interest,' => 1,
    'panic.' => 1,
    'rolled-up' => 1,
    'Antares' => 1,
    'moulded' => 1,
    'green' => 2,
    'ferns' => 1,
    'eight' => 1,
    'that,' => 1,
    'deep' => 1,
    'computers.' => 1,
    'some' => 3,
    'reasoning' => 1,
    'dust' => 1,
    'earth,' => 1,
    'another' => 1,
    'Zaphod' => 1,
    'ground' => 1,
    'higher' => 1,
    'Trillian\'s' => 1,
    'disgust' => 1,
    'galleries' => 1,
    'them,' => 2,
    'keep' => 1,
    'things.' => 2,
    'things?' => 1,
    'worry.' => 1,
    'paranoia.' => 1,
    'both' => 2,
    'cerebellum.' => 1,
    'The' => 2,
    'Maximegalon,' => 1,
    'historical' => 1,
    'painstaking' => 1,
    'themselves' => 1,
    'fire' => 1,
    'face' => 1,
    'science' => 1,
    'adultery' => 1,
    'gathered' => 1,
    'gathered...' => 1,
    'bother' => 1,
    'touch.' => 1,
    'decision' => 1,
    'turning' => 1,
    'threat' => 1,
    'tiny' => 1,
    'occasions' => 1,
    'motion' => 1,
    'craft' => 1,
    'silver' => 1,
    'converging' => 1,
    'curved' => 1,
    'me.' => 1,
    'light,' => 1,
    'infinity' => 1,
    'sight.' => 1,
    'wonderful' => 1,
    'curious' => 1,
    'metal' => 1,
    'us.' => 1,
    'activity' => 1,
    'words,' => 1,
    'mine.' => 1,
    'speech.' => 1,
    'vast' => 1,
    'stuff.' => 1,
    'tests,' => 1,
    'cheese,' => 1,
    'myxomatosis,' => 1,
    'life' => 1,
    'Brockian' => 1,
    'rice' => 1,
    'hums' => 1,
    'Time' => 1,
    'Space' => 1,
    'none' => 2,
    'future' => 2,
    'solid' => 2,
    'Life,' => 2,
    'popular' => 1,
    'philosophy' => 1,
    'New' => 1,
    'wire' => 1,
    'stripped' => 1,
    'airy' => 1,
    'carnival' => 1,
    'Deep' => 1,
    'Vroomfondel' => 1,
    'Waiting' => 1,
    'times' => 1,
    'Life!..' => 1,
    'such' => 1,
    'pleasure?' => 1,
    'valleys' => 1,
    'cows.' => 1,
    'President' => 1,
    'trouble' => 1,
    'ships,' => 1,
    'weeks,' => 1,
    'conkers' => 1,
    'illusory' => 1,
    'stealing' => 1,
    'grin' => 1,
    'Yooden' => 1,
    'anywhere' => 1,
    'planning' => 1,
    'finding' => 1,
    'debris' => 1,
    'Norway' => 1,
    'command,' => 1,
    'scale' => 1,
    'glass-topped' => 1,
    'grilled' => 1,
    'evil' => 1,
    'thing.' => 1,
    'grated' => 1,
    'art!' => 1,
    'mice?' => 1,
    'pure' => 1,
    'truth' => 1,
    'maniacs.' => 1,
    'ever' => 1,
    'anything.' => 2,
    'money,' => 1,
    'rather' => 1,
    'Earthling' => 1,
    'adjacent' => 1,
    'intelligent' => 1,
    'Kill-O-Zap' => 1,
    'near' => 1,
    'molten' => 1,
    'strangled' => 1,
    'R17' => 1,
    'yet' => 1,
    'travel' => 1,
    'varying' => 1,
    'size' => 1,
    'every' => 1,
    'Survival,' => 1,
  ),
  'unfashionable' => 
  array (
    'end' => 1,
  ),
  'end' => 
  array (
    '' => 3,
    'of' => 6,
    'we' => 1,
    'to' => 2,
    'for' => 1,
    'in' => 1,
    'they' => 1,
    'never' => 1,
  ),
  'western' => 
  array (
    'spiral' => 1,
  ),
  'spiral' => 
  array (
    'arm' => 1,
    '' => 1,
    'staircase,' => 2,
  ),
  'arm' => 
  array (
    'of' => 1,
    '' => 3,
    'he\'d' => 1,
    'suits' => 1,
    'and' => 1,
  ),
  'lies' => 
  array (
    'a' => 1,
  ),
  'small' => 
  array (
    'unregarded' => 1,
    'green' => 2,
    '' => 12,
    'planet' => 2,
    'whisper' => 1,
    'dark' => 2,
    'flat' => 1,
    'concave' => 1,
    'knot' => 1,
    'gold' => 1,
    'Paralyso-Matic' => 1,
    'piggy' => 1,
    'galley' => 1,
    'glass' => 1,
    'yellow' => 2,
    'packet' => 1,
    'ball' => 1,
    'fortune' => 1,
    'way' => 1,
    'random' => 1,
    'luminous' => 1,
    'amounts' => 1,
    'cage' => 1,
    'computer' => 1,
    'plate' => 1,
    'furry' => 2,
    'lever' => 1,
    'stick' => 1,
    'palm' => 2,
    'asteroid' => 1,
    'craft' => 1,
    'hovercraft,' => 1,
    'chamber' => 1,
    'city.' => 1,
    'black' => 1,
    'white' => 1,
    'dog.' => 1,
    'voice' => 1,
    'pack' => 1,
  ),
  'unregarded' => 
  array (
    'yellow' => 1,
  ),
  'yellow' => 
  array (
    'sun.' => 1,
    'wandered' => 1,
    'bulldozer' => 1,
    'chunky' => 1,
    'somethings' => 2,
    'machines' => 1,
    '' => 3,
    'somethings.' => 1,
    'fish' => 2,
    'and' => 3,
  ),
  'sun.' => 
  array (
    'Orbiting' => 1,
    'Damogran' => 1,
    'Today' => 1,
    'Inside' => 1,
    '-' => 1,
  ),
  'Orbiting' => 
  array (
    'this' => 1,
  ),
  'this' => 
  array (
    'at' => 2,
    'problem,' => 1,
    'time,' => 1,
    'God' => 1,
    'terrible,' => 1,
    'remarkable' => 1,
    'bypass' => 1,
    'usually' => 1,
    'was' => 10,
    'new' => 1,
    '-' => 2,
    '' => 26,
    'afternoon' => 1,
    'time' => 6,
    'and' => 2,
    'particular' => 1,
    'stage,' => 1,
    'moment' => 3,
    'afternoon?' => 1,
    'topological' => 1,
    'day' => 2,
    'means' => 1,
    'starship' => 1,
    'tiny' => 1,
    'strange' => 1,
    'theory' => 1,
    'one' => 2,
    'is' => 23,
    'button' => 1,
    'sounds' => 1,
    'fish' => 2,
    'brainwave' => 1,
    'dank' => 1,
    'book' => 1,
    'edition' => 1,
    'totally' => 1,
    'for' => 5,
    'morning' => 1,
    'sort' => 4,
    'airlock' => 1,
    'airtight' => 1,
    'switch?' => 1,
    'distance' => 1,
    'is...' => 1,
    'script' => 1,
    'way:' => 1,
    'sales' => 1,
    'door,' => 2,
    'ship?' => 1,
    'time?' => 1,
    'out.' => 1,
    'computer' => 3,
    'terrible' => 1,
    'task,' => 1,
    'guy?' => 1,
    'remark' => 1,
    'ignorant' => 1,
    'party,' => 1,
    'friend' => 1,
    'guy' => 1,
    'thought' => 1,
    'industry' => 1,
    'venture' => 1,
    'ship...' => 1,
    'planet,' => 2,
    'Magrathea' => 1,
    'spaceship?' => 1,
    'situation' => 1,
    'because' => 1,
    'means?' => 1,
    'ship.' => 2,
    'Improbability' => 2,
    'stage?' => 1,
    'poor' => 1,
    'whistling' => 1,
    'thing?' => 1,
    'thing' => 1,
    'thin' => 1,
    'after' => 1,
    'planet' => 3,
    'robot' => 1,
    'end' => 2,
    'again.' => 1,
    'great' => 1,
    'isn\'t' => 1,
    'of' => 2,
    'pocket' => 1,
    'present' => 1,
    'machine' => 2,
    'point?' => 1,
    'has' => 1,
    'a' => 1,
    'the' => 1,
    'program' => 1,
    'really' => 1,
    'explains' => 1,
    'replacement' => 1,
    'wretched' => 1,
    'way,' => 1,
    'hole,' => 1,
    'entry.' => 1,
  ),
  'at' => 
  array (
    'a' => 11,
    'least' => 5,
    'ease' => 2,
    'the' => 46,
    'it.' => 5,
    'great' => 2,
    'himself' => 1,
    'him.' => 13,
    'him' => 15,
    'point' => 4,
    '' => 38,
    'my' => 1,
    'all' => 5,
    'all.' => 8,
    'Prosser.' => 1,
    'him,' => 8,
    'Arthur,' => 4,
    'all,' => 5,
    'once,' => 1,
    'Ford' => 2,
    'Arthur' => 2,
    'Arthur.' => 4,
    'them' => 8,
    'them.' => 1,
    'one' => 4,
    'this' => 6,
    'it' => 5,
    'Ford.' => 2,
    'his' => 5,
    'least.' => 2,
    'over' => 1,
    'least,' => 2,
    'something' => 2,
    'Trillian' => 1,
    'sea' => 1,
    'school' => 1,
    'Barnard\'s' => 1,
    'that' => 7,
    'this,' => 1,
    'you.' => 1,
    'last.' => 2,
    'what' => 2,
    'Sol\'s' => 1,
    'Southend.' => 1,
    'an' => 2,
    'parties' => 1,
    'her' => 2,
    'other' => 1,
    'another' => 1,
    'each' => 7,
    'Zaphod.' => 1,
    'last' => 1,
    'Ford,' => 1,
    'Trillian.' => 2,
    'all:' => 1,
    'Zaphod\'s' => 1,
    'this.' => 2,
    'night' => 1,
    'us.' => 1,
    'from' => 1,
    'where' => 1,
    'Marvin' => 1,
    'Zaphod' => 1,
    'random.' => 2,
    'them,' => 2,
    'home,' => 1,
    'us!' => 1,
    'ease,' => 1,
    'Marvin,' => 1,
    'that.' => 1,
    'which' => 1,
    'it,' => 2,
    'several' => 1,
    'distances' => 1,
    'and' => 1,
    'birth' => 1,
    'Deep' => 1,
    'last,' => 1,
    'me:' => 1,
    'himself,' => 1,
    'two' => 1,
    'everyone.' => 1,
    'us,' => 2,
    'unbearable' => 1,
    'speeds' => 1,
    'R17' => 1,
  ),
  'distance' => 
  array (
    'of' => 1,
    'leaving' => 1,
    'is' => 2,
    'behind' => 2,
    '' => 2,
    'seemed' => 1,
  ),
  'roughly' => 
  array (
    'ninety-two' => 1,
    'humanoid' => 1,
  ),
  'ninety-two' => 
  array (
    'million' => 1,
  ),
  'million' => 
  array (
    'miles' => 2,
    '"pages"' => 1,
    'light' => 1,
    'for' => 1,
    'years,' => 4,
    'seven' => 1,
    'sheep' => 1,
    '' => 2,
    'years' => 6,
    'years!..' => 1,
    'years\'' => 1,
  ),
  'miles' => 
  array (
    'is' => 1,
    'above' => 2,
    '' => 4,
    'long,' => 1,
    'to' => 1,
    'out' => 1,
    'beneath' => 2,
    'an' => 1,
    'across' => 1,
  ),
  'is' => 
  array (
    'an' => 5,
    'odd' => 1,
    'not' => 10,
    'the' => 10,
    'also' => 2,
    'it' => 2,
    '' => 43,
    'this' => 5,
    'apocryphal,' => 1,
    'slightly' => 1,
    'exactly' => 1,
    'there' => 3,
    'to' => 7,
    'lost).' => 1,
    'going' => 5,
    'why' => 2,
    'that' => 9,
    'is' => 1,
    'clearly' => 2,
    'from' => 1,
    'never' => 1,
    'Prostetnic' => 1,
    'one' => 4,
    'kept' => 1,
    'now' => 2,
    'nearly' => 2,
    'very' => 1,
    'apparently' => 1,
    'required' => 1,
    'wielded.' => 1,
    'handled' => 1,
    'really' => 4,
    'truly' => 1,
    'so' => 1,
    'some' => 2,
    'shrouded' => 1,
    'still' => 2,
    'obviously' => 1,
    'a' => 15,
    'it?' => 7,
    'what' => 4,
    'your' => 3,
    'cancelled.' => 1,
    'small,' => 1,
    'such' => 1,
    'white' => 1,
    'no' => 2,
    'of' => 3,
    'reported' => 1,
    'useless!' => 4,
    'great,' => 1,
    'does' => 1,
    'useless,' => 1,
    'there?' => 1,
    'it,' => 2,
    'terrific,' => 1,
    'me' => 1,
    'big.' => 1,
    'surgically' => 1,
    'vitally' => 1,
    'just' => 3,
    'comforting' => 1,
    'Southend?' => 1,
    'Southend,' => 1,
    'something' => 2,
    'on' => 1,
    'rapidly' => 1,
    'normal' => 1,
    'fantastic!' => 1,
    'big' => 1,
    'their' => 1,
    'worth' => 1,
    'important.' => 1,
    'wild.' => 1,
    'make' => 1,
    'this?' => 1,
    'my' => 2,
    'getting' => 2,
    'Eddie' => 1,
    'beautiful' => 1,
    'killing' => 1,
    'in' => 2,
    'temporarily' => 1,
    'resumed' => 1,
    'most' => 1,
    'terrific!' => 1,
    'trying' => 1,
    'absolutely' => 1,
    'possible' => 2,
    'about' => 1,
    'Magrathea...' => 1,
    'how' => 1,
    'better' => 1,
    'being' => 1,
    'looking' => 1,
    'incomprehensible' => 1,
    'where' => 1,
    'sometimes' => 1,
    'enormous.' => 1,
    'this.' => 2,
    'solid' => 1,
    'precisely' => 1,
    'quite' => 1,
    'but' => 1,
    'unless' => 1,
    'over!' => 1,
    'preparing' => 1,
    'one?' => 1,
    'one,' => 1,
    'all' => 1,
    'Frankie' => 1,
    'more' => 1,
    'encoded' => 1,
    'here,' => 1,
    'probably' => 1,
    'consistent' => 1,
    'therefore' => 1,
    'impossible' => 1,
    'completely' => 1,
    'characterized' => 1,
  ),
  'an' => 
  array (
    'utterly' => 1,
    'Earth' => 1,
    'bypass' => 1,
    'ape.' => 1,
    'ape,' => 1,
    '' => 38,
    'old' => 1,
    'olive.' => 1,
    'answer' => 2,
    'Algolian' => 1,
    'illusion.' => 2,
    'Electronic' => 1,
    'interstellar' => 2,
    'empty' => 2,
    'interest' => 2,
    'extra' => 2,
    'anachronism.' => 1,
    'elected' => 1,
    'infuriating' => 1,
    'island' => 1,
    'octopoid' => 1,
    'upholstered' => 1,
    'extraordinary' => 3,
    'Arab' => 1,
    'ugly' => 1,
    'unruly' => 1,
    'annoyed' => 1,
    'electronic' => 3,
    'official' => 1,
    'announcement' => 1,
    'encore' => 1,
    'entry!' => 1,
    'improvement.' => 1,
    'approach' => 1,
    'alien' => 2,
    'amazed' => 1,
    'interesting' => 1,
    'interest,' => 1,
    'Islington' => 1,
    'inch' => 2,
    'airliner' => 1,
    'improbability' => 1,
    'infinite' => 1,
    'atomic' => 1,
    'ordinary' => 1,
    'edition' => 1,
    'incomprehensible' => 1,
    'invitingly' => 1,
    'ingratiating' => 1,
    'awkward' => 3,
    'angry' => 1,
    'Ilford-based' => 1,
    'hour' => 1,
    'altitude' => 1,
    'instant' => 1,
    'Improbability' => 1,
    'argument' => 1,
    'upset' => 1,
    'emergency' => 1,
    'idea' => 1,
    'attack' => 1,
    'expedition' => 1,
    'odd' => 1,
    'important' => 1,
    'insane' => 1,
    'hour.' => 1,
    'Earthman?' => 1,
    'invisible' => 1,
    'enormous' => 2,
    'Arcturan' => 1,
    'answer?' => 1,
    'answer.' => 1,
    'nearby' => 1,
    'outraged' => 1,
    'observation' => 1,
    'awed' => 1,
    'explosion' => 1,
    'amazingly' => 1,
    'offer' => 1,
    'organic' => 2,
    'instant.' => 1,
    'earsplitting' => 1,
    'angle' => 1,
    'enlightened' => 1,
    'aircar' => 1,
    'arrow' => 1,
    'almost' => 1,
    'absolute,' => 1,
    'acute' => 1,
    'inert' => 1,
  ),
  'utterly' => 
  array (
    'insignificant' => 1,
    'alone' => 1,
    '' => 1,
  ),
  'insignificant' => 
  array (
    'little' => 1,
  ),
  'little' => 
  array (
    'blue' => 1,
    'fur' => 1,
    'cottage' => 1,
    'pricks' => 1,
    'bits,' => 1,
    'nob' => 1,
    '' => 8,
    'loophole.' => 1,
    'callousness.' => 1,
    'passage' => 1,
    'too' => 1,
    'whine' => 1,
    'clicks' => 1,
    'disclaimers.' => 1,
    'notion.' => 1,
    'treaties' => 1,
    'time' => 1,
    'shudders' => 1,
    'was' => 1,
    'more' => 2,
    'bits' => 1,
    'too...' => 1,
    'of' => 1,
    'time.' => 1,
    'while' => 1,
    'problems' => 1,
    'eyes.' => 1,
    'voices' => 1,
    'piggy' => 1,
    'peckish' => 1,
  ),
  'blue' => 
  array (
    'green' => 1,
    '' => 1,
    'oceans...' => 1,
  ),
  'green' => 
  array (
    '' => 5,
    'pieces' => 2,
    'was' => 2,
    'slyph-like' => 1,
    'rubbery' => 1,
    'bug-eyed' => 1,
    'across' => 1,
    'and' => 1,
    'retractables,' => 1,
    'catalogue' => 1,
    'sweet-smelling' => 1,
    'in' => 1,
  ),
  'planet' => 
  array (
    '' => 18,
    'has' => 2,
    'in' => 3,
    'some' => 1,
    'beneath' => 1,
    'the' => 2,
    'were' => 1,
    'is' => 3,
    'Vogsphere' => 1,
    'and' => 3,
    'to' => 1,
    'leave' => 1,
    'Earth.' => 1,
    'demolished' => 1,
    'seemed' => 1,
    'Bethselamin' => 1,
    'Earth,' => 2,
    'they' => 3,
    'blew' => 1,
    'as' => 1,
    'again,' => 1,
    'out' => 1,
    'building.' => 1,
    'Magrathea,' => 1,
    'of' => 2,
    'there.' => 1,
    'again.' => 1,
    'rolling' => 1,
    'rolled' => 1,
    'was' => 2,
    'appeared' => 1,
    'where' => 2,
    'continues' => 1,
    'surface.' => 1,
    'entirely' => 1,
    'that' => 1,
    'called' => 1,
    'tick' => 1,
    'Earth' => 1,
    'you' => 1,
    'catalogue' => 1,
    'who' => 1,
    'early' => 1,
    'got' => 1,
    'burst' => 1,
  ),
  'whose' => 
  array (
    '' => 3,
    'it' => 1,
    'merest' => 2,
    'two-man' => 1,
  ),
  'apedescended' => 
  array (
    '' => 1,
  ),
  'life' => 
  array (
    'forms' => 2,
    'form' => 3,
    '' => 4,
    'was' => 2,
    'forms.' => 2,
    'again.' => 2,
    'difficult' => 1,
    'and' => 2,
    'that' => 1,
    'can\'t' => 1,
    'in' => 1,
    'with' => 1,
    'inevitably' => 1,
    'till' => 1,
    'which' => 1,
    'on' => 1,
    'itself' => 1,
    'I\'ve' => 1,
    'form,' => 1,
  ),
  'forms' => 
  array (
    'are' => 1,
    '' => 2,
    'would' => 1,
    'and' => 1,
  ),
  'are' => 
  array (
    'so' => 3,
    'a' => 4,
    'inextricably' => 1,
    'devices' => 1,
    'often' => 2,
    '' => 16,
    'you?' => 8,
    'you' => 18,
    'going' => 3,
    'mixed,' => 1,
    'sir,' => 2,
    'now' => 6,
    'not' => 4,
    'an' => 1,
    'the' => 5,
    'very' => 1,
    'one' => 1,
    'usually' => 1,
    'about' => 3,
    'steel' => 1,
    'to' => 1,
    'good...' => 1,
    'pretty' => 2,
    'Arthur,' => 1,
    'two' => 2,
    'all' => 1,
    'we' => 2,
    'swirling...' => 1,
    'you,' => 2,
    'perfectly' => 1,
    'bound' => 1,
    'sure' => 1,
    'they' => 1,
    'on' => 1,
    'governed' => 1,
    'currently' => 1,
    'fairies' => 1,
    'part' => 1,
    'of' => 2,
    'aren\'t' => 1,
    'we?' => 1,
    'supposed' => 1,
    'determined' => 1,
    'coming' => 1,
    'something' => 1,
    'afoot.' => 1,
    'at' => 1,
    'merely' => 1,
    'Why' => 1,
    'people' => 1,
    'Philosophers.' => 1,
    'quite' => 1,
    'still' => 1,
    'powerless' => 1,
    'mice' => 1,
    'works' => 1,
    'made!' => 1,
    'these' => 1,
    'firmly' => 1,
    'some' => 1,
  ),
  'so' => 
  array (
    'amazingly' => 3,
    'the' => 4,
    'worried' => 1,
    'juggled' => 1,
    'great' => 3,
    'many' => 2,
    'keen' => 2,
    'you' => 1,
    'redly' => 1,
    'kind.' => 1,
    '' => 18,
    'he' => 4,
    'low' => 1,
    'you\'ve' => 1,
    'deserted' => 1,
    'secret.' => 1,
    'for' => 1,
    'much' => 6,
    'Zaphod' => 1,
    'that' => 4,
    'I' => 6,
    'I\'m' => 1,
    'unpleasant' => 1,
    'mindboggingly' => 1,
    'far' => 2,
    'what\'s' => 1,
    'well.' => 1,
    'on.' => 1,
    'fast' => 1,
    'extraordinary' => 1,
    'new.' => 1,
    'ten' => 1,
    'if' => 2,
    'depressed.' => 1,
    '-' => 1,
    'successful' => 1,
    'much.' => 1,
    'came' => 1,
    'tense?' => 1,
    'we' => 2,
    'let\'s' => 1,
    'behind' => 1,
    'I\'ve' => 1,
    'thin' => 1,
    'anyway,' => 1,
    'on' => 1,
    'they' => 2,
    'soft' => 1,
    'paralysingly' => 1,
    'fed' => 1,
    'later' => 1,
    'had' => 1,
    'secret' => 1,
    'important' => 2,
    'carelessly' => 1,
    'to' => 1,
  ),
  'amazingly' => 
  array (
    'primitive' => 1,
    'together' => 1,
    'good' => 1,
    'popular' => 1,
    'amazing' => 1,
    '' => 1,
    'intelligent' => 1,
    'balletic' => 1,
  ),
  'primitive' => 
  array (
    'that' => 1,
    '' => 1,
    'who' => 1,
  ),
  'that' => 
  array (
    'they' => 12,
    'were' => 3,
    '' => 98,
    'even' => 2,
    'no' => 1,
    'had' => 6,
    'terrible' => 1,
    'was' => 10,
    'used' => 1,
    'people' => 2,
    'the' => 25,
    'he' => 25,
    'so' => 2,
    'bulldozer' => 1,
    'one' => 3,
    'his' => 3,
    'honestly' => 1,
    'much' => 1,
    'green' => 1,
    'any' => 1,
    'a' => 7,
    'we' => 7,
    'this' => 8,
    'Ford' => 1,
    'served' => 1,
    'ancient' => 1,
    'Old' => 2,
    'sinful' => 1,
    'perhaps' => 1,
    'Arthur' => 5,
    'anyway,' => 1,
    'sound?' => 2,
    'it' => 11,
    'Ol\'' => 1,
    'Santraginean' => 1,
    'would' => 3,
    'in' => 4,
    'I\'m' => 1,
    'most' => 2,
    'if' => 7,
    'hoopy' => 1,
    'moment' => 5,
    'lunchtime.' => 1,
    'exists' => 1,
    'being' => 1,
    'help?' => 1,
    'Mr.' => 1,
    'something' => 2,
    'drove' => 1,
    'bricks' => 1,
    'two' => 1,
    'lay' => 2,
    'way' => 1,
    'once' => 1,
    'without' => 1,
    'assembly.' => 1,
    'particular' => 1,
    'anyone' => 1,
    'bulged' => 1,
    'because' => 1,
    'way.' => 2,
    'nestled' => 1,
    'morning,' => 1,
    'I' => 12,
    'someone' => 2,
    'moment.' => 2,
    'when' => 1,
    'pleased' => 1,
    'fish' => 1,
    'anything' => 1,
    'black' => 1,
    'didn\'t' => 1,
    '-' => 1,
    'gave' => 1,
    'all' => 2,
    'noise?' => 1,
    'of' => 2,
    'kept' => 1,
    'not' => 1,
    'some' => 2,
    'right?' => 1,
    'coming' => 1,
    'spaceship' => 1,
    'much.' => 1,
    'doesn\'t' => 1,
    'great' => 1,
    'you' => 6,
    'stir' => 1,
    'will' => 3,
    'interstellar' => 1,
    'what' => 1,
    'is' => 7,
    'voice?' => 1,
    'tedious' => 1,
    'such' => 1,
    'figure' => 1,
    'robot' => 3,
    'job' => 1,
    'stretched' => 1,
    'door,' => 1,
    'for?' => 1,
    'mean' => 1,
    'point?' => 1,
    'whatever' => 1,
    'wretched' => 1,
    'party.' => 1,
    'miserable' => 1,
    'did' => 1,
    'bloody' => 1,
    'or' => 1,
    'governed' => 1,
    'she' => 1,
    'charted' => 1,
    'up' => 1,
    'from' => 1,
    'nothing' => 1,
    'Magrathea' => 1,
    'for' => 1,
    'Zaphod' => 1,
    'as' => 2,
    'your' => 1,
    'could' => 1,
    'all?' => 1,
    'formed' => 1,
    'matter' => 1,
    'happened' => 2,
    'got' => 1,
    'now' => 1,
    'went' => 1,
    'her' => 1,
    'human' => 1,
    'owns' => 1,
    'exit' => 1,
    'caught' => 1,
    'direction' => 1,
    'hadn\'t' => 1,
    'it\'s' => 1,
    'part' => 1,
    'maybe' => 1,
    'somebody' => 1,
    'purpose,' => 1,
    'related' => 1,
    'to' => 1,
    'simply' => 1,
    'unattended' => 1,
    'Voojagig' => 1,
    'sunset!' => 1,
    'custom-made' => 1,
    'we\'d' => 1,
    'things' => 1,
    'seemed' => 1,
    'its' => 1,
    'hung' => 1,
    'betrayed' => 1,
    'direction.' => 1,
    'sort' => 1,
    'there' => 2,
    'demarcation' => 1,
    'my' => 1,
    'running' => 1,
    'time' => 1,
    'is...' => 1,
    'you\'re' => 1,
    'quite' => 1,
    'you\'ve' => 1,
    'organic' => 1,
    'there?' => 1,
    'breath' => 1,
    'series' => 1,
    'came' => 1,
    'guy' => 1,
    'ship?' => 1,
    'are' => 1,
    'kind' => 1,
    'I\'ve' => 1,
    'careless' => 1,
    'bowl' => 1,
    'won\'t' => 1,
    'one,' => 1,
    'Benji' => 1,
    'sounds' => 3,
    'out,' => 1,
    'computer' => 1,
    'Trillian' => 1,
    'at' => 2,
    'does' => 1,
    'cracked' => 1,
    'you\'d' => 1,
    'still' => 1,
    'exactly' => 1,
    'stood' => 1,
    'lead' => 1,
  ),
  'they' => 
  array (
    'still' => 1,
    'probably' => 1,
    'say,' => 1,
    'just' => 1,
    'wanted' => 2,
    'made' => 1,
    '' => 32,
    'could' => 4,
    'should' => 2,
    'were' => 20,
    'registered' => 1,
    'haven\'t' => 1,
    'are!' => 1,
    'told' => 1,
    'didn\'t' => 4,
    'hung,' => 1,
    'said,' => 1,
    'only' => 1,
    'knew' => 2,
    'completely' => 1,
    'had' => 9,
    'watched' => 1,
    'did' => 1,
    'simply' => 1,
    'have' => 1,
    'don\'t' => 2,
    'let' => 1,
    'buzz' => 1,
    'find' => 1,
    'be' => 1,
    'really' => 2,
    'are' => 3,
    'drifted' => 1,
    'must' => 1,
    'weren\'t' => 1,
    'couldn\'t' => 2,
    'encountered' => 1,
    'grumpily' => 1,
    'Trillian?' => 1,
    'would' => 3,
    'make' => 1,
    'said.' => 3,
    'ask' => 1,
    'tried' => 1,
    'said' => 4,
    'occupied' => 1,
    'began' => 1,
    'laboured' => 1,
    'want' => 2,
    'quite' => 1,
    'passed' => 1,
    'arrived' => 1,
    'approached' => 1,
    'became' => 1,
    'suddenly' => 1,
    'met' => 1,
    'all' => 2,
    'will.' => 1,
    'discovered' => 1,
    'can' => 1,
    'seem.' => 1,
    'eventually' => 1,
    'spent' => 1,
    'finally' => 1,
    'climbed' => 1,
    'hadn\'t' => 1,
    'appear.' => 1,
    'die?' => 1,
    'decided' => 1,
    'built' => 1,
    'conducted' => 1,
    'seated' => 1,
    'cried' => 1,
    'turned' => 1,
    'stepped' => 1,
    'found' => 1,
    'got' => 1,
    'looked.' => 1,
    'looked' => 1,
    'become' => 1,
    'give' => 1,
    'tell' => 1,
    'came' => 1,
    'say.' => 1,
    'entered.' => 1,
    'composed' => 1,
    'ugly' => 1,
    'carried' => 1,
    'were.' => 1,
    'lay' => 1,
    'thought.' => 1,
    'called' => 1,
    'begin' => 1,
  ),
  'still' => 
  array (
    'think' => 1,
    'seems' => 1,
    '' => 6,
    'running,' => 1,
    'nothing' => 1,
    'the' => 1,
    'a' => 1,
    'holding' => 1,
    'quiet' => 1,
    'listening' => 1,
    'existed.' => 1,
    'didn\'t' => 1,
    'an' => 1,
    'got' => 1,
    'just' => 1,
    'lying' => 1,
    'can\'t' => 1,
    'engrossed' => 1,
    'moaning.' => 1,
    'scooted' => 1,
    'and' => 1,
    'sat' => 1,
    'illuminated' => 1,
    'locked' => 1,
    'need' => 1,
    'further.' => 1,
    'there?' => 1,
    'as' => 2,
    'dangled' => 1,
  ),
  'think' => 
  array (
    'digital' => 1,
    'it\'s' => 6,
    'that' => 4,
    'is' => 1,
    'the' => 3,
    '' => 12,
    'I\'d' => 2,
    'we\'re' => 3,
    'things' => 1,
    'I' => 2,
    'you\'ve' => 1,
    'if' => 2,
    'of' => 6,
    'so,' => 2,
    'this' => 3,
    'about' => 4,
    'you' => 2,
    'and' => 1,
    'I\'ll' => 2,
    'life' => 1,
    'about.' => 2,
    'we' => 3,
    'they\'re' => 2,
    'down' => 1,
    'it' => 2,
    'why' => 1,
    'they' => 1,
    'therefore' => 1,
    'Who' => 1,
    'Yooden' => 1,
    'we\'ve' => 1,
    'we\'d' => 1,
  ),
  'digital' => 
  array (
    'watches' => 1,
    'watches.' => 1,
    'watch' => 1,
    'watches?' => 1,
  ),
  'watches' => 
  array (
    'are' => 1,
  ),
  'pretty' => 
  array (
    'neat' => 1,
    'much' => 1,
    'but' => 1,
    'meaningless' => 1,
    'good' => 2,
    'lousy.' => 1,
    'improbable' => 2,
    'low,' => 1,
    'sum.' => 1,
    '' => 1,
    'unpleasant' => 1,
    'young' => 1,
    'treelined' => 1,
  ),
  'neat' => 
  array (
    'idea.' => 1,
  ),
  'idea.' => 
  array (
    'This' => 1,
  ),
  'This' => 
  array (
    'planet' => 1,
    'time' => 2,
    'is' => 18,
    'friend' => 1,
    '' => 6,
    'must' => 1,
    'signal' => 1,
    'wasn\'t' => 2,
    'impression' => 1,
    'suited' => 1,
    'was' => 2,
    'above' => 1,
    'fact' => 1,
    'struck' => 1,
  ),
  'has' => 
  array (
    '-' => 1,
    '' => 8,
    'got' => 3,
    'to' => 2,
    'the' => 2,
    'a' => 1,
    'great' => 1,
    'immense' => 1,
    'his' => 1,
    'passed' => 1,
    'always' => 1,
    'been' => 4,
    'simply' => 1,
    'ever' => 1,
    'already' => 1,
    'supplied' => 1,
    'caused' => 2,
    'gone.' => 1,
    'gone,' => 1,
    'he' => 1,
    'gone' => 1,
    'trod' => 1,
    'waited' => 1,
    'that.' => 1,
    'achieved' => 1,
    'landed' => 1,
  ),
  '-' => 
  array (
    'or' => 4,
    'a' => 16,
    'not' => 4,
    'of' => 2,
    'more' => 1,
    '' => 182,
    'most' => 1,
    'so.' => 1,
    'Yellow,' => 1,
    'he' => 211,
    'which' => 6,
    'Come' => 8,
    'you' => 15,
    'He' => 27,
    'I\'m' => 18,
    'we\'ll' => 1,
    'First' => 1,
    'said' => 402,
    'What' => 44,
    'You' => 48,
    'Appropriate' => 2,
    'hooted' => 1,
    'But' => 43,
    'Oh' => 38,
    'On' => 3,
    'That\'s' => 13,
    'With' => 2,
    'Ah,' => 9,
    'So' => 12,
    'Yes,' => 33,
    'yes' => 1,
    'It\'s' => 23,
    'You\'ll' => 2,
    'Shut' => 3,
    'Mr.' => 1,
    'Hello?' => 2,
    'Some' => 2,
    'How' => 13,
    'None' => 2,
    'with,' => 1,
    'Oh,' => 17,
    'Green' => 1,
    'Don\'t' => 12,
    'Hello' => 1,
    'Ford!' => 4,
    'Fine,' => 4,
    'look,' => 1,
    'Am' => 2,
    'exclaimed' => 6,
    'Well,' => 29,
    'Good,' => 1,
    'What?' => 17,
    'We\'ve' => 4,
    'talk.' => 1,
    'And' => 36,
    'Look,' => 13,
    'That' => 8,
    'Well' => 20,
    'Ah.' => 3,
    'Nothing.' => 3,
    'I\'ve' => 11,
    'Because' => 4,
    'who' => 1,
    'Excuse' => 4,
    'Yes?' => 1,
    'Has' => 2,
    'Can' => 5,
    'called' => 4,
    'assume' => 1,
    'Well?' => 6,
    'sighed' => 1,
    'So?' => 1,
    'Could' => 2,
    'actually' => 1,
    'we' => 8,
    'Thank' => 6,
    'thank' => 2,
    'So,' => 1,
    'continued' => 9,
    'if' => 6,
    'perhaps' => 1,
    'my' => 1,
    'to' => 6,
    'Yes.' => 12,
    'In' => 7,
    'Instead' => 1,
    'In,' => 1,
    'Promise?' => 1,
    'Promise,' => 1,
    'get' => 1,
    'The' => 37,
    'growled' => 1,
    'his' => 2,
    'what' => 5,
    'Myself' => 1,
    'and' => 22,
    'About' => 1,
    'come' => 4,
    'Six' => 1,
    'Going' => 1,
    'No,' => 33,
    'What\'s' => 12,
    'Arsenal' => 1,
    'it\'s' => 9,
    'Lucky' => 1,
    'There' => 12,
    'Get' => 1,
    'They\'re' => 3,
    'Keep' => 2,
    'What,' => 6,
    'You\'ve' => 1,
    'Ford,' => 8,
    'would' => 3,
    'Drink' => 4,
    'you\'ve' => 1,
    'Three' => 1,
    'At' => 5,
    'Time' => 1,
    'Very' => 5,
    'Why' => 5,
    'Muscle' => 3,
    'Did' => 6,
    'Alright,' => 9,
    'I\'ll' => 9,
    'Arthur' => 6,
    'Er,' => 10,
    'Most' => 2,
    'I' => 111,
    'This' => 7,
    'daft' => 1,
    'Hey,' => 13,
    'Why?' => 6,
    'they' => 14,
    'shouted' => 31,
    'My' => 7,
    'It' => 21,
    'Fun?' => 1,
    'yelped' => 2,
    'Fun!' => 1,
    'Damn' => 1,
    'Stop,' => 1,
    'bawled' => 3,
    'twenty-eight' => 1,
    'Are' => 6,
    'But,' => 2,
    'in' => 1,
    'Isn\'t' => 2,
    'that' => 9,
    'If' => 8,
    'Will' => 2,
    'asked' => 11,
    'Last' => 2,
    'until' => 1,
    'People' => 1,
    'the' => 16,
    'As' => 2,
    'There\'s' => 3,
    'Energize' => 1,
    'Zaphod' => 5,
    'an' => 2,
    'you\'re' => 4,
    'mostly' => 1,
    'but' => 16,
    'Hi,' => 4,
    'Hi' => 6,
    'Wow,' => 1,
    'Wow.' => 1,
    'Who' => 11,
    'Here,' => 3,
    'urged' => 5,
    'Whhhrrrr...' => 1,
    'No' => 13,
    'Dark,' => 1,
    'no' => 1,
    'Like' => 2,
    'We\'re' => 7,
    'this' => 5,
    'We' => 23,
    'Is' => 9,
    'when' => 1,
    'Shade' => 1,
    'Good' => 8,
    'is' => 11,
    'Go' => 2,
    'These' => 2,
    'Vogon' => 1,
    'Great' => 1,
    'Unfortunately' => 1,
    'Easy,' => 1,
    'A' => 15,
    'Yeah.' => 3,
    'Buzz' => 1,
    'Yeah,' => 18,
    'Ford' => 5,
    'insisted' => 8,
    'Understand' => 2,
    'Yes' => 7,
    'Alright' => 1,
    'Shush!' => 2,
    'Listen,' => 3,
    'Im...' => 1,
    'Listen!' => 1,
    'Howl' => 1,
    'Secondly,' => 1,
    'Charming' => 1,
    'They\'ve' => 2,
    'you\'d' => 3,
    'Yeah?' => 6,
    'Now' => 5,
    'says' => 4,
    'Meanwhile,' => 1,
    'somehow' => 1,
    'Let' => 3,
    'Yeah' => 4,
    'down' => 1,
    'Mostly' => 2,
    'admitted' => 1,
    'hissed' => 2,
    'No!' => 1,
    'whispered' => 5,
    'Then' => 5,
    'strapped' => 1,
    'all' => 5,
    '...thy' => 1,
    'Aaaaaaarggggghhhhhh!' => 1,
    'went' => 2,
    'Groop' => 1,
    'Nnnnnnnnnnyyyyyyyuuuuuuurrrrrrrggggggghhhhh!' => 1,
    'cried' => 12,
    'whirred' => 1,
    'tell' => 1,
    'Actually' => 1,
    'invited' => 1,
    'Oh...' => 2,
    '...humanity' => 1,
    'Vogonity,' => 1,
    'Ah' => 3,
    '(...' => 1,
    'Into' => 2,
    'too' => 1,
    'don\'t' => 4,
    'yelled' => 6,
    'Resistance' => 6,
    'Hmmmm,' => 1,
    'counterpoint' => 1,
    'Death\'s' => 1,
    'spluttered' => 1,
    'bellowed' => 3,
    'Just' => 7,
    'stammered' => 2,
    'complained' => 1,
    'just' => 2,
    'snapped' => 4,
    'Do' => 6,
    'Enjoy?' => 1,
    'They\'d' => 1,
    'agreed' => 4,
    'except' => 1,
    'Sure,' => 1,
    'interrupted' => 3,
    'then' => 2,
    'Er...' => 6,
    'er...' => 2,
    'Try' => 1,
    'Here' => 1,
    'added' => 4,
    '...and' => 3,
    'Well.' => 1,
    'encouraged' => 1,
    'so' => 3,
    'stop' => 1,
    'Eerrrrrrmmmmmmmmmmmmmmmmmmmmm...' => 1,
    'erm,' => 1,
    'that\'s' => 5,
    'Huhhhhgggggggnnnnnnn...' => 1,
    'pursued' => 2,
    'there\'s' => 5,
    'Desperately' => 1,
    'Da' => 1,
    'Potentially' => 1,
    'we\'re' => 3,
    'panted' => 1,
    'it' => 15,
    'So...' => 1,
    'except...' => 1,
    'Why,' => 2,
    'Oh.' => 1,
    'Space,' => 1,
    'she' => 15,
    'gasped' => 1,
    'sure.' => 1,
    'Bright' => 1,
    'Hell,' => 2,
    'Perhaps' => 3,
    'we\'d' => 1,
    'Therefore' => 1,
    'Nice' => 1,
    'there' => 1,
    'Probability?' => 1,
    'Probability.' => 1,
    'Haaaauuurrgghhh...' => 1,
    'Southend' => 1,
    'how' => 3,
    'Two' => 2,
    'Where' => 2,
    'Please' => 2,
    'raged' => 1,
    'Admittedly,' => 1,
    'they\'re' => 2,
    'squawked' => 2,
    'Welcome,' => 2,
    'by' => 1,
    'Arthur!' => 2,
    'partly' => 1,
    'Five' => 1,
    'She' => 1,
    'Anything' => 1,
    'Section' => 1,
    'dash,' => 1,
    'Zaphod,' => 3,
    'Not' => 5,
    'Trillian' => 3,
    'You\'d' => 1,
    'Anyway,' => 1,
    'Huh?' => 3,
    'Whilst' => 1,
    'Look' => 3,
    'muttered' => 9,
    'droned' => 1,
    'Marvin!' => 2,
    'warned' => 1,
    'nothing' => 1,
    'She\'s' => 1,
    'Good...' => 1,
    'great...' => 1,
    'lilted' => 2,
    'You\'re' => 3,
    'probed' => 1,
    'Marvin' => 2,
    'Life,' => 3,
    'Have' => 2,
    'clearly' => 1,
    'GPP' => 1,
    'sounds' => 1,
    'Ghastly,' => 1,
    'All' => 2,
    'Hummmmmmmyummmmmmm' => 1,
    'Let\'s' => 2,
    'Which' => 5,
    'started' => 3,
    'Stolen?' => 2,
    'mimicked' => 2,
    'Sorry,' => 2,
    'Pardon' => 1,
    'those' => 1,
    'Does' => 3,
    'Mmmmm,' => 1,
    'ZZ' => 1,
    'Any' => 1,
    'There,' => 2,
    'right' => 1,
    'Hey...' => 2,
    'now' => 3,
    'Improbability' => 2,
    'Picking' => 1,
    'Sure' => 2,
    'OK,' => 8,
    'from' => 1,
    ',' => 1,
    'two' => 4,
    '...it\'s' => 1,
    'Bat\'s' => 1,
    'Computer!' => 4,
    'chattered' => 2,
    'Telephone' => 1,
    'No?' => 1,
    'Really?' => 1,
    'for' => 3,
    'Funny,' => 1,
    'came' => 2,
    'What\'s...?' => 1,
    'Shhh,' => 2,
    'great' => 1,
    'Know' => 1,
    'he\'s...' => 1,
    'hi' => 1,
    'Err...' => 1,
    'What!' => 2,
    'Cool' => 1,
    'demanded' => 4,
    'London,' => 1,
    'Islington.' => 1,
    'Looking' => 1,
    'persisted' => 2,
    'was' => 1,
    'Zaphod?' => 1,
    'Tricia' => 1,
    'Same' => 1,
    'Infinity' => 1,
    'Trillian,' => 2,
    'Zaphod...?' => 1,
    'See?' => 1,
    'No.' => 8,
    'enthused' => 2,
    'Recognize' => 2,
    'Inside' => 1,
    'That...' => 1,
    'none' => 1,
    'Magrathea' => 2,
    'Computer,' => 2,
    'Proving' => 1,
    'any' => 1,
    'adding,' => 1,
    'whatever' => 1,
    'let\'s' => 1,
    'Or' => 1,
    'Soulianis' => 1,
    'with' => 1,
    'Magrathea\'s' => 1,
    'Greetings' => 1,
    'as' => 1,
    '...but' => 1,
    'They' => 4,
    'Meanwhile' => 1,
    'Shhh!' => 1,
    'will' => 1,
    'about' => 1,
    'Missiles?' => 1,
    'Hey' => 4,
    'Someone' => 1,
    'Terrific,' => 1,
    'Apart' => 1,
    '...or' => 1,
    '...er...' => 1,
    'explained' => 2,
    'impact' => 1,
    'Right!' => 2,
    'We\'ll' => 3,
    'I\'d' => 4,
    'OK' => 3,
    'full' => 1,
    'chirped' => 1,
    'only' => 2,
    'Impact' => 1,
    'When' => 1,
    'hold' => 2,
    'Eddie' => 1,
    'crooned' => 1,
    '...is' => 2,
    'Walk' => 2,
    'sang' => 1,
    'Though' => 4,
    'sand' => 1,
    'does' => 1,
    'Exactly' => 1,
    'cut' => 1,
    'well,' => 1,
    'Was' => 1,
    'But...' => 2,
    'yeah,' => 1,
    'have' => 2,
    'ground!' => 1,
    'Nuts' => 1,
    'Computer...' => 2,
    'began' => 2,
    'It\'ll' => 1,
    'Desolate' => 1,
    'didn\'t' => 1,
    'murmured' => 1,
    'Come,' => 3,
    'something' => 1,
    'In?' => 1,
    'loathe' => 1,
    'According' => 1,
    'Why\'s' => 1,
    'Arthur,' => 1,
    'Guard?' => 1,
    'Whose?' => 1,
    'simple' => 1,
    'Research.' => 1,
    'Because...' => 1,
    'Listen' => 1,
    'clear' => 1,
    'Somebody' => 1,
    'Initials?' => 1,
    'Z.B.,' => 1,
    'choked' => 1,
    'Night\'s' => 1,
    'Wretched' => 1,
    'persevered' => 1,
    'Can\'t' => 1,
    'Tell' => 3,
    'inquired' => 3,
    'do' => 2,
    'Hate' => 1,
    'Who...' => 1,
    'I...' => 1,
    'Hmmmm?' => 1,
    'An' => 3,
    'Dead?' => 1,
    'Slept?' => 1,
    'Fascinating' => 1,
    'doing' => 1,
    'Bring' => 1,
    'leave' => 1,
    'Late?' => 1,
    'Dent.' => 1,
    'Late,' => 1,
    'Another' => 1,
    'Slartibartfast,' => 1,
    'repeated' => 1,
    'Slartibartfast?' => 1,
    'whilst' => 1,
    'Earthman,' => 3,
    'at' => 1,
    'clearer' => 1,
    'distance' => 1,
    'seduced' => 1,
    'welcome,' => 1,
    'This,' => 1,
    'no,' => 2,
    'Pity,' => 2,
    'Mice?' => 1,
    'Indeed' => 1,
    'are' => 5,
    'Such' => 1,
    'one' => 1,
    'Time,' => 1,
    'Your' => 1,
    'intoned' => 1,
    'mention' => 1,
    'could' => 1,
    'pronounced' => 1,
    'Now.' => 1,
    'O' => 2,
    'Life!' => 1,
    'Everything!' => 1,
    'Tricky,' => 2,
    'announced' => 1,
    'Alright!' => 1,
    'We,' => 1,
    'demarcation,' => 1,
    'Might' => 1,
    'Seven' => 3,
    'declaimed' => 1,
    'Bloody' => 1,
    'Dunno,' => 4,
    'Terribly' => 1,
    'many' => 1,
    'Honoured' => 1,
    'Never' => 1,
    'never' => 1,
    'Seventy-five' => 1,
    'breathed' => 1,
    'confirmed' => 1,
    'To' => 2,
    'Now?' => 2,
    'Now,' => 4,
    'Doesn\'t' => 2,
    'Yes!' => 3,
    'observed' => 1,
    'Yes!..' => 3,
    'Of' => 2,
    'Is...' => 2,
    'Yes!!!?..' => 1,
    'Forty-two,' => 1,
    'Forty-two!' => 1,
    'howled' => 1,
    'Exactly!' => 1,
    'Who?' => 1,
    'End' => 1,
    'Zaphod!' => 1,
    'Mmmmmwwwwwerrrrr?' => 1,
    'Would' => 1,
    'Nor' => 1,
    'Hallmark,' => 1,
    'Fish?' => 1,
    'Yuch.' => 1,
    'Ow!' => 1,
    'Whatever' => 1,
    'Ancient' => 1,
    'One' => 1,
    'stuff' => 1,
    'lots' => 1,
    'His' => 1,
    'Deep' => 1,
    'Ten' => 1,
    'Everyone?' => 1,
    'Maybe.' => 1,
    'Where\'s' => 1,
    'where' => 1,
    'Hosts?' => 1,
    'Welcome' => 1,
    'Ugh!' => 1,
    'Oh!' => 1,
    'Pleased' => 1,
    'Skiing' => 1,
    'Those' => 1,
    'Forty-Two...' => 1,
    'put' => 1,
    'Since' => 1,
    'jump' => 1,
    'Something' => 1,
    'Right?' => 1,
    'For' => 2,
    'protested' => 1,
    'Treated,' => 1,
    'Diced.' => 1,
    'wailed' => 1,
    'who\'d' => 1,
    'See' => 1,
    'Emergency!' => 1,
    'blared' => 1,
    'Hostile' => 1,
    'Damnation,' => 1,
    'Difficult,' => 1,
    'Here\'s' => 1,
    'Aha,' => 1,
    'Cops!' => 1,
    'Suits' => 1,
    'chimed' => 1,
    'Because,' => 1,
    'wouldn\'t' => 1,
    'Shall' => 1,
    'Dunno.' => 1,
    'Right,' => 1,
    'Simple.' => 1,
    'pressed' => 1,
  ),
  'or' => 
  array (
    'rather' => 1,
    'heard' => 1,
    'at' => 1,
    'less' => 7,
    'protests' => 1,
    'anything.' => 1,
    'a' => 1,
    'not' => 2,
    'the' => 4,
    'has' => 1,
    'to' => 1,
    '' => 10,
    'put' => 1,
    'something.' => 2,
    'so,' => 3,
    'so' => 6,
    'I' => 1,
    'two' => 2,
    'three' => 1,
    'You\'re' => 1,
    'intelligible' => 1,
    'didn\'t' => 1,
    'just' => 1,
    'should' => 1,
    'ignore' => 1,
    'overpopulated?' => 1,
    'mine?' => 1,
    'something...' => 1,
    'not.' => 1,
    'you' => 1,
    'tell' => 1,
    'far' => 1,
    'may' => 3,
    'so.' => 1,
    'other.' => 1,
    'are' => 1,
    'define,' => 1,
  ),
  'rather' => 
  array (
    'had' => 1,
    'suspected:' => 1,
    '' => 9,
    'like' => 1,
    'a' => 1,
    'politely' => 1,
    'trying.' => 1,
    'thought' => 1,
    'involved' => 1,
    'longer:' => 1,
    'startled' => 1,
    'smart.' => 1,
    'than' => 1,
    'dull' => 1,
    'depressed' => 1,
    'faster.' => 1,
    'expensive' => 1,
    'be' => 1,
    'startled.' => 1,
    'subdued' => 1,
    'nice' => 1,
    'lucidly' => 1,
    'think' => 1,
    'ugly' => 2,
  ),
  'had' => 
  array (
    '-' => 2,
    'been' => 27,
    '' => 51,
    'four' => 1,
    'lived' => 1,
    'just' => 5,
    'earned' => 1,
    'no' => 2,
    'gone' => 4,
    'to' => 11,
    'probably' => 1,
    'the' => 8,
    'that' => 1,
    'never,' => 1,
    'first' => 2,
    'worked' => 1,
    'made' => 4,
    'skimped' => 1,
    'gathered' => 1,
    'settled' => 2,
    'company.' => 1,
    'never' => 2,
    'heard' => 2,
    'an' => 4,
    'a' => 7,
    'given' => 1,
    'eventually' => 1,
    'ever' => 2,
    'recovered' => 1,
    'either.' => 1,
    'become.' => 1,
    'dragged' => 1,
    'grown' => 2,
    'wanted' => 1,
    'nearly' => 1,
    'suddenly' => 2,
    'enough.' => 1,
    'known' => 2,
    'waited' => 1,
    'gripped' => 1,
    'plenty' => 1,
    'sent' => 1,
    'seen' => 1,
    'finally' => 2,
    'announced' => 1,
    'built' => 2,
    'bargained' => 1,
    'arrived.' => 1,
    'very' => 2,
    'existed' => 1,
    'irritably' => 1,
    'flipped' => 1,
    'lain' => 1,
    'turned' => 3,
    'chosen' => 1,
    'inevitably' => 1,
    'recently' => 1,
    'always' => 3,
    'formed' => 1,
    'taken' => 1,
    'gone.' => 1,
    'gone!' => 1,
    'sunk' => 1,
    'had' => 2,
    'happened' => 2,
    'quite' => 1,
    'your' => 1,
    'now' => 2,
    'fallen.' => 1,
    'died' => 1,
    'jammed' => 1,
    'come' => 1,
    'such' => 1,
    'winked' => 1,
    'moved' => 1,
    'already' => 2,
    'paused' => 1,
    'insisted' => 1,
    'expected' => 1,
    'become' => 1,
    'split' => 1,
    'crept' => 1,
    'left' => 1,
    'found' => 1,
    'swung' => 1,
    'come,' => 2,
    'in' => 1,
    'been.' => 1,
    'it' => 1,
    'decided' => 1,
    'caved' => 1,
    'disappeared' => 1,
    'locked' => 1,
    'cauterized' => 1,
    'thoughtfully' => 1,
    'claimed' => 1,
    'got' => 1,
    'vanished' => 1,
    'achieved' => 1,
    'hardly' => 1,
    'happened.' => 1,
    'plunged' => 1,
    'their' => 1,
    'passed' => 1,
    'they?' => 1,
    'started' => 1,
    'related' => 1,
    'time' => 1,
    'described' => 1,
    'not' => 1,
    'souped' => 1,
    'this' => 1,
    'said' => 1,
    'any' => 1,
    'almost' => 1,
  ),
  'problem,' => 
  array (
    'which' => 1,
    'but' => 1,
    '-' => 2,
    'I' => 1,
    'to' => 1,
  ),
  'which' => 
  array (
    'was' => 10,
    'is' => 7,
    'no' => 1,
    'more' => 1,
    '' => 31,
    'allow' => 1,
    'you' => 3,
    'we' => 1,
    'winked' => 1,
    'Ford' => 3,
    'looked' => 2,
    'any' => 1,
    'shine' => 1,
    'has' => 3,
    'really' => 1,
    'by' => 1,
    'had' => 3,
    'the' => 6,
    'keeps' => 1,
    'used' => 2,
    'could' => 1,
    'swayed' => 1,
    'hovered' => 1,
    'carried' => 1,
    'made' => 1,
    'sidled' => 1,
    'said' => 1,
    'gives' => 1,
    'haven\'t' => 1,
    'quite' => 1,
    'seemed' => 1,
    'contrives' => 1,
    'suddenly' => 1,
    'required' => 1,
    'travels' => 1,
    'danced' => 1,
    'I' => 1,
    'obviously' => 1,
    'controlled' => 1,
    'settled' => 1,
    'contained' => 1,
    'way' => 1,
    'still' => 1,
    'they' => 4,
    'he' => 1,
    'it' => 1,
    'involved' => 1,
    'can' => 2,
    'clearly' => 1,
    'passed' => 1,
    'promptly' => 1,
    'happened' => 1,
    'stood' => 1,
  ),
  'was' => 
  array (
    'this:' => 2,
    'that' => 10,
    'right,' => 1,
    'lost' => 3,
    'probably' => 2,
    '' => 95,
    'in' => 10,
    'only' => 5,
    'about' => 7,
    'the' => 20,
    'looking' => 7,
    'quite' => 5,
    'hung' => 1,
    'he' => 1,
    'of' => 2,
    'out' => 1,
    'advancing' => 1,
    'forty,' => 1,
    'also' => 4,
    'by' => 3,
    'a' => 40,
    'particularly' => 1,
    'to' => 3,
    'out.' => 1,
    'just' => 4,
    'when' => 1,
    'on' => 5,
    'for' => 2,
    'often' => 2,
    'filled' => 1,
    'not' => 9,
    'plausible' => 1,
    'something' => 3,
    'difficult' => 1,
    'any' => 1,
    'desperate' => 1,
    'Arthur\'s' => 1,
    'Mr.' => 1,
    'beginning' => 4,
    'startled' => 1,
    'concentrating.' => 1,
    'astonished' => 2,
    'played' => 1,
    'arguing' => 1,
    'surprised' => 3,
    'worried.' => 1,
    'trying' => 5,
    'substantially' => 1,
    'as' => 2,
    'more' => 4,
    'and' => 1,
    'far' => 1,
    'going' => 8,
    'smiling' => 1,
    'doing.' => 1,
    'moving' => 2,
    'exactly' => 3,
    'auditioning' => 1,
    'one' => 2,
    'published' => 1,
    'time' => 1,
    'very' => 9,
    'at' => 4,
    'born' => 1,
    'silent' => 1,
    'running' => 1,
    'staring' => 1,
    'raced' => 1,
    'happening' => 1,
    'what' => 4,
    'going.' => 1,
    'prepared.' => 1,
    'no' => 3,
    'wonderful.' => 1,
    'nowhere' => 1,
    'annoyed.' => 1,
    'so' => 10,
    'called' => 2,
    'finally' => 3,
    'governed,' => 1,
    'locked' => 1,
    'why' => 2,
    'all' => 5,
    'heightened' => 1,
    'amazingly' => 1,
    'supported' => 1,
    'fitted' => 1,
    'best' => 1,
    'roughly' => 1,
    'constructed' => 1,
    'virtually' => 2,
    'clearly' => 3,
    'thick' => 2,
    'because' => 3,
    'thoroughly' => 1,
    'right' => 1,
    'Ford' => 1,
    'nor' => 1,
    'quiet.' => 1,
    'an' => 6,
    'their' => 1,
    'surprised.' => 1,
    'glad' => 1,
    'grinning' => 2,
    'delighted.' => 1,
    'still' => 5,
    'holding' => 1,
    'experiencing' => 1,
    'lying' => 2,
    'easy,' => 1,
    'horrified' => 1,
    'now' => 5,
    'too' => 3,
    'sobbing' => 1,
    'able' => 5,
    'pointing.' => 1,
    'me' => 1,
    'done' => 1,
    'sheer' => 1,
    'lost.' => 1,
    'worse' => 1,
    'rising' => 1,
    'rasping' => 1,
    'therefore' => 2,
    'really' => 2,
    'ready' => 1,
    'about!' => 1,
    'interrupted' => 1,
    'obviously' => 1,
    'it?' => 2,
    'young.' => 1,
    'Southend.' => 1,
    'that?' => 1,
    'all.' => 1,
    'wildly' => 1,
    'ill' => 1,
    'discovered' => 1,
    'rather' => 4,
    'awarded' => 1,
    'perfectly' => 1,
    'mostly' => 1,
    'carried' => 1,
    'low' => 2,
    'getting' => 1,
    'right.' => 1,
    'saying' => 2,
    'wave' => 1,
    'always' => 3,
    'tapping' => 1,
    'renowned' => 1,
    'that...' => 1,
    'told' => 1,
    'seeing' => 1,
    'fairly' => 1,
    'back' => 1,
    'stuck' => 1,
    'plying' => 1,
    'silence' => 1,
    'there' => 3,
    'either' => 1,
    'disturbed' => 1,
    'frankly' => 1,
    'which.' => 1,
    'terribly' => 1,
    'saying.' => 1,
    'absolutely' => 1,
    'meant' => 1,
    'happening,' => 1,
    'wild,' => 1,
    'half' => 1,
    'this' => 2,
    'waving' => 1,
    'saying,' => 1,
    'piqued' => 1,
    'humming' => 1,
    'enough' => 1,
    'unfolding' => 1,
    'blurred' => 1,
    'almost,' => 1,
    'likely' => 1,
    'talking' => 2,
    'old,' => 1,
    'shocking.' => 1,
    'thrown' => 1,
    'approaching' => 1,
    'somewhat' => 1,
    'nothing' => 3,
    'silence.' => 1,
    'standing' => 5,
    'addressing' => 3,
    'generally' => 1,
    'desperately' => 1,
    'like' => 2,
    'soon' => 1,
    'his' => 2,
    'relieved' => 1,
    'rubbery.' => 1,
    'fresh' => 1,
    'visible' => 1,
    'reminded' => 1,
    'less' => 1,
    'worrying' => 1,
    'using' => 1,
    'clever,' => 1,
    'take' => 1,
    'taken' => 1,
    'sent' => 1,
    'true,' => 1,
    'later' => 1,
    'thin' => 1,
    'deeply' => 1,
    'muck' => 1,
    'misinterpreted' => 1,
    'utterly' => 1,
    'absolute' => 1,
    'denied' => 1,
    'unable' => 1,
    'irritating' => 1,
    'impossible' => 1,
    'anything' => 1,
    'pointing' => 1,
    'indeed' => 1,
    'commissioned,' => 1,
    'destroyed' => 1,
    'built,' => 1,
    'hat' => 1,
    'installed' => 1,
    'losing' => 1,
    'made' => 1,
    'suspended' => 1,
    'shining,' => 1,
    'playing,' => 1,
    'much' => 1,
    'worn' => 1,
    'Loonquawl,' => 1,
    'watching' => 1,
    'unbearable.' => 1,
    'how' => 1,
    'knee' => 1,
    'purple.' => 1,
    'crazier' => 1,
    'currently' => 1,
    'occasionally' => 1,
    'completed,' => 1,
    'realized' => 1,
    'accidentally' => 1,
    'busy' => 2,
    'destroyed.' => 1,
    'leading' => 1,
    'dead' => 1,
    'extremely' => 1,
    'brought' => 1,
    'punctuated' => 1,
    'billowing' => 1,
    'anywhere' => 1,
    'fail-safe' => 1,
    'unheard' => 1,
    'empty,' => 1,
    'from,' => 1,
    'assigned' => 1,
  ),
  'this:' => 
  array (
    'most' => 1,
    'Two' => 1,
    '-' => 2,
    'So' => 1,
  ),
  'most' => 
  array (
    '' => 14,
    'of' => 6,
    'remarkable' => 2,
    'was' => 2,
    'important' => 1,
    'brain-wretching' => 1,
    'respects' => 1,
    'welcome.' => 1,
    'unpleasant' => 1,
    'races' => 1,
    'people\'s' => 1,
    'improbable' => 1,
    'successful' => 1,
    'seasoned' => 1,
    'gratifying,' => 1,
    'enthusiastic' => 1,
    'intelligent' => 1,
    'independent' => 1,
    'popular' => 1,
    'amazing' => 1,
    'fantastic' => 1,
    'people' => 1,
    'mysterious' => 1,
  ),
  'people' => 
  array (
    'on' => 2,
    'were' => 1,
    'for' => 2,
    'always' => 1,
    'about' => 2,
    'to' => 2,
    'dash' => 1,
    'of' => 3,
    'would' => 1,
    'the' => 1,
    'like' => 2,
    'went' => 1,
    'in' => 2,
    'realize' => 1,
    'only' => 1,
    'weren\'t' => 1,
    'didn\'t' => 1,
    'around,' => 1,
    'he' => 1,
    'out' => 1,
    '' => 4,
    'off' => 1,
    'born?' => 1,
    'waiting' => 1,
    'must' => 1,
    'locked' => 1,
    'and' => 1,
    'gratuitously' => 1,
  ),
  'on' => 
  array (
    'it' => 7,
    'the' => 81,
    '' => 63,
    'Earth,' => 2,
    'its' => 4,
    'a' => 13,
    'Thursday' => 1,
    'to' => 14,
    'other' => 1,
    'each.' => 1,
    'display...' => 1,
    'display' => 2,
    'his' => 10,
    'Earth' => 2,
    'whisky,' => 1,
    'these' => 1,
    'Betelgeuse,' => 1,
    'with' => 2,
    'which' => 3,
    'top' => 4,
    'them!' => 1,
    'them' => 3,
    'Earth.' => 1,
    'their' => 6,
    'Alpha' => 1,
    'behalf' => 1,
    'across' => 1,
    'Easter' => 1,
    'Betelgeuse' => 4,
    'exercising' => 1,
    'passing' => 1,
    'somewhere' => 1,
    'board.' => 1,
    'one' => 3,
    'brainwave' => 1,
    'Nelson\'s' => 1,
    'him.' => 1,
    'this' => 4,
    'it.' => 2,
    'Ford' => 2,
    'him.)' => 1,
    'now...' => 1,
    'humming.' => 1,
    'every' => 1,
    'and' => 3,
    'fire,' => 1,
    'Damogran.' => 1,
    'regardless.' => 1,
    'down' => 1,
    'my' => 2,
    'Arthur' => 1,
    'home' => 1,
    'that' => 2,
    'him' => 2,
    'Monday.' => 1,
    'silently' => 1,
    'conventional' => 1,
    'them.' => 2,
    '-' => 2,
    'in' => 3,
    'through' => 3,
    'intricately' => 1,
    'counting' => 1,
    'both' => 1,
    'well' => 1,
    'was' => 1,
    'tables' => 1,
    'you' => 1,
    'an' => 2,
    'Vroomfondel.' => 1,
    'strike!' => 1,
    'your' => 1,
    'new' => 1,
    'parachutes.' => 1,
    'Betelgeuse.' => 1,
    'further' => 1,
    'something' => 1,
    'our' => 3,
    'high' => 1,
    'account' => 1,
    'planet.' => 1,
    'us' => 1,
    'it,' => 1,
    'important' => 1,
  ),
  'it' => 
  array (
    'were' => 3,
    'wasn\'t' => 4,
    '' => 86,
    'was' => 66,
    'would' => 7,
    'is' => 12,
    'scores' => 1,
    'has' => 2,
    'happened' => 1,
    'for' => 6,
    'made' => 2,
    'reflected' => 2,
    'had' => 9,
    'round' => 2,
    'away' => 1,
    'got' => 1,
    'roll' => 1,
    'must' => 2,
    'was.' => 5,
    'unless' => 1,
    'while' => 1,
    'as' => 8,
    'sounded' => 1,
    'fitfully' => 1,
    'exactly.' => 1,
    'to' => 10,
    'didn\'t' => 3,
    'says.' => 2,
    'one' => 1,
    'did.' => 1,
    'seemed' => 5,
    'fitted' => 1,
    'in' => 6,
    'around' => 2,
    'says,' => 2,
    'on' => 2,
    'beneath' => 1,
    'assumes' => 1,
    'can\'t' => 1,
    'if' => 1,
    'still' => 3,
    'and' => 9,
    'meant,' => 1,
    'then?' => 1,
    'with' => 4,
    'hit.' => 1,
    'just' => 3,
    'now.' => 1,
    'reached' => 1,
    'vests' => 1,
    'came' => 1,
    'careered' => 1,
    'floated' => 1,
    'climbed,' => 2,
    'that' => 1,
    'lay' => 1,
    'the' => 2,
    'again' => 1,
    'no' => 2,
    'well,' => 1,
    'on.' => 1,
    'only' => 1,
    'wouldn\'t' => 3,
    'himself:' => 1,
    'over' => 3,
    'works,' => 1,
    'from' => 1,
    'out' => 3,
    'annoys' => 1,
    'might' => 4,
    'totally' => 1,
    'into' => 3,
    'up' => 4,
    'swam' => 1,
    'existed' => 1,
    'says' => 2,
    'does,' => 1,
    'a' => 6,
    'say' => 1,
    'give' => 2,
    'all' => 6,
    'really.' => 1,
    'like' => 1,
    'of' => 1,
    'anymore.' => 1,
    'than' => 1,
    'rather' => 2,
    'is.' => 2,
    'begins' => 1,
    'takes' => 1,
    'travels' => 1,
    'goes' => 1,
    'noticed' => 1,
    'closed' => 1,
    'too,' => 2,
    'raced' => 1,
    'worked,' => 1,
    'looks' => 1,
    'or' => 2,
    'mean?' => 1,
    'said,' => 4,
    'before!' => 1,
    'closed,' => 1,
    'is,' => 1,
    'on!' => 1,
    'somehow' => 1,
    'back' => 2,
    'passes' => 1,
    'became' => 1,
    'did' => 1,
    'said.' => 1,
    'Further' => 1,
    'suddenly' => 2,
    'caught' => 1,
    'simple' => 1,
    'said' => 1,
    'out.' => 1,
    'continued.' => 1,
    'suspiciously.' => 1,
    'slid' => 1,
    'tends' => 1,
    'will' => 5,
    'doesn\'t' => 2,
    'followed' => 1,
    'burbled,' => 1,
    'turns' => 1,
    'enough' => 1,
    'too?' => 1,
    'is...' => 1,
    'isn\'t,' => 1,
    'anyway?' => 1,
    'all.' => 1,
    'functioned' => 1,
    'invariably' => 1,
    'reviving.' => 1,
    'safe?' => 1,
    'together.' => 1,
    'every' => 1,
    'whined' => 1,
    'then' => 1,
    'ended' => 1,
    'thought.' => 1,
    'my' => 1,
    'later' => 1,
    'about' => 1,
    'needs' => 1,
    'fell' => 1,
    'been' => 1,
    'open,' => 1,
    'very' => 2,
    'by' => 1,
    'with?' => 1,
    'can' => 1,
    'occurred' => 1,
    'through' => 1,
    'was,' => 1,
    'later,' => 1,
    'have' => 1,
    'seemed.' => 1,
    'here.' => 1,
    'soared' => 1,
    'at' => 1,
    'took' => 2,
    'properly' => 1,
    'gave' => 1,
    'dropped' => 1,
    'planed' => 1,
    'you' => 1,
    'save' => 1,
    'off.' => 1,
    'spoke' => 1,
    'not.' => 1,
    'off' => 2,
    'occurs' => 1,
    'won\'t' => 1,
    'flashed' => 1,
    'also' => 1,
    'shall' => 1,
    'gleamed' => 1,
    'his' => 1,
    'myself.' => 1,
    'means' => 1,
    'matter?' => 1,
    'but' => 1,
    'moved' => 1,
    'right' => 1,
    'isn\'t' => 1,
    'easier' => 1,
    'afterwards' => 2,
    'stopped,' => 1,
    'up,' => 1,
    'stood' => 1,
    'most' => 1,
  ),
  'were' => 
  array (
    'unhappy' => 1,
    'suggested' => 1,
    'largely' => 1,
    'unhappy.' => 1,
    'mean,' => 1,
    'miserable,' => 1,
    'increasingly' => 1,
    '' => 22,
    'quite' => 2,
    'on' => 1,
    'enjoying' => 1,
    'printed' => 1,
    'a' => 3,
    'talking' => 1,
    'meant' => 1,
    'there.' => 1,
    'running' => 1,
    'screaming' => 1,
    'doing' => 3,
    'looking' => 1,
    'resplendent' => 1,
    'for.' => 1,
    'almost' => 1,
    'at' => 1,
    'five' => 1,
    'standing' => 1,
    'no' => 1,
    'called' => 1,
    'passing' => 1,
    'the' => 5,
    'generally' => 1,
    'attached' => 1,
    'likely' => 1,
    'in' => 3,
    'going' => 2,
    'rescued.' => 1,
    'astronomical.' => 1,
    'all' => 1,
    'squeezing' => 1,
    'often' => 2,
    'raked' => 1,
    'contoured' => 1,
    'floating' => 1,
    'coming' => 1,
    'you' => 1,
    'ill' => 1,
    'each' => 1,
    'over,' => 2,
    'brave,' => 1,
    'high,' => 1,
    'real' => 3,
    'created' => 1,
    'hurled' => 1,
    'it' => 1,
    'reflected' => 1,
    'only' => 1,
    'dullish' => 1,
    'covered' => 1,
    'cold' => 1,
    'they,' => 1,
    'there' => 2,
    'missiles...' => 1,
    'index' => 1,
    'far' => 1,
    'misinterpreted' => 1,
    'hardly' => 1,
    'shooting,' => 1,
    'gradually' => 1,
    'as' => 1,
    'upset!' => 1,
    'furious.' => 1,
    'furious?' => 1,
    'able' => 1,
    'deployed' => 1,
    'shown' => 1,
    'aware' => 1,
    'Lunkwill' => 1,
    'being' => 1,
    'white' => 1,
    'cracked' => 1,
    'thronged' => 1,
    'fluttering' => 1,
    'ready' => 1,
    'kids,' => 1,
    'wiped' => 1,
    'sitting' => 1,
    'poised' => 1,
    'meeting' => 1,
    'stuffing' => 1,
    'proposing' => 1,
    'they' => 1,
    'about' => 1,
    'shooting.' => 1,
    'winding' => 1,
    'squatting.' => 1,
    'those' => 1,
    'directly' => 1,
  ),
  'unhappy' => 
  array (
    'for' => 1,
    'millennia' => 1,
    '' => 1,
  ),
  'much' => 
  array (
    'of' => 3,
    '' => 6,
    'damage' => 1,
    'really.' => 1,
    'they' => 1,
    'you' => 1,
    'the' => 2,
    'a' => 1,
    'as' => 5,
    'difference' => 1,
    'else' => 1,
    'to' => 3,
    'about' => 3,
    'for' => 1,
    'on' => 1,
    'higher.' => 1,
    'longer' => 1,
    'sought' => 1,
    'but' => 1,
    'in' => 1,
    'inclined' => 1,
  ),
  'time.' => 
  array (
    'Many' => 1,
    '-' => 2,
    '' => 2,
    'Message' => 2,
    'Computer!' => 1,
    'One' => 1,
    'Somewhere' => 1,
    'But' => 1,
    'Then' => 1,
    'Gone.' => 1,
    'A' => 1,
  ),
  'Many' => 
  array (
    '' => 3,
    'were' => 1,
    'people' => 1,
    'had' => 1,
    'respectable' => 1,
    'men' => 1,
  ),
  'solutions' => 
  array (
    'were' => 1,
  ),
  'suggested' => 
  array (
    'for' => 1,
    '' => 1,
  ),
  'but' => 
  array (
    'most' => 1,
    'they' => 7,
    'he' => 6,
    '' => 41,
    'I' => 3,
    'was' => 3,
    'a' => 3,
    'other' => 1,
    'Ford' => 1,
    'Mr.' => 1,
    'very' => 1,
    'the' => 9,
    'when' => 2,
    'there' => 3,
    'annoyingly' => 1,
    'fascinating' => 1,
    'to' => 2,
    'here' => 1,
    'just' => 1,
    'today' => 1,
    'by' => 1,
    'in' => 2,
    'all' => 1,
    'otherwise,' => 1,
    'it' => 8,
    'this' => 3,
    'bad' => 1,
    'mostly' => 2,
    'what' => 2,
    'then' => 2,
    'from' => 1,
    'that' => 2,
    'it\'s' => 1,
    'now' => 3,
    'Arthur' => 2,
    'slowly,' => 1,
    'for' => 1,
    'look!' => 1,
    'you' => 2,
    'could' => 2,
    'something' => 1,
    'do' => 1,
    'minus' => 1,
    'being' => 1,
    'meant' => 1,
    'got' => 1,
    'not' => 5,
    'that\'s' => 1,
    'had' => 1,
    'those' => 1,
    'no' => 1,
    'she' => 1,
    'keep' => 1,
    'shiver' => 1,
    'only' => 2,
    'as' => 1,
    'apart' => 1,
    'much' => 1,
    'his' => 1,
    'I\'ll' => 1,
    'Marvin' => 1,
    'trying' => 1,
    'slept.' => 1,
    'infinite,' => 1,
    'somewhat' => 1,
    'before' => 1,
    'even' => 1,
    'inexorably' => 1,
    'Zaphod' => 1,
    'I\'d' => 1,
    'we\'d' => 1,
    'also' => 1,
    'one' => 1,
  ),
  'these' => 
  array (
    'were' => 1,
    '' => 6,
    'and' => 1,
    'occasions.' => 1,
    'bulldozers' => 1,
    'years.' => 1,
    'years,' => 1,
    'creatures.' => 1,
    'enlightened' => 1,
    'five' => 1,
    'strange' => 1,
    '(the' => 1,
    'creatures\'' => 1,
    'nagging' => 1,
    'guys?' => 1,
    'guys,' => 1,
  ),
  'largely' => 
  array (
    '' => 2,
    'of' => 1,
    'tax' => 1,
  ),
  'concerned' => 
  array (
    'with' => 1,
  ),
  'with' => 
  array (
    'the' => 25,
    'digital' => 1,
    'this' => 5,
    'a' => 32,
    '' => 67,
    'Arthur' => 1,
    'his' => 12,
    'axes' => 1,
    'you.' => 1,
    'fire' => 1,
    'at' => 1,
    'visions' => 1,
    'oddly' => 1,
    'some' => 3,
    'union' => 1,
    'you' => 3,
    'rage,' => 1,
    'what' => 1,
    'him,' => 1,
    'you?' => 1,
    'him' => 2,
    'mind-buggering' => 1,
    'people,' => 1,
    'distortion' => 1,
    'easy' => 1,
    'an' => 3,
    'thin' => 1,
    'it.' => 1,
    'long' => 1,
    'surgery.' => 1,
    'iron' => 2,
    'silken' => 1,
    'Arthur,' => 1,
    'musty' => 1,
    'itself' => 1,
    'nothing' => 1,
    'very' => 1,
    'himself.' => 1,
    'me' => 1,
    'horror' => 1,
    'wonder.' => 1,
    'nerve' => 1,
    'crinkly' => 1,
    'my' => 3,
    'detached' => 1,
    '-' => 1,
    'only' => 1,
    'large' => 1,
    'excitement.' => 2,
    'astonishment' => 1,
    'disgust' => 1,
    'pleased' => 1,
    'Genuine' => 1,
    'that' => 1,
    'great' => 1,
    'yourself' => 1,
    'anger,' => 1,
    'Earth' => 1,
    'Zaphod' => 2,
    'lots' => 1,
    'white' => 1,
    'half' => 1,
    'quite' => 1,
    'your' => 1,
    'hope' => 1,
    'not' => 1,
    'anticipation...' => 1,
    'me?' => 1,
    'distaste' => 1,
    'any' => 1,
    'it' => 1,
    'black' => 1,
    'its' => 1,
    'severe' => 1,
    'decay.' => 1,
    'all' => 2,
    'other' => 1,
    'polite' => 1,
    'me.' => 1,
    'slight' => 1,
    'unimaginable' => 1,
    'Arthur.' => 1,
    'life,' => 1,
    'rich' => 1,
    'brief' => 1,
    'Fook,' => 1,
    'second' => 1,
    'breathless' => 1,
    'each' => 1,
    'cheerful' => 1,
    'subtitles.' => 1,
    'expectancy.' => 1,
    'infinite' => 1,
    'you,' => 1,
    'us.' => 1,
    'one' => 1,
    'space' => 1,
    'fake' => 1,
    'laughter.' => 1,
    'soft' => 1,
    'sympathy.' => 1,
    'exotic' => 1,
    'sudden' => 1,
    'them' => 1,
    'static.' => 1,
    'energy' => 1,
    'which' => 1,
    'health,' => 1,
    'speed' => 1,
    'awareness' => 1,
  ),
  'movements' => 
  array (
    'of' => 1,
  ),
  'pieces' => 
  array (
    'of' => 3,
    '' => 1,
  ),
  'paper,' => 
  array (
    'which' => 1,
  ),
  'odd' => 
  array (
    'because' => 1,
    '' => 2,
    'little' => 1,
    'about' => 2,
    'felling' => 1,
    'sensation' => 1,
  ),
  'because' => 
  array (
    'on' => 1,
    'it' => 9,
    '' => 18,
    'he' => 8,
    'fifteen' => 1,
    'they\'ll' => 1,
    'you\'re' => 1,
    'no' => 2,
    'they' => 3,
    'billions' => 1,
    'their' => 1,
    'of' => 2,
    'there' => 1,
    'underneath' => 1,
    'Reason' => 1,
    'I\'d' => 1,
    'that' => 1,
    'nothing' => 1,
    'we' => 1,
    'I' => 1,
  ),
  'whole' => 
  array (
    'it' => 1,
    'life' => 1,
    'planet.' => 1,
    'string' => 1,
    '' => 5,
    'episode' => 1,
    'world' => 1,
    'Poghril' => 1,
    'ship.' => 1,
    'of' => 1,
    'place' => 1,
    'attention.' => 1,
    'vast' => 1,
    'alien' => 1,
    'a' => 1,
    'section' => 1,
    'business' => 1,
    'story.' => 1,
    'experience' => 1,
    'thing,' => 1,
  ),
  'wasn\'t' => 
  array (
    'the' => 2,
    '' => 4,
    'him.' => 1,
    'making' => 1,
    'worth' => 1,
    'anybody' => 1,
    'much' => 1,
    'previously' => 1,
    'all' => 1,
    'perfectly' => 1,
    'fair' => 1,
    'doing' => 1,
    'quite' => 2,
    'important,' => 1,
    'to' => 1,
    'aware' => 1,
  ),
  'paper' => 
  array (
    'that' => 1,
    'bag' => 1,
    '' => 1,
    'hats' => 1,
    'and' => 1,
    'from' => 1,
  ),
  'unhappy.' => 
  array (
    'And' => 1,
  ),
  'And' => 
  array (
    'so' => 2,
    '' => 7,
    'then,' => 1,
    'drink,' => 1,
    'again.' => 1,
    'he' => 1,
    'can' => 1,
    'if' => 3,
    'no' => 2,
    'quickly' => 1,
    'boiled...' => 1,
    'then' => 3,
    'I' => 7,
    'still' => 1,
    'the' => 6,
    'there' => 2,
    'they\'ll' => 1,
    'that\'s' => 2,
    'what\'s' => 1,
    'what' => 2,
    'hooptiously' => 1,
    'you' => 2,
    'shouting,' => 2,
    'yesterday' => 1,
    'of' => 1,
    'Arthur,' => 1,
    'thus' => 1,
    'don\'t...' => 1,
    'you\'ll' => 1,
    'since' => 1,
    'hey,' => 1,
    'wow!' => 1,
    'its' => 1,
    'it' => 2,
    'as' => 1,
    'to' => 1,
    'are' => 2,
    'Everything!..' => 1,
    'you\'re' => 1,
    'stop' => 1,
    'before' => 1,
    'five' => 1,
    'they' => 1,
    'this' => 2,
  ),
  'problem' => 
  array (
    'remained;' => 1,
    '' => 2,
    'of' => 1,
    'is' => 1,
    'isn\'t' => 1,
  ),
  'remained;' => 
  array (
    'lots' => 1,
  ),
  'lots' => 
  array (
    'of' => 5,
  ),
  'mean,' => 
  array (
    '' => 1,
    'why\'s' => 1,
    '-' => 2,
    'here' => 1,
    'don\'t' => 1,
    'yes' => 1,
  ),
  'them' => 
  array (
    'were' => 1,
    'off,' => 1,
    'had' => 2,
    'would' => 1,
    'wasn\'t' => 1,
    'driving' => 1,
    'had,' => 1,
    '' => 15,
    'for.' => 1,
    '-' => 1,
    'have' => 1,
    'and' => 6,
    'where' => 1,
    'they' => 2,
    'if' => 1,
    'particularly' => 1,
    'one' => 1,
    'a' => 2,
    'there' => 2,
    'anyway.' => 1,
    'to' => 5,
    'from' => 1,
    'going' => 1,
    'out!' => 1,
    'out' => 3,
    'both' => 1,
    'on.' => 1,
    'cling' => 1,
    'back' => 1,
    'up' => 5,
    'die?' => 1,
    'up.' => 1,
    'said,' => 1,
    'it' => 1,
    'up...' => 1,
    'in' => 5,
    'was' => 3,
    'excitement' => 1,
    'as' => 2,
    'two' => 1,
    'into' => 1,
    'now' => 1,
    'wildly.' => 1,
    'flattened' => 1,
    'by' => 1,
    'the' => 2,
    'but' => 1,
    'through' => 1,
    'myself,' => 1,
    'at' => 2,
    'on' => 1,
    'ran' => 1,
    'simultaneously.' => 1,
    'published' => 1,
    'started' => 1,
    'again' => 1,
    'next' => 1,
    'stood' => 1,
  ),
  'miserable,' => 
  array (
    'even' => 1,
  ),
  'even' => 
  array (
    'the' => 2,
    '' => 11,
    'tells' => 1,
    'have' => 1,
    'had' => 1,
    'more' => 2,
    'talk' => 1,
    'work' => 1,
    'cities' => 1,
    'supposing' => 1,
    'I' => 1,
    'a' => 1,
    'now' => 1,
    'guess' => 1,
    'before' => 1,
    'finished' => 1,
    'so' => 1,
    'myself?' => 1,
    'death.' => 1,
    'for' => 1,
  ),
  'ones' => 
  array (
    'with' => 1,
    'flitted' => 1,
    'who' => 1,
  ),
  'watches.' => 
  array (
    'Many' => 1,
  ),
  'increasingly' => 
  array (
    'of' => 1,
    'obsessed' => 1,
  ),
  'opinion' => 
  array (
    'that' => 1,
  ),
  'they\'d' => 
  array (
    '' => 2,
    'been' => 2,
    'known' => 1,
    'just' => 1,
    'settled' => 1,
  ),
  'made' => 
  array (
    '' => 9,
    'of' => 1,
    'him' => 2,
    'one' => 1,
    'on' => 2,
    'any' => 1,
    'no' => 2,
    'a' => 2,
    'much' => 1,
    'amazingly' => 1,
    'this' => 1,
    'interstellar' => 1,
    'them' => 1,
    'touch-sensitive' => 1,
    'to' => 2,
    'the' => 3,
    'an' => 1,
    'nervous' => 1,
    'out' => 2,
    'for' => 1,
  ),
  'big' => 
  array (
    'mistake' => 1,
    'one.' => 1,
    'yellow' => 1,
    'hello' => 2,
    'it' => 1,
    'league' => 1,
    'thing' => 1,
    'news' => 1,
    'Z' => 1,
    '' => 3,
    'and' => 1,
    'effort' => 1,
    'show' => 1,
  ),
  'mistake' => 
  array (
    'in' => 1,
  ),
  'coming' => 
  array (
    'down' => 1,
    'to' => 1,
    'from' => 1,
    'up' => 1,
    'towards' => 1,
    'out.' => 1,
    '' => 1,
  ),
  'down' => 
  array (
    'from' => 2,
    'his' => 2,
    'to' => 9,
    'the' => 9,
    'and' => 7,
    'if' => 1,
    'beside' => 2,
    '' => 16,
    'in' => 6,
    'Mr.' => 1,
    'or' => 2,
    'it' => 1,
    'into' => 7,
    'a' => 5,
    'on' => 2,
    'there,' => 1,
    'at' => 5,
    'again' => 1,
    'next' => 1,
    'its' => 1,
    'my' => 1,
    'well.' => 1,
    'there' => 1,
    'there?' => 1,
    'which' => 1,
    'over' => 1,
    'towards' => 1,
    'of' => 1,
    'here,' => 1,
  ),
  'from' => 
  array (
    'the' => 32,
    'an' => 2,
    'point' => 2,
    '' => 22,
    'his' => 2,
    'a' => 12,
    'Guildford' => 2,
    'them.' => 1,
    'him.' => 1,
    'certain' => 2,
    'one' => 2,
    'Marks' => 1,
    'your' => 2,
    'it.' => 1,
    'their' => 2,
    'focusing.' => 1,
    'Arthur' => 1,
    'Betelgeuse' => 2,
    'no' => 1,
    'its' => 3,
    'those' => 1,
    'where' => 1,
    'Betelgeuse,' => 1,
    'countless' => 1,
    'end' => 1,
    'famine' => 1,
    'Ford.' => 1,
    'fourth' => 1,
    'Croydon.' => 1,
    'The' => 1,
    'Alpha' => 2,
    'any' => 1,
    'space,' => 1,
    'way' => 1,
    'ancient' => 1,
    'that.' => 1,
    'that?' => 1,
    'her' => 1,
    'view.' => 1,
    'another' => 1,
    'our' => 1,
    'I' => 1,
    'under' => 1,
    'nowhere.' => 1,
    'my' => 1,
    'really' => 1,
    'beneath' => 1,
    'Blagulon' => 1,
    'him' => 1,
    'it;' => 1,
  ),
  'trees' => 
  array (
    'in' => 1,
    'had' => 1,
    '' => 1,
  ),
  'first' => 
  array (
    'place.' => 1,
    '' => 8,
    'arrived' => 1,
    'crawled' => 1,
    'rays' => 1,
    'Ford' => 1,
    'place' => 1,
    'phrase' => 1,
    'against' => 1,
    'instead' => 1,
    'was' => 1,
    'three' => 1,
    'activating' => 1,
    'day' => 1,
    'time' => 1,
    'half' => 1,
    'floor' => 1,
    'to' => 1,
    'two?' => 1,
    'two' => 1,
    'phase' => 1,
  ),
  'place.' => 
  array (
    '' => 1,
    'This' => 1,
    'The' => 1,
    'You\'ll' => 1,
    '-' => 1,
  ),
  'some' => 
  array (
    '' => 15,
    'people' => 1,
    'fifteen' => 1,
    'success.' => 1,
    'girl' => 1,
    'arrangement,' => 1,
    'sense' => 2,
    'reason,' => 1,
    'dust' => 1,
    'kind' => 3,
    'peanuts.' => 2,
    'strange' => 1,
    'green' => 1,
    'more' => 1,
    'of' => 5,
    'thinkers' => 1,
    'other' => 1,
    'small' => 1,
    'weeks' => 1,
    'initial' => 1,
    'exotic' => 1,
    'dartoid' => 1,
    'words.' => 1,
    'ludicrous' => 1,
    'ancient' => 1,
    'five-million-year-old' => 1,
    'subtle' => 1,
    'kind,' => 1,
    'while' => 1,
    'mistake,' => 1,
    'very' => 1,
    'wonderful' => 1,
    'Vegan' => 1,
    'form' => 1,
    'heavy' => 1,
    'things' => 1,
  ),
  'said' => 
  array (
    'that' => 6,
    '' => 43,
    'Arthur,' => 38,
    'no' => 1,
    'Arthur' => 23,
    'Arthur.' => 27,
    'green' => 1,
    'the' => 37,
    'Ford,' => 36,
    'urgently.' => 1,
    'Ford.' => 42,
    'Ford' => 16,
    'in' => 3,
    'Mr.' => 4,
    'to' => 7,
    'nothing.' => 1,
    'gaily,' => 1,
    'a' => 2,
    'again.' => 1,
    'though' => 1,
    'Zaphod' => 17,
    'it' => 3,
    'they' => 2,
    'and' => 4,
    'at' => 2,
    'The' => 1,
    'brightly:' => 1,
    'anything' => 3,
    'it.' => 1,
    'two' => 1,
    'patiently,' => 1,
    'Trillian,' => 6,
    'Trillian' => 8,
    'Marvin,' => 6,
    'Marvin.' => 6,
    'Marvin' => 4,
    'pathetically.' => 1,
    'weakly.' => 1,
    'Zaphod,' => 24,
    'quietly,' => 1,
    'Trillian.' => 7,
    'Zaphod.' => 26,
    'patiently.' => 1,
    'brightly' => 1,
    '(ticker' => 1,
    '"hi"' => 1,
    'we\'ve' => 1,
    '-' => 1,
    'Ford.)' => 1,
    'forget' => 1,
    'that?' => 1,
    'Eddie' => 1,
    'nothing' => 1,
    'you' => 3,
    'trying' => 1,
    'Slartibartfast' => 2,
    'Slartibartfast,' => 6,
    'Slartibartfast.' => 1,
    'Lunkwill,' => 2,
    'Deep' => 17,
    'Fook' => 2,
    'Lunkwill.' => 2,
    'finally.' => 1,
    'Majikthise,' => 2,
    'Vroomfondel' => 2,
    'I\'d' => 1,
    'one,' => 1,
    'Phouchg,' => 1,
    'Loonquawl.' => 1,
    'Loonquawl' => 2,
    'Phouchg.' => 1,
    'Loonquawl,' => 1,
    'firmly.' => 1,
    'about' => 1,
    'hoiking' => 1,
    'one' => 1,
    'Benji' => 3,
    'Frankie' => 3,
    'Frankie,' => 5,
    'Benji.' => 5,
    'Frankie.' => 3,
    'Benji,' => 2,
    'that,' => 1,
    'Zaphod\'s' => 1,
  ),
  'been' => 
  array (
    'a' => 6,
    'nailed' => 1,
    'going' => 1,
    'drinking' => 1,
    'telling' => 1,
    'in' => 1,
    'appallingly' => 1,
    'available' => 1,
    '' => 10,
    'like' => 1,
    'too' => 1,
    'looking' => 1,
    'his' => 1,
    'on' => 2,
    'to' => 1,
    'so' => 1,
    'up' => 1,
    'temporarily' => 1,
    'salvaged' => 1,
    'written' => 1,
    'named' => 1,
    'working' => 1,
    'demolished.' => 1,
    'able' => 2,
    'fed' => 1,
    'if' => 1,
    'close' => 1,
    'standing' => 1,
    'wiped,' => 1,
    'gathering' => 1,
    'prepared' => 1,
    'touched,' => 1,
    'through.' => 1,
    'compiled' => 1,
    'demolished,' => 1,
    'rescued' => 1,
    'picked' => 1,
    'left' => 1,
    'dead.' => 1,
    'happy' => 1,
    'ordered' => 1,
    'stolen.' => 1,
    'operated' => 1,
    'trying' => 2,
    'brought' => 1,
    're-awakened' => 1,
    'bothering' => 1,
    'dead' => 2,
    'used' => 1,
    'revealed,' => 1,
    'great' => 1,
    'called' => 2,
    'generally' => 1,
    'attacked' => 1,
    'given,' => 1,
    'very' => 1,
    'their' => 1,
    'asleep' => 1,
    'experimenting' => 1,
    'connected' => 1,
    'made' => 1,
    'well' => 1,
    'constructed' => 1,
    'trained' => 1,
    'selected' => 1,
    'doing' => 2,
    'hailed,' => 1,
    'lying' => 1,
    'gassing' => 1,
    'more' => 1,
    'there.' => 1,
  ),
  'bad' => 
  array (
    'move,' => 1,
    'at' => 1,
    'tempered,' => 1,
    'thing.' => 1,
    'shoe' => 1,
  ),
  'move,' => 
  array (
    'and' => 1,
    '-' => 1,
  ),
  'no' => 
  array (
    'one' => 13,
    'Earthman' => 1,
    '' => 12,
    'means' => 1,
    'he\'d' => 1,
    'not' => 1,
    'longer' => 4,
    'sneaky' => 1,
    'point,' => 1,
    'friends' => 1,
    'concert,' => 1,
    'doubt' => 1,
    'point' => 3,
    'sympathy' => 1,
    'such' => 1,
    'real' => 1,
    'power' => 1,
    'truck' => 1,
    'more.' => 1,
    'use' => 1,
    'light.' => 2,
    'account' => 1,
    'one\'s' => 2,
    'source' => 1,
    'way' => 1,
    'outcry,' => 1,
    'illusions' => 1,
    'idea' => 1,
    'bad' => 1,
    '-' => 1,
    'apparent' => 2,
    'Marvin,' => 2,
    'further' => 3,
    'thoughts' => 1,
    'man' => 2,
    'notice,' => 1,
    'revelation' => 1,
    'significance' => 1,
    'playing' => 1,
    'other' => 1,
    'attempt' => 1,
    'doubt.' => 1,
    'readily' => 1,
    'problem,' => 1,
    'good,' => 1,
    'question,' => 1,
    'resistance.' => 1,
    'curiosity.' => 1,
  ),
  'one' => 
  array (
    'should' => 1,
    'Thursday,' => 1,
    '' => 24,
    'girl' => 1,
    'would' => 2,
    '-' => 3,
    'he' => 1,
    'seemed' => 1,
    'wanted' => 1,
    'of' => 26,
    'careless' => 1,
    'more' => 2,
    'and' => 2,
    'yourself.' => 1,
    'bottle' => 1,
    'measure' => 1,
    'end;' => 1,
    'on' => 1,
    'followed' => 1,
    'man' => 1,
    'had' => 1,
    'to' => 3,
    'being' => 1,
    'hell' => 1,
    'ever' => 3,
    'as' => 1,
    'left' => 1,
    'knew' => 2,
    'final' => 1,
    'is' => 2,
    'responsible' => 1,
    'against.' => 3,
    'hundred' => 3,
    'against' => 6,
    'wing' => 1,
    'day,' => 1,
    'thing' => 1,
    'corner' => 1,
    'side.' => 1,
    'wild' => 1,
    'was' => 2,
    'head' => 2,
    'believes' => 1,
    'looked' => 1,
    'end' => 1,
    'day' => 3,
    'here.' => 1,
    'Arthur' => 1,
    'Veet' => 1,
    'sun' => 1,
    'species' => 1,
    'extraordinary' => 1,
    'word' => 1,
    'has' => 1,
    'in' => 1,
    'though.' => 1,
    'solid' => 1,
    'voice' => 1,
    'could' => 1,
    'or' => 1,
    'called' => 1,
    'going' => 1,
    'else' => 1,
    'can' => 1,
  ),
  'should' => 
  array (
    'ever' => 1,
    'get' => 1,
    'send' => 1,
    'I' => 2,
    '' => 6,
    'have' => 3,
    'see...' => 1,
    'not' => 1,
    'warn' => 1,
    'steal' => 1,
    'be' => 1,
  ),
  'ever' => 
  array (
    '' => 4,
    'to' => 1,
    'heard' => 3,
    'since' => 2,
    'suspected' => 1,
    'heard.' => 1,
    'experienced' => 1,
    'built.' => 1,
    'had' => 2,
    'conceived,' => 1,
    'went' => 1,
    'knew' => 1,
    'come' => 1,
    'going' => 1,
    'he\'d' => 1,
    'mentioned' => 1,
    'want...' => 1,
    'listens.' => 1,
    'existed.' => 1,
    'done' => 1,
    'dolphin' => 1,
    'go' => 1,
    'met.' => 1,
    'having' => 1,
  ),
  'have' => 
  array (
    'left' => 1,
    'to' => 22,
    'been.' => 1,
    'known' => 1,
    'a' => 16,
    'been' => 13,
    'sarcasm' => 1,
    '' => 22,
    'died' => 2,
    'an' => 2,
    'we' => 1,
    'made' => 2,
    '"lost".' => 1,
    'sex' => 1,
    'their' => 2,
    'you' => 4,
    'come' => 1,
    'manned' => 1,
    'virtually' => 1,
    'survived.' => 1,
    'attempted' => 1,
    'some,' => 1,
    'cushioned' => 1,
    'fallen' => 1,
    'ever' => 1,
    'this' => 1,
    'felt' => 1,
    'chosen' => 1,
    'evolved' => 1,
    'cared' => 1,
    'his' => 2,
    'gone,' => 1,
    'faltered.' => 1,
    'all' => 1,
    'I,' => 1,
    'done' => 1,
    'fitted' => 1,
    'normality,' => 1,
    'normality.' => 1,
    'picked' => 2,
    'gone' => 2,
    'thought' => 2,
    'difficulty' => 1,
    'we?' => 1,
    'meaning' => 1,
    'turned' => 1,
    'I' => 1,
    'speculated' => 1,
    'escaped!' => 1,
    'commanded' => 1,
    'so' => 1,
    'now.' => 1,
    'good' => 1,
    'guessed.' => 1,
    'found' => 2,
    'oceans?' => 1,
    'something' => 2,
    'but' => 1,
    'endless' => 1,
    'mattered' => 1,
    'formed' => 1,
    'contemplated' => 1,
    'designed' => 1,
    'the' => 1,
    'not' => 1,
    'showed' => 1,
    'passed.' => 1,
    'any' => 1,
    'it,' => 1,
    'now' => 1,
    'since' => 1,
    'to,' => 1,
    'blown' => 1,
    'lunch?' => 1,
  ),
  'left' => 
  array (
    'the' => 3,
    'in' => 1,
    'to' => 3,
    'him' => 3,
    '' => 6,
    'off.' => 1,
    'is' => 1,
    'arm\'s' => 1,
    'shoulder.' => 1,
    'leg,' => 1,
    'hand' => 1,
    'Ford' => 1,
    'them' => 2,
    'it' => 1,
  ),
  'oceans.' => 
  array (
    'And' => 1,
  ),
  'then,' => 
  array (
    'one' => 1,
    '' => 3,
    'had' => 1,
    'I\'ve' => 1,
    'after' => 1,
  ),
  'Thursday,' => 
  array (
    'nearly' => 1,
    '' => 1,
    '-' => 1,
    'something' => 1,
  ),
  'nearly' => 
  array (
    'two' => 1,
    'empty' => 1,
    'reached' => 1,
    'dead' => 1,
    'everyone.' => 1,
    'blew' => 1,
    'rich' => 1,
    'thirty' => 1,
    'upon' => 1,
    'blasted' => 1,
    'tripped' => 1,
  ),
  'two' => 
  array (
    'thousand' => 1,
    'important' => 1,
    'contestants' => 1,
    '' => 14,
    'minutes' => 1,
    'of' => 2,
    'down' => 1,
    'hundredth' => 1,
    'arms' => 3,
    'or' => 1,
    'heads' => 2,
    'had' => 1,
    'humanoids' => 1,
    'to' => 3,
    'engines' => 1,
    'hundred' => 2,
    'long' => 1,
    'entry' => 1,
    'lucky' => 1,
    'figures' => 1,
    'silver' => 1,
    'massively' => 1,
    'missiles' => 1,
    'ideas' => 1,
    'lumps' => 1,
    'suns' => 1,
    'suns!' => 1,
    'programmers' => 1,
    'angry' => 1,
    'men' => 3,
    'philosophers' => 1,
    'wires.' => 1,
    'windpipes.' => 1,
    'nodded' => 1,
    'opposing' => 2,
    'white' => 1,
    'mice' => 2,
    'glass' => 1,
    'pounds' => 1,
    'computer' => 1,
    'data' => 1,
    'others' => 1,
    'policemen' => 1,
  ),
  'thousand' => 
  array (
    'years' => 2,
    '' => 4,
    'miles' => 1,
    'light' => 1,
    'feet' => 1,
    'scintillating' => 1,
    'years.' => 2,
    'seven' => 2,
    'lightly' => 1,
    'to' => 6,
    'one' => 1,
    'times' => 1,
    'million' => 1,
    'years,' => 1,
    'glaciers' => 1,
  ),
  'years' => 
  array (
    'after' => 1,
    '' => 8,
    'previously,' => 1,
    'pretending' => 1,
    'was' => 1,
    'away' => 2,
    'from' => 3,
    'in' => 3,
    'every' => 1,
    'and' => 2,
    'to' => 2,
    'more' => 1,
    'of' => 4,
    'old.' => 1,
    'our' => 1,
    'it' => 1,
    'the' => 1,
    'finding' => 1,
    'between' => 1,
  ),
  'after' => 
  array (
    'one' => 1,
    'all.' => 3,
    'all,' => 3,
    'him.' => 2,
    'him' => 3,
    'which' => 1,
    '' => 6,
    'four' => 1,
    'that' => 2,
    'a' => 4,
    'golden' => 1,
    'he' => 1,
    'us' => 1,
    'him,' => 1,
    'fifteen' => 1,
    'exchanging' => 1,
    'me!' => 1,
    'Slartibartfast' => 1,
    'the' => 1,
    'their' => 1,
    'bolt' => 1,
  ),
  'man' => 
  array (
    '' => 5,
    'wants' => 1,
    'lie' => 1,
    'sitting' => 2,
    'next' => 2,
    'waved' => 2,
    'to' => 1,
    'with' => 4,
    'stood' => 1,
    'weep.' => 1,
    'on' => 1,
    'from' => 2,
    'trying' => 1,
    'who' => 2,
    'lolling' => 1,
    'had' => 2,
    'has' => 1,
    'before' => 1,
    'looked' => 4,
    'chuckled' => 1,
    'in' => 1,
    'stifled' => 1,
    'mildly.' => 3,
    'motioning' => 1,
    'quietly.' => 1,
    '-' => 1,
    'completely' => 1,
    'gently,' => 1,
    'tried' => 1,
    'paused,' => 1,
    'frowned' => 1,
    'as' => 1,
    'standing' => 1,
    'said,' => 1,
    'was' => 1,
    'coldly,' => 1,
    'walk' => 2,
  ),
  'nailed' => 
  array (
    'to' => 2,
  ),
  'tree' => 
  array (
    'for' => 1,
    'on' => 1,
  ),
  'saying' => 
  array (
    'how' => 1,
    'Beware' => 1,
    'Hi' => 1,
    'is' => 1,
    'things' => 1,
    'he' => 1,
    'a' => 1,
    'to' => 1,
    'that,' => 1,
    'Blood...' => 1,
    'because' => 1,
    '' => 1,
  ),
  'how' => 
  array (
    'great' => 1,
    'the' => 3,
    '' => 7,
    'much' => 3,
    'to' => 3,
    'they' => 2,
    'are' => 3,
    'far\'s' => 1,
    'you' => 1,
    'far' => 2,
    'cold' => 1,
    'it' => 2,
    'did' => 2,
    'good' => 1,
    'about' => 1,
    'vastly' => 1,
    'am' => 1,
    'improbable' => 1,
    'just' => 1,
    'in' => 1,
    'near' => 1,
    'better' => 1,
  ),
  'great' => 
  array (
    'it' => 1,
    'publishing' => 2,
    'Encyclopedia' => 1,
    'length,' => 1,
    'warrior:' => 1,
    'about' => 3,
    '' => 4,
    'practical' => 1,
    'stress,' => 1,
    'ships' => 1,
    'day' => 3,
    'to' => 2,
    'deal' => 2,
    'cracked' => 1,
    'loathing,' => 1,
    'and' => 1,
    'guys,' => 1,
    'moment.' => 1,
    'knowing' => 1,
    'fan' => 1,
    'task' => 1,
    'question' => 1,
    'Question' => 1,
    'incisions' => 1,
    'length' => 1,
  ),
  'would' => 
  array (
    '' => 14,
    'work,' => 1,
    'sort' => 2,
    'just' => 3,
    'have' => 15,
    'suffer' => 1,
    'often' => 2,
    'get' => 2,
    'start' => 1,
    'joke' => 1,
    'laugh' => 1,
    'reply' => 1,
    'usually' => 1,
    'arrive' => 2,
    'sit' => 1,
    'be' => 10,
    'then' => 3,
    'probably' => 2,
    'you' => 5,
    'estimate.' => 1,
    'suddenly' => 1,
    'not' => 3,
    'stop' => 1,
    'annoy' => 1,
    'catch' => 1,
    'snap' => 1,
    'I' => 1,
    'come' => 1,
    'break' => 1,
    'you?' => 1,
    'appear' => 1,
    'soften' => 1,
    'transpire.' => 1,
    'like' => 2,
    'ask' => 1,
    'appear,' => 1,
    'know' => 1,
    'let' => 1,
    'forget' => 1,
    'make' => 1,
    'happily' => 1,
    'save' => 1,
    'simply' => 1,
    'it' => 1,
    'represent' => 1,
    'care' => 2,
    'witness' => 1,
    'eclipse' => 1,
    'need' => 1,
    'never' => 1,
    'tell' => 1,
    'suffice.' => 1,
  ),
  'be' => 
  array (
    '' => 34,
    'the' => 8,
    'built' => 1,
    'built!' => 1,
    'built?' => 2,
    'at' => 2,
    'said,' => 1,
    'an' => 1,
    'placed' => 1,
    'refilled.' => 1,
    'staying' => 1,
    'anything' => 1,
    'quiet.' => 1,
    'full' => 2,
    'properly' => 1,
    'Thursday,' => 1,
    'summoned' => 1,
    'clean' => 1,
    'reckoned' => 1,
    'aware' => 1,
    'any' => 1,
    'so' => 1,
    'further' => 1,
    'noticed.' => 1,
    'too' => 2,
    'treated' => 1,
    'aware,' => 1,
    'bothered' => 3,
    'some' => 2,
    'introduced' => 1,
    'completely' => 1,
    'vested' => 1,
    'more' => 1,
    'to' => 1,
    'lowered' => 1,
    'a' => 6,
    'needing' => 2,
    'giving' => 1,
    'nervous.' => 1,
    'genuinely' => 2,
    'him' => 1,
    'most' => 1,
    'nervous' => 1,
    'important.' => 1,
    'prepared' => 1,
    'serious' => 1,
    'accepted' => 1,
    'loved,' => 1,
    'left' => 1,
    'going' => 2,
    'fair' => 1,
    'mad,' => 1,
    'mad.' => 1,
    'melting' => 1,
    'telling' => 1,
    'alarmed,' => 2,
    'sent' => 1,
    'just' => 1,
    'yours\'' => 1,
    'saying' => 1,
    'stupid' => 2,
    'outrageously' => 1,
    'puzzled' => 1,
    'there?' => 1,
    'made' => 3,
    'thoroughly' => 1,
    'outcooled.' => 1,
    'deterred.' => 1,
    'no' => 2,
    'ashamed' => 1,
    'in' => 1,
    'swinging' => 1,
    'isn\'t' => 1,
    'stored' => 1,
    'exacerbated' => 1,
    'able' => 2,
    'on' => 1,
    'seen' => 1,
    'something' => 2,
    'afraid...' => 1,
    'tossed' => 1,
    'friends' => 1,
    'your' => 1,
    'better' => 1,
    'excited,' => 1,
    'circular' => 1,
    'disappointed' => 1,
    'done,' => 1,
    'lying.' => 1,
    'seen.' => 2,
    'revived' => 1,
    'late.' => 1,
    'very' => 1,
    'ultra' => 1,
    'set' => 1,
    'my' => 1,
    'Vroomfondel!' => 1,
    'quite' => 1,
    'called...' => 1,
    'equipped' => 1,
    'letting' => 1,
    'happy' => 1,
    'having' => 2,
    'necessary,' => 1,
    'sacrilege' => 1,
    'all.' => 1,
    'brutally' => 1,
    'prepared.' => 1,
    'replaced,' => 1,
    'from' => 1,
    'looking' => 1,
    'connected.' => 1,
  ),
  'nice' => 
  array (
    '' => 1,
    'little' => 1,
    'house,' => 1,
    'relaxing' => 1,
    'day,' => 1,
    'relaxed' => 1,
    'girl' => 1,
    'hot' => 1,
    'meal' => 1,
  ),
  'change,' => 
  array (
    'one' => 1,
  ),
  'girl' => 
  array (
    'sitting' => 1,
    'and' => 1,
    '' => 1,
    'whom' => 1,
  ),
  'sitting' => 
  array (
    'on' => 1,
    'next' => 2,
    'alone' => 1,
    '' => 3,
    'up' => 1,
    'in' => 1,
    'round' => 1,
    'there' => 1,
  ),
  'her' => 
  array (
    '' => 3,
    'story.' => 1,
    'in' => 1,
    'to' => 3,
    'red' => 1,
    'long' => 1,
    'eyebrows' => 1,
    'eyes' => 1,
    'microphone' => 1,
    'seat' => 1,
    'fingers' => 1,
    'again,' => 1,
    'relationship' => 1,
    'head' => 1,
    'head.' => 1,
    'and' => 1,
    'with' => 1,
    'again.' => 1,
    'attention' => 1,
    'last' => 1,
    'bring.' => 1,
    'negative' => 1,
    'whole' => 1,
    'what' => 1,
    'cabin.' => 1,
    'remark' => 1,
    'eye,' => 1,
  ),
  'own' => 
  array (
    '' => 8,
    'and' => 1,
    'business.' => 1,
    'lookout.' => 1,
    'right' => 1,
    'grandmothers' => 1,
    'navel.' => 1,
    'arguments,' => 1,
    'legs' => 1,
    'major' => 1,
    'devising.' => 1,
    'problem.' => 1,
    'ground,' => 1,
    'voice' => 1,
    'relative' => 1,
    'pan-dimensional' => 1,
    'ceiling...' => 1,
    'brain' => 1,
    'dimension,' => 1,
    'dimensional' => 1,
    'having' => 1,
  ),
  'cafe' => 
  array (
    '' => 1,
  ),
  'Rickmansworth' => 
  array (
    'suddenly' => 1,
  ),
  'suddenly' => 
  array (
    'realized' => 3,
    'lunge' => 1,
    '' => 5,
    'to' => 1,
    'shivered:' => 1,
    'laughed' => 1,
    'become,' => 1,
    'frozen' => 1,
    'discovered' => 1,
    'seeing' => 1,
    'resolve' => 1,
    'gave' => 1,
    'felt' => 1,
    'looked' => 1,
    'lunged' => 1,
    'heard' => 1,
    'generates.' => 1,
    'does.' => 1,
    'began' => 1,
    'occurred' => 1,
    'through' => 1,
    'dropped' => 1,
    'been' => 1,
    'coming' => 1,
    'full' => 1,
    'claimed' => 1,
    'present' => 1,
    'gasped' => 1,
    'Arthur' => 1,
    'hitting' => 1,
    'materialize' => 1,
    'sustained' => 1,
    'yelped.' => 1,
    'the' => 1,
  ),
  'realized' => 
  array (
    'what' => 2,
    'that' => 5,
    'it' => 1,
    '' => 1,
  ),
  'what' => 
  array (
    'it' => 9,
    'he' => 10,
    'a' => 5,
    'sort' => 1,
    '' => 25,
    'about' => 1,
    'the' => 10,
    'voluntary' => 1,
    'with' => 2,
    'they' => 6,
    'Zaphod' => 2,
    'she' => 1,
    'nature' => 1,
    'do' => 4,
    'to' => 3,
    'is...' => 1,
    'am' => 1,
    'else' => 3,
    'sounded' => 1,
    'does' => 3,
    'you\'re' => 2,
    'are' => 4,
    'happens' => 1,
    'did' => 2,
    'was' => 4,
    'is' => 4,
    'Ford' => 1,
    'we' => 3,
    'were' => 2,
    'you' => 2,
    'parents' => 1,
    'Zaphod\'s' => 1,
    'this' => 1,
    'for' => 1,
    'I' => 6,
    'I\'m' => 3,
    'it\'s' => 2,
    'these' => 1,
    'had' => 1,
    'seemed' => 1,
    'appeared' => 1,
    'infinity' => 1,
    'happened' => 2,
    'answer' => 1,
    'actually' => 1,
    'happens?' => 1,
    'really' => 1,
    'all' => 1,
    'section' => 1,
    'happened?' => 1,
  ),
  'going' => 
  array (
    'wrong' => 1,
    'to' => 38,
    '' => 15,
    'on.' => 3,
    'on?' => 1,
    'on' => 3,
    'was' => 1,
    'so' => 1,
    'mad.' => 2,
    'to...' => 1,
    'past' => 1,
  ),
  'wrong' => 
  array (
    '' => 2,
    'with' => 1,
    'today,' => 1,
    'so' => 1,
    'shade' => 1,
    'bit' => 1,
  ),
  'time,' => 
  array (
    'and' => 1,
    '' => 3,
    'the' => 1,
    'which' => 1,
    '-' => 2,
    'in' => 1,
    'by' => 1,
    'but' => 1,
  ),
  'she' => 
  array (
    'finally' => 1,
    'could' => 2,
    'would' => 1,
    'looked' => 1,
    'thought' => 1,
    '' => 8,
    'tell' => 1,
    'went' => 1,
    'said.' => 6,
    'said' => 2,
    'said,' => 4,
    'pointed,' => 1,
    'was' => 3,
    'had' => 1,
    'shook' => 1,
    'knew' => 1,
    'saw' => 1,
    'glanced' => 1,
  ),
  'finally' => 
  array (
    'knew' => 1,
    'to' => 1,
    'gone' => 1,
    '' => 1,
    'realized' => 1,
    'flipped?' => 1,
    'beginning' => 1,
    'managed' => 1,
    'sent' => 1,
    'stopped' => 1,
    'learn' => 1,
    'dived' => 1,
  ),
  'knew' => 
  array (
    'how' => 2,
    'about' => 2,
    '' => 6,
    'it.' => 1,
    'that' => 5,
    'they' => 2,
    'what' => 5,
    'where' => 1,
    'it' => 1,
    'all' => 1,
    'that,' => 1,
    'much' => 1,
    'offhand' => 1,
    'as' => 1,
    'quite' => 1,
    'exactly' => 1,
    'the' => 1,
    'perfectly' => 1,
  ),
  'world' => 
  array (
    'could' => 1,
    'as' => 1,
    'always' => 1,
    'being' => 1,
    '' => 2,
    'was' => 1,
    'city' => 1,
    'quietly' => 1,
    'around' => 1,
    'where' => 1,
    'resolved' => 1,
  ),
  'could' => 
  array (
    'be' => 6,
    'get' => 3,
    'find' => 1,
    'turn' => 2,
    'be...' => 1,
    'slip' => 1,
    'only' => 2,
    '' => 17,
    'have' => 2,
    'say.' => 1,
    'bear' => 1,
    'shout' => 1,
    'on' => 1,
    'grasp' => 1,
    'identify.' => 1,
    'forbid' => 1,
    'not' => 2,
    'feel' => 1,
    'dimly' => 1,
    'see' => 4,
    'seriously' => 1,
    'easily' => 1,
    'actually' => 1,
    'make' => 2,
    'drop' => 1,
    'probably' => 1,
    'happen.' => 1,
    'you' => 1,
    'check.' => 1,
    'enjoy' => 1,
    'kill' => 1,
    'neither' => 1,
    'talk' => 1,
    'spit' => 1,
    'grow' => 1,
    'do' => 1,
    'just' => 1,
    'always' => 1,
    'avoid' => 1,
    'mention!' => 1,
    'tell,' => 1,
    'sense' => 3,
  ),
  'good' => 
  array (
    '' => 6,
    'book;' => 1,
    'at' => 3,
    'time.' => 5,
    'you' => 1,
    'for' => 1,
    'then?' => 1,
    'idea' => 2,
    'party' => 1,
    'fortune' => 1,
    'try' => 1,
    'thinking' => 1,
    'can\'t' => 1,
    'place' => 1,
    'ideas' => 1,
    'life.' => 1,
    'heavens' => 1,
    'at,' => 1,
    'dream' => 1,
    'lifestyle' => 1,
    'offices' => 1,
    'chance' => 1,
  ),
  'happy' => 
  array (
    'place.' => 1,
    'Hikers' => 1,
    'drunken' => 1,
    'to' => 1,
    'as' => 1,
    'than' => 1,
  ),
  'time' => 
  array (
    'it' => 2,
    'at' => 2,
    'you' => 3,
    '' => 10,
    'do' => 1,
    'for' => 1,
    'to' => 6,
    'somebody' => 1,
    'he' => 2,
    'the' => 2,
    'warp' => 1,
    'we' => 1,
    'and' => 1,
    'promising' => 1,
    'worried' => 1,
    'fifteen' => 1,
    'I\'ve' => 1,
    'itself...' => 1,
    'a' => 1,
    'nobody' => 1,
    'with.' => 1,
    'in' => 1,
    'which' => 1,
    'there' => 1,
    'wearing' => 1,
    'is' => 1,
    'before' => 1,
    'span?' => 1,
    'across' => 1,
  ),
  'right,' => 
  array (
    'it' => 1,
    '' => 1,
    '-' => 1,
    'and' => 1,
  ),
  'work,' => 
  array (
    'and' => 1,
    '-' => 1,
    'a' => 1,
  ),
  'get' => 
  array (
    'nailed' => 1,
    'to' => 2,
    'dressed.' => 1,
    'there,' => 1,
    'there.' => 1,
    'badly' => 1,
    'seized' => 1,
    '' => 8,
    'lifts' => 1,
    'run' => 1,
    'paid' => 1,
    'up' => 2,
    'on' => 6,
    'through.' => 1,
    'the' => 1,
    'blisters,' => 1,
    'here?' => 1,
    'home?' => 1,
    'very' => 1,
    'a' => 7,
    'there' => 1,
    'where' => 1,
    'you' => 1,
    'off' => 2,
    'rescued' => 1,
    'invited' => 1,
    'them' => 1,
    'people' => 1,
    'any' => 1,
    'rid' => 1,
    'it' => 2,
    'it?' => 1,
    'manual' => 1,
    'angry.' => 1,
    'an' => 1,
    'his' => 1,
    'lynched' => 1,
    'excited,' => 1,
    'this,' => 1,
    'if' => 1,
    'shot' => 1,
  ),
  'anything.' => 
  array (
    'Sadly,' => 1,
    '-' => 1,
    'Zaphod' => 1,
    'That\'s' => 1,
    'He' => 1,
    'Trillian' => 1,
  ),
  'Sadly,' => 
  array (
    'however,' => 1,
  ),
  'however,' => 
  array (
    'before' => 1,
    'remain' => 1,
  ),
  'before' => 
  array (
    'she' => 1,
    'the' => 6,
    '' => 9,
    'being' => 1,
    'he' => 3,
    'them.' => 1,
    '-' => 1,
    'them' => 1,
    'it' => 3,
    'my' => 1,
    'I' => 1,
    'falling' => 1,
    'them,' => 1,
    'anyone' => 2,
    'that,' => 1,
    'they' => 1,
    'Yooden' => 1,
  ),
  'phone' => 
  array (
    'to' => 1,
    '' => 1,
  ),
  'tell' => 
  array (
    'anyone' => 1,
    'his' => 1,
    'me' => 6,
    '' => 3,
    'you' => 10,
    'him' => 1,
    'you?' => 2,
    'by' => 1,
    'can\'t' => 1,
    'which' => 1,
    'their' => 1,
    'how' => 1,
    'me,' => 1,
    'us' => 1,
  ),
  'anyone' => 
  array (
    '' => 2,
    'had' => 1,
    'there' => 1,
    'maintain' => 1,
    'interested' => 1,
    'who' => 2,
    'turn' => 1,
    'know' => 1,
    'know...' => 1,
    'spoke.' => 1,
  ),
  'about' => 
  array (
    'it,' => 4,
    '' => 28,
    'three' => 2,
    'a' => 2,
    'it.' => 10,
    'the' => 16,
    'point' => 2,
    'it' => 9,
    'to' => 16,
    'time' => 1,
    'my' => 1,
    'whether' => 2,
    'this.' => 3,
    'this' => 5,
    'five' => 2,
    'four' => 1,
    'what' => 2,
    'twenty' => 1,
    'human' => 1,
    'him,' => 3,
    'them.' => 1,
    'in' => 4,
    'anything.' => 1,
    'Vogons,' => 1,
    'how' => 1,
    'that.' => 1,
    'being' => 3,
    'panicking?' => 1,
    'yet!' => 1,
    'this?' => 1,
    'it...' => 1,
    'imperceptibly.' => 1,
    'that,' => 1,
    'life.' => 2,
    'me' => 1,
    'yourself' => 1,
    'at' => 2,
    'life' => 1,
    'that' => 1,
    'with' => 1,
    'his' => 2,
    'it!' => 1,
    'them' => 2,
    'an' => 1,
    'is' => 1,
    'myself' => 1,
    'moodily.' => 1,
    'himself' => 1,
    'its' => 1,
    'or' => 1,
    'him' => 1,
    'shadowy' => 1,
    'our' => 1,
    'fishing' => 1,
    'it?' => 1,
    'having' => 1,
    'inside' => 1,
    'wildly.' => 1,
    'sensitivity' => 1,
  ),
  'it,' => 
  array (
    'a' => 1,
    'telling' => 1,
    'he' => 1,
    'Mr.' => 1,
    '-' => 22,
    'the' => 2,
    '' => 7,
    'it' => 2,
    'struggle' => 1,
    'unseen,' => 1,
    'oh' => 1,
    'but' => 2,
    'you' => 1,
    'little' => 1,
    'didn\'t' => 1,
    'they' => 1,
    'not' => 1,
    'and' => 2,
    'so' => 1,
    'like' => 1,
    'pointing' => 1,
  ),
  'terribly' => 
  array (
    'stupid' => 1,
    '' => 2,
    'bad' => 1,
    'therapeutic' => 1,
    'tired.' => 1,
  ),
  'stupid' => 
  array (
    'catastrophe' => 2,
    'Thursday,' => 1,
    'hopeful' => 1,
    'animal,' => 1,
    'everyone' => 1,
    'just' => 1,
    'because' => 1,
    'to' => 1,
  ),
  'catastrophe' => 
  array (
    'occurred,' => 2,
    'and' => 1,
  ),
  'occurred,' => 
  array (
    'and' => 1,
    'never' => 1,
  ),
  'idea' => 
  array (
    'was' => 2,
    'how' => 1,
    'what' => 2,
    'of' => 2,
    'why' => 1,
    'to' => 1,
    'who?' => 1,
    'at' => 1,
    '' => 1,
    'that' => 1,
  ),
  'lost' => 
  array (
    'forever.' => 1,
    'some' => 1,
    '' => 1,
    'but' => 1,
    'in' => 1,
    'to' => 1,
  ),
  'forever.' => 
  array (
    'This' => 1,
  ),
  'not' => 
  array (
    'her' => 1,
    'an' => 1,
    'as' => 3,
    'descended' => 1,
    'from' => 3,
    'conspicuously' => 2,
    'especially,' => 1,
    'unlike' => 1,
    '' => 26,
    'exactly' => 1,
    'now.' => 1,
    'really,' => 1,
    'in' => 3,
    'those' => 1,
    'to' => 6,
    'even' => 2,
    'be' => 7,
    'a' => 6,
    'allow' => 1,
    'like' => 1,
    'now' => 1,
    'actually' => 1,
    'panicking!' => 1,
    'have' => 1,
    'so' => 2,
    'occurred' => 1,
    'going' => 3,
    'really.' => 1,
    'fit' => 1,
    'the' => 2,
    'happy' => 1,
    'asking' => 1,
    'getting' => 2,
    'all' => 2,
    'of' => 1,
    'worry' => 1,
    'here' => 1,
    'eventually' => 1,
    'on' => 1,
    'interpret' => 1,
    'good.' => 1,
    'unkind,' => 1,
    'important,' => 1,
    'harm' => 1,
    'literally' => 1,
    'entirely' => 1,
    'quite' => 1,
    'currently' => 1,
    'dissimilar' => 1,
    'making' => 1,
    'with' => 1,
    'worthy' => 2,
    'be,' => 1,
    'proud.' => 1,
    'doing' => 1,
    'known.' => 1,
    'unbitterly.' => 1,
    'equatorial' => 1,
    'always' => 1,
    'knowing' => 1,
    'to.' => 1,
    'very' => 1,
    'then.' => 1,
    'his' => 1,
    'being' => 1,
    'only' => 1,
  ),
  'story.' => 
  array (
    'But' => 1,
    'It\'ll' => 1,
  ),
  'But' => 
  array (
    'it' => 4,
    'the' => 4,
    'Mr.' => 1,
    'look,' => 1,
    'I' => 5,
    'why?' => 3,
    'what' => 4,
    'can' => 3,
    'there' => 1,
    'his' => 1,
    'who' => 2,
    'how' => 2,
    'if' => 1,
    'alright,' => 1,
    'at' => 1,
    'hang' => 1,
    'thanks' => 1,
    'listen,' => 1,
    'I\'ll' => 2,
    'unfortunately,' => 1,
    'that\'s' => 3,
    'relative' => 1,
    'you' => 2,
    'so' => 1,
    'don\'t' => 1,
    'by' => 1,
    'where' => 1,
    'have' => 1,
    'that' => 1,
    'he' => 1,
    '' => 1,
    'are' => 1,
    'aren\'t' => 1,
    'we\'ve' => 1,
  ),
  'story' => 
  array (
    'of' => 5,
    '' => 1,
    'tonight' => 1,
    'to' => 1,
    'Earthman,' => 1,
  ),
  'terrible' => 
  array (
    'stupid' => 1,
    'catastrophe' => 1,
    'hangover' => 1,
    'odds,' => 1,
    '' => 3,
    'ghastly' => 3,
    'showoff.' => 1,
    'number' => 1,
    'pain' => 1,
    'miscalculation' => 1,
  ),
  'its' => 
  array (
    'consequences.' => 1,
    'cover.' => 3,
    'extraordinary' => 1,
    'own' => 4,
    'diurnal' => 1,
    'intoxicating' => 1,
    'echo' => 1,
    '' => 9,
    'job.' => 2,
    'carrier' => 2,
    'throat.' => 1,
    'discovery.' => 1,
    'gleaming' => 1,
    'more' => 1,
    'bearing' => 1,
    'feet' => 1,
    'speech' => 1,
    'orbital' => 1,
    'guidance' => 1,
    'way' => 1,
    'identity' => 1,
    'thoughts' => 1,
    'life' => 1,
    'lot.' => 1,
    'dark' => 1,
    'current' => 2,
    'editors' => 1,
    'five-million-year' => 1,
    'destruction.' => 1,
    'greatest' => 1,
    'operational' => 1,
    'ten-million-year' => 1,
    'forms,' => 1,
    'limp' => 1,
    'sparse' => 1,
    'own.' => 1,
    'external' => 1,
  ),
  'consequences.' => 
  array (
    'It' => 1,
  ),
  'It' => 
  array (
    'is' => 8,
    'begins' => 1,
    'stood' => 1,
    'was,' => 1,
    'hadn\'t' => 1,
    'had' => 2,
    'would' => 5,
    'was' => 32,
    'cast' => 1,
    '' => 18,
    'says' => 2,
    'really' => 1,
    'nestled' => 1,
    'looked' => 2,
    'hardly' => 1,
    'said:' => 4,
    'cut' => 1,
    'consists' => 1,
    'consisted' => 1,
    'might' => 1,
    'flashed' => 1,
    'tells' => 1,
    'just' => 1,
    'feeds' => 1,
    'then' => 1,
    'could' => 2,
    'proves' => 1,
    'Up' => 1,
    'doesn\'t' => 2,
    'wasn\'t' => 1,
    'has' => 1,
    'contains' => 1,
    'takes' => 1,
    'sounded' => 2,
    'said' => 1,
    'startled' => 1,
    'pulled' => 1,
    'stopped' => 1,
    'won\'t' => 1,
    'says:' => 1,
    'is.' => 1,
    'saved' => 1,
    'seemed' => 2,
    'slid' => 1,
    'crept' => 1,
    'faintly' => 1,
    'is,' => 1,
    'suddenly' => 1,
    'preceded' => 1,
    'means' => 1,
    'must' => 1,
    'gives' => 1,
    'announced' => 1,
    'sped' => 1,
    'scares' => 1,
    'met' => 1,
    'may' => 1,
    'gleamed' => 1,
    'said,' => 2,
    'looks' => 1,
    'isn\'t' => 1,
    'hated' => 1,
    'committed' => 1,
  ),
  'also' => 
  array (
    'the' => 2,
    '' => 4,
    'a' => 2,
    'assume,' => 1,
    'notes' => 1,
    'mentions' => 1,
    'tells' => 1,
    'had' => 2,
    'his' => 1,
    'wished' => 1,
    'going' => 1,
    'curved.' => 1,
    'unto' => 1,
    'with' => 1,
  ),
  'book,' => 
  array (
    'a' => 1,
    'never' => 1,
    '' => 2,
  ),
  'book' => 
  array (
    'called' => 1,
    'ever' => 1,
    'begins' => 1,
    'The' => 1,
    '' => 2,
    'to' => 1,
    'began' => 1,
    'said.' => 1,
    'back' => 1,
    'if' => 1,
    'thing' => 1,
    'with' => 1,
    'and' => 1,
    'down.' => 1,
  ),
  'called' => 
  array (
    'The' => 1,
    'Indian' => 1,
    'Ford,' => 1,
    'a' => 1,
    'France.' => 1,
    'Vogons' => 1,
    '' => 6,
    'into' => 1,
    'Earth' => 1,
    'the' => 2,
    'Norway?' => 1,
    'one' => 1,
    'back.' => 2,
    'out' => 1,
  ),
  'Earth' => 
  array (
    'book,' => 1,
    'years' => 1,
    'society' => 1,
    'as' => 1,
    'moved' => 1,
    'game' => 1,
    '' => 3,
    'had' => 1,
    'it' => 1,
    'passed' => 1,
    'minutes.' => 1,
    'years,' => 1,
    'for' => 1,
    'would' => 1,
    'of' => 1,
    'used' => 1,
    '-' => 2,
    'you' => 1,
    'by' => 1,
    'Mark' => 1,
    'and' => 1,
    'we\'re' => 1,
    'creature.' => 1,
    'any' => 1,
    'creature,' => 1,
  ),
  'never' => 
  array (
    'published' => 1,
    'seen' => 2,
    'quite' => 1,
    '' => 5,
    'could' => 1,
    'possible' => 1,
    'been' => 4,
    'evolved' => 1,
    'have' => 2,
    'learned' => 1,
    'seriously' => 1,
    'saw' => 1,
    'appeared' => 1,
    'walk' => 1,
    'send' => 1,
    'think' => 1,
    'again' => 1,
    'actually' => 1,
    'told' => 1,
    'came,' => 1,
  ),
  'published' => 
  array (
    'on' => 1,
    'in' => 1,
    'yet,' => 1,
  ),
  'Earth,' => 
  array (
    'and' => 1,
    '-' => 1,
    '' => 2,
    'your' => 1,
    'you' => 1,
    'the' => 1,
    'except' => 1,
    'man' => 1,
    'we' => 1,
  ),
  'until' => 
  array (
    'the' => 2,
    'someone' => 1,
    'you\'ve' => 1,
    'I' => 1,
    'such' => 1,
    'whoever' => 1,
    '' => 1,
  ),
  'seen' => 
  array (
    'or' => 1,
    'it' => 1,
    'to' => 1,
    'from' => 1,
    'of' => 1,
    'anything' => 1,
    'it,' => 1,
    '' => 1,
  ),
  'heard' => 
  array (
    'of' => 4,
    'either.' => 1,
    'I' => 1,
    '' => 1,
    'himself' => 1,
    'what' => 1,
    'the' => 3,
    'a' => 3,
    'rumors' => 1,
    'Marvin\'s' => 1,
  ),
  'by' => 
  array (
    'any' => 2,
    'no' => 1,
    '' => 23,
    'a' => 14,
    'now.' => 2,
    'very' => 2,
    'another' => 2,
    'that' => 1,
    'the' => 23,
    'sun' => 1,
    'this' => 1,
    'an' => 2,
    'four,' => 1,
    'some' => 1,
    'combining' => 1,
    'chance.' => 1,
    'your' => 1,
    'thinking' => 1,
    'their' => 2,
    'gnawing' => 1,
    'ten' => 1,
    'it.' => 1,
    'anything' => 1,
    'simply' => 1,
    'making' => 1,
    'now,' => 1,
    'itself.' => 1,
    'analysing' => 1,
    'means' => 1,
    'none' => 1,
    'Eccentrica' => 1,
    'telephone' => 1,
    'her' => 1,
    'that?' => 1,
    'slight' => 1,
    'time,' => 1,
    'second' => 1,
    'who' => 1,
    'most' => 1,
    'surprise.' => 1,
    'himself' => 1,
    'humanoids,' => 1,
    'now' => 1,
    'asking' => 1,
    'mice.' => 1,
    'his' => 1,
    'seven?' => 1,
  ),
  'any' => 
  array (
    'Earthman.' => 1,
    'means' => 1,
    'way' => 4,
    'convenient' => 1,
    'suggestions' => 1,
    'idea' => 3,
    'length' => 1,
    'astrophysicist' => 1,
    'kind' => 1,
    'flying' => 1,
    'of' => 4,
    'Earth' => 1,
    'one' => 1,
    '' => 9,
    'point' => 1,
    'longer.' => 1,
    'difference' => 1,
    'formal' => 1,
    'useful' => 1,
    'moment,' => 1,
    'form' => 2,
    'such' => 1,
    'clear' => 1,
    'monitor' => 1,
    'worse' => 1,
    'programme' => 1,
    'minute' => 1,
    'other' => 1,
    'tea' => 1,
    'more.' => 2,
    'headway' => 1,
    'coherent' => 1,
    'naughty' => 1,
    'reference' => 1,
    'sign' => 1,
    'further' => 1,
    'inkling' => 1,
    'day.' => 1,
    'real' => 1,
    'notice' => 1,
  ),
  'Earthman.' => 
  array (
    'Nevertheless,' => 1,
    '-' => 1,
  ),
  'Nevertheless,' => 
  array (
    'a' => 1,
  ),
  'wholly' => 
  array (
    'remarkable' => 3,
    '' => 1,
  ),
  'remarkable' => 
  array (
    'book.' => 2,
    'book' => 3,
    '' => 1,
    'house' => 1,
    'of' => 1,
  ),
  'book.' => 
  array (
    'in' => 1,
    'It' => 2,
    'How' => 1,
    '-' => 1,
  ),
  'fact' => 
  array (
    'it' => 5,
    'that' => 8,
    'he' => 2,
    'from' => 2,
    '' => 9,
    'and' => 1,
    'out' => 1,
    'they' => 1,
    'the' => 2,
    'may' => 1,
    'flattened' => 1,
    'sensationally' => 1,
    'there' => 1,
    'it\'s' => 1,
  ),
  'probably' => 
  array (
    'the' => 3,
    'thought.' => 1,
    'gone.' => 1,
    'keep' => 1,
    'just' => 2,
    'have' => 1,
    'lost' => 1,
    'seize' => 1,
    'reach' => 1,
    'find' => 1,
    'caused' => 1,
    '' => 2,
    'go' => 1,
  ),
  'come' => 
  array (
    'out' => 1,
    'to' => 9,
    'over' => 1,
    '' => 8,
    'and' => 6,
    'on,' => 3,
    'along' => 1,
    'off' => 2,
    'in.' => 1,
    'on' => 1,
    'with' => 1,
    'now' => 1,
    'after' => 1,
    'a' => 1,
    'up' => 1,
    'quietly,' => 1,
  ),
  'publishing' => 
  array (
    'houses' => 1,
    'corporations' => 1,
  ),
  'houses' => 
  array (
    'of' => 1,
  ),
  'Ursa' => 
  array (
    'Minor' => 2,
  ),
  'Minor' => 
  array (
    '-' => 2,
  ),
  'Earthman' => 
  array (
    'had' => 1,
  ),
  'either.' => 
  array (
    'Not' => 1,
    '-' => 1,
  ),
  'Not' => 
  array (
    'only' => 2,
    'a' => 1,
    'the' => 1,
    '' => 2,
    'that' => 2,
    'as' => 2,
    'die' => 1,
    'on' => 1,
    'until' => 1,
    'even' => 1,
    'that,' => 1,
    'now' => 1,
  ),
  'only' => 
  array (
    'is' => 1,
    'person' => 1,
    'because' => 1,
    '' => 8,
    'human.' => 1,
    'vestiges' => 1,
    'assume' => 1,
    'trembled' => 1,
    'place' => 2,
    'louder.' => 1,
    'heard' => 1,
    'four' => 1,
    'archipelago' => 1,
    'six' => 1,
    'man' => 1,
    'sort' => 1,
    'gave' => 1,
    'now' => 1,
    'existed' => 2,
    'thing' => 4,
    'bit' => 1,
    'fooling,' => 1,
    'thought' => 1,
    'one' => 3,
    'had' => 1,
    'links' => 1,
    'the' => 2,
    'know' => 2,
    'dimly' => 1,
    'a' => 4,
    'disturbed' => 1,
    'guess.' => 1,
    'very' => 1,
    'ever' => 1,
    'I' => 1,
    'goes' => 1,
    'half' => 1,
    'possible' => 1,
    'joking.' => 1,
    'were' => 1,
    'with' => 1,
    'have' => 1,
  ),
  'highly' => 
  array (
    'successful' => 1,
    'domed' => 1,
    '' => 2,
    'profitable' => 1,
    'trained' => 1,
  ),
  'successful' => 
  array (
    'one' => 1,
    '' => 1,
    'life' => 1,
    'merchants' => 1,
    'was' => 1,
  ),
  'more' => 
  array (
    'popular' => 2,
    'controversial' => 1,
    'relaxed' => 1,
    'pedestrian' => 1,
    'or' => 7,
    '' => 8,
    'of' => 3,
    'like' => 1,
    'quickly.' => 1,
    'unpleasant' => 1,
    'wrong.>' => 1,
    'the' => 1,
    'warmly' => 1,
    'keys.' => 1,
    'and' => 2,
    'to' => 2,
    'when' => 1,
    'important' => 1,
    'tickertape.' => 1,
    'filled' => 1,
    'about' => 1,
    'intelligent' => 3,
    'than' => 1,
    'enthusiastic' => 1,
    'a' => 2,
    'fiendish' => 1,
    'power.' => 1,
    'quietly,' => 1,
    'years' => 1,
    'yank,' => 1,
    'sharply' => 1,
    'seconds.' => 1,
  ),
  'popular' => 
  array (
    'than' => 1,
    'tri-D;' => 1,
    '' => 1,
    'fact' => 1,
    'are' => 1,
    'publicity' => 1,
    'press,' => 1,
  ),
  'than' => 
  array (
    'the' => 5,
    '' => 16,
    'Oolon' => 1,
    'thirty' => 1,
    'that...' => 1,
    'sixteen' => 1,
    'two' => 1,
    'a' => 2,
    'anyone' => 1,
    'anything' => 1,
    'ever' => 1,
    'that' => 1,
    'my' => 1,
    'contemptuous.' => 1,
    'we' => 1,
    'you' => 1,
    'an' => 1,
    'nobody.' => 1,
    'dolphins' => 1,
    'dolphins,' => 1,
    'I' => 1,
    'right' => 1,
    'they' => 1,
  ),
  'Celestial' => 
  array (
    'Home' => 1,
  ),
  'Home' => 
  array (
    'Care' => 1,
  ),
  'Care' => 
  array (
    'Omnibus,' => 1,
  ),
  'Omnibus,' => 
  array (
    'better' => 1,
  ),
  'better' => 
  array (
    'selling' => 1,
    '' => 5,
    'be' => 1,
    'get' => 1,
    'stick' => 1,
    'minds' => 1,
    'dimension.' => 1,
    'start' => 1,
    'name' => 1,
    'off' => 1,
    'to' => 3,
    'warn' => 1,
    'listen' => 1,
  ),
  'selling' => 
  array (
    '' => 1,
    'detergent.' => 1,
  ),
  'Fifty' => 
  array (
    '' => 1,
  ),
  'More' => 
  array (
    '' => 2,
    'of' => 2,
    'importantly,' => 1,
    'gunk' => 1,
  ),
  'Things' => 
  array (
    '' => 1,
  ),
  'do' => 
  array (
    '' => 14,
    'it.' => 4,
    'you' => 25,
    'it' => 7,
    'you?' => 3,
    'both' => 1,
    'anything' => 1,
    'about' => 1,
    'that' => 3,
    'for' => 1,
    'if' => 1,
    'continue...' => 1,
    'a' => 2,
    'it?' => 4,
    'I.' => 1,
    'not' => 2,
    'the' => 2,
    'was' => 1,
    'is' => 2,
    'mighty' => 1,
    'we' => 4,
    'I' => 1,
    'now.' => 1,
    'with' => 3,
    'this.' => 1,
    'to' => 1,
    'something,' => 1,
    'something?' => 1,
    'know' => 1,
    'they' => 1,
    'and' => 1,
    'now,' => 1,
    'that.' => 1,
    'that!' => 1,
    'even' => 1,
  ),
  'Zero' => 
  array (
    '' => 1,
  ),
  'Gravity,' => 
  array (
    '' => 1,
  ),
  'controversial' => 
  array (
    'than' => 1,
    'choice,' => 1,
  ),
  'Oolon' => 
  array (
    'Colluphid\'s' => 1,
    '' => 1,
  ),
  'Colluphid\'s' => 
  array (
    'trilogy' => 1,
  ),
  'trilogy' => 
  array (
    'of' => 1,
  ),
  'philosophical' => 
  array (
    'blockbusters' => 1,
  ),
  'blockbusters' => 
  array (
    'Where' => 1,
  ),
  'Where' => 
  array (
    'God' => 1,
    'are' => 2,
    'no' => 1,
    'phases.' => 1,
    'shall' => 1,
  ),
  'God' => 
  array (
    'Went' => 1,
    'Person' => 1,
    'what' => 1,
    'it' => 1,
    'for' => 1,
    'they' => 1,
    'I\'m' => 1,
    'bless...' => 1,
    '' => 1,
  ),
  'Went' => 
  array (
    'Wrong,' => 1,
    'on' => 1,
  ),
  'Wrong,' => 
  array (
    'Some' => 1,
  ),
  'Some' => 
  array (
    'More' => 1,
    'factual' => 1,
    'invite' => 1,
    'of' => 1,
    'bastard' => 1,
    'people' => 1,
  ),
  'God\'s' => 
  array (
    'Greatest' => 1,
    'sake' => 1,
    'sake?' => 1,
  ),
  'Greatest' => 
  array (
    'Mistakes' => 1,
    'and' => 1,
  ),
  'Mistakes' => 
  array (
    'and' => 1,
  ),
  'Who' => 
  array (
    'is' => 1,
    'needs' => 1,
    'said' => 2,
    'was' => 2,
    '-' => 1,
    'are' => 3,
    'picked' => 1,
    'by?' => 1,
    'am' => 1,
    'put' => 1,
    'cares?' => 1,
  ),
  'Person' => 
  array (
    'Anyway?' => 1,
  ),
  'Anyway?' => 
  array (
    'In' => 1,
  ),
  'In' => 
  array (
    'many' => 1,
    'other' => 2,
    '' => 4,
    'fact,' => 2,
    'front' => 1,
    'the' => 7,
    'return' => 1,
    'a' => 4,
    'moments' => 1,
    'fact' => 6,
    'My' => 1,
    'one' => 1,
    'those' => 1,
    'these' => 1,
    'order' => 1,
    'my' => 1,
    'seven' => 1,
    'orbit' => 1,
    'this' => 1,
  ),
  'many' => 
  array (
    'of' => 1,
    '' => 5,
    'people' => 2,
    'miles' => 1,
    'times' => 1,
    'years' => 1,
    'different' => 1,
    'passages' => 1,
    'structures' => 1,
    'problems' => 1,
    'were' => 1,
    'roads' => 2,
  ),
  'relaxed' => 
  array (
    'civilizations' => 1,
    'and' => 2,
    'on' => 1,
    'day,' => 1,
    'and,' => 1,
  ),
  'civilizations' => 
  array (
    'on' => 1,
  ),
  'Outer' => 
  array (
    'Eastern' => 1,
  ),
  'Eastern' => 
  array (
    'Rim' => 1,
  ),
  'Rim' => 
  array (
    'of' => 1,
  ),
  'Galaxy,' => 
  array (
    'the' => 1,
    '' => 4,
    'and' => 3,
  ),
  'already' => 
  array (
    '' => 3,
    'spent' => 1,
    'thrown' => 1,
    'learned' => 1,
    'been' => 2,
    'you' => 1,
    'thought' => 1,
  ),
  'supplanted' => 
  array (
    '' => 1,
  ),
  'Encyclopedia' => 
  array (
    'Galactica' => 2,
    'Galactica.' => 1,
  ),
  'Galactica' => 
  array (
    'as' => 1,
    'has' => 1,
    'defines' => 1,
    'that' => 1,
  ),
  'as' => 
  array (
    'the' => 21,
    'well,' => 1,
    'they' => 6,
    'soon' => 4,
    'I' => 1,
    'he' => 15,
    'if' => 9,
    'being' => 3,
    '' => 47,
    'mindboggingly' => 1,
    'a' => 13,
    'such...' => 1,
    'you' => 4,
    'Mr.' => 1,
    'office' => 1,
    'birds.' => 1,
    'in' => 3,
    'their' => 1,
    'to' => 3,
    'President' => 1,
    'an' => 5,
    'simply' => 1,
    'it' => 10,
    'much' => 4,
    'anything.' => 1,
    'catering' => 1,
    'well' => 2,
    'heavily' => 1,
    'firelighters.' => 1,
    'Arthur' => 1,
    'because' => 1,
    'lumps' => 1,
    'well!' => 1,
    'sluggish' => 1,
    'huge' => 1,
    'with' => 1,
    'we' => 2,
    'such,' => 2,
    'such?' => 2,
    'comes' => 1,
    '"Your' => 1,
    '"a' => 2,
    'Zaphod' => 2,
    'you,' => 1,
    'long' => 1,
    'was' => 1,
    'of' => 1,
    'I\'m' => 1,
    'our' => 1,
    'everyone' => 2,
    'had' => 1,
    'my' => 1,
    'Ford' => 1,
    'nothing' => 1,
    'day.' => 1,
    'all' => 1,
    'theories' => 1,
    'amusing' => 1,
    'familiar' => 1,
    'far' => 1,
    'representatives' => 1,
    'Slartibartfast' => 1,
    'bright' => 1,
    'both' => 1,
  ),
  'standard' => 
  array (
    'repository' => 1,
  ),
  'repository' => 
  array (
    '' => 1,
  ),
  'knowledge' => 
  array (
    '' => 1,
    'of' => 1,
  ),
  'wisdom,' => 
  array (
    'for' => 1,
  ),
  'though' => 
  array (
    'it' => 4,
    'he' => 3,
    'intervening' => 1,
    'was' => 1,
    '' => 1,
    'there' => 1,
    'you' => 1,
    'no' => 1,
    'this' => 1,
    'not' => 1,
  ),
  'omissions' => 
  array (
    '' => 1,
  ),
  'contains' => 
  array (
    '' => 1,
    'contributions' => 1,
    'many' => 1,
  ),
  'apocryphal,' => 
  array (
    'or' => 1,
  ),
  'least' => 
  array (
    'wildly' => 1,
    'three' => 1,
    '' => 1,
    'no' => 1,
    'give' => 1,
    'not' => 1,
  ),
  'wildly' => 
  array (
    'inaccurate,' => 1,
    'for' => 1,
    'around' => 1,
    'excited.' => 1,
  ),
  'inaccurate,' => 
  array (
    'it' => 1,
  ),
  'scores' => 
  array (
    'over' => 1,
  ),
  'over' => 
  array (
    'the' => 10,
    'a' => 5,
    'Arthur' => 1,
    '' => 14,
    'you?' => 1,
    'by' => 1,
    'here' => 1,
    'from' => 1,
    'his' => 3,
    'our' => 1,
    'three' => 2,
    'nervously' => 1,
    'The' => 1,
    'again.' => 1,
    'each' => 1,
    'many' => 1,
    'pieces' => 1,
    'here...' => 1,
    'to' => 3,
    'Magrathea.' => 1,
    'there' => 1,
    'on' => 1,
    'there?' => 1,
    'in' => 2,
    'Africa!' => 1,
    'again' => 1,
    'an' => 1,
  ),
  'older,' => 
  array (
    '' => 1,
  ),
  'pedestrian' => 
  array (
    'work' => 1,
  ),
  'work' => 
  array (
    'in' => 1,
    'out' => 6,
    '' => 4,
    'on' => 1,
    'of' => 1,
    'this' => 1,
    'out,' => 1,
    'it' => 1,
    'something' => 1,
    'at,' => 1,
    'properly.' => 1,
    'gone' => 1,
    'like' => 1,
  ),
  'important' => 
  array (
    'respects.' => 1,
    'that' => 1,
    'thing' => 1,
    'to' => 1,
    'than' => 1,
    '' => 2,
    'and' => 1,
    'about' => 2,
  ),
  'respects.' => 
  array (
    'First,' => 1,
  ),
  'First,' => 
  array (
    'it' => 1,
  ),
  'slightly' => 
  array (
    'cheaper;' => 1,
    'odd' => 1,
    'too' => 1,
    'alarmed' => 1,
    'and' => 1,
    'less' => 1,
    'on' => 1,
    'embarrassed' => 1,
    'raised' => 1,
    'soft' => 1,
    '' => 1,
  ),
  'cheaper;' => 
  array (
    'and' => 1,
  ),
  'secondly' => 
  array (
    'it' => 1,
  ),
  'words' => 
  array (
    '' => 1,
    'he' => 1,
    'Don\'t' => 1,
    'Vogon' => 1,
    'began' => 1,
    'time' => 1,
    'Mostly' => 1,
    'Please' => 1,
    'the' => 1,
    'far' => 1,
    'I' => 1,
  ),
  'Don\'t' => 
  array (
    'Panic' => 2,
    'you' => 2,
    'worry,' => 2,
    'Panic.' => 2,
    'knock' => 1,
    'talk' => 1,
    'bother' => 1,
    'make' => 1,
    'blame' => 1,
    'get' => 1,
    'feel' => 1,
    'pretend' => 1,
  ),
  'Panic' => 
  array (
    'inscribed' => 1,
    'printed' => 1,
    'sprouted' => 1,
  ),
  'inscribed' => 
  array (
    'in' => 1,
  ),
  'large' => 
  array (
    'friendly' => 2,
    'glass' => 1,
    'gold' => 1,
    'buildings' => 1,
    '' => 5,
    'part' => 1,
    'red' => 1,
    'circular' => 1,
    'woobly' => 1,
    'video' => 1,
    'mind.' => 1,
    'desk' => 1,
    'sums' => 1,
    'axe,' => 1,
    'circle' => 1,
    'stately' => 1,
    'perspex' => 1,
    'table' => 1,
  ),
  'friendly' => 
  array (
    'letters' => 1,
    'letters.' => 1,
    'smile.' => 1,
    'condescension,' => 1,
  ),
  'letters' => 
  array (
    'on' => 1,
    '' => 2,
  ),
  'cover.' => 
  array (
    'But' => 1,
    '-' => 2,
  ),
  'terrible,' => 
  array (
    'stupid' => 1,
  ),
  'extraordinary' => 
  array (
    'consequences,' => 1,
    'new' => 1,
    '' => 3,
    'of' => 1,
    'person,' => 1,
    'commission' => 1,
  ),
  'consequences,' => 
  array (
    'and' => 1,
  ),
  'consequences' => 
  array (
    '' => 1,
  ),
  'inextricably' => 
  array (
    'intertwined' => 1,
  ),
  'intertwined' => 
  array (
    'with' => 1,
  ),
  'begins' => 
  array (
    'very' => 1,
    'with' => 1,
    'like' => 1,
    'to' => 1,
  ),
  'very' => 
  array (
    'simply.' => 1,
    'good.' => 2,
    'fast' => 1,
    'fast.' => 4,
    'long' => 1,
    'nervous.' => 1,
    'slightly' => 2,
    'stiff' => 1,
    'much,' => 2,
    '' => 18,
    'simple,' => 1,
    'worried.' => 1,
    'carefully...' => 1,
    'ravenous);' => 1,
    'kind' => 1,
    'far,' => 1,
    'ultimate' => 1,
    'pretty' => 1,
    'much' => 6,
    'few' => 3,
    'recently' => 1,
    'tall,' => 1,
    'angry' => 1,
    'thoroughly' => 1,
    'lucky' => 1,
    'worst' => 1,
    'slowly.' => 1,
    'much.' => 4,
    'sad.' => 1,
    'neat.' => 1,
    'alien.' => 1,
    'good' => 4,
    'nice' => 1,
    'odd' => 1,
    'very' => 2,
    'improbable.' => 1,
    'depressed,' => 1,
    'insecure.' => 1,
    'calmly,' => 1,
    'happy.' => 1,
    'well' => 1,
    'excited' => 1,
    'old.' => 1,
    'interesting.' => 1,
    'large' => 2,
    'rich' => 2,
    'surprised' => 1,
    'little' => 1,
    'fast?' => 1,
    'cold.' => 1,
    'hard' => 1,
    'strong' => 1,
    'unevenly' => 1,
    'fine' => 1,
    'faintly,' => 1,
    'rapid' => 1,
    'slight' => 1,
    'effective.' => 1,
    'big,' => 1,
    'vectors' => 1,
    'salutary,' => 1,
    'thoroughly,' => 1,
    'heavy' => 1,
    'safe' => 1,
    'moment' => 2,
    'well,' => 1,
    'relaxed' => 1,
    'significant' => 1,
    'effective' => 1,
    'bored' => 1,
  ),
  'simply.' => 
  array (
    'It' => 1,
  ),
  'house.' => 
  array (
    'Chapter' => 1,
    'He' => 1,
    'Mr.' => 1,
    '' => 1,
  ),
  'Chapter' => 
  array (
    1 => 1,
    2 => 1,
    3 => 1,
    4 => 1,
    5 => 1,
    6 => 1,
    7 => 1,
    8 => 1,
    9 => 1,
    10 => 1,
    11 => 1,
    12 => 1,
    13 => 1,
    14 => 1,
    15 => 1,
    16 => 1,
    17 => 1,
    18 => 1,
    19 => 1,
    20 => 1,
    21 => 1,
    22 => 1,
    23 => 1,
    24 => 1,
    25 => 1,
    26 => 1,
    27 => 1,
    28 => 1,
    29 => 1,
    30 => 1,
    31 => 1,
    32 => 1,
    33 => 1,
    34 => 1,
    35 => 1,
  ),
  'house' => 
  array (
    'stood' => 1,
    'by' => 1,
    'was' => 1,
    'and' => 2,
    'got' => 2,
    'being' => 2,
    'had' => 1,
    'down' => 1,
    'down!' => 1,
    'down?' => 1,
    '' => 2,
    'down.' => 1,
  ),
  'stood' => 
  array (
    'on' => 3,
    'and' => 3,
    'up,' => 1,
    'with' => 1,
    'a' => 2,
    'up.' => 3,
    'out' => 1,
    'high' => 1,
    'in' => 1,
    '' => 3,
    'waiting' => 2,
    'starkly' => 1,
    'another' => 1,
  ),
  'slight' => 
  array (
    'rise' => 2,
    'whisper,' => 1,
    'groan.' => 1,
    'hiss' => 1,
    'cough,' => 1,
    'parallel' => 1,
    '' => 2,
    'clanking' => 1,
    'whistle.' => 1,
    'degrees' => 1,
    'and' => 1,
    'involuntary' => 1,
    'yawn' => 1,
    'he' => 1,
    'subsidence' => 1,
    'doubt' => 1,
  ),
  'rise' => 
  array (
    'just' => 1,
    'in' => 1,
  ),
  'just' => 
  array (
    'on' => 1,
    'found' => 3,
    'wouldn\'t' => 1,
    'once' => 1,
    'any' => 1,
    'liked' => 1,
    'let' => 2,
    'looking' => 1,
    '' => 15,
    'like' => 3,
    'won.' => 1,
    'that' => 2,
    'in' => 1,
    'said:' => 1,
    'how' => 1,
    'your' => 1,
    'had' => 2,
    'have' => 2,
    'another' => 1,
    'beneath' => 1,
    'for' => 4,
    'went' => 1,
    'stuck' => 1,
    'received.' => 1,
    'boiled' => 1,
    'come' => 1,
    'a' => 6,
    'want' => 2,
    'under' => 2,
    'the' => 2,
    'write' => 1,
    'after' => 2,
    'stop' => 1,
    'trying' => 2,
    'find' => 1,
    'lay' => 1,
    'been' => 1,
    'won\'t' => 1,
    'appeared' => 1,
    'said,' => 1,
    'as' => 1,
    'do' => 1,
    'fine,' => 2,
    'act' => 1,
    'fine.' => 1,
    'part' => 1,
    'thought' => 1,
    'to' => 3,
    'too...' => 1,
    'use' => 1,
    'when' => 1,
    'fall' => 1,
    'show' => 1,
    'dropped' => 1,
    'somebody.' => 1,
    'far' => 1,
    'great' => 1,
    'going' => 1,
    'supposing' => 1,
    'some' => 1,
    'interested!' => 1,
    'saying,' => 1,
    'saved' => 1,
    'sort' => 1,
    'strange' => 1,
    'look' => 1,
    'happens.' => 1,
    'didn\'t' => 1,
    'take' => 1,
    'slept' => 1,
    'very' => 1,
    'one' => 1,
    'gave' => 1,
    'by' => 1,
    'keep' => 1,
    'coincidences,' => 1,
    'life,' => 1,
    'go' => 1,
    'habit' => 1,
    'sitting' => 1,
    'mentioning' => 1,
    'taking' => 1,
    'read' => 1,
    'gaped.' => 1,
    'don\'t' => 1,
    'ignore' => 1,
  ),
  'edge' => 
  array (
    'of' => 4,
  ),
  'village.' => 
  array (
    '' => 1,
    'He' => 1,
  ),
  'looked' => 
  array (
    'over' => 2,
    '' => 10,
    'up' => 3,
    'into' => 1,
    'across' => 1,
    'around.' => 1,
    'at' => 16,
    'instead' => 1,
    'back' => 4,
    'straight' => 1,
    'rather' => 1,
    'insanely' => 1,
    'round' => 5,
    'wildly' => 1,
    'about,' => 1,
    'vaguely' => 1,
    'away.' => 4,
    'that' => 1,
    'lost.' => 1,
    'infuriatingly' => 1,
    'very' => 1,
    'up.' => 2,
    'like' => 1,
    'excitingly' => 1,
    'as' => 2,
    'about' => 1,
    'inquiringly' => 1,
    'dead' => 1,
    'back.' => 1,
    'for' => 1,
    'gravely' => 1,
    'down' => 1,
    'like.' => 1,
    'out' => 1,
    'around' => 1,
    'pointedly' => 1,
    'him' => 1,
    'round.' => 1,
  ),
  'broad' => 
  array (
    'spread' => 1,
  ),
  'spread' => 
  array (
    'of' => 1,
    'his' => 2,
    '' => 1,
  ),
  'West' => 
  array (
    'Country' => 1,
  ),
  'Country' => 
  array (
    '' => 1,
  ),
  'farmland.' => 
  array (
    'Not' => 1,
  ),
  'means' => 
  array (
    '-' => 1,
    'a' => 1,
    'small' => 1,
    'that' => 1,
    'of' => 2,
    'we' => 1,
    'shortly' => 1,
    'something!' => 1,
  ),
  'thirty' => 
  array (
    '' => 4,
    'seconds' => 2,
    'seconds.' => 1,
    'seconds...' => 1,
    'thousand' => 1,
  ),
  'old,' => 
  array (
    'squattish,' => 1,
    'courteous,' => 1,
  ),
  'squattish,' => 
  array (
    'squarish,' => 1,
  ),
  'squarish,' => 
  array (
    'made' => 1,
  ),
  'brick,' => 
  array (
    'and' => 1,
  ),
  'four' => 
  array (
    'windows' => 1,
    'litres' => 1,
    'inches' => 1,
    'packets' => 1,
    'light' => 1,
    '' => 6,
    'in' => 1,
    'years' => 1,
    'against.' => 1,
    'were' => 1,
    'figures' => 1,
    'of' => 2,
    'stared' => 1,
  ),
  'windows' => 
  array (
    'set' => 1,
    'and' => 2,
    'looked' => 1,
    '' => 1,
  ),
  'set' => 
  array (
    'in' => 1,
    '' => 3,
    'speech' => 1,
    'into' => 1,
    'magnificently' => 1,
    'all' => 1,
    'yourself' => 1,
  ),
  'front' => 
  array (
    'of' => 16,
    '' => 4,
    'had' => 1,
  ),
  'size' => 
  array (
    'and' => 2,
    'on' => 1,
    'it' => 1,
    'of' => 3,
    '' => 1,
    'that' => 1,
  ),
  'proportion' => 
  array (
    'which' => 1,
  ),
  'less' => 
  array (
    'exactly' => 1,
    'than' => 2,
    'that' => 1,
    'a' => 1,
    'right.' => 1,
    '' => 1,
    'slowly,' => 1,
    'brightly.' => 1,
    'humanoid' => 1,
    'at' => 1,
    'interesting' => 1,
    'thoroughly' => 1,
    'running' => 1,
    'the' => 1,
  ),
  'exactly' => 
  array (
    'failed' => 1,
    'gone' => 1,
    'how' => 2,
    'need...' => 1,
    'the' => 2,
    'what' => 1,
    '' => 4,
    'a' => 1,
    'why' => 1,
  ),
  'failed' => 
  array (
    'to' => 4,
    '' => 1,
  ),
  'please' => 
  array (
    '' => 1,
    'tell' => 2,
  ),
  'eye.' => 
  array (
    'The' => 1,
  ),
  'person' => 
  array (
    'for' => 1,
  ),
  'whom' => 
  array (
    'the' => 2,
    '' => 1,
    'he' => 1,
  ),
  'way' => 
  array (
    'special' => 1,
    'before' => 1,
    '' => 12,
    'up' => 2,
    'he' => 2,
    'that' => 4,
    'from' => 1,
    'at' => 1,
    'and' => 1,
    'to' => 3,
    'his' => 1,
    'out' => 2,
    'down' => 1,
    'commemorated' => 1,
    'the' => 1,
    'of' => 3,
    'round.' => 1,
    'somewhere...' => 1,
    'be' => 1,
    'it' => 3,
    'perfectly' => 1,
    'in.' => 1,
    'I' => 1,
    'through' => 1,
    'into' => 2,
    'out.' => 1,
    'do' => 1,
    'back' => 1,
  ),
  'special' => 
  array (
    'was' => 1,
    'service' => 1,
    'clients' => 1,
    'way' => 1,
  ),
  'Arthur' => 
  array (
    'Dent,' => 3,
    'that' => 1,
    'didn\'t' => 2,
    'Dent\'s' => 3,
    '' => 17,
    'lay' => 3,
    'Dent' => 5,
    'Dent.' => 5,
    'himself' => 1,
    'with' => 6,
    'looked' => 9,
    'was' => 8,
    'had' => 5,
    'stood' => 1,
    'remained' => 1,
    'who' => 2,
    'smiled' => 1,
    'stared' => 6,
    'thought.' => 1,
    'shrugged' => 1,
    'gave' => 1,
    'musing' => 1,
    'choked' => 1,
    'and' => 5,
    'tripped,' => 1,
    'struggled' => 1,
    'prodded' => 1,
    'turned' => 1,
    'blinked' => 4,
    'began' => 3,
    'levelly.' => 1,
    'discovered' => 1,
    'thought' => 4,
    'let' => 1,
    'grabbed' => 1,
    'followed' => 3,
    'lolling' => 1,
    'lolled.' => 1,
    'said' => 2,
    'felt' => 3,
    'you\'re' => 1,
    'twisted' => 1,
    'rather' => 1,
    'agreed' => 1,
    'without' => 1,
    'through' => 1,
    'twisting' => 1,
    'popped' => 1,
    'once' => 1,
    'were' => 2,
    'as' => 2,
    '-' => 1,
    'listened' => 1,
    'muttered' => 1,
    'irritably.' => 1,
    'grimly' => 1,
    'couldn\'t' => 2,
    'goggled' => 1,
    'sharply.' => 1,
    'coldly.' => 1,
    'would' => 1,
    'a' => 1,
    'slept:' => 1,
    'awoke' => 1,
    'testily.' => 1,
    'drank' => 1,
    'scrambled' => 1,
    'can\'t' => 1,
    'in' => 2,
    'stamped' => 1,
    'wandered' => 1,
    'now' => 1,
    'read' => 1,
    'got' => 1,
    'slapped' => 1,
    'practically' => 2,
    'guessed.' => 1,
    'frowned' => 1,
    'incredulously.' => 1,
    'to' => 2,
    'shivered' => 1,
    'tried' => 2,
    'realized' => 1,
    'could' => 1,
    'guessed' => 1,
    'made' => 1,
    'knew,' => 1,
    'weakly,' => 1,
    'towards' => 1,
    'found' => 1,
    'suddenly' => 1,
    'holding' => 1,
    'thoughtfully,' => 1,
    'glanced' => 3,
    'gaped.' => 1,
    'doubtfully.' => 1,
  ),
  'Dent,' => 
  array (
    'and' => 1,
    '-' => 4,
    'the' => 1,
    'says' => 1,
  ),
  'happened' => 
  array (
    'to' => 8,
    'when' => 1,
    'so' => 1,
    '' => 3,
    'now' => 1,
    'was' => 3,
    'after' => 1,
  ),
  'he' => 
  array (
    'lived' => 1,
    '' => 74,
    'was' => 50,
    'always' => 3,
    'thought' => 5,
    'stopped' => 1,
    'hung' => 1,
    'been' => 1,
    'must' => 1,
    'rather' => 1,
    'thought.' => 4,
    'didn\'t' => 8,
    'had' => 26,
    'said,' => 55,
    'wanted' => 1,
    'just' => 3,
    'hoped' => 1,
    'said' => 26,
    'wiped' => 1,
    'told' => 1,
    'said.' => 61,
    'usually' => 1,
    'would' => 10,
    'could' => 11,
    'squatted' => 1,
    'can' => 1,
    'asked.' => 5,
    'did' => 5,
    'asked' => 5,
    'wants' => 1,
    'can\'t' => 1,
    'shouted.' => 1,
    'did)' => 1,
    'called.' => 1,
    'hasn\'t?' => 1,
    'and' => 1,
    'will' => 2,
    'knew' => 10,
    'continued,' => 3,
    'felt' => 4,
    'liked' => 1,
    'pretended' => 1,
    'also' => 1,
    'urged.' => 1,
    'yelped.' => 1,
    'hooted' => 1,
    'gave' => 2,
    'experienced' => 1,
    'couldn\'t' => 4,
    'left.' => 1,
    'yelled.' => 3,
    'noticed' => 2,
    'shrieked.' => 1,
    'opened' => 1,
    'wields' => 1,
    'is' => 2,
    'has' => 1,
    'skipped' => 1,
    'smiled' => 1,
    'cooed' => 1,
    'ran' => 1,
    'waved' => 2,
    'put' => 1,
    'thought,' => 5,
    'might' => 1,
    'grinned' => 1,
    'fingered' => 1,
    'ever' => 1,
    'both' => 1,
    'christened' => 1,
    'quite' => 1,
    'agreed' => 1,
    'asked,' => 1,
    'shouted' => 2,
    'hissed' => 1,
    'scrabbled' => 1,
    'heard...' => 1,
    'added' => 3,
    'used' => 1,
    'came' => 2,
    'burst' => 1,
    'hadn\'t' => 1,
    'began.' => 1,
    'had)' => 1,
    'whirred,' => 1,
    'joined' => 1,
    'boomed.' => 2,
    'resumed.' => 1,
    'had.' => 1,
    'went' => 1,
    'grabbed' => 1,
    'hummed' => 1,
    'suddenly' => 2,
    'cried.' => 1,
    'left' => 1,
    'totally' => 1,
    'continued' => 1,
    'quacked.' => 1,
    'got' => 2,
    'tapped' => 1,
    'did.' => 1,
    'shouted,' => 1,
    'read' => 1,
    'began' => 1,
    'reached' => 2,
    'turned.' => 2,
    'droned,' => 1,
    'muttered,' => 1,
    'actually' => 1,
    'walked' => 2,
    'kept' => 1,
    'stepped' => 2,
    'intoned' => 1,
    'drawled,' => 1,
    'paused,' => 1,
    'wouldn\'t' => 1,
    'never' => 1,
    'entered' => 1,
    'hissed.' => 1,
    'continued.' => 1,
    'hated' => 1,
    'realized' => 1,
    'watched' => 1,
    'suggested.' => 1,
    'pulled' => 1,
    'demanded.' => 1,
    'hadn\'t.' => 1,
    'shut' => 1,
    'strode' => 1,
    'frowned' => 1,
    'visited' => 1,
    'saw' => 1,
    'wasn\'t.' => 1,
    'muttered' => 2,
    'seated' => 1,
    'spluttered.' => 1,
    'tried' => 1,
    'made' => 1,
    'sensed' => 1,
    'sat' => 1,
    'addressed' => 1,
    'added,' => 1,
    'explained' => 1,
    'paused' => 1,
    'now' => 1,
    'pottered' => 1,
    'took' => 1,
    'cried' => 1,
    'sailed' => 1,
    'found' => 2,
    'whispered.' => 1,
    'assumed.' => 1,
    'explained.' => 1,
    'breathed' => 1,
    'teleported' => 1,
    'say?' => 2,
    'come' => 1,
    'but' => 1,
    'added.' => 1,
    'detected' => 1,
    'seemed' => 1,
    'approached' => 1,
    'walked,' => 1,
    'nearly' => 1,
    'exclaimed.' => 1,
    'reasoned,' => 1,
  ),
  'lived' => 
  array (
    'in.' => 1,
    'in' => 1,
    'long' => 1,
    '' => 1,
    'on' => 2,
  ),
  'in.' => 
  array (
    '' => 3,
    'A' => 1,
    'Beneath' => 1,
    'Vogons' => 1,
    'Their' => 1,
    '-' => 3,
    'He' => 2,
    'Ford' => 1,
    'Bit' => 1,
    'Marvin' => 1,
  ),
  'He' => 
  array (
    'had' => 9,
    'was' => 29,
    'worked' => 1,
    'woke' => 2,
    'adjusted' => 1,
    'shaved' => 1,
    'stared' => 2,
    'began' => 2,
    'supposed' => 1,
    'caught' => 1,
    'stood' => 1,
    'vaguely' => 1,
    'took' => 1,
    '' => 29,
    'stuck' => 2,
    'tried' => 3,
    'would' => 1,
    'didn\'t' => 6,
    'flushed' => 1,
    'shifted' => 1,
    'stuttered' => 1,
    'struck' => 1,
    'said,' => 3,
    'looked' => 5,
    'wants' => 1,
    'thought' => 2,
    'frowned,' => 1,
    'sighed.' => 1,
    'turned' => 6,
    'felt' => 3,
    'saw' => 1,
    'pushed' => 4,
    'frowned.' => 1,
    'just' => 2,
    'added,' => 1,
    'quickly' => 1,
    'made' => 1,
    'suddenly' => 1,
    'heard' => 3,
    'wouldn\'t' => 1,
    'knew' => 2,
    'is' => 1,
    'banked' => 1,
    'relaxed' => 1,
    'twisted' => 2,
    'grinned' => 2,
    'spread' => 1,
    'waited' => 1,
    'singled' => 1,
    'said' => 2,
    'lifted' => 1,
    'breathed' => 1,
    'crouched' => 1,
    'opened' => 3,
    'wished' => 2,
    'sat' => 3,
    'snatched' => 1,
    'couldn\'t,' => 1,
    'gasped' => 1,
    'tossed' => 1,
    'prodded' => 1,
    'decided' => 1,
    'passed' => 2,
    'jerked' => 1,
    'always' => 1,
    'pressed' => 1,
    'could' => 1,
    'clenched' => 1,
    'went' => 2,
    'threw' => 1,
    'did' => 3,
    'rolled' => 2,
    'floundered.' => 1,
    'floundered' => 1,
    'paused.' => 3,
    'hummed' => 1,
    'considered' => 1,
    'spluttered' => 1,
    'filled' => 1,
    'flung' => 1,
    'slumped' => 1,
    'wound' => 1,
    'tapped' => 1,
    'shook' => 1,
    'proffered' => 1,
    'hadn\'t' => 1,
    'heaved' => 1,
    'stepped' => 1,
    'gatecrashed' => 1,
    'only' => 1,
    'also' => 1,
    'attacked' => 1,
    'edged' => 1,
    'cleared' => 1,
    'got' => 3,
    'shrugged.' => 1,
    'glanced' => 2,
    'released' => 1,
    'struggled' => 1,
    'stooped' => 1,
    'seemed' => 2,
    'dragged' => 1,
    'watched' => 1,
    'trudged' => 1,
    'paused' => 2,
    'pointed' => 1,
    'peered' => 1,
    'closed' => 1,
    'continued:' => 1,
    'gestured' => 1,
    'experienced' => 1,
    'poked' => 1,
    'gave' => 3,
    'told' => 1,
    'picked' => 1,
    'rummaged' => 1,
    'swivelled' => 1,
    'wasn\'t' => 1,
    'scuttled' => 1,
    'thought.' => 1,
    'reached' => 1,
    'hurried' => 1,
    'jacked' => 1,
    'came' => 1,
  ),
  'three' => 
  array (
    'years,' => 1,
    '' => 3,
    'cubes' => 1,
    'pints' => 2,
    'green' => 1,
    'billion' => 2,
    'to' => 3,
    'inches' => 1,
    'airlock' => 1,
    'hundred' => 2,
    'coffee' => 1,
    'planets' => 1,
    'million' => 1,
    'sat' => 1,
    'parsecs' => 1,
    'could' => 1,
    'distinct' => 1,
  ),
  'years,' => 
  array (
    'ever' => 1,
    'maybe' => 1,
    'but' => 2,
    'so' => 1,
    '-' => 2,
    'into' => 1,
    'Earthman...' => 1,
    'it' => 1,
  ),
  'since' => 
  array (
    '' => 4,
    'his' => 1,
    'the' => 2,
    'this' => 1,
  ),
  'moved' => 
  array (
    '' => 3,
    'slowly' => 2,
    'across' => 1,
    'a' => 1,
    'again.' => 1,
    'ahead' => 1,
    'forward' => 1,
  ),
  'London' => 
  array (
    'because' => 1,
    '' => 1,
  ),
  'him' => 
  array (
    'nervous' => 1,
    'most' => 1,
    'what' => 4,
    'though.' => 1,
    'for' => 2,
    'if' => 1,
    'feel' => 1,
    'to' => 12,
    'again.' => 1,
    'to!' => 1,
    'here.' => 1,
    'with' => 3,
    'severely.' => 1,
    'in' => 10,
    '' => 10,
    'wanly' => 1,
    'and' => 7,
    'a' => 5,
    'had' => 1,
    'dearly' => 1,
    'very' => 1,
    'he' => 2,
    'by' => 1,
    'rather' => 1,
    'expectantly.' => 1,
    'blankly' => 1,
    'that' => 2,
    'something' => 1,
    'who' => 1,
    'wearing' => 1,
    'sliding' => 1,
    'full' => 1,
    'wildly.' => 1,
    'as' => 2,
    'even' => 1,
    'an' => 1,
    '-' => 1,
    'pretending' => 1,
    'quizzically.' => 1,
    'laughing.' => 1,
    'when' => 1,
    'like' => 1,
    'sharply.' => 1,
    'with.' => 1,
    'so' => 1,
    'entirely' => 1,
    'balefully' => 1,
    'his' => 1,
    'again' => 1,
    'gravely.' => 1,
    'several' => 1,
    'was' => 1,
    'bitterly.' => 1,
    'not' => 2,
    'coming' => 1,
    'once' => 1,
    'desperately' => 1,
    'towards' => 1,
    'pinned' => 1,
  ),
  'nervous' => 
  array (
    'and' => 2,
    '' => 3,
    'steps' => 1,
    'laugh.' => 1,
    'tension' => 1,
    'faces' => 1,
    'noises.' => 1,
  ),
  'irritable.' => 
  array (
    'He' => 1,
  ),
  'well,' => 
  array (
    'dark' => 1,
    'no' => 1,
    'and' => 1,
    'are' => 1,
    'but' => 1,
    '-' => 3,
    '' => 1,
    'look' => 1,
    'it' => 1,
    'forget' => 1,
    'just' => 1,
    'yes.' => 1,
    'I' => 1,
  ),
  'dark' => 
  array (
    'haired' => 1,
    '' => 3,
    'green' => 1,
    'cabin' => 1,
    'cloud.' => 1,
    'nebula' => 2,
    'screen.' => 1,
    'featureless' => 1,
    'recesses,' => 1,
    'tiles' => 1,
    'millennia,' => 1,
    'sphere' => 1,
    'and' => 1,
  ),
  'haired' => 
  array (
    'and' => 1,
  ),
  'quite' => 
  array (
    'at' => 1,
    'a' => 2,
    'entitled' => 1,
    'interesting' => 2,
    'possibly),' => 1,
    'liked' => 2,
    'clearly' => 4,
    'relaxed' => 1,
    'simply' => 1,
    'like.' => 1,
    'touched.' => 1,
    '' => 9,
    'fit' => 1,
    'right' => 1,
    'unmistakable' => 1,
    'naturally' => 1,
    'definitely' => 2,
    'strong.' => 1,
    'dizzy' => 1,
    'surprised' => 1,
    'unsettled' => 1,
    'shocking' => 1,
    'as' => 1,
    'the' => 2,
    'prepared' => 1,
    'frankly' => 1,
    'enormously' => 1,
    'short.' => 1,
    'fantastic.' => 1,
  ),
  'ease' => 
  array (
    'with' => 1,
    'knowing' => 1,
  ),
  'himself.' => 
  array (
    '' => 2,
    'He' => 3,
    'In' => 1,
    'A' => 1,
    '-' => 7,
    'Beneath' => 1,
  ),
  'thing' => 
  array (
    '' => 8,
    'you\'ve' => 1,
    'you\'re' => 1,
    'only' => 1,
    'he' => 1,
    'anybody\'s' => 1,
    'you' => 2,
    'as' => 1,
    'and' => 1,
    'that' => 5,
    'they' => 2,
    'of' => 1,
    'going' => 1,
    'suddenly' => 1,
    'stung' => 1,
    'I' => 2,
    'to' => 2,
    'is' => 1,
    'called' => 1,
    'we' => 1,
  ),
  'used' => 
  array (
    'to' => 8,
    '' => 3,
    'it' => 1,
    'before.' => 1,
    'in' => 1,
  ),
  'worry' => 
  array (
    'him' => 1,
    '' => 1,
    'about' => 2,
    'and' => 1,
  ),
  'always' => 
  array (
    '' => 6,
    'used' => 1,
    'cover' => 1,
    'happened' => 1,
    'been' => 1,
    'concealed' => 1,
    'an' => 1,
    'made' => 1,
    'unshaven.' => 1,
    'found' => 2,
    'remained' => 1,
    'help' => 1,
    'heavily' => 1,
    'works' => 1,
    'superstitious' => 1,
    'wanted' => 1,
    'my' => 1,
    'assumed' => 1,
    'believed' => 1,
    'think' => 1,
    'appreciated.' => 1,
    'be' => 1,
  ),
  'ask' => 
  array (
    '' => 1,
    'him' => 1,
    'passing' => 1,
    'a' => 2,
    'me' => 1,
    'them' => 1,
    'me,' => 1,
    'this' => 1,
    'the' => 1,
    'them?' => 1,
  ),
  'looking' => 
  array (
    'so' => 1,
    'for' => 5,
    'for.' => 2,
    '' => 7,
    'at.' => 1,
    'at' => 6,
    'straight' => 1,
    'well,' => 1,
    'at,' => 1,
    'whale...' => 1,
    'very' => 1,
  ),
  'worried' => 
  array (
    'about.' => 2,
    'man.' => 1,
    'because' => 1,
    '' => 2,
    'him,' => 2,
    'that' => 1,
    'look' => 1,
  ),
  'about.' => 
  array (
    'He' => 1,
    'It' => 1,
    'Today' => 1,
    '-' => 3,
    'Ford' => 1,
    'Zaphod' => 1,
    'For' => 1,
  ),
  'worked' => 
  array (
    'in' => 2,
    'for' => 1,
    '' => 1,
    'hard' => 1,
    'out' => 1,
    'out.' => 1,
    'with' => 1,
    'there' => 1,
  ),
  'local' => 
  array (
    '' => 3,
    'council.' => 1,
    'affairs' => 1,
  ),
  'radio' => 
  array (
    '' => 1,
    'transmitter,' => 1,
    'wavebands' => 1,
  ),
  'his' => 
  array (
    'friends' => 2,
    'house' => 1,
    '' => 54,
    'mouth.' => 1,
    'mind' => 8,
    'clearest' => 1,
    'garden' => 1,
    'genes' => 1,
    'mighty' => 1,
    'job' => 1,
    'eyes' => 5,
    'fur' => 2,
    'finger' => 1,
    'elbow' => 1,
    'back.' => 2,
    'brain' => 4,
    'closest' => 1,
    'had' => 1,
    'preparatory' => 1,
    'features' => 1,
    'behalf.' => 1,
    'skull' => 1,
    'lawyer,' => 1,
    'mother' => 1,
    'will' => 1,
    'opponent' => 1,
    'senses' => 1,
    'head.' => 4,
    'shoe' => 1,
    'shoulders:' => 1,
    'whole' => 1,
    'bottom' => 1,
    'arms' => 4,
    'shoes.' => 1,
    'head' => 6,
    'eyes.' => 3,
    'arguments' => 1,
    'glasses' => 2,
    'beer.' => 1,
    'own' => 6,
    'beer,' => 2,
    'neck.' => 3,
    'head,' => 1,
    'towel' => 4,
    'third' => 1,
    'tongue' => 1,
    'feet.' => 3,
    'last' => 1,
    'flippest.' => 1,
    'pockets.' => 1,
    'whisky.' => 1,
    'throat.' => 4,
    'house.' => 1,
    'home.' => 1,
    'Sub-Etha' => 1,
    'pillar' => 1,
    'small' => 1,
    'heart.' => 1,
    'satchel.' => 2,
    'ion' => 1,
    'way' => 1,
    'intention' => 1,
    'dying' => 1,
    'heirs' => 1,
    'two' => 5,
    'boat' => 1,
    'right' => 1,
    'ski-boxing.' => 1,
    'nerves' => 1,
    'job.' => 1,
    'every' => 1,
    'chins' => 1,
    'knee.' => 1,
    'orange' => 1,
    'prepared' => 1,
    'hands.' => 2,
    'set' => 1,
    'pocket.' => 2,
    'heart' => 1,
    'heads' => 1,
    'primitive' => 1,
    'now' => 1,
    'pocket,' => 1,
    'lungs' => 2,
    'unpleasant' => 1,
    'control' => 1,
    'meals.' => 1,
    'throat,' => 1,
    'grandmother' => 1,
    'mind.' => 4,
    'ear' => 2,
    'hand' => 2,
    'aural' => 1,
    'embarrassment' => 1,
    'bestselling' => 1,
    'nauseated' => 1,
    'imagination' => 1,
    'feelings' => 1,
    'parents' => 1,
    'sister' => 1,
    'mind,' => 1,
    'mother.' => 2,
    'shoulder.' => 1,
    'poem' => 1,
    'audience' => 1,
    'neck' => 2,
    'brain.' => 1,
    'prisoners' => 2,
    'temples.' => 1,
    'seat.' => 4,
    'teeth.' => 2,
    'parched' => 1,
    'nose' => 1,
    'thoughts' => 1,
    'rescue,' => 1,
    'mouth:' => 1,
    'embittered' => 1,
    'huge' => 1,
    'captain\'s' => 1,
    'notebook' => 2,
    'grip.' => 1,
    'captor\'s' => 1,
    'face.' => 2,
    'eyebrows' => 2,
    'argument,' => 1,
    'home' => 1,
    'problem,' => 1,
    'entire' => 1,
    'original' => 1,
    'shoulder' => 1,
    'back,' => 1,
    'body' => 1,
    'pond' => 1,
    'hands' => 2,
    'arm,' => 1,
    'utter' => 1,
    'heel' => 1,
    'exile.' => 1,
    'fingers' => 1,
    'voice' => 2,
    'private' => 1,
    'reasons' => 1,
    'prey.' => 1,
    'feet' => 2,
    'right-hand' => 1,
    'planet' => 1,
    'teeth' => 1,
    'semi-cousin' => 1,
    'leaving' => 1,
    'cabin' => 1,
    'companions.' => 1,
    'hand.' => 1,
    'ironical' => 1,
    'skin' => 1,
    'copy' => 1,
    'Brantisvogan' => 1,
    'eyebrows.' => 1,
    'trousers,' => 1,
    'eyes,' => 1,
    'thread' => 1,
    'craft' => 1,
    'face' => 3,
    'solemn' => 1,
    'voice,' => 1,
    'bleeding' => 1,
    'watch.' => 1,
    'name,' => 1,
    'peculiar' => 1,
    'eye' => 1,
    'apparently' => 1,
    'body.' => 1,
    'fingernail.' => 2,
    'breath' => 1,
    'megafreighter.' => 1,
    'tri-jet' => 1,
    'idea' => 1,
    'minds.' => 1,
    'study.' => 1,
    'name' => 1,
    'words' => 1,
    'black' => 1,
    'sickly' => 1,
    'pink' => 1,
    'murine' => 1,
    'problems.' => 1,
    'curious' => 1,
    'chair' => 1,
    'fine' => 1,
    'whiskers' => 1,
    'problem' => 1,
    'foot' => 1,
    'space' => 1,
    'astonishment,' => 1,
    'curiosity.' => 1,
  ),
  'friends' => 
  array (
    'was' => 2,
    'worked' => 1,
    'he' => 1,
    '' => 1,
    'with' => 1,
  ),
  'lot' => 
  array (
    '' => 3,
    'of' => 18,
    'and' => 1,
    'more' => 1,
  ),
  'interesting' => 
  array (
    '' => 4,
    'in' => 1,
    'challenge?' => 1,
    'to' => 1,
    'and' => 1,
  ),
  'thought.' => 
  array (
    'It' => 1,
    'The' => 2,
    '' => 1,
    '-' => 3,
    'Ford' => 1,
    'There' => 1,
    'Er,' => 1,
    'Then' => 1,
    'How' => 1,
  ),
  'was,' => 
  array (
    'too' => 1,
    'as' => 1,
    '' => 1,
    '-' => 1,
  ),
  'too' => 
  array (
    '-' => 1,
    'broadly' => 1,
    'wrapped' => 1,
    'minute' => 1,
    'busy' => 1,
    '' => 3,
    'big.' => 1,
    'little' => 1,
    'late.' => 1,
    'good' => 1,
    'asphyxicated' => 1,
    'excited' => 1,
    'much!' => 1,
    'long,' => 1,
    'polluted' => 1,
    'highly' => 1,
    'suddenly' => 1,
    'excited.' => 1,
    'literal,' => 1,
    'fast.' => 1,
  ),
  'advertising.' => 
  array (
    'It' => 1,
  ),
  'hadn\'t' => 
  array (
    'properly' => 1,
    'exactly' => 1,
    '' => 5,
    'thought' => 1,
    'killed' => 1,
    'liked' => 1,
    'worked' => 2,
    'the' => 1,
    'lived' => 1,
    'paid' => 1,
  ),
  'properly' => 
  array (
    'registered' => 1,
    'iced' => 1,
    'evolved' => 1,
    '' => 1,
    'or' => 1,
  ),
  'registered' => 
  array (
    'with' => 2,
    'at' => 1,
  ),
  'council' => 
  array (
    'wanted' => 1,
    'didn\'t' => 1,
    'for' => 1,
    'of' => 1,
  ),
  'wanted' => 
  array (
    '' => 5,
    'a' => 1,
    'to' => 3,
    'climbing' => 1,
    'axes.' => 1,
    'it.' => 1,
    'someone' => 1,
  ),
  'knock' => 
  array (
    'down' => 1,
    '' => 1,
    'my' => 1,
    'your' => 1,
    'it,' => 1,
  ),
  'build' => 
  array (
    'an' => 1,
    'bypasses.' => 1,
    'the' => 1,
    'robots' => 1,
    'another' => 1,
  ),
  'bypass' => 
  array (
    'instead.' => 1,
    'he' => 1,
    'has' => 1,
    'with' => 1,
  ),
  'instead.' => 
  array (
    'At' => 1,
  ),
  'At' => 
  array (
    'eight' => 1,
    'lunchtime?' => 1,
    '' => 4,
    'that' => 3,
    'last' => 1,
    'any' => 1,
    'the' => 7,
    'this' => 1,
    'an' => 1,
    'intervals' => 1,
    'a' => 1,
  ),
  'eight' => 
  array (
    'o\'clock' => 1,
    'minutes' => 1,
    'million' => 1,
  ),
  'o\'clock' => 
  array (
    'on' => 1,
  ),
  'Thursday' => 
  array (
    'morning' => 1,
    'morning.' => 1,
  ),
  'morning' => 
  array (
    'Arthur' => 1,
    'and' => 2,
    'twilight.' => 1,
  ),
  'didn\'t' => 
  array (
    'feel' => 2,
    'have' => 2,
    'know' => 5,
    'tell' => 1,
    'you?' => 2,
    '' => 10,
    'matter' => 2,
    'realize' => 1,
    'seem' => 2,
    'understand' => 2,
    'notice' => 4,
    'it' => 1,
    'need' => 1,
    'register,' => 1,
    'think' => 1,
    'sound' => 1,
    'like' => 2,
    'look' => 1,
    'you' => 1,
    'notice.' => 1,
    'listen.' => 1,
    'get' => 1,
    'quite' => 1,
    'pick' => 1,
    'what' => 1,
    'he' => 1,
    'just' => 1,
    'turn' => 1,
    'I?' => 1,
    'wake' => 1,
    'want' => 3,
    'land' => 1,
    'enjoy' => 1,
    'work' => 1,
  ),
  'feel' => 
  array (
    'very' => 2,
    'better.' => 1,
    'that' => 1,
    'safe.' => 1,
    'the' => 1,
    'you' => 2,
    'some' => 1,
    '' => 2,
    'his' => 1,
    'to' => 1,
  ),
  'good.' => 
  array (
    'He' => 1,
    'The' => 2,
    'Zaphod' => 1,
    'For' => 1,
  ),
  'woke' => 
  array (
    'up' => 2,
    'the' => 1,
  ),
  'up' => 
  array (
    'blearily,' => 1,
    'his' => 2,
    'on' => 8,
    'and' => 15,
    'for' => 3,
    '' => 16,
    'in' => 11,
    'being' => 1,
    'to' => 12,
    'the' => 7,
    'to.' => 2,
    'beneath' => 1,
    'it' => 2,
    'recently' => 1,
    'a' => 9,
    'into' => 5,
    'from' => 3,
    'through' => 1,
    'this' => 1,
    'as' => 2,
    'at' => 3,
    'I' => 1,
    'expectantly.' => 1,
    'lots' => 1,
    'hitch' => 1,
    'with' => 3,
    'later.' => 1,
    'then?' => 1,
    'here.' => 1,
    'sharply,' => 1,
    'towards' => 1,
    'those' => 1,
    'in.' => 1,
    'hope.' => 1,
    'too,' => 1,
    'if' => 1,
    'by' => 1,
    'high...' => 1,
    'any' => 1,
    'nothing.' => 1,
    'because' => 1,
    'again.' => 1,
    'again' => 1,
    'half' => 1,
    'with,' => 1,
    'sharply.' => 1,
    'short' => 1,
    'now' => 1,
  ),
  'blearily,' => 
  array (
    'got' => 1,
  ),
  'got' => 
  array (
    'up,' => 1,
    'cleared' => 1,
    'to' => 19,
    'a' => 9,
    '' => 10,
    'knocked' => 1,
    'ten' => 1,
    'three' => 1,
    'stuck' => 1,
    'as' => 1,
    'that' => 1,
    'problems.' => 1,
    'them' => 1,
    'lynched' => 1,
    'some' => 2,
    'an' => 1,
    'no' => 2,
    'this' => 1,
    'her' => 1,
    'it,' => 2,
    'that?' => 1,
    'something' => 1,
    'silly,' => 1,
    'up' => 2,
    'so' => 1,
    'fed' => 1,
    'in' => 1,
    'the' => 2,
    'you' => 1,
    'enough' => 1,
    'very' => 1,
  ),
  'up,' => 
  array (
    'wandered' => 1,
    '-' => 5,
    'feeling' => 1,
    'but' => 1,
    'wrote' => 1,
    '' => 1,
    'meeting' => 1,
  ),
  'wandered' => 
  array (
    '' => 1,
    'through' => 2,
    'slowly' => 1,
    'about' => 1,
  ),
  'blearily' => 
  array (
    '' => 1,
  ),
  'round' => 
  array (
    '' => 10,
    'the' => 8,
    'to' => 4,
    'of' => 1,
    'his' => 5,
    'at' => 3,
    'your' => 1,
    'a' => 4,
    'him' => 1,
    'and' => 5,
    'each' => 1,
    'in' => 3,
    'casually,' => 1,
    'himself' => 1,
    'now' => 1,
    'laboriously' => 1,
    'them' => 1,
  ),
  'room,' => 
  array (
    '' => 1,
    'changes' => 1,
    'and' => 1,
    'thrusting' => 1,
    'cut' => 1,
  ),
  'opened' => 
  array (
    '' => 2,
    'and' => 1,
    'his' => 3,
    'on' => 1,
    'my' => 1,
    'their' => 2,
    'the' => 1,
    'up' => 1,
    'fire' => 1,
  ),
  'window,' => 
  array (
    'saw' => 1,
    'so' => 1,
    'every' => 1,
    'which' => 1,
  ),
  'saw' => 
  array (
    'a' => 2,
    'the' => 1,
    '' => 3,
    'where' => 1,
    'her' => 1,
    'that' => 1,
  ),
  'bulldozer,' => 
  array (
    'found' => 1,
  ),
  'found' => 
  array (
    '' => 7,
    'out' => 1,
    'the' => 3,
    'what' => 2,
    'hardest' => 1,
    'my' => 1,
    'himself' => 3,
    'this' => 2,
    'it!' => 2,
    'a' => 2,
    'it' => 2,
    'it.' => 1,
  ),
  'slippers,' => 
  array (
    '' => 1,
  ),
  'stomped' => 
  array (
    '' => 1,
    'off' => 2,
    'on' => 1,
    'through.' => 1,
  ),
  'off' => 
  array (
    '' => 15,
    'to' => 2,
    'back' => 1,
    'it,' => 2,
    'wondering' => 1,
    'home' => 1,
    'down' => 2,
    'for' => 1,
    'his' => 2,
    'like' => 1,
    'a' => 1,
    'the' => 3,
    'spaceships...' => 1,
    'with' => 2,
    'through' => 1,
    'too.' => 1,
    'yet.' => 1,
    'figures.' => 1,
    '-' => 1,
    'things.' => 1,
    'their' => 1,
    'your' => 1,
    'his.' => 1,
    'it?' => 1,
    'part' => 1,
    'now!' => 1,
    'in' => 1,
    'experimentally' => 1,
    'it' => 1,
    'solid' => 1,
    'you.' => 1,
  ),
  'bathroom' => 
  array (
    'to' => 1,
    '' => 1,
    'he' => 1,
  ),
  'wash.' => 
  array (
    'Toothpaste' => 1,
  ),
  'Toothpaste' => 
  array (
    'on' => 1,
  ),
  'brush' => 
  array (
    '-' => 1,
    'the' => 2,
  ),
  'so.' => 
  array (
    'Scrub.' => 1,
    '-' => 2,
    '' => 1,
    'The' => 1,
    'Ford' => 1,
  ),
  'Scrub.' => 
  array (
    'Shaving' => 1,
  ),
  'Shaving' => 
  array (
    'mirror-pointing' => 1,
  ),
  'mirror-pointing' => 
  array (
    'at' => 1,
  ),
  'ceiling.' => 
  array (
    'He' => 1,
    '-' => 1,
  ),
  'adjusted' => 
  array (
    'it.' => 1,
  ),
  'it.' => 
  array (
    'For' => 1,
    '-' => 24,
    'Ridiculous.' => 1,
    'Arthur' => 2,
    'Mr.' => 1,
    'The' => 9,
    'He' => 5,
    '' => 10,
    'Running' => 1,
    'All' => 1,
    'Zaphod' => 3,
    'A' => 2,
    'At' => 1,
    'They' => 2,
    'Ford' => 2,
    'Again' => 1,
    'Look' => 1,
    'She' => 2,
    'It' => 1,
    'Chapter' => 1,
    'Another' => 1,
    'Ah!..' => 1,
    'Hey!' => 1,
    'You' => 1,
    'Like' => 1,
    'I' => 2,
    'So' => 1,
    'No' => 1,
    'In' => 1,
    'And' => 1,
  ),
  'For' => 
  array (
    'a' => 13,
    'instance' => 2,
    'the' => 1,
    'my' => 1,
    '' => 6,
    'God.' => 1,
    'light' => 1,
    'as' => 1,
    'instance,' => 3,
    'today' => 1,
    'what?' => 1,
    'thousands' => 1,
    'lots' => 1,
  ),
  'moment' => 
  array (
    'it' => 4,
    '' => 7,
    'filled' => 1,
    'and' => 2,
    'the' => 6,
    'under' => 1,
    'came' => 1,
    'floating' => 1,
    'his' => 1,
    'slipping' => 1,
    'in' => 1,
    'carried' => 1,
    'of' => 1,
    'that' => 2,
    'I' => 1,
    'a' => 2,
    'however' => 1,
    'later,' => 1,
    'they' => 1,
    'or' => 1,
    'your' => 1,
    'every' => 1,
  ),
  'reflected' => 
  array (
    'a' => 1,
    'Arthur' => 1,
    'in' => 1,
    'from.' => 1,
  ),
  'second' => 
  array (
    'bulldozer' => 1,
    'or' => 5,
    '' => 1,
    'worst' => 1,
    'now' => 1,
    'long,' => 1,
    'for' => 1,
    'later' => 1,
    'the' => 1,
    'without' => 1,
    'later.' => 1,
    'thoughts,' => 1,
    'greatest' => 2,
    'best.' => 1,
    'greatest,' => 1,
    'man' => 1,
    'man.' => 1,
    'Kill-O-Zap' => 1,
    'by' => 1,
  ),
  'bulldozer' => 
  array (
    '' => 1,
    'wandered' => 1,
    'outside' => 1,
    'that' => 1,
    'indefinitely.' => 1,
    'drivers.' => 1,
    'would' => 1,
    'drivers' => 2,
    'driver\'s' => 1,
  ),
  'through' => 
  array (
    '' => 14,
    'his' => 5,
    'the' => 48,
    'them' => 1,
    'your' => 1,
    'all' => 1,
    'hyperspace.' => 1,
    'hyperspace' => 1,
    'it.' => 3,
    'heavy' => 1,
    'a' => 3,
    'every' => 3,
    'into' => 1,
    'oneeighty' => 1,
    'white' => 1,
    'me.' => 1,
    'wormholes' => 1,
    'what' => 1,
    'which' => 1,
    'him.' => 1,
    'towards' => 1,
    'my' => 1,
    'Ford\'s' => 1,
    'three' => 1,
  ),
  'window.' => 
  array (
    '' => 1,
    '-' => 2,
  ),
  'Properly' => 
  array (
    'adjusted,' => 1,
  ),
  'adjusted,' => 
  array (
    'it' => 1,
  ),
  'Dent\'s' => 
  array (
    'bristles.' => 1,
    'house' => 2,
    'house.' => 1,
    '' => 2,
  ),
  'bristles.' => 
  array (
    'He' => 1,
  ),
  'shaved' => 
  array (
    'them' => 1,
  ),
  'off,' => 
  array (
    'washed,' => 1,
    '-' => 1,
    '' => 1,
  ),
  'washed,' => 
  array (
    'dried,' => 1,
  ),
  'dried,' => 
  array (
    'and' => 1,
  ),
  'kitchen' => 
  array (
    'to' => 1,
    'window' => 1,
  ),
  'find' => 
  array (
    'something' => 1,
    'them.' => 1,
    'till' => 1,
    '' => 4,
    'that' => 2,
    'some' => 1,
    'you' => 1,
    'a' => 2,
    'here?' => 1,
    'out' => 2,
    'anybody' => 1,
    'his' => 1,
    'somewhere' => 1,
    'the' => 1,
    'this' => 1,
    'it' => 1,
  ),
  'something' => 
  array (
    'pleasant' => 1,
    'to' => 6,
    '' => 8,
    'very' => 2,
    'like:' => 1,
    'was' => 3,
    'else.' => 2,
    'going' => 1,
    'simple' => 1,
    'like' => 1,
    'behind' => 1,
    'altogether' => 1,
    'in' => 1,
    'wrong?' => 1,
    'out' => 1,
    'important.' => 1,
    'jamming' => 1,
    'we\'re' => 1,
    'on' => 1,
    'he' => 1,
    'of' => 1,
    'totally' => 1,
    'soft.' => 1,
    'that' => 2,
    'about' => 1,
  ),
  'pleasant' => 
  array (
    'to' => 1,
    'amount' => 1,
    '' => 3,
    'smile' => 1,
  ),
  'put' => 
  array (
    'in' => 2,
    'it' => 3,
    'upon,' => 1,
    'a' => 2,
    '' => 3,
    'to' => 1,
    'that' => 1,
    'this' => 1,
    'his' => 2,
    'the' => 3,
    'all' => 1,
    'us' => 1,
    'it,' => 1,
  ),
  'mouth.' => 
  array (
    'Kettle,' => 1,
  ),
  'Kettle,' => 
  array (
    'plug,' => 1,
  ),
  'plug,' => 
  array (
    'fridge,' => 1,
  ),
  'fridge,' => 
  array (
    'milk,' => 1,
  ),
  'milk,' => 
  array (
    'coffee.' => 1,
  ),
  'coffee.' => 
  array (
    'Yawn.' => 1,
  ),
  'Yawn.' => 
  array (
    'The' => 1,
  ),
  'word' => 
  array (
    'bulldozer' => 1,
    'yellow' => 1,
    'safe' => 1,
    'of' => 2,
    '' => 1,
    'registered' => 1,
    'suddenly' => 1,
    'was' => 1,
    'Phouchg' => 1,
  ),
  'mind' => 
  array (
    'for' => 1,
    'in' => 1,
    'was' => 2,
    'seemed' => 1,
    'his' => 1,
    'of' => 1,
    '' => 6,
    '-' => 1,
    'nearly' => 1,
    'occupied' => 1,
    'boggling' => 1,
    'might' => 1,
    'off' => 1,
    'suddenly' => 1,
    'just' => 1,
    'and' => 1,
  ),
  'search' => 
  array (
    'of' => 2,
    '' => 1,
    'party,' => 1,
  ),
  'connect' => 
  array (
    'with.' => 2,
  ),
  'with.' => 
  array (
    'The' => 1,
    'Fifteen' => 1,
    'Hence' => 1,
    'It' => 1,
    'He' => 2,
    'But' => 1,
  ),
  'outside' => 
  array (
    'the' => 2,
    'filtered' => 1,
    'who' => 1,
    'observer' => 1,
    'of' => 1,
    'was' => 1,
  ),
  'window' => 
  array (
    'was' => 1,
    'again' => 1,
  ),
  'one.' => 
  array (
    'He' => 1,
    'At' => 1,
    'If' => 1,
    'One' => 1,
    '-' => 3,
    'Only' => 1,
    'Majikthise' => 1,
    '' => 2,
    'It' => 1,
  ),
  'stared' => 
  array (
    'at' => 14,
    'distractedly' => 1,
    'fixedly' => 1,
    '' => 5,
    'into' => 1,
    'about' => 2,
    'round' => 1,
    'up' => 1,
    'down' => 1,
    'after' => 1,
  ),
  'Yellow,' => 
  array (
    '-' => 1,
  ),
  'thought' => 
  array (
    'and' => 2,
    'struck' => 4,
    'about' => 4,
    'that' => 4,
    'it' => 1,
    '' => 6,
    'to' => 3,
    'of' => 8,
    'him' => 1,
    'you' => 4,
    'frequencies' => 1,
    'was' => 2,
    'my' => 1,
    'no' => 1,
    'I\'d' => 1,
    'he' => 2,
    'I' => 2,
    'aside' => 1,
    'Ford.' => 1,
    'by' => 1,
    'might' => 1,
    'you\'d' => 1,
    'hard' => 1,
    'they' => 2,
    'so.' => 1,
  ),
  'back' => 
  array (
    'to' => 6,
    'and' => 4,
    '' => 17,
    'out' => 1,
    'at' => 2,
    'down' => 3,
    'foaming' => 1,
    'for' => 1,
    'towards' => 3,
    'into' => 2,
    'on' => 4,
    'as' => 1,
    'now,' => 1,
    'in' => 4,
    'the' => 1,
    'across' => 1,
    'on!' => 1,
    'in,' => 1,
    'up' => 1,
    'through' => 1,
    'with' => 1,
  ),
  'bedroom' => 
  array (
    '' => 1,
  ),
  'dressed.' => 
  array (
    'Passing' => 1,
  ),
  'Passing' => 
  array (
    'the' => 1,
  ),
  'stopped' => 
  array (
    'to' => 1,
    '' => 2,
    'dead' => 1,
    'in' => 1,
    'and' => 1,
    'talking' => 1,
    'it' => 1,
  ),
  'drink' => 
  array (
    'a' => 1,
    'it.' => 1,
    'in' => 1,
    'out' => 1,
    'mixers' => 1,
  ),
  'glass' => 
  array (
    'of' => 2,
    '' => 3,
    'jar' => 1,
    'without' => 1,
    'transports' => 2,
  ),
  'water,' => 
  array (
    '' => 1,
    'it' => 1,
  ),
  'another.' => 
  array (
    'He' => 1,
  ),
  'began' => 
  array (
    'to' => 13,
    'involuntarily' => 1,
    '' => 7,
    'the' => 1,
    'its' => 1,
    'Zaphod...' => 1,
    'Fook.' => 1,
  ),
  'suspect' => 
  array (
    'that' => 3,
  ),
  'hung' => 
  array (
    'over.' => 1,
    '' => 1,
    'motionless' => 1,
    'in' => 2,
    'about' => 1,
  ),
  'over.' => 
  array (
    'Why' => 1,
    'The' => 2,
    '-' => 1,
  ),
  'Why' => 
  array (
    'was' => 1,
    'three' => 1,
    '' => 1,
    'bother?' => 1,
    'hello' => 1,
    'don\'t' => 1,
    'doesn\'t' => 1,
    'am' => 1,
    'not?' => 1,
    'are' => 1,
    'do' => 4,
    'and' => 1,
  ),
  'over?' => 
  array (
    'Had' => 1,
  ),
  'Had' => 
  array (
    'he' => 1,
  ),
  'drinking' => 
  array (
    'the' => 1,
    'coffee' => 1,
    'game' => 1,
    '' => 1,
  ),
  'night' => 
  array (
    'before?' => 1,
    'streets' => 1,
    'sky' => 3,
    'beside' => 1,
    'smashing' => 1,
    'of' => 2,
    'closed' => 1,
    'side' => 1,
    '' => 1,
    'if' => 1,
    'side...' => 1,
    'I' => 1,
    'to' => 1,
    'arguing' => 1,
  ),
  'before?' => 
  array (
    'He' => 1,
  ),
  'supposed' => 
  array (
    'that' => 1,
    'to' => 3,
  ),
  'must' => 
  array (
    'have' => 6,
    'be' => 9,
    'logically' => 1,
    'admit' => 1,
    'come' => 1,
    'one' => 1,
    'know' => 1,
    '' => 1,
    'a' => 2,
  ),
  'been.' => 
  array (
    'He' => 1,
    'There' => 1,
  ),
  'caught' => 
  array (
    'a' => 1,
    'him' => 2,
    'and' => 1,
    '' => 2,
  ),
  'glint' => 
  array (
    'in' => 1,
  ),
  'shaving' => 
  array (
    'mirror.' => 1,
  ),
  'mirror.' => 
  array (
    '"Yellow,"' => 1,
    'He' => 1,
  ),
  '"Yellow,"' => 
  array (
    'he' => 1,
    '' => 1,
  ),
  'bedroom.' => 
  array (
    'He' => 1,
  ),
  'pub,' => 
  array (
    'he' => 1,
    '' => 1,
    'Ford?' => 1,
  ),
  'Oh' => 
  array (
    '' => 3,
    'no.' => 1,
    'yes,' => 13,
    'shut' => 1,
    'don\'t' => 1,
    'that' => 1,
    'those' => 1,
    'yes' => 3,
    'good,' => 1,
    'dear,' => 1,
    'frettled' => 1,
    'good...' => 1,
    'give' => 1,
    'sure,' => 2,
    'come' => 1,
    'yes.' => 1,
    'God,' => 3,
    'just' => 1,
    'no...' => 1,
    'well,' => 2,
    'nothing,' => 2,
    'terrific,' => 1,
    'good.' => 1,
  ),
  'dear,' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'pub.' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'vaguely' => 
  array (
    '' => 2,
    'Arabic.' => 1,
  ),
  'remembered' => 
  array (
    '' => 1,
  ),
  'being' => 
  array (
    '' => 10,
    'a' => 4,
    'consumed' => 1,
    'nicely' => 1,
    'about' => 1,
    'is' => 1,
    'offered' => 1,
    'obstructively' => 1,
    'drunk.' => 1,
    'drunk?' => 1,
    'thrown' => 1,
    'unable' => 1,
    'genuinely' => 1,
    'not' => 1,
    'back' => 1,
    'stuck' => 1,
    'broadcast' => 1,
    'and' => 1,
    'like' => 1,
    'lame,' => 1,
    'revived' => 1,
    'made' => 1,
    'generally' => 1,
    'run' => 1,
    'extremely' => 1,
    'wretched,' => 1,
  ),
  'angry,' => 
  array (
    '' => 1,
  ),
  'angry' => 
  array (
    '' => 2,
    'about,' => 1,
    'indeed' => 1,
    'flash' => 1,
    'men' => 1,
  ),
  'seemed' => 
  array (
    'important.' => 1,
    'to' => 19,
    '' => 9,
    'remote' => 1,
    'that' => 1,
    'juvenile.' => 1,
    'was' => 1,
    'sunk' => 1,
    'certain' => 1,
    'unbelievable,' => 1,
    'somehow' => 1,
  ),
  'important.' => 
  array (
    'He\'d' => 1,
    '-' => 3,
    'Whatever' => 1,
    'Suddenly' => 1,
  ),
  'He\'d' => 
  array (
    'been' => 1,
    'got' => 1,
    'never' => 1,
  ),
  'telling' => 
  array (
    'people' => 2,
    '' => 1,
    'us?' => 1,
    'me' => 1,
    'me,' => 1,
  ),
  'length,' => 
  array (
    'he' => 1,
  ),
  'suspected:' => 
  array (
    'his' => 1,
  ),
  'clearest' => 
  array (
    'visual' => 1,
  ),
  'visual' => 
  array (
    'recollection' => 1,
  ),
  'recollection' => 
  array (
    'was' => 1,
  ),
  'glazed' => 
  array (
    'looks' => 1,
  ),
  'looks' => 
  array (
    'on' => 1,
    'just' => 1,
    '' => 1,
    'very' => 1,
  ),
  'people\'s' => 
  array (
    'faces.' => 1,
    'lives' => 1,
  ),
  'faces.' => 
  array (
    'Something' => 1,
    '-' => 2,
  ),
  'Something' => 
  array (
    'about' => 1,
    'extraordinary' => 1,
    'pretty' => 1,
    'that' => 1,
  ),
  'new' => 
  array (
    'bypass' => 1,
    'ploy' => 1,
    '' => 5,
    'sense' => 1,
    'form' => 2,
    'one.' => 1,
    'pair' => 1,
    'entry' => 2,
    'concept.' => 1,
    'breakthrough' => 1,
    'Improbability' => 1,
    'planet,' => 2,
    'and' => 1,
    'voice,' => 1,
    'forms' => 1,
    'Earth' => 1,
  ),
  'pipeline' => 
  array (
    'for' => 1,
  ),
  'months' => 
  array (
    'only' => 1,
    'ago.' => 1,
  ),
  'known' => 
  array (
    'about' => 1,
    'each' => 1,
    'ever' => 1,
    'creation' => 1,
    'exactly' => 1,
    'perfectly' => 1,
    '' => 2,
    'what' => 1,
    'to' => 1,
    'that' => 1,
    'as' => 1,
  ),
  'Ridiculous.' => 
  array (
    'He' => 1,
  ),
  'took' => 
  array (
    'a' => 2,
    'it' => 1,
    '' => 2,
    'on' => 1,
    'him' => 2,
    'out' => 1,
    'hold' => 1,
  ),
  'swig' => 
  array (
    '' => 1,
  ),
  'water.' => 
  array (
    '' => 2,
    'It' => 1,
    'Arthur' => 1,
  ),
  'sort' => 
  array (
    'itself' => 2,
    'of' => 19,
    '' => 6,
    'of...' => 2,
  ),
  'itself' => 
  array (
    'out,' => 1,
    'out.' => 1,
    'off' => 1,
    'round' => 1,
    'on.' => 1,
    '' => 6,
    'there' => 1,
    'with.' => 1,
    'tight,' => 1,
    'in' => 1,
    'for' => 1,
    'away' => 1,
    'up' => 1,
    'soon' => 1,
    'disappeared' => 1,
    'from' => 1,
    'to' => 1,
    'again' => 1,
    'again.' => 1,
    'into' => 1,
    'through' => 1,
    'and' => 1,
  ),
  'out,' => 
  array (
    'he\'d' => 1,
    'reached' => 1,
    '-' => 2,
    'and' => 1,
  ),
  'he\'d' => 
  array (
    'decided,' => 1,
    'come' => 2,
    'recently' => 1,
    '' => 3,
    'been' => 1,
    'learnt' => 1,
    'suffered' => 1,
    'ever' => 1,
  ),
  'decided,' => 
  array (
    'no' => 1,
  ),
  'bypass,' => 
  array (
    '' => 1,
  ),
  'leg' => 
  array (
    'to' => 2,
  ),
  'stand' => 
  array (
    'on.' => 1,
    '' => 2,
    'for' => 1,
    'was' => 1,
    'that' => 1,
    'in' => 1,
  ),
  'on.' => 
  array (
    'It' => 1,
    'None' => 1,
    '' => 2,
    'Every' => 1,
    'Because' => 1,
    'They' => 2,
    'Even' => 1,
    '-' => 5,
    '(After' => 1,
    'Wild' => 1,
    'The' => 1,
    'Now' => 1,
    'At' => 1,
  ),
  'out.' => 
  array (
    'God' => 1,
    '-' => 2,
    'Sometimes' => 1,
    '' => 3,
    'Ford' => 3,
    'His' => 1,
    'When' => 1,
    'Chapter' => 2,
    'Computer!' => 1,
    'It\'s' => 1,
    'From' => 1,
    'It' => 1,
    'I\'ve' => 1,
    'They' => 1,
  ),
  'hangover' => 
  array (
    'it' => 1,
  ),
  'earned' => 
  array (
    'him' => 1,
  ),
  'though.' => 
  array (
    'He' => 1,
    '' => 1,
    'Trillian' => 1,
    'Seas' => 1,
  ),
  'himself' => 
  array (
    'in' => 1,
    'running' => 1,
    'together.' => 1,
    '' => 3,
    'say:' => 1,
    'about' => 1,
    'apprehensively.' => 1,
    'and' => 3,
    'up' => 2,
    'for' => 1,
    'killed' => 1,
    'violently' => 1,
    'backwards' => 1,
    'against' => 1,
    'reasoning' => 1,
    'out' => 1,
    'on' => 1,
    'through' => 1,
    'with' => 1,
    'think' => 1,
    'off.' => 1,
    'to' => 1,
    'next' => 1,
    'that' => 1,
    'gliding' => 1,
    'moving' => 1,
    'up.' => 1,
  ),
  'wardrobe' => 
  array (
    'mirror.' => 1,
  ),
  'stuck' => 
  array (
    '' => 6,
    'in' => 2,
    'out' => 1,
    'on' => 1,
    'here' => 1,
    'there' => 1,
    'up' => 1,
    'a' => 1,
  ),
  'tongue.' => 
  array (
    '' => 1,
    'Because' => 1,
  ),
  'Fifteen' => 
  array (
    'seconds' => 1,
    'years' => 1,
  ),
  'seconds' => 
  array (
    'later' => 1,
    'Ford' => 1,
    'he' => 2,
    'of' => 2,
    'are' => 1,
    '' => 3,
    'fellas...' => 1,
    'they' => 1,
    'had' => 1,
    'to' => 1,
    'away.' => 1,
    'before' => 1,
    'at' => 1,
  ),
  'later' => 
  array (
    'he' => 3,
    '' => 4,
    'Ford' => 1,
    'and' => 2,
    'part' => 1,
    'when' => 1,
    'on.' => 1,
    'discovered' => 1,
    'the' => 1,
  ),
  'lying' => 
  array (
    'in' => 5,
    'here' => 1,
    '' => 3,
    'curled' => 1,
    'on' => 2,
    'face' => 1,
  ),
  'advancing' => 
  array (
    'up' => 1,
  ),
  'garden' => 
  array (
    'path.' => 1,
    'is' => 1,
  ),
  'path.' => 
  array (
    'Mr.' => 1,
    'The' => 1,
  ),
  'Mr.' => 
  array (
    'L' => 2,
    'Dent,' => 4,
    '' => 5,
    'Prosser' => 14,
    'Prosser\'s' => 2,
    'Prosser,' => 3,
    'Dent' => 2,
    'Prosser.' => 2,
    'Dent.' => 1,
  ),
  'L' => 
  array (
    'Prosser' => 2,
  ),
  'Prosser' => 
  array (
    'was,' => 1,
    'of' => 1,
    'gripping' => 1,
    'shook' => 1,
    'wanted' => 1,
    'said:' => 1,
    'frowned' => 1,
    'was' => 3,
    '(who' => 1,
    'thought' => 2,
    'who' => 2,
    'again.' => 1,
    'realized' => 1,
    'took' => 1,
    'only' => 1,
    '' => 1,
  ),
  'say,' => 
  array (
    'only' => 1,
    '-' => 1,
    'No' => 1,
  ),
  'human.' => 
  array (
    'In' => 1,
    '-' => 1,
  ),
  'carbon-based' => 
  array (
    'life' => 2,
  ),
  'form' => 
  array (
    'descended' => 1,
    'of' => 6,
    'that' => 1,
    '' => 4,
    'it' => 1,
    'present' => 1,
    'or' => 1,
  ),
  'descended' => 
  array (
    'from' => 2,
  ),
  'ape.' => 
  array (
    '' => 1,
  ),
  'specifically' => 
  array (
    '' => 1,
  ),
  'forty,' => 
  array (
    'fat' => 1,
  ),
  'fat' => 
  array (
    'and' => 1,
    'contract' => 1,
  ),
  'shabby' => 
  array (
    'and' => 1,
  ),
  'council.' => 
  array (
    'Curiously' => 1,
  ),
  'Curiously' => 
  array (
    '' => 1,
    'enough,' => 3,
  ),
  'enough,' => 
  array (
    'though' => 1,
    'the' => 3,
    'an' => 1,
    '' => 1,
  ),
  'know' => 
  array (
    'it,' => 3,
    'why' => 4,
    'it.' => 1,
    'nothing' => 2,
    'what' => 6,
    'that' => 3,
    '' => 7,
    'whence' => 1,
    'about.' => 1,
    'about' => 2,
    'if' => 1,
    'that,' => 1,
    'anything' => 2,
    'at' => 1,
    'I\'m' => 2,
    'that.' => 2,
    'what\'s' => 1,
    'this' => 1,
    'there\'s' => 1,
    'Magrathea' => 1,
    'I' => 3,
    'that?' => 1,
    'a' => 1,
    'as' => 1,
    'who' => 1,
    'we' => 1,
    'little' => 1,
    'it!' => 1,
    'the' => 2,
    'you' => 1,
  ),
  'direct' => 
  array (
    '' => 1,
    'homing' => 1,
  ),
  'male-line' => 
  array (
    '' => 1,
  ),
  'descendant' => 
  array (
    '' => 1,
  ),
  'Genghis' => 
  array (
    'Khan,' => 1,
  ),
  'Khan,' => 
  array (
    'though' => 1,
  ),
  'intervening' => 
  array (
    'generations' => 1,
    'time' => 1,
  ),
  'generations' => 
  array (
    '' => 2,
  ),
  'racial' => 
  array (
    '' => 2,
  ),
  'mixing' => 
  array (
    '' => 1,
  ),
  'juggled' => 
  array (
    'his' => 1,
  ),
  'genes' => 
  array (
    'that' => 1,
  ),
  'discernible' => 
  array (
    '' => 1,
  ),
  'Mongoloid' => 
  array (
    '' => 1,
  ),
  'characteristics,' => 
  array (
    'and' => 1,
  ),
  'vestiges' => 
  array (
    'left' => 1,
  ),
  'mighty' => 
  array (
    'ancestry' => 1,
    'Khan' => 1,
    'deeds,' => 1,
    '' => 1,
  ),
  'ancestry' => 
  array (
    'were' => 1,
  ),
  'pronounced' => 
  array (
    'stoutness' => 1,
    'Deep' => 1,
  ),
  'stoutness' => 
  array (
    'about' => 1,
  ),
  'tum' => 
  array (
    'and' => 1,
  ),
  'predilection' => 
  array (
    'for' => 1,
  ),
  'fur' => 
  array (
    'hats.' => 1,
    'hat' => 2,
  ),
  'hats.' => 
  array (
    'He' => 1,
  ),
  'warrior:' => 
  array (
    'in' => 1,
  ),
  'man.' => 
  array (
    'Today' => 1,
    'He' => 1,
    'The' => 3,
    '-' => 4,
    'Arthur' => 1,
    '' => 1,
    'No' => 1,
  ),
  'Today' => 
  array (
    'he' => 1,
    'was' => 3,
    'however' => 1,
  ),
  'particularly' => 
  array (
    'nervous' => 1,
    'nice' => 1,
    'somewhere' => 1,
    'because' => 1,
    'effective.' => 1,
    'unsuccessful' => 1,
    '' => 1,
  ),
  'gone' => 
  array (
    'seriously' => 1,
    '' => 2,
    'bananas.' => 1,
    'bananas,' => 1,
    'to' => 1,
    'and' => 1,
    'away.' => 1,
    'up' => 1,
    'right' => 1,
    'just' => 1,
    'spontaneously' => 1,
  ),
  'seriously' => 
  array (
    'wrong' => 1,
    'believed' => 1,
    '' => 1,
    'believe' => 1,
    'believes' => 1,
  ),
  'job' => 
  array (
    '-' => 1,
    'is' => 1,
    'of' => 1,
    'well' => 1,
    'satisfaction?' => 1,
    'aren\'t' => 1,
    'and' => 1,
  ),
  'see' => 
  array (
    '' => 12,
    'who' => 1,
    'the' => 5,
    'his' => 1,
    'how' => 1,
    'it,' => 2,
    'you' => 3,
    'was' => 2,
    'and' => 1,
    'just' => 1,
    'why' => 1,
    'it' => 2,
    'what' => 3,
    'it.' => 1,
    'beside' => 1,
    'if' => 2,
    'much' => 1,
    'nothing' => 1,
    'or' => 1,
    'him' => 1,
    'you,' => 1,
    'two' => 1,
    'that' => 2,
    'very' => 1,
    'a' => 2,
    'were' => 1,
    'this' => 1,
    'me.' => 1,
    'Ford,' => 1,
    'any...' => 1,
    'here,' => 1,
  ),
  'cleared' => 
  array (
    'out' => 1,
    'his' => 3,
    'its' => 1,
  ),
  'day' => 
  array (
    'was' => 2,
    '' => 5,
    'of' => 4,
    'that' => 1,
    'when' => 1,
    'it' => 1,
    'for' => 1,
    'nicer' => 1,
    '-' => 1,
    'out' => 1,
    'sentinent' => 1,
    'an' => 1,
    'they' => 1,
    'come' => 1,
  ),
  'Come' => 
  array (
    'off' => 1,
    'on,' => 6,
    'on' => 1,
    'on.' => 1,
  ),
  'said,' => 
  array (
    '-' => 62,
    'some' => 1,
    'and' => 5,
    '' => 9,
    'taking' => 1,
    'they' => 1,
    'Hi' => 2,
    'less' => 1,
    'patting' => 1,
    'what' => 1,
    'very' => 1,
    'pointing' => 1,
    'lamely.' => 1,
    'Whatever' => 1,
    'with' => 1,
    'This' => 1,
  ),
  'you' => 
  array (
    'can\'t' => 6,
    '' => 52,
    'mean,' => 1,
    'know.' => 10,
    'found' => 2,
    'know' => 8,
    'any' => 3,
    'talked' => 1,
    'think' => 9,
    'went' => 2,
    'busy?' => 1,
    'Ford?' => 2,
    'the' => 4,
    'now,' => 2,
    'in' => 3,
    'are' => 6,
    'give' => 1,
    'pour' => 1,
    'started' => 1,
    'would' => 6,
    'want' => 10,
    'very' => 2,
    'talking' => 2,
    'say' => 4,
    'will' => 5,
    'on' => 1,
    'can' => 14,
    'rehabilitate' => 1,
    'how' => 2,
    'reckon' => 4,
    'said,' => 1,
    'sir.' => 1,
    'please' => 1,
    'should' => 1,
    'react' => 1,
    'for' => 1,
    'bound' => 1,
    '-' => 1,
    'sass' => 1,
    'vandals!' => 1,
    'serious,' => 1,
    'like,' => 1,
    'mean' => 4,
    'seem' => 1,
    'feel?' => 1,
    'where' => 1,
    'trying' => 2,
    'think?' => 1,
    'see,' => 7,
    'said' => 3,
    'everything' => 1,
    'need' => 2,
    'see' => 3,
    'get' => 5,
    'from' => 1,
    'are.' => 3,
    'a' => 5,
    'I' => 1,
    'some' => 1,
    'like.' => 1,
    'stick' => 1,
    'actually' => 1,
    'exist,' => 1,
    'don\'t.' => 1,
    'must' => 2,
    'managed' => 1,
    'thought' => 2,
    'off' => 2,
    'brute!' => 1,
    'worry,' => 1,
    'haven\'t' => 1,
    'really' => 3,
    'mean?' => 3,
    'doing?' => 2,
    'come' => 1,
    'do' => 5,
    'just' => 5,
    'know,' => 7,
    'put' => 1,
    'see...' => 2,
    'both' => 1,
    'about' => 2,
    'don\'t' => 4,
    'take' => 1,
    'you' => 1,
    'may' => 3,
    'things' => 1,
    'eat' => 1,
    'excrete' => 1,
    'leave:' => 1,
    'go' => 1,
    'to' => 7,
    'hold' => 1,
    'are,' => 1,
    'I\'d' => 1,
    'only' => 1,
    'feel' => 1,
    'ought' => 2,
    'still' => 1,
    'wouldn\'t' => 1,
    'know...' => 1,
    'and' => 3,
    'could' => 5,
    'down' => 5,
    'down.' => 1,
    'tell?' => 1,
    'got' => 1,
    'alright?' => 1,
    'merely' => 1,
    'had' => 2,
    'know?' => 3,
    'originally' => 1,
    'solve' => 1,
    'ever' => 2,
    'realize' => 1,
    'flipped?' => 1,
    'that...' => 1,
    'Marvin?' => 1,
    'Arthur!' => 1,
    'doing' => 2,
    'came' => 1,
    'predicted.' => 1,
    'see?' => 1,
    'care' => 1,
    'after?' => 1,
    'hear' => 1,
    'that' => 2,
    'fly' => 1,
    'walk' => 1,
    'crazy?' => 2,
    'guys,' => 1,
    'gazed' => 1,
    'touched' => 1,
    'supposed' => 1,
    'all' => 3,
    'open' => 1,
    'with' => 1,
    'ask' => 1,
    'understand,' => 1,
    'sure' => 1,
    'have' => 5,
    'stole' => 1,
    'something,' => 1,
    'never' => 1,
    'couldn\'t' => 1,
    'keep' => 2,
    'going?' => 1,
    'startled' => 2,
    'shot' => 1,
    'were' => 4,
    'see.' => 3,
    'originally...' => 1,
    'lived' => 2,
    'speak.' => 1,
    'call' => 1,
    'I\'m' => 1,
    'not' => 1,
    'not,' => 2,
    'speak?' => 1,
    'want?' => 1,
    'what' => 1,
    'sit' => 1,
    'in?' => 1,
    'have...' => 1,
    'who' => 1,
    'yourselves' => 1,
    'wake' => 1,
    'earlier,' => 1,
    'bust' => 1,
    'about?' => 1,
    'telling' => 1,
    'set' => 1,
    'conceive' => 1,
    'happen' => 1,
    'pass' => 1,
    'Slartibartfast,' => 2,
    'dismantle' => 1,
    'been' => 1,
    'begin' => 1,
    'wouldn\'t,' => 1,
    'covered.' => 1,
    'didn\'t' => 1,
    'shooting' => 1,
    'going' => 2,
    'out?' => 1,
    'prefer?' => 1,
    'better' => 1,
    'up' => 1,
    'lying' => 1,
    'hate' => 1,
    'do,' => 1,
  ),
  'can\'t' => 
  array (
    '' => 1,
    'lie' => 1,
    'he?' => 1,
    'because' => 1,
    'see' => 2,
    'be' => 1,
    'speak' => 1,
    'throw' => 1,
    'cope' => 1,
    'you?' => 1,
    'work' => 1,
    'possibly' => 1,
    'help' => 2,
    'either,' => 1,
    'turn' => 1,
    'I?' => 1,
    'like' => 1,
    'keep' => 2,
    'let' => 1,
    'mean' => 1,
    'possibly,' => 1,
  ),
  'win' => 
  array (
    '' => 1,
    'through,' => 1,
  ),
  'know.' => 
  array (
    '' => 2,
    '-' => 7,
    'I\'m' => 1,
    'They' => 1,
    'Just' => 1,
    'A' => 1,
    'I' => 1,
    'Turn' => 1,
    'Lovely' => 1,
    'Look' => 1,
    'Obviously.' => 1,
    'Zaphod' => 1,
  ),
  'You' => 
  array (
    'can\'t' => 3,
    'were' => 2,
    'hadn\'t' => 1,
    'haven\'t' => 1,
    '' => 5,
    'don\'t,' => 1,
    'want' => 4,
    'got' => 2,
    'home' => 1,
    'think' => 3,
    'barbarians!' => 1,
    'can\'t,' => 1,
    'press' => 1,
    'just' => 4,
    'mean' => 3,
    'don\'t' => 2,
    'wouldn\'t' => 2,
    'ask' => 2,
    'wait' => 1,
    'see' => 1,
    'know,' => 4,
    'are' => 2,
    'will' => 1,
    'watch' => 1,
    'can' => 1,
    'hear' => 1,
    'explained' => 1,
    'know' => 4,
    'recognize' => 1,
    'didn\'t' => 1,
    'remember' => 2,
    'know?' => 1,
    'choose' => 1,
    'seem' => 1,
    'mean,' => 1,
    'never' => 1,
    'see,' => 1,
    'still' => 1,
    'talked' => 1,
    'hungry' => 1,
  ),
  'lie' => 
  array (
    'in' => 3,
    'squelching' => 1,
    'here' => 1,
    'down...' => 1,
    'there...' => 1,
    'down.' => 1,
    'on' => 1,
    'down' => 1,
    '' => 1,
  ),
  'indefinitely.' => 
  array (
    '-' => 1,
  ),
  'tried' => 
  array (
    'to' => 11,
    'again.' => 2,
    'desperately' => 1,
    'it' => 1,
    '' => 4,
    'on' => 1,
    'patiently' => 1,
  ),
  'make' => 
  array (
    '' => 3,
    'any' => 2,
    'some' => 1,
    'a' => 4,
    'up' => 1,
    'it' => 5,
    'sure' => 1,
    'one' => 1,
    'your' => 1,
    'it.' => 1,
    'me' => 1,
    'their' => 1,
    'out' => 1,
    'most' => 1,
    'sense.' => 1,
    'an' => 1,
    'out.' => 1,
  ),
  'eyes' => 
  array (
    'blaze' => 1,
    '' => 7,
    'began' => 2,
    'will' => 1,
    'pop' => 1,
    'waved' => 1,
    'and' => 3,
    'of' => 1,
    'at' => 1,
    'turned' => 1,
    'he' => 1,
    'yet.' => 1,
    'desperately' => 1,
    'in' => 1,
    'again.' => 1,
    'flashing,' => 1,
    'popped' => 1,
  ),
  'blaze' => 
  array (
    'fiercely' => 1,
    'wherever' => 1,
  ),
  'fiercely' => 
  array (
    'but' => 1,
  ),
  'wouldn\'t' => 
  array (
    'do' => 2,
    'need' => 2,
    'now' => 1,
    '' => 2,
    'have' => 2,
    'enjoy' => 1,
    'want' => 1,
    'like' => 1,
    'it?' => 1,
    'let' => 1,
    'trust' => 2,
    'know' => 1,
    'be' => 2,
    'you' => 1,
    'sustain' => 1,
    'we?' => 1,
  ),
  'lay' => 
  array (
    'in' => 1,
    'propped' => 1,
    'in.' => 1,
    '' => 2,
    'uncovered' => 1,
    'a' => 1,
    'around' => 1,
    'panting' => 1,
    'panting.' => 1,
    'the' => 2,
    'down,' => 1,
    'shattered' => 1,
    'several' => 1,
    'reassuringly' => 1,
  ),
  'mud' => 
  array (
    'and' => 1,
    '' => 3,
    'Arthur' => 1,
    'on' => 1,
  ),
  'squelched' => 
  array (
    'at' => 1,
  ),
  'him.' => 
  array (
    '-' => 22,
    'Mr.' => 1,
    'By' => 1,
    'He' => 6,
    'A' => 1,
    'Arthur' => 1,
    'Turning' => 1,
    'She' => 2,
    'England' => 1,
    'The' => 1,
    '' => 2,
    'All' => 1,
    'From' => 1,
    'Chapter' => 1,
  ),
  'I\'m' => 
  array (
    'game,' => 1,
    'afraid' => 1,
    'sorry,' => 8,
    'trying' => 1,
    '' => 11,
    'sure' => 1,
    'confused,' => 1,
    'doing' => 2,
    'a' => 3,
    'not' => 4,
    'panicking,' => 1,
    'already' => 1,
    'trapped' => 1,
    'relieved' => 1,
    'feeling' => 1,
    'so' => 1,
    'very' => 1,
    'standing?' => 1,
    'from' => 1,
    'afraid,' => 2,
    'just' => 1,
    'quite' => 1,
    'fifty' => 1,
    'waiting,' => 1,
    'looking' => 1,
    'mine.' => 1,
    'afraid.' => 1,
    'eventually' => 1,
    'good' => 1,
    'old' => 2,
    'going' => 1,
    'supposed' => 1,
  ),
  'game,' => 
  array (
    '-' => 1,
  ),
  'we\'ll' => 
  array (
    'see' => 1,
    'be' => 1,
    'take' => 2,
  ),
  'who' => 
  array (
    'rusts' => 1,
    'would' => 2,
    'began' => 1,
    'he' => 1,
    'no' => 1,
    'sadly,' => 1,
    'have' => 2,
    'shrugged' => 1,
    'can' => 1,
    '' => 11,
    'could' => 1,
    'raised' => 1,
    'entered' => 1,
    'delivered' => 1,
    'was' => 4,
    'are' => 4,
    'is' => 1,
    'died' => 1,
    'want' => 2,
    'had' => 4,
    'were' => 1,
    'didn\'t' => 1,
    'knew' => 1,
    'felt' => 1,
    'cared' => 2,
    'am' => 2,
    'the' => 2,
    'pursued' => 1,
    'claimed' => 1,
    'crawled' => 1,
    'now' => 1,
    'tried' => 1,
    'better' => 1,
    'will' => 1,
    'can,' => 1,
    'study' => 1,
    'they' => 1,
    'knows' => 1,
  ),
  'rusts' => 
  array (
    'first.' => 1,
  ),
  'first.' => 
  array (
    '-' => 2,
    '' => 1,
  ),
  'afraid' => 
  array (
    'you\'re' => 1,
    '' => 2,
    'where' => 1,
  ),
  'you\'re' => 
  array (
    'going' => 2,
    'away' => 1,
    'lying' => 1,
    'resigned' => 1,
    'likely' => 1,
    'a' => 2,
    '' => 3,
    'doing' => 1,
    'very' => 1,
    'saying' => 2,
    'completely' => 1,
    'getting' => 1,
    'good' => 1,
    'not' => 2,
    'turning' => 1,
    'looking' => 1,
    'cruising' => 1,
    'doing?' => 1,
    'starting' => 1,
    'ready' => 1,
  ),
  'accept' => 
  array (
    'it,' => 1,
  ),
  'gripping' => 
  array (
    'his' => 1,
  ),
  'hat' => 
  array (
    'and' => 2,
    'the' => 1,
  ),
  'rolling' => 
  array (
    'it' => 1,
    'and' => 1,
    'on' => 1,
    'in' => 1,
    'away' => 1,
    '' => 1,
    'the' => 1,
  ),
  'top' => 
  array (
    '' => 3,
    'of' => 10,
  ),
  'head,' => 
  array (
    '' => 1,
    'which' => 1,
  ),
  'built' => 
  array (
    'and' => 1,
    'the' => 2,
    'it' => 1,
    'into' => 1,
    'up' => 1,
    'planets' => 1,
    'themselves' => 1,
    '' => 1,
  ),
  'it\'s' => 
  array (
    'going' => 2,
    'a' => 2,
    'about' => 2,
    'just' => 5,
    'the' => 3,
    'got!' => 1,
    '' => 6,
    'only' => 2,
    'dark.' => 1,
    'out' => 1,
    'got' => 1,
    'still' => 1,
    'mostly' => 1,
    'all' => 2,
    'wise' => 1,
    'been' => 2,
    'what' => 1,
    'partly' => 1,
    'safe.' => 1,
    'getting' => 1,
    'for.' => 1,
    'for' => 1,
    'such' => 1,
    'Magrathea' => 1,
    'finely' => 1,
    'hard' => 1,
    'not' => 1,
    'Forty-two,' => 1,
    'important.' => 1,
  ),
  'built!' => 
  array (
    '-' => 1,
  ),
  'First' => 
  array (
    'I\'ve' => 1,
    'he' => 1,
    '' => 1,
  ),
  'I\'ve' => 
  array (
    'heard' => 1,
    '' => 4,
    'got' => 10,
    'been' => 4,
    'finished' => 1,
    'no' => 1,
    'just' => 2,
    'still' => 1,
    'asked' => 1,
    'a' => 1,
    'found' => 2,
    'actually' => 1,
    'bought' => 1,
    'never' => 3,
    'seen' => 1,
    'had' => 1,
  ),
  'Arthur,' => 
  array (
    '' => 8,
    '-' => 41,
    'and' => 3,
    'who' => 4,
    'but' => 1,
    'struggling' => 1,
    'rather' => 2,
    'that' => 1,
    'glad' => 1,
    'trembling' => 1,
    'glaring' => 1,
    'sadly' => 1,
    'a' => 1,
    'trying' => 1,
    'slowly' => 1,
    'after' => 1,
    'not' => 1,
    'sharply.' => 1,
    'hopelessly.' => 1,
    'tipping' => 1,
    'backing' => 1,
    'crouching' => 1,
  ),
  'why\'s' => 
  array (
    '' => 1,
    'it' => 1,
    'everyone' => 1,
  ),
  'built?' => 
  array (
    'Mr.' => 1,
    '-' => 1,
  ),
  'shook' => 
  array (
    'his' => 2,
    '' => 2,
    'himself.' => 1,
    'the' => 1,
    'herself' => 1,
    'their' => 1,
  ),
  'finger' => 
  array (
    'at' => 2,
    '' => 4,
    'down' => 1,
    'on.' => 1,
  ),
  'bit,' => 
  array (
    'then' => 1,
    'yes.' => 1,
    'but' => 1,
    '-' => 1,
    'though' => 1,
  ),
  'then' => 
  array (
    'stopped' => 1,
    'pulled' => 1,
    'suddenly' => 1,
    'concentrate' => 1,
    'have' => 1,
    'be' => 1,
    'he' => 1,
    'smiled,' => 1,
    'tried' => 1,
    'you' => 2,
    'happily' => 1,
    '' => 11,
    'I\'ll' => 1,
    'rolled' => 1,
    'sat' => 1,
    'land' => 1,
    'strut' => 1,
    'slowly' => 1,
    'excretes' => 1,
    'his' => 2,
    'turned' => 4,
    'why' => 1,
    'go' => 1,
    'added,' => 1,
    'it' => 1,
    'the' => 4,
    'laughed.' => 1,
    'looked' => 2,
    'of' => 1,
    'accidentally' => 1,
    'out' => 1,
    'at' => 2,
    'a' => 1,
    'sent' => 1,
    'silence.' => 1,
    'had' => 1,
    'wished' => 1,
    'whenever' => 1,
    'left' => 1,
    'running' => 1,
    'we' => 1,
    'carried' => 1,
    'roared' => 1,
    'down' => 1,
    'I' => 2,
    'bragging' => 1,
    'precipitately' => 1,
  ),
  'away' => 
  array (
    'again.' => 1,
    'of' => 1,
    'can\'t' => 1,
    'for' => 2,
    '' => 8,
    'in' => 2,
    'it' => 1,
    'you' => 1,
    'into' => 3,
    'on' => 1,
    'from' => 3,
    'the' => 4,
    'a' => 2,
    'to' => 1,
    'beneath' => 1,
    'quietly' => 1,
    'beyond' => 1,
    'before' => 1,
    'some' => 1,
    'still' => 1,
  ),
  'again.' => 
  array (
    '-' => 15,
    'And' => 1,
    'Once' => 1,
    'He' => 6,
    '' => 6,
    'It' => 2,
    'Three' => 1,
    'Everyone' => 1,
    'Ford' => 3,
    'Arthur' => 2,
    'America,' => 1,
    'New' => 1,
    'More' => 1,
    'Zaphod' => 2,
    'There' => 1,
    'Fifteen' => 1,
    'A' => 2,
    'The' => 1,
    'They' => 3,
    'Before' => 1,
  ),
  'What' => 
  array (
    'do' => 12,
    'are' => 6,
    'a' => 3,
    'the' => 5,
    'Mr.' => 1,
    'they' => 1,
    'is' => 6,
    'was' => 3,
    'I' => 2,
    'sort' => 1,
    'couple' => 1,
    'would' => 1,
    'can' => 1,
    '' => 2,
    'from?' => 1,
    'you' => 1,
    'for?' => 1,
    'an' => 1,
    'computer' => 1,
    'we' => 1,
    'did' => 3,
    'does' => 1,
    'were' => 2,
    'happened' => 2,
    'hosts?' => 1,
    'happened?' => 1,
  ),
  'said.' => 
  array (
    '' => 3,
    '-' => 51,
    'He' => 3,
    'Arthur' => 1,
    'A' => 2,
    'The' => 5,
    'Its' => 1,
    'Marvin' => 1,
    'So' => 1,
    'Chapter' => 3,
    'An' => 1,
    'Trillian' => 1,
    'At' => 1,
    'Lunkwill' => 1,
    'Slartibartfast' => 1,
  ),
  'It\'s' => 
  array (
    '' => 2,
    'not' => 1,
    'vitally' => 1,
    'very' => 1,
    'probably' => 1,
    'difficult' => 1,
    'dark,' => 1,
    'a' => 9,
    'the' => 4,
    'amazing,' => 1,
    'been' => 1,
    'unpleasantly' => 1,
    'translating' => 1,
    'now' => 1,
    'alright,' => 2,
    'at' => 1,
    'carrying' => 1,
    'just' => 2,
    'millions' => 1,
    'fantastic...' => 1,
    'like' => 1,
    'rubbish.' => 1,
    'more' => 1,
    'only' => 1,
    'all' => 1,
    'gold,' => 1,
    'delicious' => 1,
    'got' => 1,
    'part' => 1,
  ),
  'bypass.' => 
  array (
    'You\'ve' => 1,
    '-' => 1,
  ),
  'You\'ve' => 
  array (
    'got' => 2,
  ),
  'bypasses.' => 
  array (
    'Bypasses' => 1,
  ),
  'Bypasses' => 
  array (
    'are' => 1,
  ),
  'devices' => 
  array (
    'which' => 1,
    '' => 1,
  ),
  'allow' => 
  array (
    'some' => 1,
    'it.' => 1,
    'a' => 1,
    'me' => 1,
  ),
  'drive' => 
  array (
    'from' => 1,
    'delta' => 1,
    '' => 1,
    'reaches' => 1,
  ),
  'point' => 
  array (
    'A' => 3,
    'B' => 3,
    '' => 7,
    'C,' => 1,
    'a' => 1,
    'D,' => 1,
    'E,' => 1,
    'D.' => 1,
    'any' => 1,
    'in' => 5,
    'is' => 1,
    'of' => 2,
    '-' => 1,
    'I\'m' => 1,
  ),
  'A' => 
  array (
    'to' => 1,
    '' => 7,
    'that' => 1,
    'are' => 1,
    'cloud' => 1,
    'shadow' => 1,
    'man' => 3,
    'towel,' => 1,
    'sudden' => 2,
    'twenty-foot-high' => 1,
    'thoroughly' => 1,
    'government' => 1,
    'marvellous' => 1,
    'meal' => 1,
    'huge' => 2,
    'screen,' => 1,
    'pained' => 2,
    'teaser?' => 2,
    'steel' => 1,
    'thought' => 2,
    'motor' => 1,
    'slight' => 1,
    'computer' => 2,
    'hole' => 1,
    'million-gallon' => 1,
    'frightening' => 1,
    'giant' => 1,
    'second' => 1,
    'voice' => 2,
    'spasm' => 1,
    'loud' => 1,
    'party' => 1,
    'red' => 1,
    'real' => 1,
    'dark' => 1,
    'moment' => 2,
    'what?' => 1,
    'recording?' => 1,
    'short' => 2,
    'quick' => 2,
    'new' => 1,
    'few' => 1,
    'lot' => 1,
    'whole' => 1,
    'mere' => 1,
    'five-week' => 1,
    'simple' => 2,
    'soft' => 1,
    'slow' => 1,
    'who?' => 1,
    'catalogue,' => 1,
    'wilder' => 1,
    'tall' => 1,
    'dreadful' => 1,
    'small' => 1,
    'millisecond' => 1,
  ),
  'B' => 
  array (
    'very' => 1,
    'to' => 1,
    'are' => 1,
    '' => 1,
    'and' => 1,
  ),
  'fast' => 
  array (
    'whilst' => 1,
    'that' => 1,
    'lane' => 1,
  ),
  'whilst' => 
  array (
    'other' => 1,
    '' => 3,
    'visiting' => 1,
    'fighting' => 1,
    'on' => 1,
    'all' => 1,
    'whistling' => 1,
    'another' => 1,
  ),
  'dash' => 
  array (
    'from' => 1,
  ),
  'fast.' => 
  array (
    'People' => 1,
    'Very' => 1,
    '-' => 1,
    'So' => 1,
    'The' => 1,
  ),
  'People' => 
  array (
    'living' => 1,
    'of' => 1,
    'Personalities.' => 1,
    'Personalities,' => 1,
  ),
  'living' => 
  array (
    'at' => 1,
  ),
  'C,' => 
  array (
    'being' => 1,
  ),
  'directly' => 
  array (
    '' => 1,
    'linked' => 1,
  ),
  'between,' => 
  array (
    '' => 1,
  ),
  'often' => 
  array (
    'given' => 1,
    '' => 2,
    'bothered' => 1,
    'enough' => 1,
    'gatecrash' => 1,
    'ask' => 1,
    'thought' => 1,
    'used' => 2,
    'difficult' => 1,
    'paid' => 1,
  ),
  'given' => 
  array (
    'to' => 1,
    'up' => 2,
    'it' => 1,
    'over' => 1,
    'me' => 1,
    'us' => 1,
  ),
  'wonder' => 
  array (
    'what\'s' => 1,
    'if' => 1,
  ),
  'what\'s' => 
  array (
    'so' => 3,
    'the' => 3,
    'happened' => 3,
    '' => 2,
  ),
  'keen' => 
  array (
    'to' => 2,
  ),
  'there,' => 
  array (
    'and' => 1,
    'but' => 1,
    'see' => 1,
    'the' => 1,
    'completely' => 1,
  ),
  'there.' => 
  array (
    'They' => 1,
    'This' => 1,
    'Every' => 1,
    '-' => 3,
    'Most' => 1,
    'It\'s' => 1,
    'I\'m' => 1,
    'Er,' => 1,
    '' => 1,
    'We\'ve' => 1,
  ),
  'They' => 
  array (
    'often' => 1,
    'Knocked' => 1,
    'don\'t' => 1,
    '' => 10,
    'couldn\'t' => 1,
    'slashed' => 1,
    'never' => 1,
    'brought' => 1,
    'were' => 7,
    'are' => 2,
    'cruise' => 1,
    'find' => 1,
    'had' => 3,
    'both' => 3,
    'plunged' => 1,
    'span' => 1,
    'watched' => 1,
    'want' => 1,
    'waited.' => 3,
    'would' => 1,
    'looked' => 1,
    'stopped' => 1,
    'all' => 2,
    'showed' => 1,
    'left' => 2,
    'shrugged' => 1,
    'charged.' => 1,
    'sank' => 1,
    'performed' => 1,
    'emerged' => 1,
    'squeezed' => 1,
    'held' => 1,
    'let' => 1,
    'huddled' => 1,
    'stopped,' => 1,
    'haven\'t' => 1,
    'waited' => 1,
  ),
  'wish' => 
  array (
    '' => 1,
    'I' => 1,
    'I\'d' => 1,
    'you\'d' => 2,
  ),
  'once' => 
  array (
    'and' => 3,
    '' => 4,
    'went' => 1,
    'more' => 1,
    'again,' => 2,
    'again' => 1,
    'already' => 1,
    'more,' => 1,
  ),
  'where' => 
  array (
    'the' => 6,
    '' => 9,
    'his' => 2,
    'he' => 5,
    'it' => 3,
    'Arthur' => 1,
    'I\'m' => 1,
    'you' => 3,
    'they' => 3,
    'are' => 1,
    'we' => 2,
    'do' => 1,
    'even' => 1,
    'strange' => 1,
  ),
  'hell' => 
  array (
    'they' => 1,
    '' => 1,
    'am' => 1,
    'of' => 3,
    'we' => 1,
    'happened?' => 1,
    'out' => 1,
  ),
  'be.' => 
  array (
    'Mr.' => 1,
    '' => 1,
    '-' => 1,
    'He' => 1,
  ),
  'D.' => 
  array (
    '' => 1,
    'His' => 1,
  ),
  'Point' => 
  array (
    '' => 1,
  ),
  'D' => 
  array (
    '' => 1,
  ),
  'anywhere' => 
  array (
    '' => 1,
    'we' => 1,
    'else' => 1,
    'to' => 1,
  ),
  'particular,' => 
  array (
    'it' => 1,
    'or' => 1,
    'stood' => 1,
  ),
  'convenient' => 
  array (
    'point' => 1,
  ),
  'long' => 
  array (
    'way' => 2,
    '' => 5,
    'have' => 1,
    'trek' => 1,
    'waves' => 1,
    'flowing' => 1,
    'haul' => 1,
    'steel-lined' => 1,
    'sought' => 1,
    'walls' => 1,
    'but' => 1,
    'as' => 1,
    'sullen' => 1,
    'enough' => 1,
    'time' => 2,
    'period' => 1,
    'grey' => 1,
    'and' => 1,
    'moment.' => 1,
  ),
  'points' => 
  array (
    'A,' => 1,
    'of' => 2,
  ),
  'A,' => 
  array (
    'B' => 1,
  ),
  'C.' => 
  array (
    'He' => 1,
  ),
  'cottage' => 
  array (
    'at' => 1,
  ),
  'D,' => 
  array (
    'with' => 1,
  ),
  'axes' => 
  array (
    'over' => 1,
  ),
  'door,' => 
  array (
    'and' => 2,
    '-' => 3,
    '' => 1,
    'which' => 1,
  ),
  'spend' => 
  array (
    'a' => 1,
    'it.' => 1,
    'so' => 1,
  ),
  'amount' => 
  array (
    'of' => 3,
    'you' => 2,
  ),
  'E,' => 
  array (
    'which' => 1,
  ),
  'nearest' => 
  array (
    'pub' => 1,
    'bar' => 1,
    '' => 1,
  ),
  'pub' => 
  array (
    'to' => 1,
    'in' => 1,
    'for' => 1,
    'just' => 1,
    'another' => 1,
    'frowned' => 1,
    'furiously' => 1,
    '' => 1,
    'was' => 1,
    'with' => 1,
  ),
  'His' => 
  array (
    'wife' => 1,
    '' => 4,
    'skin' => 1,
    'eyes' => 2,
    'job' => 1,
    'heads' => 1,
    'highly' => 1,
    'dark' => 1,
    'busy' => 1,
    'name' => 1,
    'fingers' => 1,
    'feet' => 1,
    'voice' => 2,
    'mouth' => 1,
    'left' => 1,
    'right-hand' => 1,
    'face' => 1,
    'idea?' => 1,
    'whiskers' => 1,
  ),
  'wife' => 
  array (
    'of' => 1,
  ),
  'course' => 
  array (
    'wanted' => 1,
    'dry' => 1,
    'the' => 1,
    '' => 2,
    'I\'ve' => 1,
    'not,' => 1,
    'became' => 1,
    'it\'s' => 1,
    'merely' => 1,
    'so' => 1,
    'more' => 1,
    'Zaphod' => 1,
    'many' => 1,
    'I\'m' => 1,
    'well' => 1,
  ),
  'climbing' => 
  array (
    'roses,' => 1,
    '' => 1,
  ),
  'roses,' => 
  array (
    '' => 1,
  ),
  'axes.' => 
  array (
    'He' => 2,
  ),
  'why' => 
  array (
    '-' => 1,
    'his' => 1,
    'he' => 3,
    '' => 6,
    'it' => 2,
    'anybody' => 1,
    'do' => 2,
    'he\'s' => 1,
    'I' => 2,
    'Arthur' => 1,
    'the' => 1,
    'not,' => 1,
    'did' => 1,
    'have' => 1,
    'not?' => 1,
  ),
  'liked' => 
  array (
    'axes.' => 1,
    'and' => 1,
    'to' => 1,
    'human' => 1,
    'anything' => 1,
    'it.' => 1,
    'this' => 1,
  ),
  'flushed' => 
  array (
    '' => 1,
  ),
  'hotly' => 
  array (
    'under' => 1,
  ),
  'under' => 
  array (
    'the' => 1,
    '' => 6,
    'great' => 1,
    'Eccentrica' => 1,
    'rubbery' => 1,
    'many' => 1,
    'surveillance.' => 1,
    'it.' => 1,
    'your' => 1,
    'a' => 1,
    'tottering' => 1,
  ),
  'derisive' => 
  array (
    'grins' => 1,
  ),
  'grins' => 
  array (
    'of' => 1,
  ),
  'drivers.' => 
  array (
    'He' => 1,
  ),
  'shifted' => 
  array (
    '' => 1,
    'out' => 1,
  ),
  'weight' => 
  array (
    '' => 1,
    'lifted' => 1,
    'let' => 1,
    '-' => 1,
  ),
  'foot' => 
  array (
    '' => 2,
    'down' => 1,
  ),
  'foot,' => 
  array (
    '' => 1,
  ),
  'equally' => 
  array (
    'uncomfortable' => 1,
    'hollow,' => 1,
    '' => 2,
  ),
  'uncomfortable' => 
  array (
    'on' => 1,
    'silence' => 1,
  ),
  'each.' => 
  array (
    'Obviously' => 1,
  ),
  'Obviously' => 
  array (
    'somebody' => 1,
  ),
  'somebody' => 
  array (
    'had' => 2,
    'somewhere' => 1,
    'came' => 1,
    'else\'s.' => 1,
    'and' => 1,
  ),
  'appallingly' => 
  array (
    'incompetent' => 1,
  ),
  'incompetent' => 
  array (
    'and' => 1,
  ),
  'hoped' => 
  array (
    'to' => 1,
  ),
  'said:' => 
  array (
    '-' => 9,
    '' => 1,
  ),
  'entitled' => 
  array (
    'to' => 1,
    'My' => 1,
  ),
  'suggestions' => 
  array (
    'or' => 1,
  ),
  'protests' => 
  array (
    'at' => 1,
  ),
  'appropriate' => 
  array (
    'time' => 1,
  ),
  'Appropriate' => 
  array (
    'time?' => 2,
  ),
  'time?' => 
  array (
    '-' => 2,
    'The' => 1,
    'We' => 1,
  ),
  'hooted' => 
  array (
    'Arthur.' => 1,
    'and' => 1,
  ),
  'Arthur.' => 
  array (
    '-' => 58,
    '' => 4,
    'Arthur,' => 1,
    'Suddenly' => 1,
    'The' => 3,
    'He' => 3,
  ),
  'I' => 
  array (
    'knew' => 1,
    'asked' => 2,
    'heard' => 2,
    'went' => 4,
    '' => 55,
    'eventually' => 1,
    'did.' => 1,
    'happen' => 1,
    'just' => 6,
    'busy?' => 1,
    'don\'t,' => 1,
    'don\'t' => 33,
    'may' => 4,
    'could' => 6,
    'hadn\'t' => 3,
    'need' => 1,
    'do' => 3,
    'said' => 7,
    'never' => 3,
    'have?' => 1,
    'doing' => 2,
    'would' => 3,
    'thought,' => 2,
    'will' => 7,
    'get' => 5,
    'can' => 18,
    'think' => 28,
    'bought' => 1,
    'regret' => 1,
    'wasn\'t' => 3,
    'thought' => 11,
    'like' => 1,
    'got' => 5,
    'intended,' => 1,
    'came' => 3,
    'rescued' => 1,
    'beg' => 5,
    'can\'t' => 5,
    'worked' => 1,
    'have' => 5,
    'might' => 1,
    'wish' => 3,
    'refuse' => 1,
    'exist,' => 1,
    'am' => 8,
    'was' => 14,
    'hope' => 2,
    'managed' => 1,
    'Found' => 1,
    'implore' => 1,
    'don\'t!' => 1,
    'quite' => 1,
    'write' => 2,
    'really' => 2,
    'mean' => 7,
    'woke' => 1,
    'mean,' => 4,
    'dunno.' => 1,
    'suppose...' => 1,
    'keep' => 1,
    'know.' => 1,
    'didn\'t' => 2,
    'told' => 1,
    'haven\'t' => 2,
    'must' => 1,
    'going' => 1,
    'repeat' => 1,
    'expect.' => 1,
    'won\'t' => 1,
    'wouldn\'t' => 5,
    'am,' => 1,
    'don\'t.' => 2,
    'hate' => 1,
    'say' => 1,
    'bother' => 1,
    'want' => 8,
    'understand.' => 1,
    'tell' => 2,
    'suppose' => 4,
    'saved' => 1,
    'say...' => 1,
    'doubt' => 1,
    'hitched' => 1,
    'know' => 4,
    'only' => 3,
    'said,' => 1,
    'think...' => 1,
    'did' => 4,
    'here?' => 1,
    'shall' => 4,
    'built' => 1,
    'wonder' => 1,
    'promise' => 1,
    'stole' => 1,
    'freewheel' => 1,
    'decide' => 3,
    'work' => 2,
    'stop' => 1,
    'put' => 2,
    'couldn\'t' => 1,
    'wondered' => 1,
    'had' => 1,
    'started' => 1,
    'always' => 2,
    'know,' => 2,
    'sort' => 1,
    'should' => 1,
    'didn\'t.' => 1,
    'see' => 1,
    'described' => 1,
    'am.' => 2,
    'speak' => 2,
    'demand' => 2,
    'make' => 1,
    'wanted' => 1,
    'call' => 1,
    'have.' => 1,
    'checked' => 1,
    'figure' => 1,
    'reckon,' => 1,
    'design' => 1,
    'gather,' => 1,
    'seem' => 1,
    'brought' => 1,
    'see,' => 1,
    'mean?' => 2,
    'finished' => 1,
    'would,' => 1,
    'for' => 1,
    'rather' => 1,
    'go' => 1,
    'agonize' => 1,
    'better' => 1,
    'expect' => 1,
    'talked' => 2,
    'suppose,' => 1,
  ),
  'when' => 
  array (
    'a' => 3,
    'you' => 5,
    '' => 16,
    'he' => 4,
    'the' => 4,
    'can' => 1,
    'his' => 2,
    'I' => 2,
    'confronted' => 1,
    'just' => 1,
    'this' => 1,
    'our' => 1,
    'she' => 1,
    'it' => 1,
    'everybody' => 1,
    'Arthur' => 1,
    'they' => 1,
    'we' => 1,
  ),
  'workman' => 
  array (
    'arrived' => 1,
  ),
  'arrived' => 
  array (
    'at' => 3,
    'on' => 1,
    '' => 1,
    'and' => 1,
  ),
  'my' => 
  array (
    'home' => 1,
    '' => 7,
    'house' => 2,
    'head' => 1,
    'tongue' => 1,
    'eyes' => 2,
    'house?..' => 1,
    'client,' => 1,
    'mind.' => 1,
    'job.' => 1,
    'poetry' => 1,
    'ear?' => 1,
    'foonting' => 1,
    'blurglecruncheon,' => 1,
    'poem' => 1,
    'mean' => 2,
    'bearings.' => 1,
    'aunt.' => 1,
    'mother' => 1,
    'legs' => 1,
    'left' => 2,
    'digital' => 1,
    'colleague' => 1,
    'ego' => 1,
    'intellectual' => 1,
    'semi-cousin' => 1,
    'way' => 1,
    'weight.' => 1,
    'guidance' => 1,
    'purpose' => 2,
    'stomach.' => 1,
    'head?' => 1,
    'mind' => 1,
    'heads' => 1,
    'nomination' => 1,
    'aircar,' => 1,
    'problems.' => 1,
    'teeming' => 1,
    'fate' => 1,
    'circuits' => 1,
    'study' => 1,
    'mind,' => 1,
    'secrets.' => 1,
    'life' => 1,
    'life.' => 1,
    'lifestyle,' => 2,
    'lifestyle' => 1,
    'fjords' => 1,
    'girlfriend!' => 1,
    'view' => 1,
  ),
  'home' => 
  array (
    'yesterday.' => 1,
    'sir?' => 1,
    'wreckers!' => 1,
    'of' => 2,
    'stretch' => 1,
    'planet' => 1,
    'ground' => 1,
    '' => 1,
  ),
  'yesterday.' => 
  array (
    'I' => 1,
    'Two' => 1,
  ),
  'asked' => 
  array (
    'him' => 2,
    'plaintively.' => 1,
    'for' => 2,
    'the' => 2,
    'you' => 1,
    'Arthur.' => 3,
    'Arthur,' => 1,
    'suddenly.' => 1,
    'in' => 1,
    'Arthur' => 2,
    'Ford.' => 2,
    'his' => 1,
    'her' => 1,
    'Ford' => 1,
    'solemnly.' => 1,
    'Fook,' => 1,
    '' => 1,
  ),
  'if' => 
  array (
    'he\'d' => 1,
    'it\'s' => 4,
    'I' => 7,
    'hypnotized' => 1,
    '' => 19,
    'he' => 4,
    'you\'re' => 2,
    'you' => 15,
    'a' => 2,
    'it' => 8,
    'you\'d' => 2,
    'the' => 3,
    'they\'d' => 1,
    'you\'ve' => 1,
    'this' => 3,
    'we\'re' => 2,
    'relationships' => 1,
    'they' => 1,
    'we' => 3,
    'necessary...' => 1,
    'there' => 1,
    'I\'d' => 1,
    'everyone' => 1,
    'they\'re' => 1,
    'there\'s' => 1,
  ),
  'clean' => 
  array (
    'the' => 1,
    'enough.' => 1,
    'because' => 1,
  ),
  'demolish' => 
  array (
    'the' => 1,
  ),
  'me' => 
  array (
    'straight' => 1,
    'a' => 5,
    '-' => 1,
    'none' => 2,
    'one' => 1,
    'what' => 2,
    '' => 2,
    'that' => 4,
    'all' => 1,
    'and' => 2,
    'see' => 1,
    'shouting,' => 1,
    'with' => 1,
    'how' => 1,
    'you' => 2,
    'when' => 1,
    'to' => 6,
    'about' => 4,
    'for' => 1,
    'for?' => 1,
    'up' => 2,
    'yourself.' => 1,
    'instead?' => 1,
    'laugh.' => 1,
    'Eddie' => 1,
    'very' => 1,
    'tell' => 1,
    'who' => 1,
    'not' => 1,
    'plug' => 1,
    'stick' => 1,
    'somebody' => 1,
    'Africa' => 1,
    'it\'s' => 1,
    'introduce' => 1,
    'the' => 1,
    'fine!' => 1,
    'go' => 1,
    'I' => 1,
    'because' => 1,
  ),
  'straight' => 
  array (
    'away' => 1,
    'round' => 1,
    'over' => 1,
    'through' => 3,
    'into' => 3,
    'up' => 2,
    'towards' => 1,
    'off' => 1,
    'out' => 1,
  ),
  'course.' => 
  array (
    'Oh' => 1,
    'The' => 2,
    'His' => 1,
    '-' => 2,
    '' => 1,
  ),
  'no.' => 
  array (
    'First' => 1,
    'Not' => 1,
  ),
  'wiped' => 
  array (
    '' => 2,
    'out' => 1,
  ),
  'couple' => 
  array (
    'of' => 15,
    '' => 2,
  ),
  'charged' => 
  array (
    'me' => 1,
  ),
  'fiver.' => 
  array (
    'Then' => 1,
  ),
  'Then' => 
  array (
    'he' => 4,
    '' => 3,
    'there' => 1,
    'she' => 1,
    'who' => 1,
    'I\'ll' => 1,
    'a' => 2,
    'why\'s' => 1,
    'turn' => 1,
    'what\'s' => 1,
    'it' => 1,
    'I' => 1,
    'the' => 1,
    'Lunkwill' => 1,
    'what,' => 1,
    'Frankie' => 1,
  ),
  'told' => 
  array (
    'me.' => 2,
    'him' => 3,
    'us' => 1,
    'me' => 3,
    '' => 2,
    'to' => 1,
    'me,' => 1,
  ),
  'me.' => 
  array (
    '-' => 6,
    'Ford' => 1,
    '' => 3,
    'Arthur' => 1,
    'Great' => 1,
    'Hold' => 1,
    'So' => 1,
    'If' => 1,
  ),
  'plans' => 
  array (
    'have' => 1,
    'were' => 1,
    'for' => 1,
  ),
  'available' => 
  array (
    'in' => 1,
  ),
  'planning' => 
  array (
    'office' => 1,
    'charts' => 1,
    'department' => 1,
    'and' => 1,
  ),
  'office' => 
  array (
    'for' => 1,
    'buildings,' => 1,
  ),
  'last' => 
  array (
    'nine' => 1,
    'pint.' => 1,
    'hour' => 1,
    'he' => 1,
    'moments' => 1,
    '' => 3,
    'for' => 1,
    'man' => 1,
    'I\'d' => 1,
    'and' => 1,
    'glimmers' => 1,
    'rays' => 1,
    'ever' => 1,
    'planet' => 1,
    'time.' => 1,
    'ten' => 1,
    'generation' => 1,
  ),
  'nine' => 
  array (
    'month.' => 1,
    'to' => 2,
  ),
  'month.' => 
  array (
    '-' => 1,
  ),
  'yes,' => 
  array (
    'well' => 2,
    'that\'s' => 1,
    '-' => 13,
    'Vogonity' => 1,
    'I' => 1,
    'very' => 1,
    'we\'d' => 1,
    'a' => 1,
  ),
  'well' => 
  array (
    'as' => 2,
    'the' => 2,
    'it' => 1,
    'in' => 2,
    'I' => 3,
    'you\'re' => 1,
    'that' => 1,
    '' => 2,
    'that\'s' => 1,
    'done.' => 1,
    'shut' => 1,
    'well,' => 1,
    'do' => 1,
    'with' => 2,
    'so' => 1,
    'looked' => 1,
    'known' => 1,
    'yes,' => 1,
  ),
  'soon' => 
  array (
    'as' => 6,
    'because' => 1,
    '' => 3,
    'that' => 1,
    'can' => 1,
    'lost' => 1,
  ),
  'went' => 
  array (
    'straight' => 2,
    'off' => 2,
    'unnoticed' => 1,
    'around' => 2,
    'swimming' => 1,
    'Ford' => 1,
    'limp.' => 1,
    'on' => 2,
    'on,' => 1,
    'to' => 4,
    'back' => 3,
    'for' => 1,
    'and' => 2,
    'through' => 3,
    'mad' => 1,
    'along' => 1,
    '' => 1,
  ),
  'them,' => 
  array (
    'yesterday' => 1,
    '' => 3,
    '-' => 5,
    'but...' => 1,
    'but' => 1,
    'then' => 1,
    'and' => 2,
    'at' => 1,
    'wondering' => 1,
  ),
  'yesterday' => 
  array (
    'afternoon.' => 1,
    'the' => 1,
  ),
  'afternoon.' => 
  array (
    'You' => 1,
  ),
  'your' => 
  array (
    '' => 14,
    'bloody' => 1,
    'house' => 2,
    'men' => 1,
    'brains' => 1,
    'head' => 2,
    'birthplace,' => 1,
    'skull.' => 1,
    'attention' => 1,
    'star' => 1,
    'planet' => 3,
    'Earth' => 2,
    'own' => 3,
    'system' => 1,
    'eyes...' => 1,
    'ear.' => 2,
    'pardon?' => 5,
    'captain' => 1,
    'ear' => 1,
    'Babel' => 1,
    'bodyweight' => 1,
    'mind' => 1,
    'hand' => 1,
    'ego' => 1,
    'problem,' => 1,
    'day' => 1,
    'engine' => 1,
    'bonnet' => 1,
    'stride' => 1,
    'shipboard' => 1,
    'esteemed' => 1,
    'name' => 2,
    'ship' => 1,
    'custom' => 1,
    'heads?' => 1,
    'dreams' => 1,
    'heart...' => 1,
    'hands.' => 1,
    'level.' => 1,
    'white' => 1,
    'first' => 1,
    'brain?' => 1,
    'name,' => 1,
    'mode' => 1,
    'thinking.' => 1,
    'legal' => 1,
    'working' => 1,
    'hands!' => 1,
    'tastes,' => 1,
    'friends.' => 1,
    'brain' => 2,
    'problems' => 1,
  ),
  'call' => 
  array (
    'attention' => 1,
    '' => 2,
    'an' => 1,
    'the' => 1,
    'it' => 3,
    'that...' => 1,
    'mice,' => 1,
    'thinking.' => 1,
  ),
  'attention' => 
  array (
    'to' => 2,
    'please,' => 1,
    'away' => 2,
    'had' => 1,
  ),
  'you?' => 
  array (
    '' => 2,
    '-' => 25,
    'Ford' => 1,
    'Glad' => 1,
    'Why' => 1,
    'Or' => 1,
  ),
  'mean' => 
  array (
    '' => 5,
    'you\'ve' => 2,
    'that\'s' => 2,
    'callous' => 2,
    'yes,' => 1,
    'you' => 2,
    'the' => 1,
    'anything' => 1,
    'I\'ve' => 1,
    'to' => 1,
    'by' => 2,
    'you\'re' => 1,
    'forget' => 1,
    'why' => 1,
    'ideally' => 1,
  ),
  'like' => 
  array (
    '' => 15,
    'it.' => 3,
    'the' => 7,
    'these' => 1,
    'this' => 4,
    'a' => 13,
    'this:' => 3,
    'to' => 7,
    'having' => 2,
    'you.' => 1,
    'hitch' => 1,
    'being' => 1,
    'that,' => 1,
    'that?' => 2,
    'that' => 1,
    'corks' => 1,
    'half-spent' => 1,
    'two' => 1,
    'them,' => 2,
    'Atlantis' => 1,
    'it' => 1,
    'mountains' => 1,
    'centipedes' => 1,
    'excited' => 1,
    'it,' => 1,
    'because' => 1,
    'that.' => 2,
    'quite' => 1,
    'whisky' => 1,
    'affair,' => 1,
    'some' => 1,
  ),
  'actually' => 
  array (
    '' => 2,
    'need' => 2,
    'here,' => 1,
    'wielded:' => 1,
    'there,' => 1,
    'evil,' => 1,
    'hear' => 1,
    'take' => 1,
    'didn\'t' => 1,
    'stood' => 1,
    'finds' => 1,
    'known' => 1,
    'is' => 1,
    'is,' => 1,
    'tying' => 1,
  ),
  'anybody' => 
  array (
    '' => 1,
    'in' => 1,
    'else' => 1,
    'about' => 1,
    'know' => 1,
  ),
  'display...' => 
  array (
    '-' => 1,
  ),
  'On' => 
  array (
    'display?' => 1,
    'this' => 1,
    'Earth' => 1,
    'the' => 4,
    '' => 3,
    'top' => 1,
    'no' => 1,
    'arrival' => 1,
    'Earth...' => 1,
    'second' => 1,
  ),
  'display?' => 
  array (
    'I' => 1,
  ),
  'eventually' => 
  array (
    'had' => 1,
    'bought' => 1,
    'died' => 1,
    '' => 1,
    'hit' => 1,
    'came' => 1,
    'gave' => 1,
    'to' => 2,
    'just' => 1,
    'have' => 1,
  ),
  'go' => 
  array (
    'down' => 3,
    '' => 3,
    'for' => 1,
    'to' => 6,
    'after' => 1,
    'of' => 1,
    'and' => 3,
    'through?' => 2,
    'this' => 1,
    'on' => 1,
    'skiing' => 1,
    'around' => 2,
    'instead?' => 1,
    'away.' => 1,
  ),
  'cellar' => 
  array (
    'to' => 1,
  ),
  'them.' => 
  array (
    '-' => 14,
    'He' => 2,
    'Between' => 1,
    '' => 5,
    'Together' => 1,
    'They' => 3,
    'The' => 4,
    'For' => 2,
    'Zaphod' => 1,
    'She' => 1,
    'Some' => 1,
    'There' => 1,
  ),
  'That\'s' => 
  array (
    'the' => 2,
    'it,' => 2,
    'it' => 1,
    'what' => 1,
    '' => 2,
    'pretty' => 1,
    'just' => 2,
    'high.' => 1,
    'very' => 1,
    'it!' => 1,
    'a' => 2,
    'right!' => 2,
    'where' => 1,
    'odd.' => 1,
  ),
  'display' => 
  array (
    'department.' => 1,
    'in' => 2,
    'are' => 1,
  ),
  'department.' => 
  array (
    '-' => 1,
  ),
  'With' => 
  array (
    'a' => 7,
    'her' => 1,
    'an' => 2,
    'horror' => 1,
    'little' => 1,
    'one' => 1,
  ),
  'torch.' => 
  array (
    '-' => 1,
  ),
  'Ah,' => 
  array (
    'well' => 2,
    'I\'m' => 1,
    '-' => 3,
    'take' => 1,
    'but' => 1,
    'shit,' => 1,
  ),
  'lights' => 
  array (
    'had' => 1,
    'up' => 1,
    'and' => 1,
    'on' => 1,
    'flashed' => 1,
    'congealed' => 1,
  ),
  'gone.' => 
  array (
    '-' => 1,
    'No' => 2,
    'Nelson\'s' => 1,
    '' => 1,
  ),
  'So' => 
  array (
    'had' => 1,
    'all' => 2,
    'if' => 1,
    'the' => 2,
    'what' => 3,
    'this' => 1,
    'do' => 1,
    'they' => 1,
    'big' => 1,
    'I' => 2,
    'we' => 1,
    'long' => 1,
    '' => 2,
    'saying,' => 1,
    'what\'s' => 1,
    'you' => 1,
    'there' => 1,
    'your' => 1,
    '-' => 1,
    'are' => 1,
  ),
  'stairs.' => 
  array (
    '-' => 1,
  ),
  'look,' => 
  array (
    'you' => 1,
    'are' => 1,
  ),
  'notice' => 
  array (
    'didn\'t' => 1,
    'it' => 1,
    'it.' => 1,
    'how' => 1,
    '' => 1,
    'the' => 2,
    'anything' => 1,
    'that' => 2,
    'of' => 1,
  ),
  'Yes,' => 
  array (
    '-' => 22,
    'he' => 1,
    'and...' => 1,
    'I' => 2,
    'do' => 1,
    'that\'s' => 1,
    'but' => 1,
    'through' => 1,
    'very' => 1,
    'thank' => 1,
    'an' => 1,
  ),
  'yes' => 
  array (
    'I' => 1,
    'sir?' => 1,
    'sir,' => 1,
    'idealism,' => 1,
    'the' => 2,
    'we' => 1,
  ),
  'did.' => 
  array (
    'It' => 1,
    'Ford' => 1,
    '-' => 2,
    'All' => 1,
  ),
  'bottom' => 
  array (
    'of' => 3,
    'and' => 1,
    'fell' => 1,
    '' => 2,
  ),
  'locked' => 
  array (
    'filing' => 1,
    'in' => 1,
    'off' => 1,
    'up,' => 1,
    'away' => 1,
    'away.' => 1,
  ),
  'filing' => 
  array (
    'cabinet' => 1,
  ),
  'cabinet' => 
  array (
    'stuck' => 1,
    'speakers' => 1,
  ),
  'disused' => 
  array (
    'lavatory' => 1,
  ),
  'lavatory' => 
  array (
    'with' => 1,
    'it' => 1,
  ),
  'sign' => 
  array (
    '' => 1,
    'of' => 1,
    'appeared,' => 1,
  ),
  'door' => 
  array (
    'saying' => 1,
    'slid' => 1,
    'from' => 2,
    'with' => 1,
    'were' => 1,
    'closed' => 3,
    'to' => 1,
    'slit' => 2,
    'let' => 1,
    'very' => 1,
    'and' => 2,
    'flew' => 1,
    '' => 1,
    'into' => 1,
    'at' => 1,
    'open.' => 1,
  ),
  'Beware' => 
  array (
    'of' => 1,
  ),
  'Leopard.' => 
  array (
    'A' => 1,
  ),
  'cloud' => 
  array (
    'passed' => 1,
    '' => 1,
  ),
  'passed' => 
  array (
    'overhead.' => 1,
    '' => 2,
    'into' => 1,
    'away' => 2,
    'out.' => 2,
    'it' => 1,
    'right' => 1,
    'an' => 1,
    'between' => 1,
    'a' => 1,
    'when' => 1,
  ),
  'overhead.' => 
  array (
    'It' => 1,
  ),
  'cast' => 
  array (
    'a' => 1,
    '' => 1,
  ),
  'shadow' => 
  array (
    'over' => 1,
    '' => 1,
    'moved' => 1,
  ),
  'Dent' => 
  array (
    'as' => 1,
    'had' => 2,
    '' => 2,
    'come' => 1,
    'with' => 1,
    'moved,' => 1,
    'sat' => 1,
  ),
  'propped' => 
  array (
    'up' => 1,
  ),
  'elbow' => 
  array (
    'in' => 1,
  ),
  'cold' => 
  array (
    'mud.' => 1,
    '' => 2,
    'it' => 1,
    'on' => 1,
    'rock.' => 1,
    'as' => 1,
    'clot' => 1,
    'to' => 1,
    'night' => 1,
    'darkness,' => 1,
    'and' => 1,
    'even' => 1,
    'dust.' => 1,
  ),
  'mud.' => 
  array (
    'It' => 1,
    '-' => 1,
    'As' => 1,
    'He' => 1,
  ),
  'frowned' => 
  array (
    'at' => 5,
    'to' => 1,
    'and' => 1,
    'as' => 1,
  ),
  'house,' => 
  array (
    '-' => 1,
  ),
  'sorry,' => 
  array (
    'but' => 2,
    '-' => 3,
    'I\'m' => 1,
    '' => 1,
    'mice' => 1,
  ),
  'happen' => 
  array (
    'to' => 2,
    '' => 3,
  ),
  'You\'ll' => 
  array (
    'like' => 1,
    'need' => 1,
    'have' => 1,
    'ne...' => 1,
    '' => 1,
  ),
  'shut' => 
  array (
    'up,' => 2,
    'behind' => 1,
    'up' => 3,
    'down' => 1,
    'up.' => 1,
  ),
  'Dent.' => 
  array (
    '-' => 3,
    'For' => 1,
    'He' => 1,
    'Somehow' => 1,
    'Arthur' => 1,
  ),
  'Shut' => 
  array (
    'up' => 1,
    'up!' => 3,
    'up,' => 1,
  ),
  'away,' => 
  array (
    '' => 2,
    'alright?' => 1,
    '-' => 1,
    'locked' => 1,
    'as' => 1,
    'four' => 1,
    'and' => 1,
  ),
  'take' => 
  array (
    'your' => 1,
    'it' => 1,
    'over' => 1,
    'Mr.' => 1,
    'all' => 1,
    'slightly' => 1,
    'an' => 2,
    '' => 9,
    'a' => 3,
    'you' => 2,
    'no' => 1,
    'evasive' => 1,
    'us' => 1,
    'him.' => 1,
    'the' => 1,
    'another' => 1,
    'care' => 1,
    'me' => 1,
    'on' => 1,
    'it.' => 1,
    'any' => 1,
    'in' => 1,
  ),
  'bloody' => 
  array (
    'bypass' => 1,
    'planet,' => 2,
    '' => 1,
    'engines' => 1,
    'machine' => 1,
  ),
  'you.' => 
  array (
    'You' => 2,
    'Have' => 1,
    '-' => 4,
    'The' => 2,
    'Arthur' => 3,
    'It\'s' => 1,
    'Two' => 1,
    'Nice' => 1,
    'If' => 1,
    '' => 2,
    'And' => 1,
    'We' => 1,
  ),
  'haven\'t' => 
  array (
    'got' => 1,
    '' => 2,
    'started' => 1,
    'made' => 1,
    'even' => 2,
    'opened' => 1,
    'ruled' => 1,
    'had' => 1,
    'the' => 1,
  ),
  'Prosser\'s' => 
  array (
    'mouth' => 1,
    'accepted' => 1,
  ),
  'mouth' => 
  array (
    'opened' => 1,
    'and' => 1,
    'slacked.' => 1,
    'of' => 1,
  ),
  'closed' => 
  array (
    'a' => 1,
    'his' => 2,
    'in' => 2,
    'and' => 1,
    '' => 2,
    'up' => 1,
    'behind' => 2,
    'down' => 1,
    'for' => 1,
    'the' => 1,
  ),
  'times' => 
  array (
    '' => 3,
    'over' => 2,
    'more' => 1,
    'and' => 1,
  ),
  'while' => 
  array (
    '' => 3,
    'you\'re' => 1,
    'nothing' => 1,
    'away' => 2,
    'the' => 2,
    'and' => 1,
    'there' => 1,
    'later' => 1,
    'to' => 1,
    'ago,' => 1,
  ),
  'filled' => 
  array (
    'with' => 3,
    'his' => 1,
    'the' => 1,
  ),
  'inexplicable' => 
  array (
    '' => 2,
    'humiliations' => 1,
    'arrival' => 1,
  ),
  'attractive' => 
  array (
    'visions' => 1,
  ),
  'visions' => 
  array (
    'of' => 1,
    'like' => 1,
  ),
  'consumed' => 
  array (
    'with' => 1,
  ),
  'fire' => 
  array (
    'and' => 1,
    'boiling' => 1,
    'on' => 1,
  ),
  'running' => 
  array (
    'screaming' => 1,
    'after' => 1,
    'from' => 1,
    '' => 3,
    'out' => 2,
    'furiously' => 1,
    'round' => 1,
    'down' => 1,
    'away)' => 1,
    'a' => 1,
    'your' => 1,
    'off' => 1,
  ),
  'screaming' => 
  array (
    'from' => 1,
    'through' => 1,
    '' => 1,
    'on' => 1,
    'heeby' => 1,
  ),
  'blazing' => 
  array (
    'ruin' => 1,
    'in' => 1,
  ),
  'ruin' => 
  array (
    'with' => 1,
  ),
  'hefty' => 
  array (
    '' => 1,
  ),
  'spears' => 
  array (
    'protruding' => 1,
  ),
  'protruding' => 
  array (
    'from' => 1,
  ),
  'back.' => 
  array (
    'Mr.' => 1,
    'At' => 1,
    '' => 2,
    'Trillian' => 1,
    '-' => 3,
  ),
  'bothered' => 
  array (
    'with' => 1,
    'to' => 3,
  ),
  'nervous.' => 
  array (
    'He' => 1,
    'His' => 1,
  ),
  'stuttered' => 
  array (
    'for' => 1,
  ),
  'pulled' => 
  array (
    'himself' => 1,
    '' => 2,
    'itself' => 1,
    'those.' => 1,
    'out' => 1,
  ),
  'together.' => 
  array (
    '-' => 3,
    'With' => 1,
  ),
  'Hello?' => 
  array (
    'Yes?' => 1,
    '-' => 2,
    'Why' => 1,
  ),
  'Yes?' => 
  array (
    '-' => 1,
    'Hello?' => 1,
  ),
  'factual' => 
  array (
    'information' => 1,
  ),
  'information' => 
  array (
    'for' => 1,
    'he' => 1,
    '' => 1,
  ),
  'Have' => 
  array (
    'you' => 3,
  ),
  'damage' => 
  array (
    'that' => 1,
  ),
  'suffer' => 
  array (
    'if' => 1,
  ),
  'let' => 
  array (
    'it' => 1,
    'the' => 2,
    'his' => 1,
    'them' => 3,
    'out' => 2,
    'us' => 3,
    'into' => 2,
    '' => 1,
    'her' => 1,
    'himself' => 1,
    'me' => 3,
    'anybody' => 1,
    'fly' => 1,
  ),
  'roll' => 
  array (
    'straight' => 1,
    '' => 1,
    'over' => 1,
  ),
  'How' => 
  array (
    'much?' => 1,
    'does' => 2,
    'long' => 1,
    'long?' => 2,
    'would' => 1,
    'do' => 2,
    'did' => 4,
    'can' => 4,
    'soon' => 1,
    'better' => 1,
    '' => 1,
    'many' => 2,
  ),
  'much?' => 
  array (
    '-' => 1,
  ),
  'None' => 
  array (
    'at' => 2,
    'of' => 2,
    'that' => 1,
  ),
  'all,' => 
  array (
    '' => 4,
    '-' => 2,
    'it' => 1,
    'and' => 1,
    'but' => 1,
    'deep' => 1,
    'takes' => 1,
    'Ford?' => 1,
  ),
  'Prosser,' => 
  array (
    '' => 2,
    'spelling' => 1,
    '-' => 1,
  ),
  'stormed' => 
  array (
    '' => 1,
    'out' => 1,
  ),
  'nervously' => 
  array (
    '' => 1,
    'and' => 2,
    'in' => 1,
    'up' => 1,
    'into' => 1,
  ),
  'wondering' => 
  array (
    'why' => 1,
    'who' => 1,
    'what' => 1,
  ),
  'brain' => 
  array (
    'was' => 2,
    'from' => 1,
    'which' => 1,
    'cells.' => 1,
    'the' => 1,
    'care' => 1,
    'crawled' => 1,
    '' => 2,
    'told' => 1,
    'screening' => 1,
    '-' => 1,
    'we' => 1,
    'electronically,' => 1,
    'into' => 1,
  ),
  'hairy' => 
  array (
    '' => 1,
  ),
  'horsemen' => 
  array (
    '' => 1,
    'laughing' => 1,
  ),
  'shouting' => 
  array (
    'at' => 1,
    'again.' => 1,
    '' => 2,
    'I\'ve' => 1,
  ),
  'By' => 
  array (
    'a' => 2,
    'this' => 1,
    'the' => 1,
  ),
  'curious' => 
  array (
    'coincidence,' => 1,
    '' => 3,
    'suspensions,' => 1,
    'things' => 1,
  ),
  'coincidence,' => 
  array (
    'None' => 1,
    '' => 1,
  ),
  'suspicion' => 
  array (
    'the' => 1,
    'that' => 1,
  ),
  'ape-descendant' => 
  array (
    'Arthur' => 1,
  ),
  'closest' => 
  array (
    'friends' => 1,
  ),
  'ape,' => 
  array (
    'but' => 1,
  ),
  'vicinity' => 
  array (
    'of' => 4,
  ),
  'Betelgeuse' => 
  array (
    'and' => 1,
    'trading' => 2,
    'Seven.' => 1,
    'Seven' => 1,
    'Five' => 2,
    '' => 1,
    'Seven">.' => 1,
    'holding' => 1,
    'state' => 1,
  ),
  'Guildford' => 
  array (
    'as' => 1,
    'after' => 1,
  ),
  'usually' => 
  array (
    'claimed.' => 1,
    'ended' => 1,
    'say' => 1,
    '' => 3,
    'played' => 1,
    'rich' => 1,
    'had' => 1,
  ),
  'claimed.' => 
  array (
    'Arthur' => 1,
    'She' => 1,
  ),
  'never,' => 
  array (
    'ever' => 1,
  ),
  'suspected' => 
  array (
    'this.' => 1,
  ),
  'this.' => 
  array (
    'This' => 1,
    '-' => 5,
    'Ford' => 2,
    'Only' => 1,
    'We' => 2,
  ),
  'friend' => 
  array (
    'of' => 3,
  ),
  'fifteen' => 
  array (
    'Earth' => 1,
    'years' => 3,
    'years.' => 1,
    'years!' => 1,
    'seconds' => 1,
  ),
  'previously,' => 
  array (
    'and' => 1,
  ),
  'hard' => 
  array (
    '' => 1,
    'to' => 2,
    'driving' => 1,
    'not' => 1,
    'enough' => 1,
    'about' => 1,
  ),
  'blend' => 
  array (
    '' => 1,
  ),
  'into' => 
  array (
    '' => 37,
    'the' => 52,
    'a' => 19,
    'Mr.' => 1,
    'his' => 14,
    'it' => 1,
    'had' => 1,
    'hitch' => 1,
    'your' => 3,
    'shock' => 1,
    'its' => 2,
    'space.' => 2,
    'hyperspace' => 1,
    'sharp' => 1,
    'space,' => 1,
    'space' => 1,
    'this' => 1,
    'outer' => 1,
    'communication' => 1,
    'sight' => 1,
    'an' => 2,
    'orbit,' => 1,
    'dream' => 1,
    'anonymity' => 1,
    'close' => 1,
    'pursuit.' => 1,
    'existence' => 1,
    'it,' => 1,
    'smallish' => 1,
    'one' => 1,
    'tax' => 1,
    'blackness' => 1,
    'which' => 1,
    'our' => 1,
    'existence?' => 1,
    'something' => 1,
    'any' => 1,
    'it.' => 1,
    'silence' => 1,
    'shape' => 1,
    'life.' => 1,
  ),
  'society' => 
  array (
    '-' => 1,
  ),
  'with,' => 
  array (
    'it' => 1,
    '' => 1,
    'without' => 1,
    'and' => 1,
  ),
  'success.' => 
  array (
    'For' => 1,
  ),
  'instance' => 
  array (
    'he' => 2,
  ),
  'spent' => 
  array (
    'those' => 1,
    'two' => 1,
    'a' => 1,
  ),
  'those' => 
  array (
    'fifteen' => 1,
    'Santraginean' => 1,
    'happy' => 1,
    'scheduled' => 1,
    'of' => 3,
    'criteria' => 1,
    'around' => 1,
    'are' => 1,
    'thirty' => 1,
    'sort' => 1,
    'self-satisfied' => 1,
    'couple' => 2,
    'aliens' => 1,
    'doors.' => 1,
    'Galactic' => 1,
    'days' => 1,
    'two' => 1,
    'who' => 1,
    '' => 2,
    'whinnet-ridden' => 1,
    'thuds?' => 1,
  ),
  'pretending' => 
  array (
    'to' => 3,
    '' => 1,
  ),
  'actor,' => 
  array (
    '' => 1,
  ),
  'plausible' => 
  array (
    'enough.' => 1,
  ),
  'enough.' => 
  array (
    'He' => 1,
    'More' => 1,
    'Ford' => 1,
    'Equatorial!' => 1,
  ),
  'careless' => 
  array (
    'blunder' => 1,
    'talk' => 1,
  ),
  'blunder' => 
  array (
    'though,' => 1,
  ),
  'though,' => 
  array (
    'because' => 1,
    'when' => 1,
  ),
  'skimped' => 
  array (
    'a' => 1,
  ),
  'bit' => 
  array (
    'on' => 1,
    'sozzled' => 1,
    'squalid,' => 1,
    'about' => 1,
    'upset' => 1,
    '' => 2,
    'of' => 3,
    'and' => 2,
    'longer' => 1,
    'promised' => 1,
  ),
  'preparatory' => 
  array (
    'research.' => 1,
  ),
  'research.' => 
  array (
    'The' => 1,
  ),
  'gathered' => 
  array (
    'had' => 1,
    '' => 1,
    'that' => 1,
  ),
  'led' => 
  array (
    '' => 1,
    'either' => 1,
  ),
  'choose' => 
  array (
    'the' => 1,
    '' => 1,
    'from?' => 1,
    'a' => 1,
  ),
  'name' => 
  array (
    '"Ford' => 1,
    '' => 3,
    'was' => 1,
    'and' => 1,
    'for' => 1,
    'like...' => 1,
    '-' => 1,
    'is' => 1,
    'by' => 1,
    'it' => 1,
    'on' => 1,
  ),
  '"Ford' => 
  array (
    'Prefect"' => 1,
  ),
  'Prefect"' => 
  array (
    'as' => 1,
  ),
  'nicely' => 
  array (
    'inconspicuous.' => 1,
    'chilled' => 1,
  ),
  'inconspicuous.' => 
  array (
    'He' => 1,
  ),
  'conspicuously' => 
  array (
    'tall,' => 1,
    'handsome.' => 1,
  ),
  'tall,' => 
  array (
    'his' => 1,
    'or' => 1,
  ),
  'features' => 
  array (
    '' => 1,
    'would' => 1,
  ),
  'striking' => 
  array (
    '' => 1,
  ),
  'handsome.' => 
  array (
    'His' => 1,
  ),
  'hair' => 
  array (
    '' => 2,
  ),
  'wiry' => 
  array (
    '' => 1,
  ),
  'gingerish' => 
  array (
    '' => 1,
  ),
  'brushed' => 
  array (
    'backwards' => 1,
    'some' => 1,
    'nylon.' => 1,
    'steel' => 2,
  ),
  'backwards' => 
  array (
    'from' => 1,
    '' => 3,
    'into' => 2,
  ),
  'temples.' => 
  array (
    'His' => 1,
    'These' => 1,
    'He' => 1,
  ),
  'skin' => 
  array (
    'seemed' => 1,
    'was' => 1,
    '' => 1,
    'begin' => 1,
  ),
  'nose.' => 
  array (
    'There' => 1,
  ),
  'There' => 
  array (
    'was' => 15,
    'you' => 4,
    '' => 3,
    'would' => 1,
    'seems' => 1,
    'really' => 3,
    'followed' => 1,
    'did,' => 1,
    'were' => 1,
    'are' => 3,
    'must' => 1,
    'is' => 3,
  ),
  'him,' => 
  array (
    '' => 4,
    'and' => 4,
    'puzzled.' => 1,
    '-' => 6,
    'genuinely' => 1,
    'he' => 2,
    'or,' => 1,
    'the' => 1,
    'spun' => 1,
    'slowly' => 1,
    'pretending' => 1,
    'whatever' => 1,
    'at' => 1,
    'but' => 2,
    'aghast.' => 1,
  ),
  'difficult' => 
  array (
    'to' => 3,
    'for' => 1,
    '' => 1,
  ),
  'say' => 
  array (
    'what' => 2,
    'something' => 2,
    'it,' => 2,
    'about' => 1,
    'on' => 1,
    'exactly' => 1,
    'and' => 1,
    '' => 3,
    'now?' => 1,
    'things' => 1,
    'that' => 2,
    'that,' => 1,
    'it' => 1,
    'Zaphod' => 1,
    'was' => 1,
    'you\'ve' => 1,
    'that?' => 1,
    'hang' => 1,
    'What?' => 1,
    'down' => 1,
    'five' => 1,
  ),
  'was.' => 
  array (
    'Perhaps' => 1,
    'A' => 1,
    'It' => 1,
    '-' => 3,
    'Arthur' => 1,
  ),
  'Perhaps' => 
  array (
    'it' => 2,
    'you' => 3,
    'I' => 1,
    'somewhere' => 1,
    'I\'m' => 1,
    'it\'s' => 1,
  ),
  'blink' => 
  array (
    'often' => 1,
  ),
  'enough' => 
  array (
    'and' => 2,
    'for' => 3,
    'about' => 1,
    'so' => 1,
    '' => 1,
    'to' => 4,
    'trying' => 1,
    'people' => 1,
    'problems' => 1,
  ),
  'talked' => 
  array (
    'to' => 5,
  ),
  'length' => 
  array (
    'of' => 3,
    'and' => 2,
  ),
  'involuntarily' => 
  array (
    'to' => 1,
    'as' => 1,
  ),
  'water' => 
  array (
    'on' => 1,
    '' => 2,
    'from' => 1,
    'at' => 1,
    'hissing' => 1,
    'spout.' => 1,
    'falling' => 1,
    'having' => 1,
  ),
  'behalf.' => 
  array (
    'Perhaps' => 1,
  ),
  'smiled' => 
  array (
    'slightly' => 1,
    'at' => 1,
    'wanly' => 1,
    '' => 1,
    'more' => 1,
    'weakly.' => 1,
    'very' => 1,
  ),
  'broadly' => 
  array (
    'and' => 1,
  ),
  'gave' => 
  array (
    'people' => 1,
    'up.' => 1,
    'the' => 5,
    'him' => 2,
    'a' => 3,
    'out' => 1,
    'an' => 1,
    'Arthur' => 1,
    'up' => 3,
    'that' => 1,
    'way' => 1,
    'us' => 2,
  ),
  'unnerving' => 
  array (
    'impression' => 1,
  ),
  'impression' => 
  array (
    'that' => 1,
    'was' => 1,
    '' => 1,
    'of' => 1,
    'than' => 1,
  ),
  'their' => 
  array (
    'neck.' => 1,
    'financial' => 1,
    'will' => 1,
    '' => 15,
    'presence,' => 1,
    'fun.' => 1,
    'fun!' => 1,
    'way' => 4,
    'minds' => 1,
    'PA' => 1,
    'multicolored' => 1,
    'faces' => 1,
    'Sub-Etha' => 1,
    'earlier' => 1,
    'shells' => 1,
    'backs' => 2,
    'native' => 1,
    'long' => 1,
    'habit' => 1,
    'lips,' => 2,
    'mouths' => 1,
    'brains' => 1,
    'heads' => 1,
    'Poet' => 1,
    'works' => 1,
    'straps' => 1,
    'mark,' => 1,
    'eyes' => 1,
    'pleasure' => 1,
    'satisfaction' => 1,
    'guard,' => 1,
    'point' => 1,
    'rescue' => 1,
    'thoughts.' => 1,
    'kids' => 1,
    'kind' => 1,
    'flight' => 1,
    'independence' => 1,
    'lives' => 1,
    'way,' => 1,
    'dusty' => 1,
    'own' => 3,
    'time' => 1,
    'speed' => 1,
    'terminus' => 1,
    'behaviour' => 1,
    'real' => 1,
    'favourite' => 1,
    'problems' => 1,
    'families' => 1,
    'brief' => 1,
    'leather-bound' => 1,
    'way.' => 1,
    'heels' => 1,
    'wildest' => 1,
    'legs' => 1,
    'dry' => 1,
    'chairs' => 1,
    'planet' => 1,
    'Galaxy' => 1,
    'faces.' => 1,
    'glasses' => 1,
    'piping' => 1,
    'two' => 1,
    'excitement.' => 1,
    'breath' => 1,
    'sockets.' => 1,
    'heads.' => 1,
  ),
  'neck.' => 
  array (
    'He' => 1,
    'The' => 1,
    '(An' => 1,
    '' => 1,
    '-' => 1,
  ),
  'struck' => 
  array (
    'most' => 1,
    'him.' => 2,
    'another' => 1,
    '' => 1,
    'Arthur.' => 1,
    'Ford' => 1,
  ),
  'eccentric,' => 
  array (
    'but' => 1,
  ),
  'harmless' => 
  array (
    'one' => 1,
    '' => 1,
  ),
  'unruly' => 
  array (
    '' => 1,
    'tribe' => 1,
  ),
  'boozer' => 
  array (
    '' => 1,
  ),
  'oddish' => 
  array (
    '' => 1,
  ),
  'habits.' => 
  array (
    '' => 1,
  ),
  'gatecrash' => 
  array (
    'university' => 1,
  ),
  'university' => 
  array (
    'parties,' => 1,
  ),
  'parties,' => 
  array (
    'get' => 1,
  ),
  'badly' => 
  array (
    'drunk' => 1,
    'in' => 1,
  ),
  'drunk' => 
  array (
    '' => 1,
  ),
  'start' => 
  array (
    'making' => 2,
    'guiltily' => 1,
    'working.' => 1,
    'smaller' => 1,
    'panicking.' => 1,
    '' => 3,
    'of' => 1,
    'to' => 1,
    'finding' => 1,
    'clearing' => 1,
  ),
  'making' => 
  array (
    'fun' => 1,
    '' => 4,
    'a' => 5,
    'life' => 1,
    'beep' => 1,
    'an' => 1,
    'your' => 1,
    'do' => 1,
  ),
  'fun' => 
  array (
    'of' => 1,
    'place.' => 1,
    'in' => 1,
    'doing' => 1,
  ),
  'astrophysicist' => 
  array (
    'he' => 1,
  ),
  'till' => 
  array (
    '' => 3,
    'I\'ve' => 1,
    'the' => 1,
    'he' => 1,
    'somebody' => 1,
    'they' => 2,
  ),
  'thrown' => 
  array (
    'out.' => 1,
    'out' => 1,
    'into' => 1,
    '' => 1,
    'against' => 1,
  ),
  'Sometimes' => 
  array (
    'he' => 1,
  ),
  'seized' => 
  array (
    'with' => 1,
  ),
  'oddly' => 
  array (
    'distracted' => 1,
    '' => 2,
  ),
  'distracted' => 
  array (
    'moods' => 1,
  ),
  'moods' => 
  array (
    '' => 1,
  ),
  'stare' => 
  array (
    'into' => 1,
    'at' => 1,
    '' => 1,
  ),
  'sky' => 
  array (
    'as' => 1,
    'was' => 1,
    'like' => 2,
    'again,' => 1,
    'in' => 2,
    'apart' => 1,
    'with' => 1,
    'cracked' => 1,
    'taking' => 1,
    'and' => 1,
    'quite' => 1,
    'is' => 1,
    'a' => 2,
    '' => 1,
  ),
  'hypnotized' => 
  array (
    'until' => 1,
    '' => 1,
  ),
  'someone' => 
  array (
    'asked' => 1,
    'decided' => 1,
    'would' => 1,
    '' => 1,
    'else' => 3,
    'up' => 1,
  ),
  'doing.' => 
  array (
    'Then' => 1,
    'Ford' => 1,
  ),
  'guiltily' => 
  array (
    'for' => 1,
  ),
  'moment,' => 
  array (
    'relax' => 1,
    '-' => 1,
    '' => 2,
    'hit' => 1,
    'he' => 1,
    'tipped' => 1,
    'and' => 3,
    'but' => 1,
    'nothing' => 1,
  ),
  'relax' => 
  array (
    'and' => 1,
  ),
  'grin.' => 
  array (
    '-' => 1,
    'The' => 1,
  ),
  'Oh,' => 
  array (
    'just' => 3,
    'that' => 1,
    'er,' => 1,
    'it' => 1,
    '-' => 4,
    'yeah,' => 1,
    'Zaphod,' => 1,
    'the' => 1,
    'yes,' => 1,
    'probably' => 1,
    'I\'m' => 1,
    'I' => 1,
  ),
  'flying' => 
  array (
    'saucers,' => 1,
    'saucers' => 2,
    '' => 1,
    'saucer' => 3,
    'saucer?' => 1,
  ),
  'saucers,' => 
  array (
    '-' => 1,
  ),
  'joke' => 
  array (
    '' => 1,
  ),
  'everyone' => 
  array (
    'would' => 1,
    'had' => 1,
    'else' => 1,
    'so' => 1,
    'was' => 1,
    'has' => 1,
    'looked' => 1,
  ),
  'laugh' => 
  array (
    'and' => 1,
    'wildly' => 1,
    'did' => 1,
  ),
  'saucers' => 
  array (
    'he' => 1,
    '' => 1,
    'down' => 1,
  ),
  'for.' => 
  array (
    '-' => 4,
    'A' => 1,
    'He' => 1,
    'The' => 1,
    'Something' => 1,
    'It' => 1,
  ),
  'Green' => 
  array (
    'ones!' => 1,
    'Putty' => 1,
  ),
  'ones!' => 
  array (
    '-' => 1,
  ),
  'reply' => 
  array (
    'with' => 1,
    'by' => 1,
  ),
  'wicked' => 
  array (
    'grin,' => 1,
    '' => 1,
  ),
  'grin,' => 
  array (
    'laugh' => 1,
    '-' => 1,
  ),
  'lunge' => 
  array (
    'for' => 1,
  ),
  'bar' => 
  array (
    '' => 2,
    'of' => 1,
    'looked' => 1,
    'suddenly' => 1,
    'their' => 1,
  ),
  'buy' => 
  array (
    '' => 2,
  ),
  'enormous' => 
  array (
    'round' => 1,
    '' => 1,
    'amount' => 1,
  ),
  'drinks.' => 
  array (
    'Evenings' => 1,
  ),
  'Evenings' => 
  array (
    'like' => 1,
  ),
  'ended' => 
  array (
    'badly.' => 1,
    'it.' => 1,
  ),
  'badly.' => 
  array (
    'Ford' => 1,
  ),
  'Ford' => 
  array (
    'would' => 2,
    '' => 16,
    'Prefect' => 14,
    'wished' => 1,
    'seemed' => 1,
    'glanced' => 3,
    'stared' => 7,
    'learned' => 1,
    'looked' => 6,
    'patiently,' => 1,
    'said,' => 1,
    'Prefect,' => 4,
    'nudged' => 1,
    'beckoned' => 1,
    'Prefect.' => 2,
    'at' => 2,
    'slapped' => 1,
    'ignored' => 1,
    'gave' => 2,
    'Prefect\'s' => 3,
    'Prefect?' => 1,
    'clicked' => 1,
    'had' => 4,
    'was' => 10,
    'and' => 15,
    'knew' => 1,
    'never' => 1,
    'stood' => 1,
    'struck' => 1,
    'frowned' => 2,
    'handed' => 1,
    'pressed' => 1,
    'leant' => 1,
    'sprang' => 1,
    'shrugged.' => 1,
    'with' => 2,
    'turned' => 1,
    'continued' => 1,
    'leaped' => 2,
    'hissed' => 1,
    'laughed' => 1,
    'tried' => 1,
    'hurriedly,' => 1,
    'patting' => 1,
    'suddenly' => 1,
    'scrambled' => 1,
    'carried' => 3,
    'opened' => 1,
    'thought' => 1,
    'decided' => 1,
    'skidded' => 1,
    'waddled' => 1,
    'in' => 4,
    'jabbed' => 1,
    'hunted' => 1,
    'following' => 1,
    'again.' => 1,
    'impatiently.' => 1,
    'rounded' => 1,
    'couldn\'t' => 1,
    'went' => 1,
    'frowned.' => 1,
    'quietly.' => 1,
    'gazed' => 2,
    'as' => 2,
    'tapped' => 1,
    'pleasantly.' => 1,
    'leapt' => 1,
    'doubtfully,' => 1,
    'discovered' => 1,
    'eventually.' => 1,
    'nodded.' => 1,
    'gaped' => 1,
    'made' => 1,
    'shouted' => 1,
    'poked' => 1,
    'could' => 1,
    'stayed,' => 1,
    'squatting' => 1,
  ),
  'skull' => 
  array (
    'on' => 1,
  ),
  'whisky,' => 
  array (
    'huddle' => 1,
  ),
  'huddle' => 
  array (
    'into' => 1,
  ),
  'corner' => 
  array (
    'with' => 1,
    '' => 1,
    'of' => 5,
    'and' => 2,
    'a' => 1,
    'under' => 1,
    'discussing' => 1,
  ),
  'explain' => 
  array (
    'to' => 2,
    'it' => 1,
    'what' => 1,
    'or' => 1,
  ),
  'slurred' => 
  array (
    'phrases' => 1,
  ),
  'phrases' => 
  array (
    'that' => 1,
  ),
  'honestly' => 
  array (
    'the' => 1,
  ),
  'colour' => 
  array (
    '' => 1,
    'which' => 1,
    'streaked' => 1,
    'supplements,' => 1,
    'blue,' => 1,
    'and' => 1,
  ),
  'matter' => 
  array (
    'that' => 1,
    'with' => 2,
    'a' => 1,
    '' => 1,
    'shrank' => 1,
    'is' => 1,
    'now.' => 1,
    'through' => 1,
    'of' => 2,
    'at' => 1,
    'if' => 1,
  ),
  'really.' => 
  array (
    'Thereafter,' => 1,
    '-' => 1,
    'My' => 1,
    'But' => 1,
  ),
  'Thereafter,' => 
  array (
    'staggering' => 1,
  ),
  'staggering' => 
  array (
    'semi-paralytic' => 1,
    'coincidence' => 1,
    '' => 1,
  ),
  'semi-paralytic' => 
  array (
    'down' => 1,
  ),
  'streets' => 
  array (
    'he' => 1,
    'exploded' => 1,
    'around' => 1,
    'looked' => 1,
  ),
  'passing' => 
  array (
    'policemen' => 1,
    'out.' => 1,
    'through' => 1,
    'spaceship' => 1,
    'maniac.' => 1,
  ),
  'policemen' => 
  array (
    'if' => 1,
    'would' => 1,
    'seemed' => 1,
  ),
  'Betelgeuse.' => 
  array (
    '' => 1,
    'The' => 2,
  ),
  'like:' => 
  array (
    '-' => 1,
  ),
  'sir?' => 
  array (
    '-' => 2,
    'Nice' => 1,
    '' => 1,
  ),
  'trying' => 
  array (
    'to' => 19,
    '' => 6,
    'all' => 1,
    'not' => 3,
    'very' => 1,
  ),
  'baby,' => 
  array (
    'I\'m' => 1,
    'we' => 1,
    'hold' => 1,
  ),
  'to,' => 
  array (
    '' => 1,
    'said' => 1,
    'I\'m' => 1,
    'no' => 1,
    'and' => 1,
  ),
  'invariably' => 
  array (
    'replied' => 1,
    'delivered' => 1,
  ),
  'replied' => 
  array (
    'on' => 1,
  ),
  'occasions.' => 
  array (
    'In' => 1,
  ),
  'really' => 
  array (
    '' => 10,
    'wasn\'t' => 1,
    'knows' => 1,
    'together' => 1,
    'amazingly' => 1,
    'isn\'t' => 1,
    'amazing,' => 1,
    'is' => 5,
    'particularly' => 1,
    'going' => 1,
    'just' => 1,
    'terrific.' => 1,
    'enjoy' => 1,
    'wish' => 1,
    'hot' => 1,
    'couldn\'t' => 1,
    'think' => 1,
    'terrific,' => 1,
    'poor' => 1,
    'thrash' => 1,
    'exciting,' => 1,
    'not' => 1,
    'weird' => 1,
  ),
  'distractedly' => 
  array (
    'into' => 1,
  ),
  'kind' => 
  array (
    'of' => 6,
    '' => 2,
    '-' => 2,
    'interest' => 1,
  ),
  'saucer' => 
  array (
    'at' => 2,
    'would' => 1,
  ),
  'all.' => 
  array (
    '' => 1,
    '-' => 5,
    'Only' => 1,
    'He' => 2,
    'Ford' => 1,
    'I' => 1,
    'What' => 1,
    'Then' => 1,
    'And' => 1,
    'How' => 1,
  ),
  'reason' => 
  array (
    'he' => 1,
    'was' => 1,
    'why' => 2,
    '' => 3,
    'for' => 1,
  ),
  'traditional' => 
  array (
    '' => 1,
  ),
  'space' => 
  array (
    '' => 7,
    'travel' => 1,
    'in' => 1,
    'very' => 1,
    'that' => 1,
    'like' => 1,
    'and' => 2,
    'to' => 3,
    'pirates' => 1,
    'suit' => 1,
  ),
  'livery' => 
  array (
    '' => 1,
  ),
  'trading' => 
  array (
    'scouts.' => 1,
    'scouts?' => 1,
    'scouts' => 1,
  ),
  'scouts.' => 
  array (
    'Ford' => 1,
  ),
  'Prefect' => 
  array (
    'was' => 4,
    '' => 3,
    'standing' => 1,
    'often' => 1,
    'usually' => 1,
    'knew' => 1,
    'to' => 1,
    'suddenly' => 1,
    'with' => 1,
    'said:' => 1,
    'had' => 1,
    'and' => 2,
    'after' => 1,
    'off' => 1,
  ),
  'desperate' => 
  array (
    'that' => 1,
    'fleeing' => 1,
    'attempt' => 1,
  ),
  'arrive' => 
  array (
    'soon' => 2,
    'at' => 1,
  ),
  'stranded' => 
  array (
    '' => 1,
  ),
  'anywhere,' => 
  array (
    'particularly' => 1,
  ),
  'somewhere' => 
  array (
    'as' => 1,
    '' => 3,
    'must' => 1,
    'to' => 1,
    'outside' => 1,
  ),
  'mindboggingly' => 
  array (
    'dull' => 1,
    'stupid' => 1,
    'beautiful.' => 1,
    'useful' => 1,
    'big' => 1,
  ),
  'dull' => 
  array (
    'as' => 1,
    '' => 3,
    'name,' => 1,
  ),
  'Earth.' => 
  array (
    'Ford' => 1,
    'If' => 1,
    'Motionless' => 1,
    '' => 1,
    '-' => 1,
    'Visions' => 1,
    'Prostetnic' => 1,
    'It\'s' => 1,
    'Phouchg' => 1,
    'She' => 1,
  ),
  'wished' => 
  array (
    'that' => 2,
    'there' => 1,
    'she' => 1,
    'he' => 2,
  ),
  'flag' => 
  array (
    'flying' => 1,
  ),
  'lifts' => 
  array (
    'from' => 1,
  ),
  'Marvels' => 
  array (
    'of' => 1,
  ),
  'Universe' => 
  array (
    'for' => 2,
    'jumped,' => 1,
    'can' => 1,
    '' => 5,
    'to' => 2,
    'of' => 2,
    'and' => 4,
    'has' => 1,
    'we' => 1,
    'say' => 1,
    'simply' => 1,
  ),
  'Altairan' => 
  array (
    '' => 1,
    'Dollars' => 1,
    'dollars' => 1,
  ),
  'dollars' => 
  array (
    '' => 1,
    'paid' => 1,
  ),
  'day.' => 
  array (
    'In' => 1,
    'What' => 1,
    'Ford' => 1,
    '-' => 2,
    'And' => 1,
    'A' => 1,
  ),
  'fact,' => 
  array (
    'Ford' => 1,
    'several' => 1,
    '-' => 2,
  ),
  'roving' => 
  array (
    '' => 1,
  ),
  'researcher' => 
  array (
    '' => 1,
    'on' => 1,
  ),
  'Galaxy.' => 
  array (
    'Human' => 1,
    'The' => 2,
    'It\'s' => 1,
    'It' => 1,
    'Out' => 1,
    'Zaphod' => 1,
    'Since' => 1,
  ),
  'Human' => 
  array (
    'beings' => 1,
  ),
  'beings' => 
  array (
    'are' => 1,
    'was' => 1,
    'don\'t' => 1,
    'after' => 1,
    'were' => 2,
    '' => 1,
    'murdering' => 1,
  ),
  'adaptors,' => 
  array (
    '' => 1,
  ),
  'lunchtime' => 
  array (
    '' => 1,
  ),
  'environs' => 
  array (
    'of' => 1,
  ),
  'Arthur\'s' => 
  array (
    'house' => 2,
    'accepted' => 1,
    'face.' => 1,
    '' => 1,
    'mind.' => 1,
    'eyes' => 2,
    'line' => 1,
    'brain' => 1,
    'mind' => 1,
    'yelp' => 1,
    'companion' => 1,
    'senses' => 1,
    'voice' => 1,
  ),
  'settled' => 
  array (
    '' => 5,
    'on' => 3,
    'over' => 1,
    'silently' => 1,
    'down' => 1,
    'into' => 1,
  ),
  'steady' => 
  array (
    '' => 2,
    'in' => 1,
    'as' => 1,
  ),
  'routine.' => 
  array (
    '' => 1,
  ),
  'accepted' => 
  array (
    'role' => 3,
    'as' => 1,
  ),
  'role' => 
  array (
    'to' => 2,
    '' => 1,
  ),
  'squelching' => 
  array (
    '' => 1,
  ),
  'occasional' => 
  array (
    'demands' => 1,
    'new' => 1,
    'pot' => 1,
  ),
  'demands' => 
  array (
    'to' => 1,
  ),
  'lawyer,' => 
  array (
    'his' => 1,
  ),
  'mother' => 
  array (
    'or' => 1,
    'told' => 1,
  ),
  'book;' => 
  array (
    'it' => 1,
  ),
  'tackle' => 
  array (
    'Arthur' => 1,
  ),
  'ploy' => 
  array (
    '' => 1,
  ),
  'such' => 
  array (
    '' => 4,
    'place.' => 1,
    'time' => 1,
    'a' => 5,
    'thing' => 1,
    'dizzying' => 1,
    'generators' => 1,
    'I' => 1,
    'infinite' => 1,
  ),
  'Public' => 
  array (
    'Good' => 1,
  ),
  'Good' => 
  array (
    'talk,' => 1,
    'grief,' => 1,
    'lad!' => 1,
    'god,' => 1,
    'luck' => 1,
    'afternoon' => 1,
    'lad.' => 1,
    'gracious' => 1,
    'morning,' => 2,
  ),
  'talk,' => 
  array (
    'the' => 2,
    '-' => 1,
  ),
  'March' => 
  array (
    'of' => 1,
  ),
  'Progress' => 
  array (
    'talk,' => 1,
  ),
  'Knocked' => 
  array (
    '' => 1,
  ),
  'My' => 
  array (
    'House' => 1,
    'God' => 1,
    'Armpit' => 1,
    'Favourite' => 1,
    'God,' => 1,
    'aunt' => 1,
    'white' => 1,
    'name' => 1,
    'name?' => 1,
    'name,' => 1,
    'brains!' => 1,
  ),
  'House' => 
  array (
    'Down' => 1,
  ),
  'Down' => 
  array (
    'Once' => 1,
  ),
  'Once' => 
  array (
    'You' => 1,
    'you' => 1,
  ),
  'Know,' => 
  array (
    '' => 1,
  ),
  'Never' => 
  array (
    '' => 1,
    'mind,' => 1,
    'again,' => 1,
  ),
  'Looked' => 
  array (
    '' => 1,
    'at' => 1,
  ),
  'Back' => 
  array (
    '' => 1,
    'Zaphod.' => 1,
  ),
  'talk' => 
  array (
    '' => 4,
    'to' => 6,
    'about' => 4,
    'when' => 1,
    'costs' => 1,
  ),
  'various' => 
  array (
    '' => 1,
    'parts' => 1,
  ),
  'cajoleries' => 
  array (
    'and' => 1,
  ),
  'threats;' => 
  array (
    'and' => 1,
  ),
  'drivers' => 
  array (
    'accepted' => 1,
    'about' => 1,
  ),
  'sit' => 
  array (
    'around' => 1,
    'either' => 1,
    'on.' => 1,
    '' => 2,
    'in' => 1,
    'coms?' => 1,
    'down' => 1,
    'yourself' => 1,
  ),
  'around' => 
  array (
    'drinking' => 1,
    '' => 7,
    'in.' => 2,
    'you' => 1,
    'him' => 2,
    'with' => 1,
    'the' => 5,
    'looking' => 1,
    'in' => 7,
    'it.' => 2,
    'this' => 1,
    'me,' => 1,
    'his' => 2,
    'you.' => 1,
    'them.' => 2,
    'mazes' => 1,
    'it' => 2,
    'again' => 1,
    'them' => 1,
    'and' => 1,
    'a' => 1,
    'gratuitously' => 1,
    'shooting' => 1,
  ),
  'coffee' => 
  array (
    'and' => 1,
    'cups' => 1,
  ),
  'experimenting' => 
  array (
    'with' => 1,
    'on' => 1,
  ),
  'union' => 
  array (
    'regulations' => 1,
    '' => 1,
  ),
  'regulations' => 
  array (
    'to' => 1,
  ),
  'turn' => 
  array (
    'the' => 2,
    'it' => 3,
    'out' => 1,
    'on' => 2,
    'up' => 1,
    'yet,' => 1,
  ),
  'situation' => 
  array (
    'to' => 1,
    'and' => 1,
    'should' => 1,
    'we' => 1,
  ),
  'financial' => 
  array (
    'advantage.' => 1,
  ),
  'advantage.' => 
  array (
    'The' => 1,
  ),
  'slowly' => 
  array (
    'in' => 2,
    'through' => 1,
    'down' => 1,
    'folded' => 1,
    'turned' => 1,
    'organizing' => 1,
    'over' => 2,
    '' => 3,
    'and' => 1,
    'but' => 1,
  ),
  'diurnal' => 
  array (
    'course.' => 1,
  ),
  'sun' => 
  array (
    'was' => 3,
    'and' => 1,
    '' => 1,
    'chair,' => 1,
    'at' => 1,
    'had' => 1,
  ),
  'beginning' => 
  array (
    'to' => 5,
    '' => 1,
  ),
  'dry' => 
  array (
    'out' => 1,
    'yourself' => 1,
    'lips.' => 1,
  ),
  'across' => 
  array (
    'him' => 1,
    'to' => 2,
    'the' => 19,
    '' => 6,
    'it.' => 1,
    'one' => 1,
    'it' => 2,
    'and' => 1,
    'almost' => 1,
    '-' => 1,
    'this' => 1,
  ),
  'Hello' => 
  array (
    'Arthur,' => 1,
    '' => 1,
  ),
  'shadow.' => 
  array (
    'Arthur' => 1,
  ),
  'squinting' => 
  array (
    'into' => 1,
  ),
  'startled' => 
  array (
    'to' => 2,
    'him' => 1,
    'me...' => 1,
    'me.' => 1,
  ),
  'standing' => 
  array (
    'above' => 1,
    '' => 1,
    'prism' => 1,
    'nearby' => 1,
    'behind' => 1,
    'hunched' => 1,
    'in' => 4,
    'on' => 3,
    'with' => 1,
    'and' => 1,
  ),
  'above' => 
  array (
    'him.' => 1,
    'the' => 4,
    'him' => 1,
    'a' => 1,
    'all' => 1,
    '' => 1,
  ),
  'Ford!' => 
  array (
    'Hello,' => 1,
    'Ford' => 1,
    '-' => 2,
  ),
  'Hello,' => 
  array (
    'how' => 1,
  ),
  'Fine,' => 
  array (
    '-' => 4,
  ),
  'Ford,' => 
  array (
    '-' => 42,
    '' => 8,
    'drowning' => 1,
    'stuffing' => 1,
    'with' => 1,
    'what' => 1,
    'brightly' => 1,
    'scrabbling' => 1,
    'who' => 1,
    'hi,' => 1,
    'at' => 1,
    'slumped' => 1,
    'Trillian' => 1,
    'rather' => 1,
    'and' => 1,
    'shaking' => 1,
  ),
  'busy?' => 
  array (
    '-' => 2,
  ),
  'Am' => 
  array (
    'I' => 1,
    'I?' => 1,
  ),
  'exclaimed' => 
  array (
    'Arthur.' => 1,
    'Ford,' => 1,
    'Ford.' => 2,
    'the' => 1,
    '' => 2,
    'an' => 1,
  ),
  'Well,' => 
  array (
    '' => 1,
    'if' => 2,
    '-' => 8,
    'what' => 2,
    'this' => 1,
    'I' => 4,
    'there' => 1,
    'did' => 1,
    'perhaps' => 1,
    'do' => 1,
    'you' => 3,
    'maybe' => 1,
    'even' => 1,
    'the' => 1,
    'goodbye' => 1,
    'eventually' => 1,
  ),
  'bulldozers' => 
  array (
    'and' => 1,
    'haven\'t' => 1,
    'crawling' => 1,
  ),
  'things' => 
  array (
    'to' => 2,
    'Ford' => 1,
    'they' => 1,
    'I\'ll' => 1,
    'were' => 1,
    'like' => 3,
    '' => 3,
    'you' => 2,
    'considered,' => 1,
    'human.' => 1,
    'if' => 1,
    'yet?' => 1,
    'are' => 2,
    'will' => 1,
    'with' => 1,
    'about' => 1,
    'together' => 1,
    'that' => 2,
    'of' => 1,
  ),
  'they\'ll' => 
  array (
    '' => 1,
    'always' => 1,
  ),
  'don\'t,' => 
  array (
    'but' => 1,
    '-' => 1,
  ),
  'that...' => 
  array (
    'well,' => 1,
    'Trillian' => 1,
    '-' => 1,
    'wind!' => 1,
  ),
  'especially,' => 
  array (
    'why?' => 1,
  ),
  'why?' => 
  array (
    'They' => 1,
    '-' => 4,
  ),
  'don\'t' => 
  array (
    'have' => 1,
    '' => 10,
    'want' => 5,
    'give' => 2,
    'you' => 4,
    'know,' => 7,
    'keep' => 2,
    'know' => 5,
    'need' => 1,
    'see' => 2,
    'move,' => 1,
    'we' => 1,
    'say' => 1,
    'get' => 2,
    'know.' => 4,
    'worry' => 2,
    'mind?' => 1,
    'talk' => 2,
    'think' => 2,
    'even' => 1,
    'care,' => 1,
    'mean' => 1,
    'like' => 1,
    'open' => 1,
    'demand!' => 1,
    'demand' => 1,
    'understand' => 2,
    'think,' => 1,
    'seem' => 1,
    'go' => 1,
    'believe' => 1,
  ),
  'sarcasm' => 
  array (
    'on' => 1,
  ),
  'Betelgeuse,' => 
  array (
    'and' => 3,
  ),
  'unless' => 
  array (
    'he' => 1,
    'you' => 1,
  ),
  'concentrating.' => 
  array (
    'He' => 1,
  ),
  'Good,' => 
  array (
    'is' => 1,
  ),
  'there' => 
  array (
    'anywhere' => 1,
    'won\'t' => 1,
    'didn\'t' => 1,
    'anything' => 1,
    'was' => 11,
    'were' => 2,
    'had' => 1,
    'and' => 2,
    'we' => 1,
    'in' => 4,
    'to' => 3,
    'would' => 1,
    'are' => 2,
    'aren\'t' => 1,
    'is' => 2,
    'any' => 2,
    'anything,' => 1,
    'for' => 3,
    'seemed' => 1,
    'a' => 1,
    '' => 5,
    'at' => 1,
    'now.' => 1,
    'it' => 1,
    'could' => 1,
    'must' => 1,
    'may' => 1,
    'you' => 1,
    'seconds' => 1,
    'comes' => 1,
    'right' => 1,
  ),
  'we' => 
  array (
    'can' => 5,
    '' => 21,
    'for' => 1,
    'also' => 1,
    'know' => 1,
    'trust' => 1,
    'known' => 1,
    'were,' => 2,
    'get' => 4,
    'are.' => 1,
    'have' => 10,
    'are' => 11,
    'will' => 4,
    'all,' => 1,
    'in?' => 1,
    'must' => 3,
    'seem' => 1,
    'stop' => 1,
    'were' => 4,
    'drop' => 1,
    'picked' => 2,
    'work' => 1,
    'pick' => 1,
    'go' => 2,
    'use' => 1,
    'just' => 2,
    'should' => 1,
    'do?' => 1,
    'thank' => 1,
    'would' => 2,
    'extend' => 1,
    'take?' => 1,
    'knew' => 1,
    'taking' => 1,
    'might' => 1,
    'go.' => 1,
    'heard' => 1,
    'weren\'t' => 1,
    'built' => 1,
    'programmed' => 1,
    'go?' => 1,
    'make' => 1,
    'talking' => 1,
    'demand' => 2,
    'don\'t!' => 1,
    'don\'t' => 1,
    'may' => 1,
    'are,' => 1,
    'want' => 4,
    'never' => 1,
    'tried' => 1,
    'discovered' => 1,
    'wake' => 1,
    'met' => 1,
    'had' => 1,
    'know...' => 1,
    'won\'t' => 1,
    'already' => 1,
    'still' => 1,
    'noticed' => 1,
    'would,' => 1,
    'shoot' => 1,
    'eat?' => 2,
  ),
  'can' => 
  array (
    'talk?' => 1,
    'do' => 6,
    'come' => 1,
    'we' => 4,
    'always' => 1,
    'expect' => 1,
    'mix' => 1,
    'have.' => 1,
    'wrap' => 1,
    'lie' => 1,
    'sleep' => 1,
    'wave' => 1,
    'hitch' => 1,
    '' => 13,
    'I' => 1,
    'understand' => 2,
    'instantly' => 1,
    'anyone' => 1,
    'shut' => 1,
    'tell.' => 1,
    'last' => 1,
    'survive' => 1,
    'stand' => 1,
    'you' => 5,
    'be' => 3,
    'tell' => 2,
    'imagine.' => 1,
    'even' => 1,
    'I...' => 1,
    'you?' => 2,
    'call' => 1,
    'find' => 1,
    'can' => 1,
    'really' => 1,
    'see' => 1,
    'best' => 1,
    'only' => 1,
    'count' => 1,
    'calculate' => 2,
    'navigate' => 1,
    'keep' => 1,
    'experience' => 1,
    'cater' => 1,
    'begin' => 1,
    'sense' => 1,
  ),
  'talk?' => 
  array (
    '-' => 2,
  ),
  'What?' => 
  array (
    '-' => 13,
    'Harmless?' => 1,
    'Where?' => 1,
    'You' => 1,
    'Oh...' => 1,
    'and' => 1,
  ),
  'few' => 
  array (
    'seconds' => 4,
    'nervous' => 1,
    'biros,' => 1,
    'things' => 2,
    'people' => 3,
    'reptiloid' => 1,
    'moments' => 2,
    'short' => 1,
    'months\'' => 1,
    'have' => 1,
    'sums,' => 1,
    'hard' => 1,
    'seconds,' => 2,
    'more' => 2,
    'of' => 1,
    '' => 5,
    'synapses' => 1,
    'minutes' => 1,
    'buttons' => 1,
    'years.' => 1,
    'stars,' => 1,
    'yards' => 1,
    'thousand' => 1,
    'remaining' => 1,
    'seconds.' => 1,
  ),
  'ignore' => 
  array (
    'him,' => 1,
    'it,' => 1,
    'me' => 1,
  ),
  'fixedly' => 
  array (
    '' => 1,
  ),
  'rabbit' => 
  array (
    'trying' => 1,
  ),
  'run' => 
  array (
    'over' => 1,
    '' => 2,
    'as' => 1,
    'the' => 1,
    'for' => 2,
    'and' => 1,
    'through' => 1,
    'by' => 2,
    'around' => 1,
  ),
  'car.' => 
  array (
    '' => 1,
  ),
  'squatted' => 
  array (
    'down' => 1,
  ),
  'beside' => 
  array (
    'Arthur.' => 1,
    'his' => 1,
    'him' => 2,
    'him.' => 1,
  ),
  'We\'ve' => 
  array (
    'got' => 2,
    'been' => 2,
    'arrived' => 1,
    'met,' => 2,
  ),
  'urgently.' => 
  array (
    '-' => 2,
  ),
  'talk.' => 
  array (
    '-' => 1,
  ),
  'drink,' => 
  array (
    '-' => 1,
  ),
  'Ford.' => 
  array (
    '-' => 50,
    'He' => 6,
    'I' => 1,
    'There' => 1,
    'A' => 2,
    'Arthur' => 2,
    '' => 4,
    'Even' => 1,
    'Zaphod' => 3,
    'With' => 1,
    'No' => 1,
  ),
  'vitally' => 
  array (
    'important' => 2,
  ),
  'drink.' => 
  array (
    'Now.' => 1,
    'Ford' => 1,
    'Chapter' => 1,
    'Sprinkle' => 1,
  ),
  'Now.' => 
  array (
    'We\'ll' => 1,
    'Arthur' => 1,
    'Ask' => 1,
  ),
  'We\'ll' => 
  array (
    'go' => 2,
    'do' => 1,
    'take' => 1,
  ),
  'again,' => 
  array (
    'nervous,' => 1,
    'desperate' => 1,
    'muttering' => 1,
    '' => 3,
    'then' => 1,
    'but' => 1,
    'and' => 2,
    'who' => 1,
    '-' => 3,
    'Arthur' => 1,
    'as' => 1,
  ),
  'nervous,' => 
  array (
    'expectant.' => 1,
  ),
  'expectant.' => 
  array (
    '-' => 1,
  ),
  'Look,' => 
  array (
    'don\'t' => 1,
    'what\'s' => 1,
    '-' => 5,
    'I' => 3,
    'what' => 1,
    'sorry' => 1,
    'alright,' => 1,
    'I\'m' => 1,
  ),
  'understand?' => 
  array (
    '' => 1,
  ),
  'shouted' => 
  array (
    '' => 4,
    'Arthur.' => 7,
    'at' => 1,
    'Ford.' => 5,
    'the' => 8,
    'to' => 2,
    'Zaphod.' => 2,
    'Trillian.' => 1,
    'Eddie' => 1,
    'Vroomfondel,' => 1,
    'and' => 1,
    'Arthur,' => 1,
    'Zaphod' => 1,
    'out,' => 1,
    'one' => 1,
    'Back' => 1,
  ),
  'pointed' => 
  array (
    '' => 1,
    'at' => 1,
    'down' => 1,
  ),
  'Prosser.' => 
  array (
    '-' => 3,
  ),
  'That' => 
  array (
    'man' => 1,
    'sounds' => 1,
    'is' => 4,
    'really' => 1,
    'About' => 1,
    '' => 3,
    'feels' => 1,
    'will' => 1,
    'ship?' => 1,
    'night,' => 1,
  ),
  'wants' => 
  array (
    'to' => 3,
  ),
  'down!' => 
  array (
    'Ford' => 1,
  ),
  'glanced' => 
  array (
    'at' => 4,
    'round' => 2,
    'up' => 1,
    '' => 2,
    'in' => 1,
    'across' => 1,
    'impatiently' => 1,
    'around' => 2,
    'about' => 1,
  ),
  'puzzled.' => 
  array (
    '-' => 1,
  ),
  'Well' => 
  array (
    'he' => 1,
    'no,' => 1,
    'you' => 1,
    'That' => 1,
    'for' => 1,
    'done,' => 1,
    'I' => 5,
    'the' => 1,
    'didn\'t' => 1,
    'what?' => 1,
    'well' => 1,
    'alright,' => 1,
    'we' => 1,
    '' => 1,
    'yes,' => 1,
    'that\'s' => 1,
    'perhaps' => 1,
    'surely' => 1,
  ),
  'he?' => 
  array (
    '-' => 1,
  ),
  'asked.' => 
  array (
    '-' => 4,
    'More' => 1,
  ),
  'want' => 
  array (
    'him' => 2,
    'to' => 27,
    'me,' => 1,
    'them' => 2,
    'me' => 3,
    '' => 6,
    'you' => 3,
    'it.' => 1,
    'full' => 1,
    'to...' => 1,
    'this' => 1,
    'it' => 1,
  ),
  'to!' => 
  array (
    '-' => 1,
  ),
  'Ah.' => 
  array (
    '-' => 1,
    'It\'s' => 1,
    'They' => 1,
  ),
  'Ford?' => 
  array (
    '-' => 5,
  ),
  'Nothing.' => 
  array (
    'Nothing\'s' => 1,
    '-' => 2,
    'Then' => 1,
  ),
  'Nothing\'s' => 
  array (
    'the' => 1,
  ),
  'matter.' => 
  array (
    'Listen' => 1,
  ),
  'Listen' => 
  array (
    'to' => 1,
    'old' => 1,
  ),
  'you\'ve' => 
  array (
    'ever' => 1,
    'got' => 3,
    'had' => 1,
    '' => 2,
    'never' => 3,
    'probably' => 1,
    'stolen.' => 1,
    'met?' => 1,
    'been' => 1,
  ),
  'heard.' => 
  array (
    'I\'ve' => 1,
  ),
  'now,' => 
  array (
    '' => 2,
    'because' => 1,
    '-' => 6,
    'and' => 1,
  ),
  'saloon' => 
  array (
    'bar' => 1,
  ),
  'Horse' => 
  array (
    'and' => 3,
    '' => 1,
  ),
  'Groom.' => 
  array (
    '-' => 2,
  ),
  'Because' => 
  array (
    'you' => 1,
    'of' => 1,
    'Ford' => 1,
    'I' => 1,
    '' => 2,
    'the' => 1,
    'there' => 1,
  ),
  'need' => 
  array (
    'a' => 2,
    'him' => 2,
    'it.' => 1,
    'them' => 1,
    'to' => 4,
    'to.' => 1,
    'to,' => 1,
    '' => 2,
    'it' => 1,
    'the' => 1,
  ),
  'stiff' => 
  array (
    'drink.' => 1,
  ),
  'astonished' => 
  array (
    '' => 2,
    'to' => 1,
  ),
  'will' => 
  array (
    'was' => 1,
    'fly,' => 1,
    'lie,' => 1,
    'fry' => 1,
    'on' => 1,
    'there?' => 1,
    'stop' => 1,
    'take' => 4,
    'automatically' => 1,
    'then' => 1,
    'think' => 1,
    'you!' => 1,
    'jump' => 1,
    'carry' => 1,
    'no' => 1,
    'put' => 1,
    'stay' => 1,
    'rend' => 1,
    'open' => 1,
    '' => 4,
    'be' => 11,
    'not' => 2,
    'you?' => 1,
    'when' => 1,
    'you' => 3,
    'help.' => 1,
    'now' => 1,
    'result' => 1,
    'yet' => 1,
    'once' => 1,
    'help' => 1,
    'become' => 1,
    'speak' => 1,
    'that' => 1,
    'we' => 1,
    'finally' => 1,
    'hear,' => 1,
    'see' => 1,
    'sound' => 1,
  ),
  'weaken.' => 
  array (
    'He' => 1,
  ),
  'realize' => 
  array (
    'that' => 4,
    '' => 2,
    'what' => 1,
  ),
  'old' => 
  array (
    'drinking' => 1,
    'man.' => 7,
    'Praxibetel' => 1,
    '' => 5,
    'friend,' => 1,
    'man' => 14,
    'man,' => 10,
    'man\'s' => 2,
    'eyes.' => 2,
    'mate,' => 1,
    'and' => 1,
    'fashioned' => 1,
    'lads,' => 1,
  ),
  'game' => 
  array (
    'that' => 1,
    'was' => 1,
    'called' => 1,
    'would' => 1,
    'of' => 1,
    '' => 1,
  ),
  'learned' => 
  array (
    'to' => 3,
  ),
  'play' => 
  array (
    '' => 1,
    'this' => 1,
    'the' => 1,
    'it' => 1,
  ),
  'hyperspace' => 
  array (
    '' => 1,
    'for' => 1,
    'hadn\'t' => 1,
  ),
  'ports' => 
  array (
    'that' => 1,
  ),
  'served' => 
  array (
    'the' => 1,
  ),
  'madranite' => 
  array (
    'mining' => 1,
  ),
  'mining' => 
  array (
    'belts' => 1,
    'song:' => 1,
  ),
  'belts' => 
  array (
    'in' => 1,
    '' => 1,
  ),
  'star' => 
  array (
    'system' => 1,
    '' => 3,
    'system,' => 1,
    'Sol,' => 1,
    'Sol' => 1,
    'map' => 1,
    'systems' => 1,
    'atlas,' => 1,
    'in' => 1,
    'cruisers' => 1,
  ),
  'system' => 
  array (
    'of' => 2,
    '' => 3,
    'a' => 1,
    'broke' => 1,
    'will' => 1,
    'was' => 1,
  ),
  'Orion' => 
  array (
    'Beta.' => 1,
    'mining' => 1,
  ),
  'Beta.' => 
  array (
    'The' => 1,
  ),
  'unlike' => 
  array (
    'the' => 1,
    'tea.' => 1,
    '' => 1,
  ),
  'Indian' => 
  array (
    '' => 1,
  ),
  'Wrestling,' => 
  array (
    '' => 1,
  ),
  'played' => 
  array (
    'like' => 1,
    '' => 3,
    'to' => 1,
  ),
  'Two' => 
  array (
    'contestants' => 1,
    'hundred' => 1,
    '' => 1,
    'to' => 3,
    'in' => 1,
    'severely' => 1,
  ),
  'contestants' => 
  array (
    'would' => 2,
  ),
  'either' => 
  array (
    'side' => 1,
    'that' => 1,
    '' => 3,
    'to' => 1,
    'you' => 1,
  ),
  'side' => 
  array (
    'of' => 7,
    'effects' => 1,
    '' => 1,
  ),
  'table,' => 
  array (
    '' => 1,
    'and' => 1,
  ),
  'each' => 
  array (
    'of' => 1,
    'other?' => 1,
    '' => 4,
    'a' => 1,
    'other.' => 5,
    'other' => 5,
  ),
  'Between' => 
  array (
    'them' => 1,
  ),
  'placed' => 
  array (
    'a' => 1,
  ),
  'bottle' => 
  array (
    'of' => 2,
    'and' => 1,
    'would' => 1,
  ),
  'Janx' => 
  array (
    'Spirit' => 3,
    'Spirit").' => 1,
    'spirit' => 1,
    'Spirit,' => 1,
  ),
  'Spirit' => 
  array (
    '(as' => 1,
    'No,' => 1,
    'For' => 1,
  ),
  '(as' => 
  array (
    'immortalized' => 1,
    '' => 1,
  ),
  'immortalized' => 
  array (
    'in' => 1,
  ),
  'ancient' => 
  array (
    'Orion' => 1,
    'Praxibetel' => 1,
    'time,' => 1,
    'civilization' => 1,
    'automatic' => 1,
    'Magrathea!"' => 1,
    'philology,' => 1,
  ),
  'song:' => 
  array (
    'Oh' => 1,
  ),
  'give' => 
  array (
    'me' => 2,
    'him' => 1,
    'a' => 1,
    'it' => 3,
    'you' => 3,
    'up' => 1,
    'our' => 1,
    'us' => 1,
    'Deep' => 1,
    '' => 2,
  ),
  'none' => 
  array (
    'more' => 2,
    'of' => 2,
    'at' => 1,
    'other' => 2,
    'I\'m' => 1,
    'but' => 1,
  ),
  'Old' => 
  array (
    'Janx' => 3,
  ),
  'No,' => 
  array (
    'don\'t' => 4,
    'no' => 2,
    'no,' => 3,
    'not' => 1,
    'nothing,' => 1,
    '-' => 10,
    'those' => 1,
    'well' => 1,
    'I' => 4,
    'nor' => 1,
    'the' => 1,
    'but' => 1,
    'what?' => 1,
    'of' => 1,
    'we\'re' => 1,
    'can' => 1,
    'wait...' => 1,
    '' => 1,
    'look' => 1,
    'wait' => 1,
  ),
  'head' => 
  array (
    'will' => 1,
    'sink' => 1,
    '-' => 1,
    'to' => 2,
    'or' => 1,
    'and' => 3,
    '' => 5,
    'hanging' => 1,
    'swung' => 1,
    'screamed' => 1,
    'with' => 3,
    'seemed' => 1,
    'looked' => 1,
    'on.' => 1,
    'up' => 2,
    'on' => 1,
    'sharply' => 1,
    'cut' => 1,
  ),
  'fly,' => 
  array (
    'my' => 1,
  ),
  'tongue' => 
  array (
    'will' => 1,
    'in' => 1,
    '' => 2,
  ),
  'lie,' => 
  array (
    'my' => 1,
  ),
  'fry' => 
  array (
    'and' => 1,
    'again,' => 1,
  ),
  'may' => 
  array (
    'die' => 1,
    'think' => 1,
    'have' => 1,
    'personally' => 1,
    'safely' => 1,
    'disturb' => 1,
    'interest' => 1,
    'function.' => 1,
    'or' => 3,
    'not' => 3,
    '' => 1,
    'go.' => 1,
  ),
  'die' => 
  array (
    'Won\'t' => 1,
    'down,' => 1,
    'in' => 1,
    'now!' => 1,
    '' => 1,
    'of' => 1,
    'as' => 1,
    'aren\'t' => 1,
  ),
  'Won\'t' => 
  array (
    'you' => 1,
  ),
  'pour' => 
  array (
    'me' => 1,
    '' => 1,
    'into' => 1,
  ),
  'sinful' => 
  array (
    'Old' => 1,
  ),
  'Spirit").' => 
  array (
    'Each' => 1,
  ),
  'Each' => 
  array (
    'of' => 1,
  ),
  'concentrate' => 
  array (
    'their' => 1,
  ),
  'attempt' => 
  array (
    'to' => 6,
  ),
  'tip' => 
  array (
    'it' => 1,
  ),
  'spirit' => 
  array (
    '' => 1,
    'is' => 1,
    'of' => 1,
  ),
  'opponent' => 
  array (
    '-' => 1,
  ),
  'refilled.' => 
  array (
    'The' => 1,
  ),
  'started' => 
  array (
    'to' => 6,
    'pulling' => 1,
    'yet.' => 1,
    'winking' => 1,
    'Ford' => 2,
    '' => 2,
    'back' => 1,
    'his' => 1,
    'from' => 1,
    'Arthur,' => 1,
    'after' => 1,
  ),
  'lose' => 
  array (
    'you' => 1,
  ),
  'keep' => 
  array (
    'losing,' => 1,
    'the' => 1,
    '' => 5,
    'exercising' => 1,
    'on' => 1,
    'it' => 1,
    'washing' => 1,
    'your' => 1,
    'listening' => 1,
    'quiet.' => 1,
    'cool,' => 1,
    'this' => 1,
    'going' => 1,
    'us' => 2,
    'disagreeing' => 1,
    'yourself' => 2,
  ),
  'losing,' => 
  array (
    'because' => 1,
  ),
  'effects' => 
  array (
    'of' => 2,
    '' => 1,
  ),
  'depress' => 
  array (
    'telepsychic' => 1,
  ),
  'telepsychic' => 
  array (
    'power.' => 1,
  ),
  'power.' => 
  array (
    'As' => 1,
    'On' => 1,
    '-' => 1,
  ),
  'As' => 
  array (
    'soon' => 3,
    'the' => 5,
    'you' => 2,
    'he' => 4,
    '' => 2,
    'it' => 1,
    'Ford' => 1,
    'a' => 1,
    'they' => 1,
    'with' => 1,
  ),
  'predetermined' => 
  array (
    'quantity' => 1,
  ),
  'quantity' => 
  array (
    '' => 1,
  ),
  'consumed,' => 
  array (
    '' => 1,
  ),
  'final' => 
  array (
    'loser' => 1,
    'and' => 1,
    'spasm' => 1,
  ),
  'loser' => 
  array (
    'would' => 1,
    'after' => 1,
  ),
  'perform' => 
  array (
    '' => 1,
    'just' => 1,
    'is' => 1,
  ),
  'forfeit,' => 
  array (
    '' => 1,
  ),
  'obscenely' => 
  array (
    'biological.' => 1,
  ),
  'biological.' => 
  array (
    'Ford' => 1,
  ),
  'lose.' => 
  array (
    'Ford' => 1,
  ),
  'perhaps' => 
  array (
    'he' => 1,
    'I' => 2,
    'we\'re' => 1,
    '' => 1,
    'you' => 1,
  ),
  'did' => 
  array (
    'want' => 1,
    '' => 5,
    'a' => 1,
    'the' => 2,
    'is' => 1,
    'without' => 1,
    'not' => 1,
    'we' => 3,
    'you' => 3,
    'she' => 1,
    'this,' => 1,
    'I' => 5,
    'I?' => 1,
    'turn' => 1,
    'at' => 2,
    'was...' => 1,
    'before' => 1,
    'that' => 1,
    'it.' => 1,
    'it' => 1,
    'he' => 3,
    'likewise.' => 1,
  ),
  'Groom' => 
  array (
    'after' => 1,
    '' => 1,
  ),
  'house?..' => 
  array (
    '-' => 1,
  ),
  'plaintively.' => 
  array (
    'Ford' => 1,
  ),
  'down?' => 
  array (
    '-' => 3,
    'Forty-two.' => 1,
  ),
  'build...' => 
  array (
    '-' => 1,
  ),
  'bulldozers?' => 
  array (
    '-' => 1,
  ),
  'and...' => 
  array (
    '-' => 2,
  ),
  'sure' => 
  array (
    'we' => 1,
    'that' => 1,
    'what' => 1,
    'you' => 2,
    'thing,' => 1,
  ),
  'arrangement,' => 
  array (
    '-' => 1,
  ),
  'Excuse' => 
  array (
    'me!' => 1,
    '' => 1,
    'me?' => 1,
    'me,' => 1,
  ),
  'me!' => 
  array (
    'he' => 1,
    'As' => 1,
    'Fook' => 1,
  ),
  'shouted.' => 
  array (
    'Mr.' => 1,
  ),
  '(who' => 
  array (
    'was' => 1,
  ),
  'arguing' => 
  array (
    '' => 2,
    'that' => 1,
  ),
  'spokesman' => 
  array (
    '' => 1,
  ),
  'whether' => 
  array (
    'or' => 1,
    'they' => 1,
    'Arthur\'s' => 1,
    '' => 1,
  ),
  'constituted' => 
  array (
    '' => 1,
  ),
  'mental' => 
  array (
    '' => 3,
    'arithmetic,' => 1,
    'attitude' => 2,
    'wellbeing' => 1,
  ),
  'health' => 
  array (
    'hazard,' => 1,
    'hazard' => 1,
  ),
  'hazard,' => 
  array (
    'and' => 1,
  ),
  'paid' => 
  array (
    'if' => 1,
    'for' => 2,
    'yearly' => 1,
    '' => 1,
  ),
  'did)' => 
  array (
    'looked' => 1,
  ),
  'around.' => 
  array (
    'He' => 1,
    'The' => 1,
  ),
  'surprised' => 
  array (
    'and' => 1,
    'about' => 1,
    'eyebrow' => 1,
    'to' => 3,
    'looking' => 1,
    '' => 1,
  ),
  'alarmed' => 
  array (
    'to' => 1,
  ),
  'company.' => 
  array (
    '-' => 1,
  ),
  'called.' => 
  array (
    '-' => 1,
  ),
  'Has' => 
  array (
    'Mr.' => 1,
    'it,' => 1,
  ),
  'senses' => 
  array (
    'yet?' => 1,
    'bobbed' => 1,
  ),
  'yet?' => 
  array (
    '-' => 1,
    'No.' => 1,
  ),
  'Can' => 
  array (
    'we' => 5,
    'you' => 1,
  ),
  'assume' => 
  array (
    'that' => 3,
    'were' => 1,
  ),
  'hasn\'t?' => 
  array (
    '-' => 1,
  ),
  'Well?' => 
  array (
    '-' => 5,
    'Zaphod' => 1,
  ),
  'sighed' => 
  array (
    'Mr.' => 1,
    'and' => 1,
    'heavily' => 1,
  ),
  'assume,' => 
  array (
    '-' => 1,
    '' => 1,
  ),
  'he\'s' => 
  array (
    '' => 4,
    'doing' => 1,
  ),
  'staying' => 
  array (
    'here' => 1,
  ),
  'here' => 
  array (
    'all' => 2,
    'and' => 2,
    'in' => 2,
    'you' => 1,
    'how' => 1,
    'is' => 1,
    'we' => 2,
    'under' => 1,
    '' => 3,
    'for' => 1,
    'as' => 1,
    'have' => 1,
  ),
  'day?' => 
  array (
    '-' => 1,
  ),
  'So?' => 
  array (
    '-' => 1,
  ),
  'men' => 
  array (
    'are' => 1,
    '' => 3,
    'were' => 1,
    'of' => 1,
    'naturally' => 1,
    'wearing' => 1,
    'sat' => 1,
    'shivered' => 1,
    'had' => 1,
    'fidgeted.' => 1,
    'as' => 1,
    'collapsed' => 1,
    'who' => 2,
  ),
  'doing' => 
  array (
    'nothing?' => 1,
    'that' => 2,
    'in' => 2,
    'now,' => 1,
    'themselves.' => 1,
    'it.' => 1,
    '' => 2,
    'here?' => 2,
    'and' => 1,
    'it!' => 1,
    'it' => 2,
    'when' => 1,
    'there?' => 1,
    'very' => 1,
    'the' => 2,
    'it,' => 1,
    'fjords' => 1,
    'it?' => 1,
  ),
  'nothing?' => 
  array (
    '-' => 1,
  ),
  'Could' => 
  array (
    'be,' => 1,
    'you' => 1,
  ),
  'be,' => 
  array (
    'could' => 1,
    '-' => 2,
    'and' => 1,
    'wouldn\'t' => 1,
    '' => 2,
  ),
  'be...' => 
  array (
    '-' => 1,
  ),
  'resigned' => 
  array (
    'to' => 1,
    'shrug.' => 1,
  ),
  'anyway,' => 
  array (
    'you' => 1,
    '-' => 1,
  ),
  'patiently,' => 
  array (
    '-' => 2,
  ),
  'here.' => 
  array (
    'Mr.' => 1,
    'Hey' => 1,
    '-' => 1,
    '' => 1,
  ),
  'no,' => 
  array (
    'not' => 1,
    '-' => 5,
    '' => 2,
    'it' => 1,
    'we' => 1,
    'good' => 1,
    'I' => 1,
    'too' => 1,
  ),
  'such...' => 
  array (
    '-' => 1,
  ),
  'need...' => 
  array (
    '-' => 1,
  ),
  'worried.' => 
  array (
    'He' => 1,
    '-' => 2,
  ),
  'sense.' => 
  array (
    'Ford' => 1,
    'Part' => 1,
  ),
  'read' => 
  array (
    '' => 1,
    'the' => 1,
    'poetry' => 1,
    'you' => 1,
    'us' => 1,
    '-' => 2,
    'this,' => 1,
    'his' => 1,
    'them' => 1,
  ),
  'here,' => 
  array (
    'then' => 1,
    'and' => 1,
    '-' => 1,
    'guy,' => 1,
    'I' => 1,
  ),
  'slip' => 
  array (
    'off' => 1,
  ),
  'half' => 
  array (
    'an' => 2,
    'crazed' => 1,
    'or' => 1,
    'the' => 3,
    'of' => 2,
    'million' => 5,
    'millions' => 1,
    'completed' => 1,
  ),
  'hour.' => 
  array (
    '' => 1,
    'He' => 1,
  ),
  'does' => 
  array (
    'that' => 2,
    'it' => 4,
    'the' => 1,
    'anyone' => 1,
    'not' => 1,
    'sound' => 1,
  ),
  'sound?' => 
  array (
    'Mr.' => 1,
    'The' => 1,
  ),
  'sounded' => 
  array (
    'perfectly' => 1,
    'like' => 2,
    'quite' => 1,
    '' => 1,
  ),
  'perfectly' => 
  array (
    'potty.' => 1,
    'reasonable,' => 1,
    'factually:' => 1,
    '' => 6,
    'still,' => 1,
    'well' => 2,
    'straightforward' => 1,
    'safe.' => 1,
    'save' => 1,
    'conventional' => 1,
    'clean' => 1,
    'oblong:' => 1,
    'well,' => 1,
    'natural' => 1,
    'flat.' => 1,
    'smooth' => 1,
  ),
  'potty.' => 
  array (
    '-' => 1,
  ),
  'sounds' => 
  array (
    'perfectly' => 1,
    'like' => 1,
    'of' => 2,
    'ghastly.' => 1,
    'awful.' => 1,
    'good,' => 1,
    'good?' => 2,
  ),
  'reasonable,' => 
  array (
    '-' => 1,
  ),
  'reassuring' => 
  array (
    'tone' => 1,
  ),
  'tone' => 
  array (
    'of' => 2,
  ),
  'voice,' => 
  array (
    'wondering' => 1,
    'but' => 1,
    '-' => 4,
    'right?' => 1,
  ),
  'reassure.' => 
  array (
    '-' => 1,
  ),
  'pop' => 
  array (
    'off' => 1,
    'out' => 1,
  ),
  'quick' => 
  array (
    'one' => 1,
    'tight' => 1,
    'encore' => 1,
    'change' => 1,
    '' => 2,
    'holiday,' => 1,
    'examination' => 1,
    'bite' => 1,
  ),
  'yourself' => 
  array (
    '' => 2,
    'off' => 1,
    'as' => 1,
    'and' => 1,
    'on' => 2,
    'down' => 1,
    'up' => 1,
    'occupied.' => 1,
  ),
  'on,' => 
  array (
    '' => 4,
    '-' => 8,
    'I' => 1,
    'walk' => 1,
    'with' => 1,
    'I\'ve' => 1,
    'wake' => 1,
  ),
  'cover' => 
  array (
    'up' => 1,
    'it' => 1,
  ),
  'return.' => 
  array (
    '-' => 1,
  ),
  'Thank' => 
  array (
    'you' => 3,
    'God' => 1,
    'you.' => 2,
    '' => 2,
    'you,' => 2,
  ),
  'much,' => 
  array (
    '-' => 1,
    'yes,' => 1,
  ),
  'longer' => 
  array (
    'knew' => 1,
    '' => 2,
    'existed.' => 1,
    'any' => 1,
    'it' => 1,
    'Zaphod,' => 1,
    'be' => 1,
  ),
  'thank' => 
  array (
    'you' => 3,
    '' => 2,
    'you...' => 1,
    'our' => 1,
    'you.' => 1,
    'you,' => 1,
  ),
  'that\'s' => 
  array (
    '' => 4,
    'your' => 1,
    'what' => 3,
    'more' => 1,
    'my' => 1,
    'how' => 1,
    'left' => 1,
    'not' => 1,
    'a' => 2,
    'incredible.' => 1,
    'just' => 3,
    'nowhere.' => 1,
    'one' => 1,
    'being' => 1,
    'best' => 1,
    'where' => 1,
    'for' => 1,
    'the' => 1,
    'bureaucracy' => 1,
    'his' => 1,
    'crazy!' => 1,
  ),
  'kind...' => 
  array (
    '' => 1,
  ),
  'frowned,' => 
  array (
    'then' => 1,
  ),
  'smiled,' => 
  array (
    'then' => 1,
    'picturing' => 1,
  ),
  'both' => 
  array (
    'at' => 1,
    'fathered' => 1,
    '' => 1,
    'protesting' => 1,
    'shoved' => 1,
    'going' => 1,
    'sat' => 1,
    'my' => 1,
    'brains' => 1,
    'the' => 2,
    'licked' => 1,
    'looked' => 1,
  ),
  'once,' => 
  array (
    'failed,' => 1,
  ),
  'failed,' => 
  array (
    'grasped' => 1,
  ),
  'grasped' => 
  array (
    '' => 2,
  ),
  'hold' => 
  array (
    'of' => 3,
    '' => 1,
    'a' => 1,
    'it' => 2,
    'your' => 1,
    'these,' => 1,
    'tight,' => 1,
  ),
  'rolled' => 
  array (
    'it' => 1,
    '' => 1,
    'off' => 1,
    'down' => 1,
    'his' => 1,
    'over' => 2,
    'on.' => 1,
    'away' => 1,
    'the' => 1,
  ),
  'fitfully' => 
  array (
    'round' => 1,
  ),
  'head.' => 
  array (
    'He' => 2,
    'The' => 1,
    'She' => 1,
    'Still' => 1,
    'One' => 1,
  ),
  'won.' => 
  array (
    '-' => 1,
  ),
  'So,' => 
  array (
    '-' => 1,
  ),
  'continued' => 
  array (
    'Ford' => 1,
    '' => 2,
    'to' => 3,
    'Arthur,' => 1,
    'Ford,' => 1,
    'as' => 1,
    'Marvin,' => 1,
    'Marvin.' => 1,
    'Zaphod' => 1,
    'Ford.' => 1,
    'the' => 1,
    'on' => 1,
    'Eddie\'s' => 1,
    'his' => 1,
    'for' => 1,
  ),
  'Prefect,' => 
  array (
    '-' => 2,
    'and' => 1,
    'wrenching' => 1,
  ),
  'down...' => 
  array (
    '-' => 1,
  ),
  'myself' => 
  array (
    '' => 3,
    'to' => 1,
    'as' => 2,
    'into' => 1,
    'further' => 1,
    'in' => 1,
  ),
  'fully' => 
  array (
    'clear.' => 1,
    'armed' => 1,
    'corrected' => 1,
  ),
  'clear.' => 
  array (
    'Somebody\'s' => 1,
  ),
  'Somebody\'s' => 
  array (
    'got' => 1,
  ),
  'they?' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'Or' => 
  array (
    'there' => 1,
    '' => 2,
    'do' => 1,
    'whatever,' => 1,
    'something...' => 1,
    'is' => 1,
    'why?' => 1,
    'the' => 1,
    'the...' => 1,
  ),
  'won\'t' => 
  array (
    'be' => 3,
    'believe' => 1,
    'work,' => 1,
    'enjoy' => 1,
    '' => 1,
  ),
  'anything' => 
  array (
    'to' => 2,
    'wrong' => 1,
    'we' => 1,
    'but' => 2,
    '' => 6,
    'it' => 1,
    'said' => 1,
    'else' => 2,
    'that' => 1,
    'about' => 2,
    'about...' => 1,
    'in' => 1,
    'further' => 1,
    'you' => 1,
    'important.' => 1,
    'he' => 2,
    'more' => 1,
    'vitriolic' => 1,
    'could' => 1,
    'as' => 1,
    'like' => 1,
  ),
  'stop' => 
  array (
    'them' => 1,
    'lying' => 1,
    'smiling' => 1,
    'will' => 1,
    'saying' => 2,
    'whatever' => 1,
    '' => 2,
    'panicking.' => 1,
    'doing' => 1,
    'to' => 1,
    'sulking' => 1,
    'and' => 1,
    'thinking' => 1,
    'him.' => 1,
    'talking,' => 1,
  ),
  'driving' => 
  array (
    'into' => 1,
    'cars' => 1,
    '' => 1,
  ),
  'there?' => 
  array (
    '-' => 7,
    'I' => 1,
  ),
  'simple,' => 
  array (
    '-' => 1,
  ),
  'client,' => 
  array (
    'Mr.' => 1,
  ),
  'says' => 
  array (
    'that' => 4,
    '' => 2,
    'Man,' => 2,
    'God,' => 1,
    'in' => 1,
    'Genuine' => 1,
    'Hey' => 1,
  ),
  'sole' => 
  array (
    'condition' => 1,
  ),
  'condition' => 
  array (
    'that' => 1,
  ),
  'talking' => 
  array (
    'about?' => 2,
    'about' => 3,
    '' => 1,
    'to' => 2,
    'again.' => 1,
  ),
  'about?' => 
  array (
    '-' => 3,
  ),
  'nudged' => 
  array (
    'him' => 1,
  ),
  'shoe' => 
  array (
    'to' => 1,
    'sessions' => 1,
  ),
  'quiet.' => 
  array (
    '-' => 2,
    'He' => 1,
  ),
  'me,' => 
  array (
    '-' => 11,
    '' => 4,
    'who' => 1,
    'intoned' => 1,
    'I' => 1,
  ),
  'spelling' => 
  array (
    'out' => 1,
  ),
  'himself,' => 
  array (
    '-' => 4,
    'sinking' => 1,
    'and' => 1,
    'lightly' => 1,
    '' => 1,
    'such' => 1,
    'at' => 1,
  ),
  'there...' => 
  array (
    '-' => 1,
  ),
  'Yes.' => 
  array (
    '-' => 7,
    'It' => 1,
    'This' => 1,
    'We\'re' => 1,
    'Five' => 1,
    'I' => 1,
    'Both' => 1,
  ),
  'bulldozer?' => 
  array (
    '-' => 1,
  ),
  'Instead' => 
  array (
    'of' => 1,
  ),
  'In,' => 
  array (
    'as' => 1,
  ),
  'substantially' => 
  array (
    '' => 1,
  ),
  'lifted' => 
  array (
    'itself' => 1,
    'his' => 1,
    '' => 1,
    'themselves' => 1,
  ),
  'shoulders:' => 
  array (
    'this' => 1,
  ),
  'sighed.' => 
  array (
    '-' => 1,
  ),
  'return' => 
  array (
    'for' => 1,
  ),
  'pub?' => 
  array (
    '-' => 1,
  ),
  'exactly.' => 
  array (
    'Mr.' => 1,
  ),
  'steps' => 
  array (
    'forward' => 1,
  ),
  'forward' => 
  array (
    'and' => 3,
    'through' => 1,
    'to' => 2,
    'to,' => 1,
    'straight' => 1,
    'into' => 1,
    'again.' => 1,
    '' => 2,
    'slightly.' => 1,
  ),
  'stopped.' => 
  array (
    '-' => 1,
    'Arthur' => 1,
  ),
  'Promise?' => 
  array (
    '-' => 1,
  ),
  'Promise,' => 
  array (
    '-' => 1,
  ),
  'turned' => 
  array (
    'to' => 1,
    '' => 4,
    'itself' => 1,
    'on' => 3,
    'slowly' => 1,
    'speech' => 1,
    'their' => 1,
    'aside' => 1,
    'it' => 4,
    'goggle-eyed' => 1,
    'inside' => 1,
    'and' => 5,
    'away.' => 1,
    'her' => 2,
    'hopelessly' => 1,
    'unfathomably' => 1,
    'into' => 1,
    'himself' => 1,
    'white.' => 1,
    'towards' => 1,
  ),
  'down.' => 
  array (
    'Arthur' => 1,
    'What' => 1,
    '-' => 1,
    'The' => 1,
  ),
  'feeling' => 
  array (
    'as' => 1,
    '' => 2,
    'quite' => 1,
    'very' => 1,
    'of' => 1,
    'just' => 1,
    'that' => 1,
  ),
  'dream.' => 
  array (
    'Ford' => 1,
  ),
  'beckoned' => 
  array (
    'to' => 1,
  ),
  'sadly,' => 
  array (
    'awkwardly,' => 1,
  ),
  'awkwardly,' => 
  array (
    'sat' => 1,
  ),
  'sat' => 
  array (
    'down' => 4,
    'on' => 4,
    'in' => 4,
    'and' => 1,
    'humped,' => 1,
    'hunched' => 1,
    'at' => 1,
    'there,' => 1,
    '' => 3,
    'respectfully' => 1,
  ),
  'felt' => 
  array (
    'that' => 1,
    'miserable' => 1,
    '' => 4,
    'he' => 4,
    'the' => 1,
    'his' => 2,
    'should' => 1,
    'it' => 1,
    'a' => 1,
    'awkward.' => 1,
    'extraordinarily' => 1,
    'an' => 1,
  ),
  'dream' => 
  array (
    '' => 1,
    'planets' => 1,
    'to' => 1,
  ),
  'sometimes' => 
  array (
    'wondered' => 1,
    'hard' => 1,
  ),
  'wondered' => 
  array (
    'whose' => 1,
    'if' => 1,
  ),
  'enjoying' => 
  array (
    'it.' => 1,
    '' => 1,
  ),
  'folded' => 
  array (
    'itself' => 1,
    '' => 1,
    'flat' => 1,
  ),
  'arms' => 
  array (
    'and' => 2,
    'lazily' => 2,
    'wrapped' => 1,
    'about.' => 1,
    'about' => 1,
  ),
  'oozed' => 
  array (
    'into' => 1,
  ),
  'shoes.' => 
  array (
    'Ford' => 1,
  ),
  'severely.' => 
  array (
    '-' => 1,
  ),
  'sneaky' => 
  array (
    'knocking' => 1,
  ),
  'knocking' => 
  array (
    'down' => 1,
    'my' => 1,
  ),
  'alright?' => 
  array (
    '-' => 1,
    '' => 1,
    'Ford' => 1,
  ),
  'mere' => 
  array (
    'thought,' => 1,
    '' => 2,
    'abacus' => 1,
    'kid.' => 1,
  ),
  'thought,' => 
  array (
    '-' => 4,
    'didn\'t' => 1,
    'he' => 1,
    'their' => 2,
    'has' => 1,
    'had' => 1,
    'valleys' => 1,
  ),
  'growled' => 
  array (
    'Mr.' => 1,
    'Trillian.' => 1,
  ),
  'begun' => 
  array (
    '' => 1,
  ),
  'speculate,' => 
  array (
    '-' => 1,
  ),
  'continued,' => 
  array (
    'settling' => 1,
    '-' => 3,
    '' => 1,
  ),
  'settling' => 
  array (
    '' => 1,
  ),
  'back,' => 
  array (
    '' => 1,
    'queried,' => 1,
    'hoiked' => 1,
    'raised' => 1,
  ),
  'merest' => 
  array (
    'possibility' => 1,
    'operational' => 2,
    '' => 1,
  ),
  'possibility' => 
  array (
    'of' => 1,
    'and' => 1,
    'I' => 1,
  ),
  'crossing' => 
  array (
    'my' => 1,
    'vast' => 1,
    '' => 1,
  ),
  'mind.' => 
  array (
    'He' => 1,
    '-' => 3,
    'His' => 1,
    'There' => 1,
    'England' => 1,
    '' => 1,
    'For' => 1,
  ),
  'driver\'s' => 
  array (
    'union' => 1,
  ),
  'representative' => 
  array (
    '' => 1,
  ),
  'approaching' => 
  array (
    '' => 1,
    'destruction.' => 1,
  ),
  'sink' => 
  array (
    'back' => 1,
    'downward' => 1,
    'into' => 1,
  ),
  'eyes.' => 
  array (
    'He' => 1,
    'With' => 1,
    '-' => 4,
    'Now' => 1,
  ),
  'marshal' => 
  array (
    '' => 1,
  ),
  'arguments' => 
  array (
    'for' => 1,
  ),
  'proving' => 
  array (
    'that' => 1,
  ),
  'now' => 
  array (
    '' => 13,
    'an' => 1,
    'seen' => 1,
    'virtually' => 1,
    'dead' => 1,
    'a' => 2,
    'be' => 1,
    'employ' => 1,
    'it' => 2,
    'six' => 1,
    'feeling' => 1,
    'the' => 1,
    'just' => 1,
    'you' => 1,
    'reached' => 1,
    'aren\'t' => 1,
    'all' => 2,
    'been' => 1,
    'cruising' => 1,
    'that' => 4,
    'of' => 1,
    'complete.' => 1,
    'on' => 2,
    'we' => 1,
    'traversing' => 1,
    'three' => 1,
    'stood' => 1,
    'serious' => 1,
    'covers' => 1,
    'was' => 1,
    'totally' => 1,
    'isn\'t' => 1,
    'landed.' => 1,
    'barren' => 1,
    'came' => 1,
    'very' => 1,
    'drifted' => 1,
    'made' => 1,
    'or' => 1,
    'our' => 1,
    'deep' => 1,
    'firmly' => 1,
    'irrevocably' => 1,
    'positively' => 1,
    'given' => 1,
    'and' => 1,
    'in' => 1,
  ),
  'constitute' => 
  array (
    '' => 1,
  ),
  'hazard' => 
  array (
    'himself.' => 1,
  ),
  'far' => 
  array (
    'from' => 1,
    'that' => 1,
    '' => 6,
    'and' => 1,
    'too' => 2,
    'said' => 1,
    'more' => 1,
    'it' => 1,
    'better' => 1,
    'as' => 1,
    'the' => 1,
    'rather' => 1,
    'far' => 1,
    'back' => 1,
  ),
  'certain' => 
  array (
    'about' => 1,
    'carbon-based' => 1,
    '' => 1,
    'death' => 1,
    'to' => 1,
  ),
  'full' => 
  array (
    'of' => 4,
    'title' => 1,
    '' => 6,
    'blast' => 1,
    'retro' => 1,
    'scale' => 1,
    'back-up' => 1,
  ),
  'noise,' => 
  array (
    'horses,' => 1,
  ),
  'horses,' => 
  array (
    '' => 1,
  ),
  'smoke,' => 
  array (
    '' => 1,
  ),
  'stench' => 
  array (
    '' => 1,
  ),
  'blood.' => 
  array (
    '' => 1,
  ),
  'miserable' => 
  array (
    'and' => 1,
    'planet' => 1,
    '' => 1,
  ),
  'upon,' => 
  array (
    'and' => 1,
  ),
  'able' => 
  array (
    'to' => 10,
    '' => 4,
    'satisfactorily' => 1,
  ),
  'high' => 
  array (
    'dimension' => 1,
    'above' => 2,
    'in' => 1,
    'art!' => 1,
  ),
  'dimension' => 
  array (
    'of' => 2,
  ),
  'nothing' => 
  array (
    'the' => 1,
    'happened.' => 4,
    '' => 6,
    'he' => 1,
    'you' => 2,
    'on' => 1,
    'was' => 1,
    'to' => 1,
    'would' => 1,
    'there.' => 1,
    'really...' => 1,
    'underneath' => 1,
    'about' => 1,
    'of' => 1,
    'for' => 1,
    'continued' => 1,
  ),
  'Khan' => 
  array (
    'bellowed' => 1,
  ),
  'bellowed' => 
  array (
    'with' => 1,
    'the' => 3,
  ),
  'rage,' => 
  array (
    'but' => 1,
  ),
  'trembled' => 
  array (
    'slightly' => 1,
  ),
  'whimpered.' => 
  array (
    'He' => 1,
  ),
  'fell' => 
  array (
    'little' => 1,
    'headlong,' => 1,
    'on' => 1,
    'silent' => 1,
    'out' => 3,
    '' => 2,
    'over.' => 1,
    'across' => 1,
  ),
  'pricks' => 
  array (
    'of' => 1,
  ),
  'behind' => 
  array (
    '' => 5,
    'it' => 1,
    'his' => 1,
    'in' => 1,
    'Arthur\'s' => 1,
    'him' => 1,
    'them' => 3,
    'a' => 1,
    'them.' => 2,
    'the' => 1,
    'them,' => 1,
    'him.' => 1,
  ),
  'eyelids.' => 
  array (
    'Bureaucratic' => 1,
  ),
  'Bureaucratic' => 
  array (
    '' => 1,
  ),
  'cock-ups,' => 
  array (
    '' => 1,
  ),
  'mud,' => 
  array (
    '' => 1,
  ),
  'indecipherable' => 
  array (
    'strangers' => 1,
  ),
  'strangers' => 
  array (
    'handing' => 1,
  ),
  'handing' => 
  array (
    'out' => 1,
  ),
  'humiliations' => 
  array (
    'and' => 1,
  ),
  'unidentified' => 
  array (
    '' => 1,
  ),
  'army' => 
  array (
    'of' => 1,
  ),
  'laughing' => 
  array (
    'at' => 1,
  ),
  'pair' => 
  array (
    'of' => 2,
  ),
  'dingo\'s' => 
  array (
    'kidneys' => 1,
    'kidneys,' => 1,
  ),
  'kidneys' => 
  array (
    'whether' => 1,
  ),
  'knocked' => 
  array (
    'down' => 1,
    '' => 2,
    'his' => 1,
  ),
  'now.' => 
  array (
    'Arthur' => 1,
    'His' => 1,
    'The' => 2,
    'He' => 2,
    '-' => 4,
    'Chapter' => 1,
    'It\'s' => 1,
    'No,' => 1,
  ),
  'remained' => 
  array (
    'very' => 1,
    'a' => 1,
    'desperately' => 1,
  ),
  'trust' => 
  array (
    'him?' => 1,
    'him' => 1,
    'that' => 1,
    'myself' => 1,
  ),
  'him?' => 
  array (
    '-' => 1,
  ),
  'Myself' => 
  array (
    'I\'d' => 1,
  ),
  'I\'d' => 
  array (
    'trust' => 1,
    'like' => 1,
    '' => 4,
    'have' => 3,
    'better' => 2,
    'think' => 1,
    'been' => 1,
    'got' => 1,
    'guessed' => 1,
    'given' => 1,
    'sort' => 1,
    'consciously' => 1,
    'far' => 1,
    'notice' => 1,
    'say' => 1,
  ),
  'far\'s' => 
  array (
    'that?' => 1,
  ),
  'that?' => 
  array (
    '-' => 15,
    'The' => 1,
    'Eddie,' => 1,
  ),
  'About' => 
  array (
    'twelve' => 1,
    'Wraps' => 1,
    '' => 1,
  ),
  'twelve' => 
  array (
    'minutes' => 1,
  ),
  'minutes' => 
  array (
    'away,' => 1,
    'left' => 1,
    'I' => 1,
    'are' => 1,
    'from' => 1,
    'later' => 2,
    'before' => 1,
    '' => 1,
    'late.' => 1,
  ),
  2 => 
  array (
    'Here\'s' => 1,
  ),
  'Here\'s' => 
  array (
    'what' => 1,
    'another' => 1,
    '' => 1,
    'a' => 1,
  ),
  'alcohol.' => 
  array (
    '' => 1,
    'It' => 1,
  ),
  'alcohol' => 
  array (
    '' => 1,
  ),
  'colourless' => 
  array (
    '' => 1,
  ),
  'volatile' => 
  array (
    '' => 1,
  ),
  'liquid' => 
  array (
    '' => 1,
    'that' => 2,
    'and' => 1,
  ),
  'formed' => 
  array (
    '' => 3,
    'a' => 1,
    'by' => 1,
    'part' => 1,
    'the' => 2,
  ),
  'fermentation' => 
  array (
    'of' => 1,
  ),
  'sugars' => 
  array (
    'and' => 1,
  ),
  'notes' => 
  array (
    'its' => 1,
  ),
  'intoxicating' => 
  array (
    'effect' => 1,
  ),
  'effect' => 
  array (
    '' => 2,
    'of' => 2,
    'it' => 1,
    'as' => 2,
    'that' => 1,
    'is' => 2,
  ),
  'forms.' => 
  array (
    'The' => 1,
    'And' => 1,
  ),
  'mentions' => 
  array (
    'alcohol.' => 1,
  ),
  'best' => 
  array (
    'drink' => 2,
    '' => 3,
    'at.' => 1,
    'way' => 1,
    'in' => 1,
    'ways' => 1,
    'be' => 1,
    'button' => 1,
  ),
  'existence' => 
  array (
    'is' => 1,
    'and' => 1,
    '' => 1,
    'of' => 1,
  ),
  'Pan' => 
  array (
    'Galactic' => 4,
    '' => 3,
  ),
  'Galactic' => 
  array (
    'Gargle' => 5,
    '' => 7,
    'Hyperspace' => 1,
    'Government,' => 2,
    'Government.' => 1,
    'President' => 2,
    'Civil' => 1,
    'Government\'s' => 1,
    'Institute\'s' => 1,
    'astrotechnology' => 1,
    'coordinates?' => 1,
    'Empire,' => 1,
    'Empire' => 1,
    'stock' => 1,
    'Centre' => 1,
  ),
  'Gargle' => 
  array (
    'Blaster.' => 1,
    '' => 2,
    'Blasters' => 2,
    'Blaster' => 1,
    'Blasters;' => 1,
  ),
  'Blaster.' => 
  array (
    'It' => 1,
  ),
  'Blaster' => 
  array (
    '' => 1,
    'in' => 1,
  ),
  'having' => 
  array (
    'your' => 1,
    'gone,' => 1,
    'his' => 1,
    '' => 3,
    'a' => 2,
    'it?' => 1,
    'tremendous' => 2,
    'felt' => 1,
    'you' => 1,
  ),
  'brains' => 
  array (
    'smashed' => 1,
    'start' => 1,
    'that' => 1,
    'must' => 1,
  ),
  'smashed' => 
  array (
    'out' => 1,
    '' => 1,
  ),
  'slice' => 
  array (
    'of' => 1,
  ),
  'lemon' => 
  array (
    'wrapped' => 1,
  ),
  'wrapped' => 
  array (
    'round' => 2,
    'up' => 1,
    'a' => 1,
    '' => 1,
  ),
  'gold' => 
  array (
    'brick.' => 1,
    '' => 1,
    'planets,' => 1,
    'ground' => 1,
    'does.' => 1,
  ),
  'brick.' => 
  array (
    'The' => 1,
  ),
  'tells' => 
  array (
    'you' => 3,
  ),
  'planets' => 
  array (
    '' => 3,
    'which' => 1,
    'with' => 1,
    'in' => 1,
    'inhabited' => 1,
    'are' => 1,
    'do' => 1,
    'you' => 1,
  ),
  'Blasters' => 
  array (
    'are' => 1,
    'with' => 1,
  ),
  'mixed,' => 
  array (
    'how' => 1,
  ),
  'expect' => 
  array (
    'to' => 1,
    '' => 2,
    'I' => 1,
  ),
  'pay' => 
  array (
    'for' => 1,
    'attention.' => 1,
  ),
  'voluntary' => 
  array (
    'organizations' => 1,
  ),
  'organizations' => 
  array (
    'exist' => 1,
  ),
  'exist' => 
  array (
    'to' => 1,
    '' => 1,
    'within' => 1,
  ),
  'help' => 
  array (
    'you' => 3,
    'improve' => 1,
    'him' => 1,
    'hitch' => 1,
    'what' => 1,
    'but' => 1,
    'him,' => 1,
  ),
  'rehabilitate' => 
  array (
    'afterwards.' => 1,
  ),
  'afterwards.' => 
  array (
    'The' => 1,
    '-' => 1,
  ),
  'mix' => 
  array (
    'one' => 1,
  ),
  'yourself.' => 
  array (
    'Take' => 1,
    'We' => 1,
  ),
  'Take' => 
  array (
    'the' => 1,
    '' => 1,
  ),
  'juice' => 
  array (
    'from' => 1,
  ),
  'Ol\'' => 
  array (
    'Janx' => 1,
  ),
  'Spirit,' => 
  array (
    'it' => 1,
  ),
  'says.' => 
  array (
    'Pour' => 1,
    'Oh' => 1,
  ),
  'Pour' => 
  array (
    'into' => 1,
  ),
  'measure' => 
  array (
    'of' => 1,
    '' => 1,
  ),
  'seas' => 
  array (
    'of' => 2,
    '' => 2,
  ),
  'Santraginus' => 
  array (
    'V' => 1,
    'V,' => 1,
  ),
  'V' => 
  array (
    '-' => 1,
  ),
  'Santraginean' => 
  array (
    'sea' => 1,
    'fish!!!' => 1,
  ),
  'sea' => 
  array (
    'water,' => 1,
    'vapours;' => 1,
    'that' => 1,
    'in' => 1,
    'which' => 1,
    'hundreds' => 1,
    'some' => 1,
    'of' => 1,
    'depths' => 1,
    '' => 3,
    'was' => 2,
  ),
  'fish!!!' => 
  array (
    'Allow' => 1,
  ),
  'Allow' => 
  array (
    'three' => 1,
    'four' => 1,
  ),
  'cubes' => 
  array (
    'of' => 1,
  ),
  'Arcturan' => 
  array (
    'Mega-gin' => 1,
    'MegaDonkey' => 1,
    'captain.' => 1,
    'megafreighters' => 1,
    '' => 1,
  ),
  'Mega-gin' => 
  array (
    'to' => 1,
  ),
  'melt' => 
  array (
    'into' => 1,
  ),
  'mixture' => 
  array (
    '' => 2,
  ),
  '(it' => 
  array (
    'must' => 1,
  ),
  'iced' => 
  array (
    'or' => 1,
  ),
  'benzine' => 
  array (
    'is' => 1,
  ),
  'lost).' => 
  array (
    'Allow' => 1,
  ),
  'litres' => 
  array (
    'of' => 1,
  ),
  'Fallian' => 
  array (
    'marsh' => 1,
  ),
  'marsh' => 
  array (
    '' => 1,
  ),
  'gas' => 
  array (
    '' => 1,
    'started' => 1,
  ),
  'bubble' => 
  array (
    '' => 1,
    'surged' => 1,
  ),
  'memory' => 
  array (
    'of' => 1,
    '' => 2,
    'for' => 1,
  ),
  'Hikers' => 
  array (
    'who' => 1,
  ),
  'died' => 
  array (
    'of' => 4,
    'away.' => 2,
    'out' => 1,
    'would' => 1,
    'he' => 1,
  ),
  'pleasure' => 
  array (
    'in' => 1,
    'to' => 1,
    'feller,' => 1,
  ),
  'Marshes' => 
  array (
    'of' => 1,
  ),
  'Fallia.' => 
  array (
    'Over' => 1,
  ),
  'Over' => 
  array (
    'the' => 1,
  ),
  'silver' => 
  array (
    '' => 2,
    'darts' => 1,
    'songs' => 1,
    'blur' => 1,
    'was' => 1,
    'beach' => 1,
    'tassles.' => 1,
  ),
  'spoon' => 
  array (
    '' => 1,
  ),
  'float' => 
  array (
    '' => 1,
  ),
  'Qualactin' => 
  array (
    'Hypermint' => 1,
    'Zones,' => 1,
  ),
  'Hypermint' => 
  array (
    'extract,' => 1,
  ),
  'extract,' => 
  array (
    'redolent' => 1,
  ),
  'redolent' => 
  array (
    'of' => 1,
  ),
  'heady' => 
  array (
    'odours' => 1,
    'sea' => 1,
  ),
  'odours' => 
  array (
    'of' => 1,
  ),
  'Zones,' => 
  array (
    'subtle' => 1,
  ),
  'subtle' => 
  array (
    'sweet' => 1,
    '' => 1,
    'piece' => 1,
    'experiments' => 1,
    'complexity' => 1,
  ),
  'sweet' => 
  array (
    'and' => 1,
    '' => 1,
    'silver' => 1,
  ),
  'mystic.' => 
  array (
    'Drop' => 1,
  ),
  'Drop' => 
  array (
    'in' => 1,
  ),
  'tooth' => 
  array (
    '' => 1,
  ),
  'Algolian' => 
  array (
    '' => 1,
    'Suns' => 1,
    'Suntiger' => 1,
  ),
  'Suntiger.' => 
  array (
    '' => 1,
  ),
  'Watch' => 
  array (
    '' => 1,
  ),
  'dissolve,' => 
  array (
    'spreading' => 1,
  ),
  'spreading' => 
  array (
    'the' => 1,
  ),
  'fires' => 
  array (
    'of' => 2,
  ),
  'Suns' => 
  array (
    'deep' => 1,
  ),
  'deep' => 
  array (
    'into' => 2,
    'gashes' => 1,
    '' => 3,
    'mystery:' => 1,
    'down,' => 1,
    'space' => 1,
    'black,' => 1,
    'worry' => 1,
    'Magrathean' => 1,
    'in' => 2,
    'majestic' => 1,
  ),
  'heart' => 
  array (
    'of' => 4,
    'screamed' => 1,
  ),
  'Sprinkle' => 
  array (
    'Zamphuor.' => 1,
  ),
  'Zamphuor.' => 
  array (
    'Add' => 1,
  ),
  'Add' => 
  array (
    'an' => 1,
  ),
  'olive.' => 
  array (
    'Drink...' => 1,
  ),
  'Drink...' => 
  array (
    'but...' => 1,
  ),
  'but...' => 
  array (
    'very' => 1,
    '-' => 5,
  ),
  'carefully...' => 
  array (
    'The' => 1,
  ),
  'sells' => 
  array (
    'rather' => 1,
  ),
  'Galactica.' => 
  array (
    '-' => 1,
  ),
  'Six' => 
  array (
    'pints' => 1,
  ),
  'pints' => 
  array (
    'of' => 1,
    'to' => 1,
    'all' => 1,
  ),
  'bitter,' => 
  array (
    '-' => 1,
  ),
  'barman' => 
  array (
    'of' => 2,
    'looked' => 2,
    'said,' => 1,
    'breathed' => 1,
    'simply' => 1,
    '' => 1,
    'another' => 1,
    'reeled' => 1,
    'couldn\'t' => 1,
    'cleared' => 1,
  ),
  'quickly' => 
  array (
    'please,' => 1,
    'checked' => 1,
    '' => 1,
    'learnt' => 1,
    'and' => 1,
    'by' => 1,
    'down' => 1,
  ),
  'please,' => 
  array (
    'the' => 1,
    '-' => 2,
    'computer?' => 1,
    '' => 1,
  ),
  'world\'s' => 
  array (
    'about' => 3,
    'going' => 1,
  ),
  'end.' => 
  array (
    'The' => 1,
    '-' => 1,
    'He' => 1,
    'Arthur' => 1,
    'As' => 1,
    'Chapter' => 1,
  ),
  'deserve' => 
  array (
    '' => 1,
  ),
  'treatment,' => 
  array (
    'he' => 1,
  ),
  'dignified' => 
  array (
    'old' => 1,
  ),
  'pushed' => 
  array (
    'his' => 2,
    'in' => 1,
    'a' => 2,
  ),
  'glasses' => 
  array (
    'up' => 1,
    'this' => 1,
    'on' => 1,
    'together.' => 1,
  ),
  'nose' => 
  array (
    'and' => 3,
    'rose' => 1,
  ),
  'blinked' => 
  array (
    'at' => 6,
  ),
  'Prefect.' => 
  array (
    'Ford' => 1,
    '<Ford' => 1,
  ),
  'ignored' => 
  array (
    '' => 2,
    'him.' => 2,
    'this.' => 1,
  ),
  'instead' => 
  array (
    'at' => 1,
    'of' => 1,
    '' => 1,
  ),
  'shrugged' => 
  array (
    'helplessly' => 1,
    'again.' => 1,
    'in' => 1,
    'and' => 1,
    'at' => 1,
  ),
  'helplessly' => 
  array (
    'and' => 1,
  ),
  'nothing.' => 
  array (
    'So' => 1,
    '-' => 1,
    'Nothing' => 1,
    'Finally' => 1,
  ),
  'Nice' => 
  array (
    'weather' => 1,
    'day' => 1,
    'ship' => 1,
  ),
  'weather' => 
  array (
    'for' => 1,
    '' => 1,
    'and' => 1,
  ),
  'pulling' => 
  array (
    'pints.' => 1,
  ),
  'pints.' => 
  array (
    'He' => 1,
  ),
  'Going' => 
  array (
    'to' => 1,
  ),
  'watch' => 
  array (
    'the' => 1,
    'now?' => 1,
    'this' => 1,
    'over' => 1,
  ),
  'match' => 
  array (
    'this' => 1,
    '' => 3,
    'was' => 1,
    'to' => 1,
  ),
  'afternoon' => 
  array (
    'then?' => 1,
    '' => 1,
    'boys.' => 1,
  ),
  'then?' => 
  array (
    'Ford' => 1,
    '-' => 5,
  ),
  'point,' => 
  array (
    '-' => 1,
    'it\'s' => 1,
  ),
  'What\'s' => 
  array (
    'that,' => 1,
    'that?' => 2,
    'so' => 3,
    'this' => 4,
    '' => 2,
    'happening?' => 2,
    'the' => 3,
    'my' => 1,
    'that' => 1,
    'all' => 1,
    'up?' => 1,
  ),
  'that,' => 
  array (
    'foregone' => 1,
    '-' => 12,
    'only' => 1,
    '' => 3,
    'and' => 1,
    'but' => 1,
    'computer?' => 1,
    'Earthman?' => 1,
  ),
  'foregone' => 
  array (
    'conclusion' => 1,
  ),
  'conclusion' => 
  array (
    'then' => 1,
    'of' => 1,
  ),
  'reckon' => 
  array (
    'sir?' => 1,
    'to' => 1,
    'this' => 1,
    'I\'ll' => 1,
    'Zaphod?' => 1,
  ),
  'barman.' => 
  array (
    '-' => 2,
  ),
  'Arsenal' => 
  array (
    'without' => 1,
    'if' => 1,
  ),
  'without' => 
  array (
    'a' => 2,
    'any' => 2,
    'until' => 1,
    'identifying' => 1,
    '' => 2,
    'faith' => 1,
    'warning.' => 1,
    'all' => 1,
    'first' => 1,
    'telling' => 1,
    'so' => 1,
    'apparently' => 1,
    'actually' => 1,
  ),
  'chance?' => 
  array (
    '-' => 1,
  ),
  'sir,' => 
  array (
    'so' => 1,
    'six' => 1,
    '-' => 2,
  ),
  'barman,' => 
  array (
    '' => 1,
    'slapping' => 1,
  ),
  'Lucky' => 
  array (
    'escape' => 1,
  ),
  'escape' => 
  array (
    'for' => 1,
    '' => 1,
  ),
  'genuinely' => 
  array (
    'surprised.' => 1,
    'angry' => 1,
    'stupid.' => 1,
    'stupid,' => 1,
  ),
  'surprised.' => 
  array (
    '-' => 2,
  ),
  'really,' => 
  array (
    '-' => 1,
    'cosmically' => 1,
  ),
  'frowned.' => 
  array (
    'The' => 1,
    '-' => 1,
    'She' => 1,
  ),
  'breathed' => 
  array (
    'in' => 1,
    'a' => 1,
    '' => 1,
    'Phouchg.' => 1,
    'on' => 1,
  ),
  'heavily.' => 
  array (
    '-' => 1,
  ),
  'six' => 
  array (
    'pints,' => 2,
    'feet' => 1,
    'people' => 3,
    'know' => 1,
    '' => 4,
    'and' => 1,
    'light' => 1,
    'equal' => 1,
    'months' => 1,
  ),
  'pints,' => 
  array (
    '-' => 1,
    'did' => 1,
  ),
  'wanly' => 
  array (
    'and' => 1,
    'at' => 1,
  ),
  'rest' => 
  array (
    'of' => 4,
    '' => 3,
  ),
  'case' => 
  array (
    'any' => 1,
  ),
  'had,' => 
  array (
    'and' => 1,
  ),
  'understand' => 
  array (
    '' => 3,
    'because' => 1,
    'was' => 1,
    'about' => 1,
    'that,' => 1,
    'his' => 1,
    'the' => 1,
    'what' => 2,
    'that.' => 1,
  ),
  'smiling' => 
  array (
    'at' => 2,
  ),
  'next' => 
  array (
    'to' => 7,
    '' => 3,
    'thing' => 4,
    'zebra' => 1,
    'morning?' => 1,
  ),
  'men,' => 
  array (
    '' => 1,
    'women' => 1,
  ),
  'swift' => 
  array (
    'burst' => 1,
  ),
  'burst' => 
  array (
    'of' => 1,
    'out.' => 1,
    'out' => 1,
    'in' => 1,
    'into' => 2,
    'from' => 1,
  ),
  'arithmetic,' => 
  array (
    '' => 1,
  ),
  'answer' => 
  array (
    'he' => 1,
    'this' => 1,
    '' => 4,
    'to' => 2,
    'I\'m' => 1,
    'for' => 1,
    'means.' => 1,
  ),
  'grinned' => 
  array (
    'a' => 1,
    'and' => 2,
    'at' => 2,
    'again.' => 1,
    'his' => 1,
  ),
  'hopeful' => 
  array (
    'grin' => 1,
  ),
  'grin' => 
  array (
    'at' => 1,
    'that' => 1,
  ),
  'Get' => 
  array (
    'off,' => 1,
  ),
  'They\'re' => 
  array (
    'ours,' => 1,
    'knocking' => 1,
    'the' => 1,
    'just' => 2,
    'two' => 1,
  ),
  'ours,' => 
  array (
    '-' => 1,
  ),
  'giving' => 
  array (
    '' => 2,
    'them' => 1,
    'you' => 1,
  ),
  'look' => 
  array (
    '' => 3,
    'at' => 6,
    'of' => 1,
    'up.' => 1,
    'crawled' => 1,
    'it' => 2,
    'for.' => 1,
    'frumpy.' => 1,
    'forward' => 2,
    'at.' => 2,
    'for' => 4,
    'came' => 2,
    'you' => 1,
    'passed' => 1,
  ),
  'Suntiger' => 
  array (
    'get' => 1,
  ),
  'slapped' => 
  array (
    'a' => 1,
    'his' => 1,
  ),
  'five-pound' => 
  array (
    'note' => 1,
    '' => 1,
  ),
  'note' => 
  array (
    'on' => 1,
    '' => 1,
    'of' => 1,
    'from' => 1,
    'had' => 1,
  ),
  'bar.' => 
  array (
    'He' => 1,
  ),
  'Keep' => 
  array (
    'the' => 1,
    'looking' => 1,
  ),
  'change.' => 
  array (
    '-' => 1,
    'The' => 2,
  ),
  'What,' => 
  array (
    'from' => 1,
    'no...' => 1,
    'the' => 2,
    '-' => 1,
    'down' => 1,
    'are' => 1,
  ),
  'fiver?' => 
  array (
    'Thank' => 1,
  ),
  'sir.' => 
  array (
    '-' => 1,
  ),
  'ten' => 
  array (
    'minutes' => 1,
    '' => 1,
    'feet' => 1,
    'billion' => 1,
    'pence' => 1,
    'out' => 1,
    'for' => 1,
    'decimal' => 1,
    'degrees' => 1,
    'million' => 2,
  ),
  'simply' => 
  array (
    'decided' => 1,
    '' => 1,
    'and' => 1,
    'as' => 1,
    'a' => 1,
    'given' => 1,
    'did' => 1,
    'so' => 1,
    'not' => 1,
    'hooking' => 1,
    'seemed' => 1,
    'stopped' => 1,
    'reply' => 1,
    'the' => 1,
    'didn\'t' => 1,
  ),
  'decided' => 
  array (
    'to' => 4,
    'it' => 1,
    '' => 4,
    'that' => 2,
    'he' => 1,
    'not' => 1,
  ),
  'walk' => 
  array (
    'away' => 1,
    'to' => 1,
    'through' => 1,
    'on,' => 1,
    'alone...' => 1,
    'afterwards.' => 1,
    'down?' => 2,
  ),
  'bit.' => 
  array (
    '-' => 3,
  ),
  'on?' => 
  array (
    '-' => 1,
  ),
  'Drink' => 
  array (
    'up,' => 2,
    'up.' => 2,
    '' => 1,
  ),
  'through.' => 
  array (
    '-' => 3,
  ),
  'Three' => 
  array (
    'pints?' => 1,
    'billion' => 1,
  ),
  'pints?' => 
  array (
    '-' => 1,
  ),
  'lunchtime?' => 
  array (
    'The' => 1,
  ),
  'ford' => 
  array (
    'grinned' => 1,
  ),
  'nodded' => 
  array (
    'happily.' => 1,
    'in' => 1,
  ),
  'happily.' => 
  array (
    'Ford' => 1,
  ),
  'Time' => 
  array (
    'is' => 1,
    'blossomed,' => 1,
    'and' => 1,
    '' => 1,
  ),
  'illusion.' => 
  array (
    'Lunchtime' => 1,
    '-' => 1,
  ),
  'Lunchtime' => 
  array (
    'doubly' => 1,
  ),
  'doubly' => 
  array (
    'so.' => 1,
  ),
  'Very' => 
  array (
    'deep,' => 1,
    'very' => 3,
    'few' => 1,
    'probably,' => 1,
    'good.' => 1,
    'pretty,' => 1,
    'depressed.' => 1,
  ),
  'deep,' => 
  array (
    '-' => 1,
  ),
  'send' => 
  array (
    'that' => 1,
    'the' => 1,
    'off' => 1,
  ),
  'Reader\'s' => 
  array (
    'Digest.' => 1,
  ),
  'Digest.' => 
  array (
    'They\'ve' => 1,
  ),
  'They\'ve' => 
  array (
    'got' => 2,
    'built' => 1,
    'been' => 1,
  ),
  'page' => 
  array (
    'for' => 1,
    'of' => 1,
  ),
  'up.' => 
  array (
    '-' => 12,
    'It' => 1,
    'He' => 2,
    'At' => 1,
    'After' => 1,
    'With' => 1,
    'For' => 1,
    'Ford' => 1,
  ),
  'sudden?' => 
  array (
    '-' => 1,
  ),
  'Muscle' => 
  array (
    'relaxant,' => 1,
    'relaxant?' => 1,
    'relaxant.' => 1,
  ),
  'relaxant,' => 
  array (
    'you\'ll' => 1,
  ),
  'you\'ll' => 
  array (
    'need' => 1,
    'never' => 1,
    'know' => 1,
  ),
  'relaxant?' => 
  array (
    '-' => 1,
  ),
  'relaxant.' => 
  array (
    'Arthur' => 1,
  ),
  'beer.' => 
  array (
    '-' => 1,
    '' => 1,
  ),
  'Did' => 
  array (
    'I' => 1,
    'that' => 1,
    'you' => 3,
    '' => 1,
    'the' => 1,
    'it' => 1,
  ),
  'today,' => 
  array (
    '-' => 1,
    '' => 2,
  ),
  'notice?' => 
  array (
    '-' => 1,
  ),
  'Alright,' => 
  array (
    '-' => 8,
    'just' => 1,
    'where' => 1,
  ),
  'I\'ll' => 
  array (
    'try' => 1,
    'sue' => 1,
    'have' => 3,
    'do' => 2,
    'show' => 1,
    '' => 1,
    'start' => 1,
    'mention' => 1,
    'send' => 1,
    'just' => 3,
    'give' => 1,
    'probably' => 1,
    'tell' => 4,
    'become' => 1,
  ),
  'try' => 
  array (
    'to' => 2,
    'at' => 1,
    'and' => 2,
    'a' => 1,
  ),
  'explain.' => 
  array (
    'How' => 1,
    'The' => 1,
    '-' => 1,
  ),
  'other?' => 
  array (
    '-' => 1,
  ),
  'long?' => 
  array (
    '-' => 2,
  ),
  'Er,' => 
  array (
    'about' => 1,
    'what' => 1,
    'yeah.' => 1,
    'excuse' => 3,
    'no,' => 1,
    'none' => 1,
    'hey' => 1,
    'no...' => 1,
    'economic' => 1,
    'well' => 1,
  ),
  'five' => 
  array (
    'years,' => 1,
    '' => 7,
    'miles' => 1,
    'hundred' => 3,
    'heads' => 1,
    'to' => 1,
    'pounds' => 1,
    'entirely' => 1,
    'million' => 3,
    'seconds,' => 1,
    'minutes' => 2,
    'times' => 1,
  ),
  'maybe' => 
  array (
    'six,' => 1,
    'someone' => 1,
    'mountains,' => 1,
    'even' => 1,
    'that' => 1,
  ),
  'six,' => 
  array (
    '-' => 1,
  ),
  'Most' => 
  array (
    'of' => 2,
    '' => 1,
    'leading' => 1,
    'Truly' => 1,
  ),
  'sense' => 
  array (
    'at' => 1,
    'of' => 8,
    '-' => 1,
    'to' => 1,
    '' => 3,
    'in' => 1,
    'it' => 2,
  ),
  'react' => 
  array (
    'if' => 1,
    '' => 1,
  ),
  'Betelgeuse?' => 
  array (
    'Arthur' => 1,
  ),
  'so-so' => 
  array (
    'sort' => 1,
  ),
  'way.' => 
  array (
    '-' => 3,
    'Beneath' => 1,
    'The' => 1,
  ),
  'know,' => 
  array (
    '-' => 11,
    'be' => 1,
    'the' => 1,
    'I' => 1,
    '' => 1,
    'like' => 1,
    'not' => 2,
    'on' => 1,
    'it\'s' => 1,
    'been' => 1,
    'just' => 1,
  ),
  'taking' => 
  array (
    'a' => 1,
    'an' => 1,
    '' => 1,
    'over' => 1,
    'this' => 1,
    'the' => 1,
  ),
  'pull' => 
  array (
    'of' => 1,
  ),
  'likely' => 
  array (
    'to' => 3,
  ),
  'say?' => 
  array (
    'Ford' => 1,
    'Harmless!' => 1,
    'What' => 1,
    '-' => 1,
  ),
  'worth' => 
  array (
    'bothering' => 1,
    '' => 3,
  ),
  'bothering' => 
  array (
    'at' => 1,
    'him.' => 1,
  ),
  'added,' => 
  array (
    'perfectly' => 1,
    '-' => 2,
    'not' => 1,
  ),
  'factually:' => 
  array (
    '-' => 1,
  ),
  'another' => 
  array (
    'wan' => 1,
    'five-pound' => 1,
    'meaningless' => 2,
    'match' => 1,
    '' => 4,
    'of' => 2,
    'voice.' => 1,
    'in' => 1,
    'one' => 1,
    'planet...' => 1,
    'walk,' => 1,
    'dimension.' => 1,
    'one.' => 2,
    'long' => 1,
    'ten' => 1,
    'electric' => 1,
    'drear' => 1,
  ),
  'wan' => 
  array (
    'smile.' => 1,
  ),
  'smile.' => 
  array (
    'The' => 1,
    '-' => 3,
  ),
  'waved' => 
  array (
    'at' => 2,
    'their' => 1,
    'and' => 1,
    'again.' => 1,
    'a' => 2,
  ),
  'business.' => 
  array (
    '-' => 1,
    'Thank' => 1,
    'Arthur' => 1,
    'Ford' => 1,
  ),
  'musing' => 
  array (
    'to' => 1,
  ),
  'sinking' => 
  array (
    'low' => 1,
  ),
  'low' => 
  array (
    'over' => 1,
    'murmur' => 1,
    'as' => 1,
    'irritating' => 1,
    'groan.' => 1,
    'steel' => 1,
    'and' => 2,
    '' => 1,
    'hum' => 1,
    'hairlines,' => 1,
  ),
  'beer,' => 
  array (
    '-' => 1,
    'leapt' => 1,
  ),
  'hang' => 
  array (
    'of' => 1,
    'on,' => 1,
    'heavy' => 1,
    'the' => 1,
  ),
  'Thursdays.' => 
  array (
    'Chapter' => 1,
  ),
  3 => 
  array (
    'On' => 1,
  ),
  'particular' => 
  array (
    'Thursday,' => 1,
    'is' => 1,
    'way' => 1,
    'job' => 1,
  ),
  'moving' => 
  array (
    'quietly' => 1,
    'beneath' => 1,
    'slightly' => 1,
    'at' => 1,
    'slowly' => 1,
  ),
  'quietly' => 
  array (
    'through' => 1,
    '' => 3,
    'on' => 1,
    'turned' => 1,
    'to' => 1,
    'in' => 2,
    'and' => 1,
    'towards' => 1,
    'as' => 1,
    'humming' => 1,
  ),
  'ionosphere' => 
  array (
    'many' => 1,
  ),
  'surface' => 
  array (
    'of' => 10,
    '' => 1,
    'was' => 1,
    'become' => 1,
  ),
  'planet;' => 
  array (
    'several' => 1,
  ),
  'several' => 
  array (
    '' => 4,
    'dozen' => 1,
    'unexpected' => 1,
    'million' => 1,
    'miles' => 2,
    'seconds' => 2,
    'hundred' => 1,
    'thugs' => 1,
    'rather' => 1,
  ),
  'somethings' => 
  array (
    'in' => 1,
    'went' => 1,
    'began' => 1,
    '' => 1,
  ),
  'dozen' => 
  array (
    'huge' => 1,
    '' => 1,
  ),
  'huge' => 
  array (
    'yellow' => 5,
    '' => 3,
    'ships' => 1,
    'bay.' => 1,
    'white' => 1,
    'furry' => 1,
    'leathery' => 1,
    'young' => 1,
    'blubbery' => 1,
    'children' => 1,
    'bang' => 1,
    'screen.' => 1,
    'green' => 1,
    'sign' => 1,
  ),
  'chunky' => 
  array (
    '' => 1,
    'shapes.' => 1,
    'pieces' => 1,
  ),
  'slablike' => 
  array (
    '' => 1,
  ),
  'somethings,' => 
  array (
    '' => 1,
  ),
  'buildings,' => 
  array (
    'silent' => 1,
  ),
  'silent' => 
  array (
    'as' => 1,
    'for' => 1,
    'again' => 1,
    '' => 1,
    'bobbing' => 1,
  ),
  'birds.' => 
  array (
    '' => 1,
  ),
  'soared' => 
  array (
    '' => 1,
    'into' => 1,
  ),
  'ease,' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'basking' => 
  array (
    '' => 1,
  ),
  'electromagnetic' => 
  array (
    'rays' => 1,
  ),
  'rays' => 
  array (
    'from' => 1,
    'of' => 2,
  ),
  'Sol,' => 
  array (
    '' => 1,
    'Zaphod' => 1,
  ),
  'biding' => 
  array (
    '' => 1,
  ),
  'grouping,' => 
  array (
    'preparing.' => 1,
  ),
  'preparing.' => 
  array (
    'The' => 1,
  ),
  'beneath' => 
  array (
    'them' => 3,
    'the' => 4,
    '' => 4,
    'his' => 1,
    'them.' => 5,
  ),
  'almost' => 
  array (
    '' => 6,
    'pathetic' => 1,
    'awe.' => 1,
    'always' => 1,
    'rolled' => 1,
    'childishly' => 1,
    'charming,' => 1,
    'infinite' => 1,
    'all' => 1,
  ),
  'oblivious' => 
  array (
    '' => 1,
  ),
  'presence,' => 
  array (
    'which' => 1,
  ),
  'moment.' => 
  array (
    '' => 3,
    'The' => 2,
    'Another' => 1,
    'Magrathea!' => 1,
    'What' => 1,
    'He' => 1,
    '-' => 4,
    'Finally:' => 1,
  ),
  'unnoticed' => 
  array (
    '' => 1,
  ),
  'Goonhilly,' => 
  array (
    '' => 1,
  ),
  'Cape' => 
  array (
    'Canaveral' => 1,
  ),
  'Canaveral' => 
  array (
    'without' => 1,
  ),
  'blip,' => 
  array (
    'Woomera' => 1,
  ),
  'Woomera' => 
  array (
    'and' => 1,
  ),
  'Jodrell' => 
  array (
    'Bank' => 1,
    'Bank,' => 1,
  ),
  'Bank' => 
  array (
    'looked' => 1,
  ),
  'pity' => 
  array (
    'because' => 1,
  ),
  'years.' => 
  array (
    'The' => 2,
    '-' => 1,
    'There' => 1,
    'Who\'s' => 1,
  ),
  'place' => 
  array (
    'they' => 1,
    'of' => 1,
    'then?' => 1,
    'that' => 1,
    'where' => 1,
    '' => 1,
    'has' => 1,
    'in' => 1,
    'to' => 1,
  ),
  'black' => 
  array (
    '' => 4,
    'rod,' => 1,
    'space.' => 1,
    'hair,' => 1,
    'is' => 1,
    'edge' => 1,
    'sky,' => 1,
    'and' => 1,
    'panel.' => 1,
    'jewelled' => 1,
  ),
  'device' => 
  array (
    'called' => 1,
    '' => 2,
    'in' => 1,
    'ever' => 1,
    'which' => 1,
    'after' => 1,
    'for' => 1,
  ),
  'Sub-Etha' => 
  array (
    'Sens-O-Matic' => 3,
    '' => 1,
    'News-Matics' => 1,
  ),
  'Sens-O-Matic' => 
  array (
    'which' => 1,
    'and' => 1,
    'began' => 1,
  ),
  'winked' => 
  array (
    'away' => 1,
    'at' => 1,
    'out' => 1,
  ),
  'itself.' => 
  array (
    '' => 1,
    '-' => 1,
    'Even' => 1,
    'Arthur\'s' => 1,
  ),
  'nestled' => 
  array (
    'in' => 1,
    'quietly' => 1,
  ),
  'darkness' => 
  array (
    'inside' => 1,
  ),
  'inside' => 
  array (
    'a' => 1,
    'out.' => 1,
    'of' => 3,
    '' => 3,
    'him,' => 1,
    'this' => 1,
    'the' => 1,
    'your' => 1,
  ),
  'leather' => 
  array (
    'satchel' => 1,
    'top,' => 1,
  ),
  'satchel' => 
  array (
    'which' => 1,
    '' => 1,
    'were' => 1,
  ),
  'wore' => 
  array (
    'habitually' => 1,
  ),
  'habitually' => 
  array (
    'round' => 1,
  ),
  'contents' => 
  array (
    'of' => 1,
  ),
  'Prefect\'s' => 
  array (
    '' => 2,
    'satchel' => 1,
    'original' => 1,
    'brow,' => 1,
  ),
  'physicist\'s' => 
  array (
    '' => 1,
  ),
  'concealed' => 
  array (
    'them' => 1,
  ),
  'keeping' => 
  array (
    '' => 1,
  ),
  'dog-eared' => 
  array (
    'scripts' => 1,
  ),
  'scripts' => 
  array (
    'for' => 1,
    '' => 1,
  ),
  'plays' => 
  array (
    'he' => 1,
  ),
  'pretended' => 
  array (
    'he' => 1,
  ),
  'auditioning' => 
  array (
    '' => 1,
  ),
  'stuffed' => 
  array (
    'in' => 1,
  ),
  'top.' => 
  array (
    'Besides' => 1,
  ),
  'Besides' => 
  array (
    'the' => 1,
  ),
  'Electronic' => 
  array (
    'Thumb' => 1,
  ),
  'Thumb' => 
  array (
    '-' => 1,
  ),
  'short' => 
  array (
    'squat' => 1,
    'Vog' => 1,
    'while,' => 1,
    'buzz' => 1,
    'aircar' => 1,
    'by' => 1,
  ),
  'squat' => 
  array (
    'black' => 1,
  ),
  'rod,' => 
  array (
    'smooth' => 1,
  ),
  'smooth' => 
  array (
    'and' => 2,
  ),
  'matt' => 
  array (
    'with' => 1,
  ),
  'flat' => 
  array (
    'switches' => 1,
    'press' => 1,
    '' => 2,
    'and' => 3,
    'about' => 1,
    'where' => 1,
  ),
  'switches' => 
  array (
    'and' => 1,
  ),
  'dials' => 
  array (
    'at' => 1,
  ),
  'end;' => 
  array (
    'he' => 1,
  ),
  'largish' => 
  array (
    '' => 1,
    'bath' => 1,
  ),
  'electronic' => 
  array (
    '' => 2,
    'component' => 1,
    'sub-etha' => 1,
    'book.' => 1,
    'enhancement' => 1,
    'look.' => 1,
    'sulking' => 1,
    'brain,' => 1,
  ),
  'calculator.' => 
  array (
    '' => 1,
  ),
  'hundred' => 
  array (
    'tiny' => 1,
    'thousand' => 5,
    '' => 5,
    'billion' => 1,
    'and' => 8,
    'miles' => 2,
    'yards' => 1,
    'entirely' => 1,
  ),
  'tiny' => 
  array (
    'flat' => 1,
    'sublimal' => 1,
    'spaceport' => 1,
    '' => 5,
    'piece' => 1,
    'voices' => 1,
    'ribbon' => 1,
    'flashing' => 1,
    'lights' => 1,
    'glow' => 1,
    'tear.' => 1,
    'yellow' => 1,
    'whining' => 1,
  ),
  'press' => 
  array (
    'buttons' => 1,
    'a' => 1,
    'who' => 1,
    'this' => 1,
    '' => 1,
  ),
  'buttons' => 
  array (
    'and' => 1,
    '' => 3,
    'at' => 1,
  ),
  'screen' => 
  array (
    'about' => 1,
    'lights' => 1,
    'and' => 2,
    '' => 2,
  ),
  'inches' => 
  array (
    '' => 1,
    'by' => 1,
    'in' => 1,
  ),
  'square' => 
  array (
    '' => 3,
    'was' => 1,
    'outside.' => 1,
  ),
  '"pages"' => 
  array (
    'could' => 1,
  ),
  'summoned' => 
  array (
    'at' => 1,
  ),
  'moment\'s' => 
  array (
    'notice.' => 1,
    'reflection.' => 1,
    'panic' => 1,
    'expectant' => 1,
  ),
  'notice.' => 
  array (
    'It' => 1,
    '-' => 1,
  ),
  'insanely' => 
  array (
    'complicated,' => 1,
  ),
  'complicated,' => 
  array (
    'and' => 1,
  ),
  'reasons' => 
  array (
    '' => 2,
    'for' => 1,
  ),
  'snug' => 
  array (
    'plastic' => 1,
    '' => 1,
  ),
  'plastic' => 
  array (
    'cover' => 1,
    'wrapping' => 1,
    '' => 1,
    'cup' => 1,
  ),
  'fitted' => 
  array (
    'into' => 1,
    'just' => 1,
    'with' => 1,
    'perfectly' => 1,
    'better.' => 1,
  ),
  'printed' => 
  array (
    'on' => 1,
    'in' => 1,
  ),
  'letters.' => 
  array (
    'The' => 1,
  ),
  'books' => 
  array (
    'ever' => 1,
  ),
  'corporations' => 
  array (
    'of' => 1,
  ),
  'micro' => 
  array (
    '' => 1,
  ),
  'sub' => 
  array (
    '' => 1,
  ),
  'meson' => 
  array (
    'electronic' => 1,
  ),
  'component' => 
  array (
    'is' => 1,
  ),
  'normal' => 
  array (
    '' => 3,
  ),
  'form,' => 
  array (
    '' => 1,
    'dependent' => 1,
  ),
  'interstellar' => 
  array (
    '' => 2,
    'hitch' => 1,
    'travel.' => 1,
    'distances' => 2,
    'battle.' => 1,
  ),
  'hitch' => 
  array (
    '' => 5,
    'hiker' => 1,
    'the' => 1,
    'hiking' => 2,
    'hikers.' => 2,
    'hikers' => 1,
  ),
  'hiker' => 
  array (
    '' => 2,
    'can' => 1,
    'has' => 1,
    'any' => 1,
    'trying' => 1,
  ),
  'require' => 
  array (
    '' => 1,
    'the' => 1,
  ),
  'inconveniently' => 
  array (
    '' => 1,
    'arranged' => 1,
  ),
  'buildings' => 
  array (
    'to' => 1,
    '' => 2,
    'of' => 1,
  ),
  'carry' => 
  array (
    'it' => 1,
    '' => 1,
    'most' => 1,
  ),
  'Beneath' => 
  array (
    'that' => 1,
    'it' => 1,
    'him' => 1,
  ),
  'biros,' => 
  array (
    '' => 1,
  ),
  'notepad,' => 
  array (
    'and' => 1,
  ),
  'bath' => 
  array (
    'towel' => 1,
  ),
  'towel' => 
  array (
    'from' => 1,
    '' => 1,
    'has' => 1,
    'with' => 2,
    'is' => 1,
    'is.' => 1,
    'in' => 1,
    'was.' => 1,
  ),
  'Marks' => 
  array (
    'and' => 1,
  ),
  'Spencer.' => 
  array (
    'The' => 1,
  ),
  'subject' => 
  array (
    'of' => 3,
  ),
  'towels.' => 
  array (
    'A' => 1,
  ),
  'towel,' => 
  array (
    'it' => 1,
  ),
  'says,' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'massively' => 
  array (
    '' => 1,
    'real' => 1,
    'on' => 1,
  ),
  'useful' => 
  array (
    '' => 2,
    'size' => 1,
    'little' => 1,
  ),
  'have.' => 
  array (
    'Partly' => 1,
    'The' => 1,
  ),
  'Partly' => 
  array (
    'it' => 1,
  ),
  'practical' => 
  array (
    '' => 1,
    'upshot' => 1,
    'to' => 1,
  ),
  'value' => 
  array (
    '' => 1,
    'of' => 1,
  ),
  'wrap' => 
  array (
    'it' => 2,
  ),
  'warmth' => 
  array (
    'as' => 1,
  ),
  'bound' => 
  array (
    'across' => 1,
    'to' => 2,
  ),
  'moons' => 
  array (
    'of' => 1,
  ),
  'Jaglan' => 
  array (
    'Beta;' => 1,
  ),
  'Beta;' => 
  array (
    'you' => 1,
  ),
  'brilliant' => 
  array (
    '' => 1,
    'sun.' => 1,
    'academic' => 1,
  ),
  'marble-sanded' => 
  array (
    '' => 1,
  ),
  'beaches' => 
  array (
    'of' => 1,
  ),
  'V,' => 
  array (
    'inhaling' => 1,
  ),
  'inhaling' => 
  array (
    'the' => 1,
  ),
  'vapours;' => 
  array (
    'you' => 1,
  ),
  'sleep' => 
  array (
    '' => 1,
    'anyway.' => 1,
  ),
  'stars' => 
  array (
    'which' => 1,
    'in' => 1,
    'are' => 2,
  ),
  'shine' => 
  array (
    'so' => 1,
  ),
  'redly' => 
  array (
    'on' => 1,
  ),
  'desert' => 
  array (
    'world' => 1,
    'islands' => 1,
  ),
  'Kakrafoon;' => 
  array (
    'use' => 1,
  ),
  'use' => 
  array (
    'it' => 1,
    'in' => 1,
    'to' => 1,
    'as' => 1,
    'a' => 1,
    'the' => 1,
    'it.' => 1,
    '' => 1,
  ),
  'sail' => 
  array (
    'a' => 1,
    'past' => 1,
  ),
  'mini' => 
  array (
    'raft' => 1,
  ),
  'raft' => 
  array (
    'down' => 1,
  ),
  'slow' => 
  array (
    'heavy' => 1,
    'movement' => 1,
    'stupefied' => 1,
  ),
  'heavy' => 
  array (
    'river' => 1,
    'shape' => 1,
    '' => 1,
    'on' => 1,
    'and' => 1,
    'mob' => 1,
    'design' => 1,
  ),
  'river' => 
  array (
    'Moth;' => 1,
  ),
  'Moth;' => 
  array (
    'wet' => 1,
  ),
  'wet' => 
  array (
    'it' => 1,
    '' => 2,
    'thud,' => 1,
  ),
  'hand-tohand-combat;' => 
  array (
    'wrap' => 1,
  ),
  'ward' => 
  array (
    'off' => 1,
  ),
  'noxious' => 
  array (
    '' => 1,
  ),
  'fumes' => 
  array (
    'or' => 1,
  ),
  'avoid' => 
  array (
    'the' => 1,
    'laying' => 1,
  ),
  'gaze' => 
  array (
    '' => 1,
    'hopelessly' => 1,
  ),
  'Ravenous' => 
  array (
    '' => 1,
    'Bugblatter' => 2,
  ),
  'Bugblatter' => 
  array (
    '' => 1,
    'Beast' => 2,
  ),
  'Beast' => 
  array (
    '' => 1,
    'of' => 2,
  ),
  'Traal' => 
  array (
    '' => 2,
  ),
  '(a' => 
  array (
    'mindboggingly' => 1,
    '' => 2,
  ),
  'animal,' => 
  array (
    'it' => 1,
  ),
  'assumes' => 
  array (
    'that' => 1,
  ),
  'daft' => 
  array (
    'as' => 1,
  ),
  'bush,' => 
  array (
    'but' => 1,
  ),
  'ravenous);' => 
  array (
    'you' => 1,
  ),
  'wave' => 
  array (
    'your' => 2,
    '' => 3,
    'of' => 1,
    'at' => 1,
  ),
  'emergencies' => 
  array (
    'as' => 1,
  ),
  'distress' => 
  array (
    'signal,' => 1,
  ),
  'signal,' => 
  array (
    'and' => 1,
  ),
  'seems' => 
  array (
    'to' => 4,
  ),
  'importantly,' => 
  array (
    'a' => 1,
  ),
  'immense' => 
  array (
    'psychological' => 1,
    'excitement' => 1,
    'stupidity' => 1,
    '' => 1,
  ),
  'psychological' => 
  array (
    'value.' => 1,
  ),
  'value.' => 
  array (
    '' => 1,
  ),
  'reason,' => 
  array (
    'if' => 1,
  ),
  'strag' => 
  array (
    '(strag:' => 1,
    'will' => 2,
  ),
  '(strag:' => 
  array (
    'non-hitch' => 1,
  ),
  'non-hitch' => 
  array (
    'hiker)' => 1,
  ),
  'hiker)' => 
  array (
    'discovers' => 1,
  ),
  'discovers' => 
  array (
    'that' => 1,
  ),
  'automatically' => 
  array (
    'assume' => 1,
    'in' => 1,
  ),
  'possession' => 
  array (
    'of' => 1,
  ),
  'toothbrush,' => 
  array (
    'face' => 1,
  ),
  'face' => 
  array (
    'flannel,' => 1,
    'and' => 1,
    'him' => 1,
    'was' => 2,
    '' => 2,
    'illuminated' => 1,
    'again.' => 1,
    'cleared.' => 1,
    'down' => 1,
  ),
  'flannel,' => 
  array (
    'soap,' => 1,
  ),
  'soap,' => 
  array (
    'tin' => 1,
  ),
  'tin' => 
  array (
    '' => 1,
    'can,' => 1,
  ),
  'biscuits,' => 
  array (
    '' => 1,
  ),
  'flask,' => 
  array (
    'compass,' => 1,
  ),
  'compass,' => 
  array (
    'map,' => 1,
  ),
  'map,' => 
  array (
    'ball' => 1,
  ),
  'ball' => 
  array (
    'of' => 1,
    'on' => 1,
    'to' => 1,
  ),
  'string,' => 
  array (
    'gnat' => 1,
  ),
  'gnat' => 
  array (
    'spray,' => 1,
    'knew' => 1,
  ),
  'spray,' => 
  array (
    'wet' => 1,
  ),
  'gear,' => 
  array (
    '' => 1,
  ),
  'suit' => 
  array (
    'etc.,' => 1,
    'for' => 1,
    'computers' => 1,
  ),
  'etc.,' => 
  array (
    'etc.' => 1,
  ),
  'etc.' => 
  array (
    'Furthermore,' => 1,
  ),
  'Furthermore,' => 
  array (
    'the' => 1,
  ),
  'happily' => 
  array (
    'lend' => 1,
    'bank' => 1,
  ),
  'lend' => 
  array (
    'the' => 1,
  ),
  'items' => 
  array (
    '' => 1,
  ),
  'might' => 
  array (
    'accidentally' => 1,
    'not' => 1,
    'scream.' => 1,
    'be' => 3,
    'read' => 1,
    '' => 2,
    'have' => 2,
    'include' => 1,
    'work' => 1,
    'be.' => 1,
  ),
  'accidentally' => 
  array (
    'have' => 1,
    'change' => 1,
    'swallowed' => 1,
  ),
  '"lost".' => 
  array (
    'What' => 1,
  ),
  'breadth' => 
  array (
    '' => 1,
  ),
  'galaxy,' => 
  array (
    '' => 2,
  ),
  'rough' => 
  array (
    '' => 1,
    'blobby' => 1,
  ),
  'slum' => 
  array (
    '' => 1,
  ),
  'struggle' => 
  array (
    'against' => 1,
  ),
  'against' => 
  array (
    'terrible' => 1,
    'nature.' => 1,
    'the' => 6,
    '' => 6,
    'and' => 5,
    'it' => 1,
    'them.' => 1,
    'a' => 1,
  ),
  'odds,' => 
  array (
    'win' => 1,
  ),
  'through,' => 
  array (
    'and' => 1,
  ),
  'knows' => 
  array (
    '' => 1,
    'where' => 1,
    'all' => 1,
  ),
  'clearly' => 
  array (
    'a' => 1,
    'not' => 1,
    'had' => 1,
    '' => 1,
    'was' => 1,
    'very' => 1,
    'rather' => 1,
    'hear' => 1,
    'something' => 1,
    'the' => 1,
    'dominated' => 1,
    'dead.' => 1,
    'an' => 1,
    'far' => 1,
  ),
  'reckoned' => 
  array (
    'with.' => 1,
  ),
  'Hence' => 
  array (
    'a' => 1,
  ),
  'phrase' => 
  array (
    'which' => 1,
    'he\'d' => 1,
    'around' => 1,
  ),
  'hiking' => 
  array (
    'slang,' => 1,
    'this' => 1,
  ),
  'slang,' => 
  array (
    'as' => 1,
  ),
  'Hey,' => 
  array (
    'you' => 1,
    '-' => 3,
    'who' => 1,
    'yeah,' => 1,
    'yeah?' => 1,
    'come' => 1,
    'this' => 1,
    'what' => 1,
    'have' => 1,
    'will' => 1,
    'they\'re' => 1,
  ),
  'sass' => 
  array (
    'that' => 1,
  ),
  'hoopy' => 
  array (
    'Ford' => 1,
  ),
  'Prefect?' => 
  array (
    'There\'s' => 1,
  ),
  'There\'s' => 
  array (
    'a' => 2,
    'no' => 1,
    'nothing' => 1,
    'absolutely' => 1,
  ),
  'frood' => 
  array (
    '' => 1,
  ),
  'is.' => 
  array (
    '(Sass:' => 1,
    'I' => 1,
    '-' => 4,
    'Absolutely' => 1,
  ),
  '(Sass:' => 
  array (
    'know,' => 1,
  ),
  'aware' => 
  array (
    'of,' => 1,
    'of.' => 1,
    '' => 3,
    'that' => 1,
    'of' => 1,
  ),
  'of,' => 
  array (
    'meet,' => 1,
  ),
  'meet,' => 
  array (
    'have' => 1,
  ),
  'sex' => 
  array (
    'with;' => 1,
    '' => 1,
  ),
  'with;' => 
  array (
    'hoopy:' => 1,
    'elegant' => 1,
  ),
  'hoopy:' => 
  array (
    'really' => 1,
  ),
  'together' => 
  array (
    'guy;' => 1,
    'guy.)' => 1,
    'in' => 2,
    'not' => 1,
    'and' => 2,
    '' => 1,
  ),
  'guy;' => 
  array (
    'frood:' => 1,
  ),
  'frood:' => 
  array (
    'really' => 1,
  ),
  'guy.)' => 
  array (
    'Nestling' => 1,
  ),
  'Nestling' => 
  array (
    'quietly' => 1,
  ),
  'satchel,' => 
  array (
    '' => 1,
  ),
  'wink' => 
  array (
    'more' => 1,
  ),
  'quickly.' => 
  array (
    'Miles' => 1,
  ),
  'Miles' => 
  array (
    'above' => 1,
  ),
  'fan' => 
  array (
    '' => 1,
    'of' => 1,
  ),
  'Bank,' => 
  array (
    'someone' => 1,
  ),
  'relaxing' => 
  array (
    'cup' => 1,
  ),
  'cup' => 
  array (
    'of' => 1,
    '' => 2,
    'filled' => 1,
  ),
  'tea.' => 
  array (
    '-' => 1,
    'The' => 1,
    '' => 1,
  ),
  'struggling' => 
  array (
    'through' => 1,
    '' => 1,
  ),
  'third' => 
  array (
    'pint,' => 1,
    'arm.' => 1,
    '' => 3,
    'worst' => 1,
    'thus' => 1,
    'factor.' => 1,
    'by' => 1,
  ),
  'pint,' => 
  array (
    'looked' => 1,
  ),
  'Why?' => 
  array (
    'What,' => 1,
    '-' => 5,
    'I' => 1,
  ),
  'no...' => 
  array (
    'should' => 1,
    '-' => 1,
    'well,' => 1,
  ),
  'have?' => 
  array (
    '-' => 1,
  ),
  'surprised,' => 
  array (
    'there' => 1,
  ),
  'seem' => 
  array (
    'to' => 6,
    '' => 3,
    'ill' => 1,
  ),
  'longer.' => 
  array (
    'Ford' => 1,
    '' => 1,
  ),
  'clicked' => 
  array (
    'his' => 1,
  ),
  'irritation.' => 
  array (
    '-' => 1,
    'Of' => 1,
    '' => 1,
  ),
  'urged.' => 
  array (
    'At' => 1,
  ),
  'sound' => 
  array (
    '' => 2,
    'of' => 3,
    'reproduction,' => 1,
    'with' => 1,
    'hopeful.' => 1,
    'that' => 1,
    'was' => 1,
    'thrilled' => 1,
    'going' => 1,
    'plausible.' => 1,
    'promising!' => 1,
  ),
  'rumbling' => 
  array (
    '' => 1,
  ),
  'crash' => 
  array (
    '' => 1,
  ),
  'filtered' => 
  array (
    'through' => 1,
  ),
  'murmur' => 
  array (
    'of' => 1,
  ),
  'jukebox,' => 
  array (
    'through' => 1,
  ),
  'hiccupping' => 
  array (
    '' => 1,
  ),
  'whisky' => 
  array (
    'Ford' => 1,
    'glasses' => 1,
  ),
  'bought' => 
  array (
    'him.' => 1,
    'some' => 1,
    'the' => 1,
    '' => 1,
  ),
  'choked' => 
  array (
    'on' => 1,
    'Zaphod' => 1,
  ),
  'leapt' => 
  array (
    'to' => 2,
    'off' => 1,
    'at' => 1,
    'straight' => 1,
    'out' => 1,
  ),
  'feet.' => 
  array (
    '-' => 4,
  ),
  'yelped.' => 
  array (
    '-' => 2,
  ),
  'worry,' => 
  array (
    '-' => 3,
  ),
  'yet.' => 
  array (
    '-' => 2,
    'Not' => 1,
    'The' => 1,
    'No,' => 1,
  ),
  'relaxed.' => 
  array (
    '-' => 1,
  ),
  'down,' => 
  array (
    '' => 2,
    'you' => 1,
    'the' => 1,
    'get' => 1,
    'and...' => 1,
  ),
  'drowning' => 
  array (
    'his' => 1,
  ),
  'pint.' => 
  array (
    '-' => 1,
  ),
  'Suddenly' => 
  array (
    'Ford\'s' => 1,
    'a' => 2,
    'Marvin' => 1,
    'it' => 1,
    'she' => 1,
    'he' => 1,
    'running' => 1,
    'Arthur' => 1,
    'the' => 1,
  ),
  'Ford\'s' => 
  array (
    'spell' => 1,
    'father' => 1,
    'father,' => 1,
    'finger,' => 1,
    'body' => 1,
    'direction.' => 1,
    '' => 1,
    'sceptical' => 1,
    'copy' => 2,
    'eyes' => 1,
  ),
  'spell' => 
  array (
    '' => 1,
  ),
  'broken.' => 
  array (
    '' => 1,
  ),
  'ran' => 
  array (
    'to' => 1,
    'out' => 2,
    'forward' => 1,
    'down' => 1,
  ),
  'are!' => 
  array (
    'They\'re' => 1,
  ),
  'am' => 
  array (
    'I' => 4,
    '' => 3,
    'nothing.' => 1,
    'now' => 1,
    'I?' => 5,
    'simply' => 1,
    'not' => 2,
    'Majikthise!' => 1,
    'Vroomfondel!' => 1,
    'Vroomfondel,' => 1,
  ),
  'hardly' => 
  array (
    'makes' => 1,
    'glancing' => 1,
    'moving' => 1,
    'time' => 1,
    'surprising' => 1,
  ),
  'makes' => 
  array (
    'any' => 1,
  ),
  'difference' => 
  array (
    'at' => 1,
    '' => 1,
  ),
  'stage,' => 
  array (
    '-' => 1,
  ),
  'fun.' => 
  array (
    '-' => 1,
  ),
  'Fun?' => 
  array (
    '-' => 1,
  ),
  'yelped' => 
  array (
    'Arthur.' => 1,
    'Zaphod,' => 1,
  ),
  'Fun!' => 
  array (
    '-' => 1,
  ),
  'checked' => 
  array (
    'out' => 1,
    'it' => 1,
  ),
  'again' => 
  array (
    'that' => 1,
    'and' => 5,
    'because' => 2,
    'with' => 1,
    'in' => 1,
    'on' => 2,
    '' => 4,
    'be' => 1,
    'for' => 2,
    'muttering' => 1,
    'he' => 1,
    'thirteen' => 1,
    'now?' => 1,
    'will' => 1,
    'so' => 1,
  ),
  'same' => 
  array (
    'thing.' => 1,
    'thing' => 1,
    'way' => 3,
    'time,' => 2,
    'to' => 2,
    'programme.' => 1,
    'sector' => 1,
    '' => 2,
    'distant' => 1,
    'reasons.' => 1,
  ),
  'thing.' => 
  array (
    '-' => 3,
  ),
  'Damn' => 
  array (
    'their' => 1,
  ),
  'fun!' => 
  array (
    '-' => 1,
  ),
  'furiously' => 
  array (
    'waving' => 1,
    '' => 1,
  ),
  'waving' => 
  array (
    'a' => 3,
    'aside' => 1,
    '' => 1,
    'his' => 1,
    'to' => 1,
    'their' => 1,
    'toy' => 1,
  ),
  'empty' => 
  array (
    'beer' => 1,
    'black' => 1,
    '' => 1,
    'sterility' => 1,
    'wastes' => 1,
  ),
  'beer' => 
  array (
    'glass.' => 1,
    '' => 1,
  ),
  'glass.' => 
  array (
    'He' => 1,
  ),
  'lunchtime.' => 
  array (
    '-' => 1,
  ),
  'Stop,' => 
  array (
    'you' => 1,
  ),
  'vandals!' => 
  array (
    'You' => 1,
  ),
  'wreckers!' => 
  array (
    '-' => 1,
  ),
  'bawled' => 
  array (
    'Arthur.' => 1,
    'Zaphod.' => 1,
    '' => 1,
    'Vroomfondel' => 1,
  ),
  'crazed' => 
  array (
    'Visigoths,' => 1,
  ),
  'Visigoths,' => 
  array (
    'stop' => 1,
  ),
  'you!' => 
  array (
    'Ford' => 1,
  ),
  'Turning' => 
  array (
    'quickly' => 1,
  ),
  'packets' => 
  array (
    'of' => 1,
    '' => 1,
  ),
  'peanuts.' => 
  array (
    '-' => 2,
    'Arthur' => 1,
  ),
  'slapping' => 
  array (
    'the' => 1,
  ),
  'bar,' => 
  array (
    '-' => 1,
  ),
  'twenty-eight' => 
  array (
    'pence' => 1,
    'to' => 1,
  ),
  'pence' => 
  array (
    'if' => 1,
    'each,' => 1,
  ),
  'you\'d' => 
  array (
    'be' => 1,
    'better' => 1,
    'taken' => 1,
    'stop' => 2,
    '' => 2,
    'call' => 1,
    'like' => 1,
    'just' => 1,
    'probably' => 1,
  ),
  'kind.' => 
  array (
    'Ford' => 1,
  ),
  'shivered:' => 
  array (
    'he' => 1,
  ),
  'experienced' => 
  array (
    'a' => 2,
    'it' => 1,
    '' => 1,
  ),
  'momentary' => 
  array (
    'sensation' => 1,
  ),
  'sensation' => 
  array (
    '' => 2,
    'he' => 1,
    'of' => 1,
    'in' => 1,
  ),
  'before.' => 
  array (
    'In' => 1,
    'Zaphod' => 1,
  ),
  'moments' => 
  array (
    'of' => 2,
    'he' => 1,
    'and' => 1,
    '' => 1,
  ),
  'stress,' => 
  array (
    'every' => 1,
    'and' => 1,
    'ulcers' => 1,
  ),
  'every' => 
  array (
    'life' => 1,
    'penny' => 1,
    '' => 8,
    'television,' => 1,
    'cassette' => 1,
    'woofer,' => 1,
    'mid-range' => 1,
    'dust' => 1,
    'window,' => 1,
    'sheet' => 1,
    'gesture' => 1,
    'last' => 1,
    'planet' => 1,
    'point' => 2,
    'time' => 1,
    'which' => 1,
    'major' => 2,
    'century' => 1,
    'direction,' => 1,
    'alarm' => 1,
  ),
  'exists' => 
  array (
    'gives' => 1,
  ),
  'gives' => 
  array (
    'out' => 1,
    'us' => 2,
    'me' => 2,
  ),
  'sublimal' => 
  array (
    'signal.' => 1,
    'impression' => 1,
  ),
  'signal.' => 
  array (
    'This' => 1,
  ),
  'signal' => 
  array (
    '' => 1,
    'pattern' => 1,
    'had' => 1,
  ),
  'communicates' => 
  array (
    '' => 1,
  ),
  'exact' => 
  array (
    '' => 1,
    'coordinates' => 1,
  ),
  'pathetic' => 
  array (
    'sense' => 1,
  ),
  'birth.' => 
  array (
    '' => 1,
  ),
  'possible' => 
  array (
    'to' => 2,
    'that' => 1,
    'way' => 1,
  ),
  'further' => 
  array (
    'than' => 2,
    'after' => 1,
    'because' => 1,
    'tests,' => 1,
    'thinking' => 1,
    'in' => 1,
    '' => 1,
    'reflection,' => 1,
    'backwards' => 1,
    'back' => 1,
    'before' => 1,
  ),
  'sixteen' => 
  array (
    'thousand' => 1,
  ),
  'birthplace,' => 
  array (
    'which' => 1,
  ),
  'isn\'t' => 
  array (
    'very' => 1,
    'it?' => 10,
    'nearly' => 1,
    'right,' => 1,
    'easy' => 2,
  ),
  'far,' => 
  array (
    '' => 1,
  ),
  'signals' => 
  array (
    '' => 2,
    'picked' => 1,
  ),
  'minute' => 
  array (
    'to' => 1,
    'and' => 1,
    'now' => 1,
  ),
  'noticed.' => 
  array (
    'Ford' => 1,
  ),
  'born' => 
  array (
    600 => 1,
  ),
  600 => 
  array (
    'light' => 1,
  ),
  'light' => 
  array (
    'years' => 6,
    'brown)' => 1,
    'at' => 1,
    '' => 7,
    'of' => 2,
    'switch.' => 1,
    'to' => 1,
    'exploded,' => 1,
    'and' => 1,
    'before' => 1,
    'sink' => 1,
    'he' => 1,
    'around' => 1,
    'that' => 1,
    'appeared' => 1,
    'which' => 1,
    'seconds' => 1,
    'arced' => 1,
    'glared' => 1,
    'flashed.' => 1,
    'flashed' => 1,
  ),
  'near' => 
  array (
    'vicinity' => 1,
    'or' => 1,
    '' => 1,
  ),
  'reeled' => 
  array (
    'for' => 1,
  ),
  'hit' => 
  array (
    'by' => 1,
    'the' => 1,
    '' => 2,
    'him' => 1,
    'about' => 1,
  ),
  'shocking,' => 
  array (
    '' => 1,
  ),
  'incomprehensible' => 
  array (
    'sense' => 1,
    'computer' => 1,
    '' => 1,
    'and' => 1,
  ),
  'distance.' => 
  array (
    'He' => 1,
    '-' => 1,
  ),
  'meant,' => 
  array (
    'but' => 1,
  ),
  'respect,' => 
  array (
    'almost' => 1,
  ),
  'awe.' => 
  array (
    '-' => 1,
  ),
  'Are' => 
  array (
    'you' => 5,
    'we' => 1,
  ),
  'serious,' => 
  array (
    'sir?' => 1,
  ),
  'whisper' => 
  array (
    '' => 2,
  ),
  'silencing' => 
  array (
    'the' => 1,
  ),
  'end?' => 
  array (
    '-' => 1,
  ),
  'But,' => 
  array (
    'this' => 1,
    '-' => 2,
  ),
  'afternoon?' => 
  array (
    'Ford' => 1,
  ),
  'recovered' => 
  array (
    'himself.' => 1,
  ),
  'flippest.' => 
  array (
    '-' => 1,
  ),
  'gaily,' => 
  array (
    '-' => 1,
  ),
  'estimate.' => 
  array (
    'The' => 1,
  ),
  'couldn\'t' => 
  array (
    'believe' => 3,
    'be' => 2,
    '' => 2,
    'stand' => 2,
    'sleep.' => 3,
    'see.' => 1,
    'put' => 1,
    'think' => 1,
    'clearly' => 1,
    'use' => 1,
    'have' => 1,
    'bear' => 1,
  ),
  'believe' => 
  array (
    'the' => 2,
    'that' => 1,
    'and' => 1,
    '' => 3,
    'in.' => 1,
    'he' => 1,
    'these' => 1,
  ),
  'conversation' => 
  array (
    'he' => 1,
    '' => 1,
  ),
  'having,' => 
  array (
    '' => 1,
  ),
  'Isn\'t' => 
  array (
    'there' => 2,
    'it' => 1,
  ),
  'nothing,' => 
  array (
    '-' => 3,
    'I\'m' => 1,
  ),
  'stuffing' => 
  array (
    'the' => 1,
    'their' => 1,
  ),
  'peanuts' => 
  array (
    'into' => 1,
    '' => 1,
  ),
  'pockets.' => 
  array (
    'Someone' => 1,
  ),
  'Someone' => 
  array (
    'in' => 1,
    'from' => 1,
    'down' => 1,
  ),
  'hushed' => 
  array (
    'bar' => 1,
    'voice.' => 1,
  ),
  'laughed' => 
  array (
    'raucously' => 1,
    'appreciatively,' => 1,
    'a' => 1,
  ),
  'raucously' => 
  array (
    '' => 1,
  ),
  'become.' => 
  array (
    'The' => 1,
  ),
  'sozzled' => 
  array (
    'by' => 1,
  ),
  'meant' => 
  array (
    'to' => 2,
    'that' => 1,
  ),
  'bag' => 
  array (
    'over' => 1,
  ),
  'our' => 
  array (
    'head' => 1,
    'thumbs' => 1,
    'instruments' => 1,
    '' => 7,
    'business' => 1,
    'clients' => 2,
    'planet' => 1,
    'most' => 1,
    'lives,' => 1,
    'dead' => 1,
    'rather' => 1,
    'race' => 2,
    'planet.' => 1,
    'factory' => 1,
    'planets' => 1,
    'original' => 1,
    'dimension' => 1,
    'observations' => 1,
    'own...' => 1,
    'own)' => 1,
    'sitting' => 1,
    'way' => 2,
    'own' => 4,
    'guests' => 1,
    'minds' => 1,
    'particular' => 1,
  ),
  'something.' => 
  array (
    '-' => 3,
    '' => 1,
    'Perhaps' => 1,
    'I' => 1,
  ),
  'If' => 
  array (
    'you' => 6,
    'anything' => 1,
    '' => 2,
    'they' => 1,
    'I' => 1,
    'you\'re' => 2,
    'we\'re' => 1,
    'he' => 1,
    'there\'s' => 1,
    'you\'d' => 1,
  ),
  'like,' => 
  array (
    'yes,' => 1,
  ),
  'us' => 
  array (
    'in' => 4,
    'on' => 1,
    'a' => 4,
    'some' => 1,
    'into' => 1,
    'will' => 1,
    'about' => 1,
    'by' => 1,
    '' => 4,
    'when' => 1,
    'yet.' => 1,
    'out!' => 1,
    'his' => 1,
    'the' => 1,
    'conkers' => 1,
    'food,' => 1,
    'and' => 1,
    'as' => 1,
    'socially!' => 1,
    'blast' => 1,
    'beat' => 1,
  ),
  'army,' => 
  array (
    '-' => 1,
  ),
  'man,' => 
  array (
    'and' => 4,
    '-' => 6,
    'apparently' => 1,
    'sternly.' => 1,
    'his' => 1,
    '' => 2,
    'pausing' => 1,
  ),
  'trek' => 
  array (
    'back' => 1,
  ),
  'whisky.' => 
  array (
    '-' => 1,
  ),
  'Will' => 
  array (
    'that' => 1,
    'you' => 1,
  ),
  'help?' => 
  array (
    '-' => 1,
  ),
  'go.' => 
  array (
    '-' => 2,
    'Where' => 1,
    'Zaphod' => 1,
  ),
  'wave,' => 
  array (
    'he' => 1,
  ),
  'left.' => 
  array (
    'The' => 1,
  ),
  'longer,' => 
  array (
    '' => 1,
  ),
  'embarrassingly' => 
  array (
    'enough,' => 1,
  ),
  'raucous' => 
  array (
    'laugh' => 1,
  ),
  'dragged' => 
  array (
    'along' => 1,
    'them' => 1,
    'Zaphod' => 1,
  ),
  'along' => 
  array (
    'to' => 1,
    'the' => 4,
    'with' => 3,
    'beside' => 1,
    'its' => 1,
    'beneath' => 1,
    'for' => 1,
  ),
  'grown' => 
  array (
    'to' => 1,
    '' => 1,
    'so' => 1,
  ),
  'loathe' => 
  array (
    'him' => 1,
    'it.' => 1,
    'it' => 1,
  ),
  'dearly' => 
  array (
    'over' => 1,
  ),
  'hour' => 
  array (
    'or' => 1,
    'refit,' => 1,
    'too' => 1,
  ),
  'so,' => 
  array (
    'and' => 1,
    'but' => 1,
    '-' => 2,
    'nothing' => 1,
  ),
  'satisfaction' => 
  array (
    '' => 1,
    'to' => 1,
  ),
  'evaporate' => 
  array (
    'into' => 1,
  ),
  'whiff' => 
  array (
    'of' => 2,
  ),
  'hydrogen,' => 
  array (
    'ozone' => 2,
  ),
  'ozone' => 
  array (
    'and' => 2,
  ),
  'carbon' => 
  array (
    '' => 1,
    'monoxide.' => 1,
  ),
  'monoxide.' => 
  array (
    '' => 1,
    'He' => 1,
  ),
  'However,' => 
  array (
    '' => 1,
    'no' => 1,
    'the' => 1,
  ),
  'came' => 
  array (
    'she' => 1,
    'skating' => 1,
    '' => 4,
    'for' => 1,
    'round' => 2,
    'from' => 3,
    'the' => 2,
    'another' => 1,
    'to' => 4,
    'across)' => 1,
    'up' => 1,
    'into' => 3,
    'and' => 3,
    'a' => 1,
    'again,' => 1,
    'across' => 2,
  ),
  'busy' => 
  array (
    'evaporating' => 1,
    'schedule' => 1,
    'till' => 1,
    'staring' => 1,
    'putting' => 1,
  ),
  'evaporating' => 
  array (
    'herself' => 1,
  ),
  'herself' => 
  array (
    'to' => 1,
    'and' => 1,
  ),
  'throat.' => 
  array (
    'He' => 1,
    'A' => 1,
    '-' => 4,
    'However,' => 1,
  ),
  'say:' => 
  array (
    '-' => 1,
  ),
  'Last' => 
  array (
    'orders,' => 1,
    'night' => 1,
    'thing' => 1,
  ),
  'orders,' => 
  array (
    'please.' => 1,
  ),
  'please.' => 
  array (
    'The' => 1,
  ),
  'machines' => 
  array (
    'began' => 1,
    'get' => 1,
  ),
  'downward' => 
  array (
    'and' => 1,
  ),
  'move' => 
  array (
    'faster.' => 1,
    'into' => 1,
    'beneath' => 1,
  ),
  'faster.' => 
  array (
    'Ford' => 1,
    'Dank' => 1,
  ),
  'Running' => 
  array (
    'up' => 1,
  ),
  'lane,' => 
  array (
    'Arthur' => 1,
  ),
  'reached' => 
  array (
    'his' => 1,
    '' => 1,
    'in' => 1,
    'the' => 1,
    'out' => 1,
    'it' => 1,
    'down' => 1,
  ),
  'become,' => 
  array (
    'he' => 1,
  ),
  'wind,' => 
  array (
    '' => 1,
    'hot' => 1,
  ),
  'sudden' => 
  array (
    'irrational' => 1,
    'silence' => 2,
    'spacious' => 1,
    'sickening' => 1,
    'stab' => 1,
    'inexplicable' => 1,
    'point' => 1,
    'demise' => 1,
    'access' => 1,
    'wet' => 1,
    'commotion' => 1,
    'realization.' => 1,
    'evil' => 1,
    'excitement.' => 1,
  ),
  'irrational' => 
  array (
    '' => 2,
  ),
  'squall' => 
  array (
    '' => 1,
  ),
  'rain.' => 
  array (
    '' => 1,
    'Today' => 1,
  ),
  'caterpillar' => 
  array (
    'bulldozers' => 1,
  ),
  'crawling' => 
  array (
    'over' => 1,
  ),
  'rubble' => 
  array (
    'that' => 1,
    'and' => 1,
  ),
  'home.' => 
  array (
    '-' => 1,
  ),
  'barbarians!' => 
  array (
    '-' => 1,
  ),
  'yelled.' => 
  array (
    '-' => 2,
    '' => 1,
  ),
  'sue' => 
  array (
    'the' => 1,
  ),
  'penny' => 
  array (
    'it\'s' => 1,
  ),
  'got!' => 
  array (
    'I\'ll' => 1,
  ),
  'hung,' => 
  array (
    '' => 1,
    'huge,' => 1,
  ),
  'drawn' => 
  array (
    '' => 1,
    'on' => 1,
  ),
  'quartered!' => 
  array (
    '' => 1,
  ),
  'whipped!' => 
  array (
    '' => 1,
  ),
  'boiled...' => 
  array (
    'until...' => 1,
  ),
  'until...' => 
  array (
    'until...' => 1,
    'until' => 1,
  ),
  'again!' => 
  array (
    '' => 1,
  ),
  'yelled' => 
  array (
    '' => 2,
    'Ford,' => 2,
    'Trillian,' => 1,
    'Vroomfondel,' => 1,
    'Vroomfondel.' => 1,
    'Loonquawl.' => 1,
    'till' => 1,
  ),
  'finished' => 
  array (
    'I' => 1,
    'burying' => 1,
    'our' => 1,
  ),
  'bits,' => 
  array (
    'and' => 1,
  ),
  'jump' => 
  array (
    'on' => 1,
    'into' => 1,
    '' => 1,
    'at' => 1,
  ),
  'them!' => 
  array (
    'Arthur' => 1,
  ),
  'bulldozers;' => 
  array (
    'he' => 1,
  ),
  'staring' => 
  array (
    '' => 1,
    'at' => 3,
  ),
  'hectically' => 
  array (
    '' => 1,
  ),
  'sky.' => 
  array (
    'What' => 1,
    'The' => 1,
  ),
  'noticed' => 
  array (
    '' => 1,
    'that' => 1,
    'an' => 1,
    'him.' => 1,
    'on' => 1,
  ),
  'clouds.' => 
  array (
    'Impossibly' => 1,
  ),
  'Impossibly' => 
  array (
    'huge' => 1,
  ),
  'somethings.' => 
  array (
    '-' => 1,
  ),
  'jumping' => 
  array (
    '' => 1,
  ),
  'running,' => 
  array (
    '-' => 1,
    'then' => 1,
  ),
  'blisters,' => 
  array (
    'or' => 1,
  ),
  'unpleasant' => 
  array (
    'to' => 1,
    '' => 1,
    'races' => 1,
    'about' => 1,
    'business' => 1,
    'way' => 1,
  ),
  'do,' => 
  array (
    'and' => 1,
    'everybody' => 1,
  ),
  'then...' => 
  array (
    'Arthur' => 1,
  ),
  'tripped,' => 
  array (
    'and' => 1,
  ),
  'headlong,' => 
  array (
    'rolled' => 1,
  ),
  'landed' => 
  array (
    '' => 1,
    'on' => 1,
  ),
  'shot' => 
  array (
    'upwards.' => 1,
    'now.' => 1,
    'at' => 1,
    'to' => 1,
    'forward' => 1,
    'out' => 1,
  ),
  'upwards.' => 
  array (
    '-' => 1,
    'The' => 1,
  ),
  'hell\'s' => 
  array (
    'that?' => 1,
  ),
  'shrieked.' => 
  array (
    'Whatever' => 1,
  ),
  'Whatever' => 
  array (
    'it' => 1,
    'Zaphod\'s' => 1,
    'your' => 1,
    'happened' => 1,
  ),
  'raced' => 
  array (
    'across' => 1,
    'through' => 1,
  ),
  'monstrous' => 
  array (
    '' => 1,
    'shadows' => 1,
  ),
  'yellowness,' => 
  array (
    '' => 1,
  ),
  'tore' => 
  array (
    'the' => 1,
    '' => 1,
  ),
  'apart' => 
  array (
    'with' => 1,
    'where' => 1,
    'from' => 1,
  ),
  'mind-buggering' => 
  array (
    'noise' => 1,
  ),
  'noise' => 
  array (
    'and' => 3,
    'fell' => 1,
    'leapt' => 1,
    'stopped.' => 1,
    'as' => 1,
    'was' => 1,
  ),
  'leaving' => 
  array (
    'the' => 3,
  ),
  'gaping' => 
  array (
    'air' => 1,
  ),
  'air' => 
  array (
    'to' => 1,
    'high' => 1,
    'nearby.' => 1,
    'was' => 2,
    'of' => 2,
    'with' => 1,
    'as' => 1,
    'you' => 1,
    'that' => 1,
    'clasped' => 1,
    'wafted' => 1,
    'thick' => 1,
    'leaving' => 1,
    'above' => 1,
    'and' => 1,
    'just' => 1,
    '' => 2,
    'inches' => 1,
    'exploded' => 1,
    'about' => 1,
    'at' => 1,
  ),
  'bang' => 
  array (
    'that' => 1,
    'Southend' => 1,
    'the' => 1,
    'his' => 1,
  ),
  'drove' => 
  array (
    'your' => 1,
  ),
  'ears' => 
  array (
    'six' => 1,
  ),
  'feet' => 
  array (
    'into' => 1,
    'up.' => 1,
    'below.' => 1,
    '' => 2,
    'and' => 1,
    'began' => 1,
    'in' => 1,
    'long.' => 1,
    'as' => 1,
    'on' => 1,
  ),
  'skull.' => 
  array (
    'Another' => 1,
  ),
  'Another' => 
  array (
    'one' => 1,
    'door' => 1,
    'thing' => 2,
    'voice' => 1,
    'wistful' => 1,
    'worried' => 1,
    'pause,' => 1,
  ),
  'followed' => 
  array (
    'and' => 1,
    'Ford\'s' => 1,
    'quickly' => 2,
    'him' => 1,
    '' => 2,
    'a' => 1,
    'the' => 1,
    'by' => 1,
  ),
  'louder.' => 
  array (
    'It\'s' => 1,
  ),
  'themselves.' => 
  array (
    'None' => 1,
    'This' => 1,
    'The' => 1,
  ),
  'houses,' => 
  array (
    'running' => 1,
    'howling' => 1,
  ),
  'howling' => 
  array (
    'noiselessly' => 1,
    'gargles,' => 1,
  ),
  'noiselessly' => 
  array (
    'at' => 1,
  ),
  'noise.' => 
  array (
    '' => 1,
    'For' => 1,
    'There' => 1,
  ),
  'All' => 
  array (
    '' => 3,
    'the' => 2,
    'his' => 1,
    'except' => 1,
    'by' => 1,
    'this' => 1,
    'I' => 1,
    'through' => 1,
    'in' => 1,
  ),
  'city' => 
  array (
    'streets' => 1,
    'square,' => 1,
  ),
  'exploded' => 
  array (
    'with' => 2,
    'carcass' => 1,
  ),
  'people,' => 
  array (
    'cars' => 1,
  ),
  'cars' => 
  array (
    'slewed' => 1,
    'and' => 1,
  ),
  'slewed' => 
  array (
    'into' => 1,
    '' => 1,
  ),
  'tidal' => 
  array (
    '' => 1,
  ),
  'hills' => 
  array (
    'and' => 1,
  ),
  'valleys,' => 
  array (
    'deserts' => 1,
  ),
  'deserts' => 
  array (
    'and' => 1,
  ),
  'oceans,' => 
  array (
    'seeming' => 1,
    '-' => 1,
  ),
  'seeming' => 
  array (
    'to' => 1,
  ),
  'flatten' => 
  array (
    'everything' => 1,
  ),
  'everything' => 
  array (
    'it' => 1,
    'was' => 1,
    'you' => 1,
    '' => 1,
    'will' => 1,
    'in' => 1,
  ),
  'hit.' => 
  array (
    'Only' => 1,
  ),
  'Only' => 
  array (
    'one' => 2,
    'six' => 2,
    'by' => 1,
  ),
  'watched' => 
  array (
    'the' => 3,
    'his' => 1,
    'them.' => 1,
    'with' => 2,
    'for' => 1,
    'a' => 1,
    'two' => 1,
  ),
  'sky,' => 
  array (
    'stood' => 1,
    '' => 1,
    'let' => 1,
    'the' => 1,
  ),
  'sadness' => 
  array (
    'in' => 1,
    '' => 1,
    'came' => 1,
  ),
  'rubber' => 
  array (
    'bungs' => 1,
    'planets' => 1,
  ),
  'bungs' => 
  array (
    '' => 1,
  ),
  'ears.' => 
  array (
    '' => 1,
    'Sound' => 1,
  ),
  'happening' => 
  array (
    'and' => 1,
  ),
  'Sens-OMatic' => 
  array (
    '' => 1,
  ),
  'winking' => 
  array (
    'in' => 1,
    'and' => 1,
  ),
  'dead' => 
  array (
    'of' => 2,
    'and' => 3,
    'race' => 1,
    'giveaway,' => 1,
    'planet,' => 2,
    'for' => 2,
    'planet' => 1,
    'or' => 1,
    'weight' => 1,
  ),
  'pillar' => 
  array (
    'and' => 1,
  ),
  'woken' => 
  array (
    'him' => 1,
  ),
  'start.' => 
  array (
    'It' => 1,
  ),
  'waited' => 
  array (
    'for' => 5,
  ),
  'deciphered' => 
  array (
    'the' => 1,
  ),
  'pattern' => 
  array (
    'sitting' => 1,
    '' => 1,
  ),
  'alone' => 
  array (
    'in' => 2,
  ),
  'room' => 
  array (
    '' => 3,
    'folded' => 1,
    'suddenly' => 1,
    'remarked' => 1,
    'was' => 1,
    'crashed' => 1,
    'with' => 1,
    'full' => 2,
  ),
  'coldness' => 
  array (
    '' => 1,
  ),
  'gripped' => 
  array (
    'him' => 1,
  ),
  'squeezed' => 
  array (
    'his' => 1,
    'themselves' => 1,
  ),
  'heart.' => 
  array (
    'Of' => 1,
  ),
  'Of' => 
  array (
    'all' => 2,
    'Life,' => 2,
  ),
  'races' => 
  array (
    'in' => 2,
    'and' => 1,
    '' => 1,
  ),
  'hello' => 
  array (
    '' => 1,
    'to' => 1,
    'there!' => 1,
  ),
  'Vogons.' => 
  array (
    'Still' => 1,
    'His' => 1,
    '' => 1,
  ),
  'Still' => 
  array (
    'he' => 1,
    'nothing.' => 1,
    'nothing' => 1,
  ),
  'do.' => 
  array (
    'As' => 1,
    '' => 1,
    'It' => 1,
  ),
  'Vogon' => 
  array (
    'craft' => 1,
    'Jeltz' => 6,
    'ships,' => 1,
    'Constructor' => 4,
    'Civil' => 1,
    '' => 5,
    'Jeltz\'s' => 1,
    'a' => 1,
    'guard' => 5,
    'captain' => 2,
    'is' => 1,
    'to' => 1,
    'constructor' => 1,
    'poetry' => 1,
    'began' => 1,
    '(he' => 1,
    'raised' => 1,
    'perused' => 1,
    'stood' => 1,
    'Guard' => 1,
    'armpits.' => 1,
    'tightened' => 1,
    'stopped' => 1,
    'stared' => 2,
    '-' => 1,
    'airlock' => 1,
  ),
  'craft' => 
  array (
    'screamed' => 1,
    'of' => 1,
    'which,' => 1,
    'which' => 1,
    'as' => 1,
    'it' => 1,
  ),
  'screamed' => 
  array (
    '' => 2,
    'unbearably' => 1,
    'at' => 3,
  ),
  'satchel.' => 
  array (
    'He' => 1,
    'Arthur' => 1,
  ),
  'threw' => 
  array (
    '' => 3,
    'the' => 1,
    'one' => 1,
    'himself' => 1,
    'Ford' => 1,
  ),
  'copy' => 
  array (
    '' => 3,
    'of' => 3,
    'themselves' => 1,
    'from' => 1,
  ),
  'Joseph' => 
  array (
    'and' => 1,
  ),
  'Amazing' => 
  array (
    'Technicolor' => 1,
  ),
  'Technicolor' => 
  array (
    'Dreamcoat,' => 1,
  ),
  'Dreamcoat,' => 
  array (
    'he' => 1,
  ),
  'Godspell:' => 
  array (
    'He' => 1,
  ),
  'going.' => 
  array (
    'Everything' => 1,
    '' => 1,
  ),
  'Everything' => 
  array (
    'was' => 1,
    '-' => 1,
  ),
  'ready,' => 
  array (
    'everything' => 1,
  ),
  'prepared.' => 
  array (
    'He' => 1,
    '-' => 1,
  ),
  'silence' => 
  array (
    'hit' => 1,
    'for' => 3,
    'settled' => 1,
    '' => 2,
    'again' => 1,
    'as' => 2,
    'crept' => 1,
    'fell' => 1,
    'and' => 1,
    'afterwards' => 1,
  ),
  'worse' => 
  array (
    '' => 1,
    'than' => 1,
    'it' => 1,
    'for' => 1,
  ),
  'happened.' => 
  array (
    'The' => 1,
    'Then' => 1,
    'They' => 1,
    'Then,' => 1,
    'Twenty' => 1,
  ),
  'ships' => 
  array (
    'hung' => 2,
    'turned' => 1,
    '' => 1,
  ),
  'motionless' => 
  array (
    'in' => 1,
  ),
  'air,' => 
  array (
    '' => 1,
    'carved' => 1,
    'bobbing' => 1,
  ),
  'nation' => 
  array (
    '' => 1,
  ),
  'Motionless' => 
  array (
    'they' => 1,
  ),
  'huge,' => 
  array (
    'heavy,' => 1,
  ),
  'heavy,' => 
  array (
    'steady' => 1,
  ),
  'blasphemy' => 
  array (
    'against' => 1,
  ),
  'nature.' => 
  array (
    'Many' => 1,
  ),
  'shock' => 
  array (
    'as' => 1,
    'and' => 1,
    '' => 1,
  ),
  'minds' => 
  array (
    '' => 1,
    'than' => 1,
    'and' => 1,
  ),
  'encompass' => 
  array (
    'what' => 1,
  ),
  'at.' => 
  array (
    'The' => 1,
    'He' => 1,
    'It' => 1,
    '-' => 1,
    'Arthur' => 1,
  ),
  'bricks' => 
  array (
    'don\'t.' => 1,
    'and' => 1,
  ),
  'don\'t.' => 
  array (
    'And' => 1,
    'QED.' => 1,
    'He' => 1,
    '-' => 1,
  ),
  'whisper,' => 
  array (
    'a' => 1,
    '-' => 1,
  ),
  'spacious' => 
  array (
    '' => 2,
  ),
  'open' => 
  array (
    'ambient' => 1,
    'automatically' => 1,
    'and' => 2,
    '' => 4,
    'space...' => 1,
    'for' => 1,
    'again' => 1,
    'the' => 1,
    'that' => 1,
  ),
  'ambient' => 
  array (
    '' => 1,
  ),
  'sound.' => 
  array (
    '' => 1,
    'They' => 1,
    'It' => 1,
  ),
  'Every' => 
  array (
    '' => 2,
    'tin' => 1,
    'Bogart' => 1,
  ),
  'hi' => 
  array (
    '' => 1,
    'Arthur,' => 1,
  ),
  'fi' => 
  array (
    '' => 1,
  ),
  'world,' => 
  array (
    '' => 1,
    'so' => 1,
    'something' => 1,
  ),
  'radio,' => 
  array (
    '' => 1,
  ),
  'television,' => 
  array (
    'every' => 1,
  ),
  'cassette' => 
  array (
    'recorder,' => 1,
  ),
  'recorder,' => 
  array (
    'every' => 1,
  ),
  'woofer,' => 
  array (
    '' => 1,
  ),
  'tweeter,' => 
  array (
    '' => 1,
  ),
  'mid-range' => 
  array (
    'driver' => 1,
  ),
  'driver' => 
  array (
    'in' => 1,
    'units,' => 1,
  ),
  'can,' => 
  array (
    'every' => 1,
    '-' => 1,
  ),
  'dust' => 
  array (
    'bin,' => 1,
    'off' => 1,
    'cloud?' => 1,
    'of' => 1,
    'about' => 1,
    'particle' => 1,
  ),
  'bin,' => 
  array (
    'every' => 1,
  ),
  'car,' => 
  array (
    '' => 1,
  ),
  'wine' => 
  array (
    'glass,' => 1,
  ),
  'glass,' => 
  array (
    'every' => 1,
  ),
  'sheet' => 
  array (
    'of' => 2,
    '' => 1,
  ),
  'rusty' => 
  array (
    'metal' => 1,
  ),
  'metal' => 
  array (
    '' => 1,
    'and' => 1,
    'were' => 1,
  ),
  'became' => 
  array (
    '' => 3,
    'apparent' => 1,
    'extremely' => 1,
    'rather' => 1,
    'the' => 1,
    'larger.' => 1,
    'visible,' => 1,
    'aware' => 1,
    'increasingly' => 1,
  ),
  'activated' => 
  array (
    '' => 1,
  ),
  'acoustically' => 
  array (
    'perfect' => 1,
  ),
  'perfect' => 
  array (
    'sounding' => 1,
    'quadrophonic' => 1,
  ),
  'sounding' => 
  array (
    'board.' => 1,
    'name' => 1,
  ),
  'board.' => 
  array (
    'Before' => 1,
    '-' => 1,
  ),
  'Before' => 
  array (
    'the' => 1,
    'Arthur' => 1,
  ),
  'treated' => 
  array (
    'to' => 1,
  ),
  'ultimate' => 
  array (
    'in' => 1,
    'political' => 1,
    'decision-making' => 1,
  ),
  'reproduction,' => 
  array (
    'the' => 1,
  ),
  'greatest' => 
  array (
    'public' => 1,
    'excitement' => 1,
    'moment,' => 1,
    'computer' => 3,
    'one' => 1,
    '' => 1,
  ),
  'public' => 
  array (
    '' => 1,
    'inquiry,' => 1,
    'imagination' => 1,
    'square.' => 1,
    'library.' => 1,
  ),
  'address' => 
  array (
    '' => 1,
    'of' => 1,
    'Arthur.' => 1,
  ),
  'built.' => 
  array (
    'But' => 1,
  ),
  'concert,' => 
  array (
    'no' => 1,
  ),
  'music,' => 
  array (
    '' => 1,
    'bad' => 1,
    'but' => 1,
  ),
  'fanfare,' => 
  array (
    '' => 1,
  ),
  'simple' => 
  array (
    'message.' => 1,
    'and' => 1,
    '' => 3,
    'truth' => 1,
    'for' => 1,
    'door' => 1,
    'coincidence,' => 1,
    'angular' => 1,
    'answer?' => 1,
    'one!' => 1,
  ),
  'message.' => 
  array (
    '-' => 1,
    'It\'s' => 1,
  ),
  'voice' => 
  array (
    'said,' => 3,
    'continued.' => 2,
    '' => 9,
    'was' => 6,
    'but' => 1,
    'pleasantly,' => 1,
    'cleared' => 1,
    'cut' => 1,
    'behind' => 1,
    'modulator' => 1,
    'broke' => 1,
    'circuits' => 1,
    'again.' => 1,
    'that' => 1,
    'said' => 1,
    'from' => 2,
    'took' => 1,
    'snapped' => 1,
    'tailed' => 1,
    'rich' => 1,
    'boomed' => 1,
    'rang' => 1,
    'back' => 1,
    'they' => 1,
    'cried.' => 1,
    'on' => 2,
    'replied,' => 1,
  ),
  'wonderful.' => 
  array (
    'Wonderful' => 1,
  ),
  'Wonderful' => 
  array (
    'perfect' => 1,
  ),
  'quadrophonic' => 
  array (
    'sound' => 1,
  ),
  'distortion' => 
  array (
    'levels' => 1,
  ),
  'levels' => 
  array (
    '' => 1,
  ),
  'brave' => 
  array (
    'man' => 1,
    'unknown' => 1,
  ),
  'weep.' => 
  array (
    '-' => 1,
  ),
  'Prostetnic' => 
  array (
    'Vogon' => 7,
  ),
  'Jeltz' => 
  array (
    'of' => 1,
    'was' => 3,
    'heaved' => 1,
    'smiled' => 1,
  ),
  'Hyperspace' => 
  array (
    '' => 1,
  ),
  'Planning' => 
  array (
    'Council,' => 1,
  ),
  'Council,' => 
  array (
    '-' => 1,
  ),
  'continued.' => 
  array (
    '-' => 5,
    '' => 1,
    'He' => 1,
  ),
  'doubt' => 
  array (
    'be' => 1,
    'that,' => 1,
    'came' => 1,
    'in' => 1,
    'and' => 1,
  ),
  'aware,' => 
  array (
    'the' => 1,
  ),
  'development' => 
  array (
    'of' => 1,
  ),
  'outlying' => 
  array (
    'regions' => 2,
  ),
  'regions' => 
  array (
    'of' => 1,
    'The' => 1,
  ),
  'building' => 
  array (
    'of' => 1,
    '' => 2,
    'they\'ve' => 1,
  ),
  'hyperspatial' => 
  array (
    'express' => 2,
    '' => 1,
  ),
  'express' => 
  array (
    'route' => 1,
    'routes' => 1,
  ),
  'route' => 
  array (
    'through' => 1,
  ),
  'system,' => 
  array (
    'and' => 1,
    '-' => 2,
  ),
  'regrettably' => 
  array (
    'your' => 1,
  ),
  'scheduled' => 
  array (
    'for' => 1,
  ),
  'demolition.' => 
  array (
    '' => 1,
  ),
  'process' => 
  array (
    '' => 3,
    'units.' => 1,
  ),
  'minutes.' => 
  array (
    'Thank' => 1,
  ),
  'PA' => 
  array (
    'died' => 1,
    'again.' => 1,
    'fell' => 1,
    'slammed' => 1,
  ),
  'away.' => 
  array (
    'Uncomprehending' => 1,
    'Then' => 1,
    'Arthur' => 1,
    '-' => 6,
    'The' => 3,
    'Again' => 1,
    '' => 1,
    'He' => 1,
  ),
  'Uncomprehending' => 
  array (
    'terror' => 1,
  ),
  'terror' => 
  array (
    'settled' => 1,
    'moved' => 1,
    'at' => 1,
  ),
  'watching' => 
  array (
    'people' => 1,
    '' => 2,
    'a' => 1,
  ),
  'crowds' => 
  array (
    '' => 1,
  ),
  'iron' => 
  array (
    'fillings' => 1,
    'mallets;' => 1,
    'mallets.' => 1,
  ),
  'fillings' => 
  array (
    'on' => 1,
  ),
  'board' => 
  array (
    'and' => 1,
  ),
  'magnet' => 
  array (
    'was' => 1,
  ),
  'sprouted' => 
  array (
    'again,' => 1,
  ),
  'fleeing' => 
  array (
    'panic,' => 1,
  ),
  'panic,' => 
  array (
    'but' => 1,
  ),
  'nowhere' => 
  array (
    'to' => 1,
    'in' => 1,
  ),
  'flee' => 
  array (
    'to.' => 1,
  ),
  'to.' => 
  array (
    'Observing' => 1,
    'Today' => 1,
    'Just' => 1,
    'No' => 1,
    '' => 1,
    '-' => 1,
    'Ford' => 1,
  ),
  'Observing' => 
  array (
    'this,' => 1,
  ),
  'this,' => 
  array (
    'the' => 1,
    '-' => 2,
    'transcend' => 1,
    '' => 1,
    'and' => 2,
    'Arthur' => 1,
    'Earthman,' => 1,
    'Beeblebrox,' => 1,
  ),
  'Vogons' => 
  array (
    'turned' => 1,
    'had' => 2,
    '' => 3,
    'cut' => 1,
    'would' => 1,
    'sat' => 1,
    'suddenly' => 1,
    'themselves.' => 1,
    'or' => 1,
    'run' => 1,
    'now' => 1,
    'talk?' => 1,
    'suffered' => 1,
    'arrived.' => 1,
    'came' => 1,
    'quite' => 1,
  ),
  'acting' => 
  array (
    'all' => 1,
  ),
  'charts' => 
  array (
    'and' => 1,
  ),
  'demolition' => 
  array (
    'orders' => 1,
    'beams.' => 1,
  ),
  'orders' => 
  array (
    'have' => 1,
    'signed' => 1,
  ),
  'department' => 
  array (
    'on' => 1,
    'now' => 1,
  ),
  'Alpha' => 
  array (
    'Centauri' => 2,
    'Centauri?' => 1,
    'Proxima.' => 1,
    'Centauri.' => 1,
  ),
  'Centauri' => 
  array (
    'for' => 1,
    '' => 1,
  ),
  'fifty' => 
  array (
    'of' => 1,
    'metres' => 1,
    'thousand' => 2,
    'yards' => 1,
  ),
  'plenty' => 
  array (
    'of' => 1,
  ),
  'lodge' => 
  array (
    'any' => 1,
  ),
  'formal' => 
  array (
    'complaint' => 1,
  ),
  'complaint' => 
  array (
    'and' => 1,
  ),
  'late' => 
  array (
    '' => 1,
    'Dentarthurdent,' => 1,
  ),
  'fuss' => 
  array (
    'about' => 1,
    '' => 1,
  ),
  'echo' => 
  array (
    'drifted' => 1,
  ),
  'drifted' => 
  array (
    'off' => 2,
    'on' => 1,
    'quietly' => 1,
    'across' => 1,
  ),
  'land.' => 
  array (
    'The' => 1,
    '-' => 1,
    'Bits' => 1,
    'As' => 1,
    'R' => 1,
  ),
  'easy' => 
  array (
    'power.' => 1,
    'being' => 2,
  ),
  'underside' => 
  array (
    'of' => 1,
  ),
  'hatchway' => 
  array (
    'opened,' => 1,
    'of' => 1,
    'swung' => 1,
    'into' => 1,
    'sealed' => 1,
    'in' => 1,
    'opened' => 1,
    'that' => 1,
    'opened.' => 1,
    'again.' => 1,
    '' => 1,
  ),
  'opened,' => 
  array (
    'an' => 1,
  ),
  'space.' => 
  array (
    'By' => 1,
    '-' => 4,
    'Listen...' => 1,
    '' => 1,
  ),
  'manned' => 
  array (
    'a' => 1,
  ),
  'transmitter,' => 
  array (
    'located' => 1,
  ),
  'located' => 
  array (
    'a' => 1,
  ),
  'wavelength' => 
  array (
    'and' => 1,
  ),
  'broadcasted' => 
  array (
    'a' => 1,
  ),
  'message' => 
  array (
    'back' => 1,
    '' => 2,
    'was' => 1,
  ),
  'ships,' => 
  array (
    'to' => 1,
    'and' => 1,
  ),
  'plead' => 
  array (
    'on' => 1,
  ),
  'behalf' => 
  array (
    'of' => 1,
  ),
  'planet.' => 
  array (
    'Nobody' => 1,
    'It' => 2,
    'This' => 1,
    'Zaphod' => 1,
    '-' => 2,
    'And' => 1,
    'Magrathea,' => 1,
    'Armed' => 1,
  ),
  'Nobody' => 
  array (
    'ever' => 1,
  ),
  'reply.' => 
  array (
    'The' => 1,
  ),
  'slammed' => 
  array (
    '' => 2,
  ),
  'annoyed.' => 
  array (
    'It' => 1,
  ),
  'Centauri?' => 
  array (
    'For' => 1,
  ),
  'heaven\'s' => 
  array (
    'sake' => 1,
  ),
  'sake' => 
  array (
    'mankind,' => 1,
    'of' => 2,
    'I' => 1,
  ),
  'mankind,' => 
  array (
    'it\'s' => 1,
  ),
  'interest' => 
  array (
    'in' => 2,
    'and' => 1,
    'you...' => 1,
  ),
  'affairs' => 
  array (
    'that\'s' => 1,
    'of' => 1,
  ),
  'lookout.' => 
  array (
    '-' => 1,
  ),
  'Energize' => 
  array (
    'the' => 1,
  ),
  'beams.' => 
  array (
    'Light' => 1,
  ),
  'Light' => 
  array (
    'poured' => 1,
    'on' => 1,
    'and' => 1,
  ),
  'poured' => 
  array (
    'out' => 1,
  ),
  'hatchways.' => 
  array (
    '-' => 1,
  ),
  'PA,' => 
  array (
    '' => 1,
  ),
  'apathetic' => 
  array (
    '' => 1,
  ),
  'planet,' => 
  array (
    'I\'ve' => 1,
    'just' => 1,
    '-' => 5,
    '' => 1,
    'it' => 1,
    'and' => 1,
  ),
  'sympathy' => 
  array (
    'at' => 1,
  ),
  'cut' => 
  array (
    'off.' => 1,
    'down' => 1,
    'out.' => 1,
    'into' => 1,
    'in' => 3,
    'back' => 1,
    'open,' => 1,
  ),
  'off.' => 
  array (
    'There' => 1,
    'Grunthos' => 1,
    '-' => 3,
    'The' => 1,
    'Zaphod' => 1,
    'It' => 1,
  ),
  'ghastly' => 
  array (
    'silence.' => 2,
    'noise.' => 1,
    'mistake,' => 1,
  ),
  'silence.' => 
  array (
    'There' => 1,
    'The' => 1,
    '-' => 1,
    'Curiously' => 1,
    '' => 1,
    'Then' => 1,
  ),
  'Constructor' => 
  array (
    'fleet' => 1,
    'Fleet.' => 1,
    'Fleets' => 1,
    'Fleets.' => 1,
  ),
  'fleet' => 
  array (
    'coasted' => 1,
    'was' => 1,
  ),
  'coasted' => 
  array (
    'away' => 1,
    'through' => 1,
  ),
  'inky' => 
  array (
    'starry' => 1,
  ),
  'starry' => 
  array (
    'void.' => 1,
  ),
  'void.' => 
  array (
    'Chapter' => 1,
    'She' => 1,
  ),
  4 => 
  array (
    'Far' => 1,
  ),
  'opposite' => 
  array (
    'spiral' => 1,
    'shore.' => 1,
    '' => 1,
    'direction.' => 1,
  ),
  'Zaphod' => 
  array (
    '' => 15,
    'Beeblebrox' => 10,
    'Beeblebrox.' => 3,
    'Beeblebrox?' => 3,
    'grinned' => 1,
    'Beeblebrox,' => 2,
    'had' => 3,
    'Beeblebrox\'s' => 2,
    'loved' => 1,
    'stepped' => 1,
    'smiled,' => 1,
    'claimed.' => 1,
    'burst' => 1,
    'and' => 5,
    'leaped' => 1,
    'Beeblebrox...?' => 1,
    'searched' => 1,
    'waved' => 1,
    'turned' => 1,
    'glared' => 1,
    'with' => 6,
    'scribbled' => 1,
    'knocked' => 1,
    'Beeblebrox...' => 1,
    'Beeb...' => 1,
    'gave' => 1,
    'shook' => 1,
    'breezily.' => 1,
    'looked' => 2,
    'let' => 1,
    'couldn\'t' => 1,
    'heard' => 1,
    'laughed.' => 1,
    'airily,' => 1,
    'hadn\'t' => 1,
    'on' => 1,
    'stared' => 4,
    'screamed' => 1,
    'leapt' => 1,
    'glanced' => 1,
    'tapped' => 1,
    'trying' => 1,
    'again,' => 1,
    'was' => 2,
    'standing' => 1,
    'hit' => 1,
    'shone' => 1,
    'scrambled' => 1,
    'marched' => 1,
    'into' => 1,
    'paused' => 1,
    'as' => 1,
    'petulantly.' => 1,
    'here' => 1,
    'paused.' => 1,
    'quietly.' => 1,
    'old' => 1,
    'shrugged.' => 1,
    'thought' => 1,
    'sitting' => 1,
    'clinked' => 1,
    'promptingly.' => 1,
    'leaned' => 1,
    'got' => 1,
    'were' => 1,
    'back' => 1,
    'stuck' => 1,
    'lounged' => 1,
  ),
  'Beeblebrox,' => 
  array (
    '' => 2,
    'adventurer,' => 1,
    'became' => 1,
    'hold' => 1,
    'and' => 1,
  ),
  'President' => 
  array (
    '' => 6,
    'it' => 1,
    'of' => 7,
    'in' => 1,
    'and' => 1,
    'was' => 1,
    'always' => 1,
    'grinned.' => 1,
    'Zaphod' => 1,
    'Yooden' => 1,
  ),
  'Imperial' => 
  array (
    'Galactic' => 2,
    '' => 1,
    'Galaxy' => 1,
    'is' => 1,
  ),
  'Government,' => 
  array (
    'sped' => 1,
    'not' => 1,
  ),
  'sped' => 
  array (
    'across' => 1,
    'on' => 1,
    'on.' => 1,
    'swiftly.' => 1,
  ),
  'Damogran,' => 
  array (
    '' => 1,
    'secret' => 1,
  ),
  'ion' => 
  array (
    'drive' => 1,
  ),
  'delta' => 
  array (
    'boat' => 1,
    '' => 1,
  ),
  'boat' => 
  array (
    'winking' => 1,
    'sped' => 2,
    'zipped' => 1,
    'an' => 1,
    'across' => 1,
    '' => 1,
  ),
  'flashing' => 
  array (
    'in' => 1,
    'lights' => 1,
    'over' => 1,
  ),
  'Damogran' => 
  array (
    'sun.' => 1,
    'the' => 2,
    '' => 4,
    'has' => 1,
    'for' => 2,
    'he' => 1,
    'sea' => 1,
    'Frond' => 1,
  ),
  'hot;' => 
  array (
    'Damogran' => 1,
  ),
  'remote;' => 
  array (
    'Damogran' => 1,
  ),
  'totally' => 
  array (
    'unheard' => 1,
    'clear' => 1,
    'new' => 1,
    'staggering' => 1,
    'failed' => 1,
    '' => 1,
    'impossible' => 1,
    'invisible' => 1,
    'other,' => 1,
  ),
  'unheard' => 
  array (
    'of.' => 2,
  ),
  'of.' => 
  array (
    'Damogran,' => 1,
    'Ford' => 1,
    '' => 2,
    'He' => 1,
  ),
  'secret' => 
  array (
    'home' => 1,
    'is' => 1,
    'that' => 1,
  ),
  'Heart' => 
  array (
    'of' => 16,
    '' => 6,
  ),
  'Gold.' => 
  array (
    'The' => 2,
    '-' => 1,
    '' => 1,
    'It' => 1,
    'Chapter' => 1,
  ),
  'destination' => 
  array (
    '' => 1,
  ),
  'arranged' => 
  array (
    'planet.' => 1,
  ),
  'consists' => 
  array (
    'of' => 1,
  ),
  'middling' => 
  array (
    '' => 1,
  ),
  'islands' => 
  array (
    'separated' => 1,
    'of' => 1,
  ),
  'separated' => 
  array (
    'by' => 1,
  ),
  'annoyingly' => 
  array (
    'wide' => 1,
  ),
  'wide' => 
  array (
    'stretches' => 1,
    'skidding' => 1,
    'semi-circular' => 1,
    '' => 4,
    'open-plan' => 1,
  ),
  'stretches' => 
  array (
    'of' => 1,
  ),
  'ocean.' => 
  array (
    'The' => 1,
  ),
  'topological' => 
  array (
    'awkwardness' => 1,
  ),
  'awkwardness' => 
  array (
    'Damogran' => 1,
  ),
  'deserted' => 
  array (
    'planet.' => 1,
    'and' => 1,
  ),
  'Government' => 
  array (
    '' => 1,
    'have' => 1,
    'archives.' => 1,
  ),
  'chose' => 
  array (
    'Damogran' => 1,
  ),
  'Gold' => 
  array (
    'project,' => 1,
    'was' => 3,
    'island,' => 1,
    '' => 4,
    '-' => 1,
    'fled' => 1,
    'streaked' => 1,
    'continued' => 1,
    'to' => 1,
    'which' => 1,
    'suffering' => 1,
  ),
  'project,' => 
  array (
    'because' => 1,
    'the' => 1,
  ),
  'secret.' => 
  array (
    'The' => 1,
  ),
  'zipped' => 
  array (
    'and' => 1,
    'round' => 1,
  ),
  'skipped' => 
  array (
    'across' => 1,
    'his' => 1,
  ),
  'sea,' => 
  array (
    'the' => 1,
  ),
  'between' => 
  array (
    'the' => 6,
    'them' => 1,
    'different' => 1,
    'its' => 1,
    '' => 4,
    'Arthur' => 1,
    'people' => 1,
    'atoms' => 1,
    'spending' => 1,
    'a' => 1,
    'two' => 2,
    'itself' => 1,
  ),
  'main' => 
  array (
    'islands' => 1,
    'reason' => 1,
    '' => 1,
    'console' => 1,
    'computer' => 1,
  ),
  'archipelago' => 
  array (
    'of' => 1,
  ),
  'Beeblebrox' => 
  array (
    'was' => 2,
    'had' => 1,
    'is' => 1,
    'stepped' => 1,
    'would' => 1,
    'to' => 1,
    'paced' => 1,
    'from' => 1,
    '-' => 1,
    'said:' => 1,
  ),
  'spaceport' => 
  array (
    'on' => 1,
  ),
  'Easter' => 
  array (
    'Island' => 1,
  ),
  'Island' => 
  array (
    '' => 1,
  ),
  '(the' => 
  array (
    '' => 1,
    'one' => 1,
  ),
  'entirely' => 
  array (
    '' => 5,
    'separate' => 1,
    'unlike' => 1,
    'by' => 1,
    'given' => 1,
    'reassuringly.' => 1,
    'naked' => 1,
  ),
  'meaningless' => 
  array (
    '' => 1,
    'coincidence' => 1,
    'coincidences.' => 1,
    'coincidence.' => 1,
  ),
  'coincidence' => 
  array (
    '' => 3,
    'was' => 1,
    'that' => 2,
    'isn\'t' => 1,
  ),
  'Galacticspeke,' => 
  array (
    'easter' => 1,
  ),
  'easter' => 
  array (
    'means' => 1,
  ),
  'brown)' => 
  array (
    'to' => 1,
  ),
  'island,' => 
  array (
    'which' => 1,
  ),
  'France.' => 
  array (
    'One' => 1,
  ),
  'One' => 
  array (
    'of' => 4,
    '' => 2,
    'word!' => 1,
    'Midsummer' => 1,
    'whole' => 1,
    'day,' => 1,
    'cop' => 1,
  ),
  'string' => 
  array (
    'of' => 1,
  ),
  'coincidences.' => 
  array (
    'But' => 1,
  ),
  'culmination' => 
  array (
    'of' => 1,
    'for' => 1,
  ),
  'unveiling,' => 
  array (
    'the' => 1,
  ),
  'introduced' => 
  array (
    'to' => 1,
  ),
  'marvelling' => 
  array (
    '' => 1,
  ),
  'Beeblebrox.' => 
  array (
    'It' => 1,
    'Something' => 1,
    'And' => 1,
  ),
  'Presidency,' => 
  array (
    '' => 1,
  ),
  'decision' => 
  array (
    'which' => 1,
    'suddenly' => 1,
  ),
  'sent' => 
  array (
    'waves' => 1,
    'in,' => 1,
    'back,' => 1,
    '' => 2,
    'for' => 1,
    'into' => 1,
    'to' => 1,
  ),
  'waves' => 
  array (
    '' => 1,
    'of' => 1,
  ),
  'astonishment' => 
  array (
    '' => 1,
    'at' => 1,
    'for' => 1,
  ),
  'throughout' => 
  array (
    '' => 2,
    'a' => 1,
    'Magrathea.' => 1,
  ),
  'Beeblebrox?' => 
  array (
    'President?' => 1,
    'Not' => 1,
    '-' => 1,
  ),
  'President?' => 
  array (
    'Not' => 1,
    'Many' => 1,
    'No' => 1,
    'Shortly' => 1,
  ),
  'clinching' => 
  array (
    'proof' => 1,
    '' => 1,
  ),
  'proof' => 
  array (
    'that' => 1,
    '' => 2,
  ),
  'creation' => 
  array (
    'had' => 1,
    'and' => 1,
  ),
  'bananas.' => 
  array (
    'Zaphod' => 1,
  ),
  'extra' => 
  array (
    'kick' => 1,
    'arm' => 2,
    'head' => 1,
    '' => 1,
  ),
  'kick' => 
  array (
    'of' => 1,
    'through' => 1,
    '' => 1,
    'at' => 1,
    'you?' => 1,
  ),
  'speed.' => 
  array (
    'Zaphod' => 1,
    'They' => 1,
  ),
  'adventurer,' => 
  array (
    'ex-hippy,' => 1,
  ),
  'ex-hippy,' => 
  array (
    'good' => 1,
  ),
  'timer,' => 
  array (
    '' => 1,
  ),
  '(crook?' => 
  array (
    '' => 1,
  ),
  'possibly),' => 
  array (
    'manic' => 1,
  ),
  'manic' => 
  array (
    'self-publicist,' => 1,
    'desperation' => 1,
  ),
  'self-publicist,' => 
  array (
    'terribly' => 1,
  ),
  'personal' => 
  array (
    '' => 1,
  ),
  'relationships,' => 
  array (
    'often' => 1,
  ),
  'completely' => 
  array (
    'out' => 1,
    'failed' => 1,
    'unidentifiable,' => 1,
    'wrong,' => 1,
    'unharmed' => 1,
    'at' => 1,
    'inert.' => 1,
    'misinterpreted' => 1,
    'dead.' => 1,
  ),
  'lunch.' => 
  array (
    'President?' => 1,
    'A' => 1,
  ),
  'No' => 
  array (
    'one' => 4,
    'light,' => 1,
    'reaction.' => 3,
    'Zaphod.' => 1,
    'no' => 2,
    'government' => 1,
    'stars?' => 1,
    'planets?' => 1,
    'no,' => 1,
    'we' => 1,
    'thank' => 1,
    '-' => 1,
    'follow-up,' => 1,
    'you' => 2,
    'answer.' => 1,
    'I' => 1,
  ),
  'bananas,' => 
  array (
    'not' => 1,
  ),
  'least.' => 
  array (
    'Only' => 1,
    'They' => 1,
  ),
  'entire' => 
  array (
    '' => 2,
    'planet' => 3,
    'life\'s' => 1,
    'battle' => 1,
    'multi-dimensional' => 1,
  ),
  'understood' => 
  array (
    '' => 4,
  ),
  'principle' => 
  array (
    '' => 2,
    'of' => 1,
  ),
  'governed,' => 
  array (
    'and' => 1,
  ),
  'announced' => 
  array (
    'his' => 1,
    'that' => 1,
    'itself' => 1,
    'the' => 1,
  ),
  'intention' => 
  array (
    'to' => 1,
  ),
  'fait' => 
  array (
    'accompli:' => 1,
  ),
  'accompli:' => 
  array (
    'he' => 1,
  ),
  'ideal' => 
  array (
    'Presidency' => 1,
  ),
  'Presidency' => 
  array (
    'fodder' => 1,
    '' => 1,
    'could' => 1,
  ),
  'fodder' => 
  array (
    '<President:' => 1,
  ),
  '<President:' => 
  array (
    'full' => 1,
  ),
  'title' => 
  array (
    'President' => 1,
  ),
  'Government.' => 
  array (
    'The' => 1,
  ),
  'term' => 
  array (
    'Imperial' => 1,
  ),
  'kept' => 
  array (
    'though' => 1,
    '' => 1,
    'them' => 1,
    'saying' => 1,
  ),
  'anachronism.' => 
  array (
    'The' => 1,
  ),
  'hereditary' => 
  array (
    'Emperor' => 1,
  ),
  'Emperor' => 
  array (
    'is' => 1,
    '-' => 1,
  ),
  'centuries.' => 
  array (
    '' => 1,
    'Eventually' => 1,
  ),
  'dying' => 
  array (
    'coma' => 1,
  ),
  'coma' => 
  array (
    'he' => 1,
  ),
  'statis' => 
  array (
    'field' => 1,
  ),
  'field' => 
  array (
    'which' => 1,
    '' => 2,
  ),
  'keeps' => 
  array (
    '' => 2,
  ),
  'state' => 
  array (
    'of' => 1,
    'prison.' => 1,
  ),
  'perpetual' => 
  array (
    'unchangingness.' => 1,
    '' => 1,
  ),
  'unchangingness.' => 
  array (
    'All' => 1,
  ),
  'heirs' => 
  array (
    'are' => 1,
  ),
  'dead,' => 
  array (
    'and' => 1,
  ),
  'drastic' => 
  array (
    '' => 1,
  ),
  'political' => 
  array (
    '' => 1,
    'power' => 1,
    'hub' => 1,
    'economy.' => 1,
  ),
  'upheaval,' => 
  array (
    '' => 1,
  ),
  'power' => 
  array (
    '' => 6,
    'whatsoever.' => 1,
    'but' => 1,
    'at' => 1,
    'is' => 1,
    'of' => 6,
    'feeds' => 1,
  ),
  'effectively' => 
  array (
    'moved' => 1,
    '' => 2,
  ),
  'rung' => 
  array (
    'or' => 1,
  ),
  'ladder,' => 
  array (
    '' => 1,
  ),
  'vested' => 
  array (
    'in' => 1,
  ),
  'body' => 
  array (
    'which' => 1,
    '' => 3,
    '-' => 1,
    'softening' => 1,
    'didn\'t' => 1,
    'to' => 1,
  ),
  'act' => 
  array (
    'simply' => 1,
    'as' => 1,
    'of' => 1,
  ),
  'advisers' => 
  array (
    '' => 1,
  ),
  'elected' => 
  array (
    'Governmental' => 1,
    'by' => 1,
  ),
  'Governmental' => 
  array (
    'assembly' => 1,
  ),
  'assembly' => 
  array (
    'headed' => 1,
  ),
  'headed' => 
  array (
    'by' => 1,
    'back' => 3,
    'downwards' => 1,
  ),
  'assembly.' => 
  array (
    'In' => 1,
  ),
  'vests' => 
  array (
    'in' => 1,
  ),
  'figurehead' => 
  array (
    '-' => 1,
  ),
  'wields' => 
  array (
    '' => 1,
  ),
  'real' => 
  array (
    'power' => 1,
    'cool' => 1,
    'universe' => 1,
    '' => 2,
    'women,' => 1,
    'small' => 1,
    'pleasure' => 1,
    'rockets' => 1,
    'natures,' => 1,
    'brutes' => 1,
    'truth,' => 1,
  ),
  'whatsoever.' => 
  array (
    'He' => 1,
    'Chapter' => 1,
  ),
  'apparently' => 
  array (
    'chosen' => 1,
    'unconcerned' => 1,
    '' => 1,
    'to' => 1,
    'touching' => 1,
    'non-existent' => 1,
  ),
  'chosen' => 
  array (
    'by' => 1,
    'to' => 2,
  ),
  'government,' => 
  array (
    'but' => 1,
  ),
  'qualities' => 
  array (
    'he' => 1,
    '' => 1,
  ),
  'required' => 
  array (
    'to' => 1,
    'looking' => 1,
    'data' => 1,
  ),
  'leadership' => 
  array (
    'but' => 1,
  ),
  'finely' => 
  array (
    'judged' => 1,
    'calculated' => 2,
  ),
  'judged' => 
  array (
    'outrage.' => 1,
  ),
  'outrage.' => 
  array (
    'For' => 1,
  ),
  'choice,' => 
  array (
    'always' => 1,
  ),
  'infuriating' => 
  array (
    'but' => 1,
  ),
  'fascinating' => 
  array (
    'character.' => 1,
  ),
  'character.' => 
  array (
    'His' => 1,
  ),
  'wield' => 
  array (
    'power' => 1,
    '' => 1,
  ),
  'draw' => 
  array (
    'attention' => 1,
    'breath' => 1,
  ),
  'criteria' => 
  array (
    'Zaphod' => 1,
  ),
  'Presidents' => 
  array (
    '' => 1,
  ),
  'Presidential' => 
  array (
    'years' => 1,
    'speedboat' => 1,
    'quote,' => 1,
  ),
  'prison' => 
  array (
    'for' => 1,
  ),
  'fraud.' => 
  array (
    'Very' => 1,
  ),
  'virtually' => 
  array (
    'no' => 1,
    'impossible' => 1,
    'extinct' => 1,
    'impossible.' => 1,
  ),
  'whence' => 
  array (
    'ultimate' => 1,
    'they' => 1,
  ),
  'wielded.' => 
  array (
    '' => 1,
  ),
  'others' => 
  array (
    'secretly' => 1,
    'followed' => 1,
    '' => 2,
    'swerved' => 1,
    'we' => 1,
  ),
  'secretly' => 
  array (
    'believe' => 1,
  ),
  'decision-making' => 
  array (
    '' => 1,
  ),
  'handled' => 
  array (
    'by' => 1,
    '' => 1,
  ),
  'computer.' => 
  array (
    'They' => 1,
    '-' => 4,
    'Several' => 1,
    'With' => 1,
    'Cautiously' => 1,
  ),
  'wrong.>' => 
  array (
    'What' => 1,
  ),
  'banked' => 
  array (
    'sharply,' => 1,
    'round' => 1,
  ),
  'sharply,' => 
  array (
    'shooting' => 1,
    '' => 3,
  ),
  'shooting' => 
  array (
    'a' => 1,
    'at' => 2,
    'people' => 2,
  ),
  'wild' => 
  array (
    'wall' => 1,
    'scything' => 1,
    'whoop' => 1,
    '' => 4,
    'Event' => 1,
    'coincidence' => 1,
    'guess,' => 1,
  ),
  'wall' => 
  array (
    'of' => 3,
    'again' => 1,
    'when' => 2,
    'met' => 1,
    '' => 1,
    'behind' => 1,
    'defied' => 1,
    'was' => 1,
    'appeared' => 1,
    'formed' => 1,
    'a' => 1,
  ),
  'day;' => 
  array (
    'today' => 1,
  ),
  'today' => 
  array (
    'was' => 1,
    'would' => 1,
    '' => 1,
    'we' => 1,
  ),
  'Beeblebrox\'s' => 
  array (
    '' => 1,
    'highly' => 1,
  ),
  'hundredth' => 
  array (
    'birthday,' => 1,
  ),
  'birthday,' => 
  array (
    'but' => 1,
  ),
  'coincidence.' => 
  array (
    'As' => 1,
  ),
  'wonderful' => 
  array (
    'exciting' => 1,
    'new' => 1,
    '' => 2,
    'things' => 1,
  ),
  'exciting' => 
  array (
    'day' => 1,
  ),
  'lazily' => 
  array (
    'across' => 1,
    'along' => 1,
    'sail' => 1,
  ),
  'seat' => 
  array (
    '' => 2,
    'in' => 1,
    'round' => 1,
  ),
  'steered' => 
  array (
    'with' => 1,
  ),
  'recently' => 
  array (
    'fitted' => 1,
    'whilst' => 1,
    'ceased' => 1,
    'taken' => 1,
    'voted' => 1,
  ),
  'right' => 
  array (
    'one' => 1,
    'as' => 1,
    'to' => 1,
    '' => 2,
    'by' => 1,
    'there.' => 2,
    'in' => 1,
    'under' => 1,
    'through' => 1,
    'any' => 1,
    'up' => 1,
    'over' => 1,
    'between' => 1,
  ),
  'improve' => 
  array (
    'his' => 1,
  ),
  'ski-boxing.' => 
  array (
    '-' => 1,
  ),
  'cooed' => 
  array (
    'to' => 1,
  ),
  'cool' => 
  array (
    'boy' => 1,
    'guy.' => 1,
  ),
  'boy' => 
  array (
    'you.' => 1,
  ),
  'nerves' => 
  array (
    'sang' => 1,
  ),
  'sang' => 
  array (
    'a' => 1,
    'Eddie.' => 1,
  ),
  'song' => 
  array (
    'shriller' => 1,
  ),
  'shriller' => 
  array (
    'than' => 1,
  ),
  'dog' => 
  array (
    'whistle.' => 1,
    'stand' => 1,
  ),
  'whistle.' => 
  array (
    'The' => 1,
    '-' => 1,
  ),
  'island' => 
  array (
    'of' => 1,
    'in' => 1,
  ),
  'France' => 
  array (
    'was' => 1,
  ),
  'twenty' => 
  array (
    'miles' => 1,
    'thousand' => 1,
    'seconds,' => 1,
  ),
  'long,' => 
  array (
    'five' => 1,
    'shaped' => 1,
    'a' => 1,
    'or' => 1,
  ),
  'middle,' => 
  array (
    'sandy' => 1,
    'split,' => 1,
  ),
  'sandy' => 
  array (
    'and' => 1,
  ),
  'crescent' => 
  array (
    'shaped.' => 1,
    'consisted' => 1,
    'sliced' => 1,
    'blade,' => 1,
  ),
  'shaped.' => 
  array (
    'In' => 1,
  ),
  'defining' => 
  array (
    'the' => 1,
  ),
  'sweep' => 
  array (
    'and' => 1,
    'up' => 1,
  ),
  'curve' => 
  array (
    'of' => 3,
  ),
  'bay.' => 
  array (
    'This' => 1,
    'It' => 1,
    'Zaphod' => 1,
    'Pages' => 1,
    '' => 1,
  ),
  'heightened' => 
  array (
    'by' => 1,
  ),
  'inner' => 
  array (
    'coastline' => 1,
    '' => 1,
  ),
  'coastline' => 
  array (
    'of' => 1,
  ),
  'consisted' => 
  array (
    '' => 1,
    'in' => 1,
  ),
  'steep' => 
  array (
    'cliffs.' => 1,
  ),
  'cliffs.' => 
  array (
    'From' => 1,
  ),
  'From' => 
  array (
    'the' => 2,
    '' => 4,
    'time' => 1,
    'a' => 1,
  ),
  'cliff' => 
  array (
    'the' => 2,
    'face' => 1,
  ),
  'land' => 
  array (
    'sloped' => 1,
    'right' => 1,
    '' => 1,
    'masses' => 1,
    'on' => 1,
  ),
  'sloped' => 
  array (
    'slowly' => 1,
  ),
  'shore.' => 
  array (
    'On' => 1,
  ),
  'cliffs' => 
  array (
    'stood' => 1,
  ),
  'reception' => 
  array (
    'committee.' => 1,
  ),
  'committee.' => 
  array (
    'It' => 1,
  ),
  'part' => 
  array (
    'of' => 13,
    '' => 4,
  ),
  'engineers' => 
  array (
    'and' => 1,
    '' => 1,
  ),
  'researchers' => 
  array (
    '' => 1,
  ),
  'mostly' => 
  array (
    'humanoid,' => 1,
    'because' => 1,
    'lousy,' => 1,
    '' => 1,
    'white,' => 1,
    'I' => 1,
  ),
  'humanoid,' => 
  array (
    'but' => 1,
    'with' => 1,
  ),
  'reptiloid' => 
  array (
    'atomineers,' => 1,
  ),
  'atomineers,' => 
  array (
    'two' => 1,
  ),
  'slyph-like' => 
  array (
    'maximegalacticans,' => 1,
  ),
  'maximegalacticans,' => 
  array (
    '' => 1,
  ),
  'octopoid' => 
  array (
    '' => 1,
  ),
  'physucturalist' => 
  array (
    '' => 1,
  ),
  'Hooloovoo' => 
  array (
    '' => 4,
  ),
  'super-intelligent' => 
  array (
    'shade' => 1,
  ),
  'shade' => 
  array (
    'of' => 2,
  ),
  'color' => 
  array (
    'blue).' => 1,
    'green' => 1,
  ),
  'blue).' => 
  array (
    'All' => 1,
  ),
  'except' => 
  array (
    'the' => 1,
    'for' => 2,
    'some' => 1,
    'that' => 2,
  ),
  'resplendent' => 
  array (
    'in' => 2,
  ),
  'multicolored' => 
  array (
    'ceremonial' => 1,
  ),
  'ceremonial' => 
  array (
    'lab' => 1,
  ),
  'lab' => 
  array (
    'coats;' => 1,
    '' => 1,
  ),
  'coats;' => 
  array (
    'the' => 1,
  ),
  'temporarily' => 
  array (
    'refracted' => 1,
    'closed' => 1,
  ),
  'refracted' => 
  array (
    'into' => 1,
  ),
  'free' => 
  array (
    'standing' => 1,
  ),
  'prism' => 
  array (
    'for' => 1,
  ),
  'occasion.' => 
  array (
    'There' => 1,
  ),
  'mood' => 
  array (
    'of' => 1,
    'to' => 1,
    'music,' => 1,
  ),
  'excitement' => 
  array (
    'thrilling' => 1,
    'of' => 2,
    '' => 1,
  ),
  'thrilling' => 
  array (
    'through' => 1,
  ),
  'Together' => 
  array (
    'and' => 1,
  ),
  'beyond' => 
  array (
    'the' => 2,
    'their' => 1,
  ),
  'furthest' => 
  array (
    '' => 1,
    'stars,' => 1,
    'reaches' => 1,
  ),
  'limits' => 
  array (
    'of' => 1,
  ),
  'physical' => 
  array (
    'laws,' => 1,
    'violence' => 1,
    '' => 1,
  ),
  'laws,' => 
  array (
    'restructured' => 1,
  ),
  'restructured' => 
  array (
    'the' => 1,
  ),
  'fundamental' => 
  array (
    'fabric' => 1,
    'dichotomies' => 1,
  ),
  'fabric' => 
  array (
    'of' => 3,
  ),
  'matter,' => 
  array (
    'strained,' => 1,
  ),
  'strained,' => 
  array (
    'twisted' => 1,
  ),
  'twisted' => 
  array (
    'and' => 1,
    'the' => 1,
    'his' => 2,
    'sharply' => 1,
    '' => 1,
  ),
  'broken' => 
  array (
    'the' => 1,
  ),
  'laws' => 
  array (
    'of' => 1,
    '' => 1,
  ),
  'impossibility,' => 
  array (
    '' => 1,
    'then' => 1,
  ),
  'meet' => 
  array (
    'a' => 1,
    'the' => 1,
    '' => 1,
    'you,' => 1,
  ),
  'orange' => 
  array (
    'sash' => 3,
  ),
  'sash' => 
  array (
    'round' => 1,
    'was' => 1,
    'blazing' => 1,
  ),
  '(An' => 
  array (
    'orange' => 1,
  ),
  'traditionally' => 
  array (
    'wore.)' => 1,
  ),
  'wore.)' => 
  array (
    'It' => 1,
  ),
  'wielded:' => 
  array (
    'none' => 1,
  ),
  'attract' => 
  array (
    'attention' => 1,
  ),
  'job.' => 
  array (
    'The' => 1,
    'Arthur' => 1,
    'Fun,' => 1,
    'He' => 1,
  ),
  'crowd' => 
  array (
    'gasped,' => 1,
    'turned' => 1,
    'laughed' => 1,
    'over' => 1,
    'erupted' => 1,
  ),
  'gasped,' => 
  array (
    'dazzled' => 1,
  ),
  'dazzled' => 
  array (
    'by' => 1,
  ),
  'seemanship,' => 
  array (
    'as' => 1,
  ),
  'speedboat' => 
  array (
    'zipped' => 1,
  ),
  'headland' => 
  array (
    'into' => 1,
  ),
  'flashed' => 
  array (
    'and' => 1,
    'him' => 2,
    '' => 1,
    'silently' => 1,
    'up' => 1,
    'across' => 1,
    'a' => 1,
    'on' => 1,
    'above' => 1,
  ),
  'shone' => 
  array (
    '' => 2,
    'a' => 1,
  ),
  'skating' => 
  array (
    'over' => 1,
  ),
  'skidding' => 
  array (
    'turns.' => 1,
  ),
  'turns.' => 
  array (
    'In' => 1,
  ),
  'touch' => 
  array (
    'the' => 1,
    'sensitive' => 1,
  ),
  'supported' => 
  array (
    'on' => 1,
  ),
  'hazy' => 
  array (
    'cushion' => 1,
  ),
  'cushion' => 
  array (
    'of' => 1,
  ),
  'ionized' => 
  array (
    'atoms' => 1,
  ),
  'atoms' => 
  array (
    '-' => 1,
    'drifting' => 1,
    'and' => 1,
    '' => 1,
    'in' => 1,
  ),
  'thin' => 
  array (
    'finblades' => 1,
    'air.' => 1,
    '' => 1,
    'atmosphere' => 1,
    'stagnant' => 1,
    'air' => 2,
    'atmosphere.' => 1,
    'and' => 2,
    'metallic' => 1,
    'oxygen' => 1,
  ),
  'finblades' => 
  array (
    'which' => 1,
  ),
  'lowered' => 
  array (
    '' => 1,
  ),
  'slashed' => 
  array (
    'sheets' => 1,
  ),
  'sheets' => 
  array (
    'of' => 1,
  ),
  'hissing' => 
  array (
    'into' => 1,
  ),
  'carved' => 
  array (
    'deep' => 1,
    '' => 1,
  ),
  'gashes' => 
  array (
    'into' => 1,
  ),
  'swayed' => 
  array (
    'crazily' => 1,
  ),
  'crazily' => 
  array (
    'and' => 1,
  ),
  'sank' => 
  array (
    'back' => 1,
    'into' => 1,
  ),
  'foaming' => 
  array (
    'into' => 1,
  ),
  'boat\'s' => 
  array (
    'wake' => 1,
  ),
  'wake' => 
  array (
    'as' => 1,
    'up' => 1,
    'up.' => 1,
    'me' => 1,
    'you' => 1,
  ),
  'careered' => 
  array (
    'across' => 1,
  ),
  'loved' => 
  array (
    'effect:' => 1,
    '' => 1,
  ),
  'effect:' => 
  array (
    'it' => 1,
  ),
  'wheel' => 
  array (
    '' => 1,
  ),
  'scything' => 
  array (
    'skid' => 1,
  ),
  'skid' => 
  array (
    'beneath' => 1,
  ),
  'dropped' => 
  array (
    'to' => 1,
    'in' => 1,
    'out' => 1,
    'dizzily' => 1,
    '' => 1,
  ),
  'lightly' => 
  array (
    '' => 2,
    'fingering' => 1,
    'fried' => 1,
  ),
  'rocking' => 
  array (
    'waves.' => 1,
  ),
  'waves.' => 
  array (
    'Within' => 1,
  ),
  'Within' => 
  array (
    'seconds' => 1,
    'a' => 1,
  ),
  'onto' => 
  array (
    'the' => 2,
  ),
  'deck' => 
  array (
    'and' => 1,
  ),
  'billion' => 
  array (
    'people.' => 1,
    'people' => 1,
    'and' => 1,
    'stars' => 1,
    'visiting' => 1,
    'worlds,' => 1,
  ),
  'people.' => 
  array (
    'The' => 1,
    'Somewhere' => 1,
  ),
  'weren\'t' => 
  array (
    'actually' => 1,
    'going' => 1,
    'really' => 1,
  ),
  'gesture' => 
  array (
    'through' => 1,
  ),
  'robot' => 
  array (
    '' => 4,
    'camera' => 1,
    'sat' => 1,
    'much' => 1,
    'as' => 2,
    'say' => 1,
    'with' => 1,
    'still' => 1,
    'up' => 1,
    'is' => 1,
    'obediently' => 1,
    'yours?' => 1,
  ),
  'tri-D' => 
  array (
    'camera' => 1,
  ),
  'camera' => 
  array (
    'which' => 1,
    'homed' => 1,
  ),
  'hovered' => 
  array (
    'obsequiously' => 1,
  ),
  'obsequiously' => 
  array (
    'in' => 1,
  ),
  'nearby.' => 
  array (
    '' => 1,
  ),
  'antics' => 
  array (
    '' => 1,
  ),
  'tri-D;' => 
  array (
    'that\'s' => 1,
  ),
  'bigger' => 
  array (
    'antic' => 1,
  ),
  'antic' => 
  array (
    'than' => 1,
  ),
  'bargained' => 
  array (
    'for.' => 1,
  ),
  'homed' => 
  array (
    'in' => 1,
  ),
  'close' => 
  array (
    'up' => 1,
    'to.' => 1,
    'itself' => 1,
    'again' => 1,
    'focus' => 1,
  ),
  'heads' => 
  array (
    'and' => 3,
    'looked' => 2,
    'up' => 1,
    'together' => 1,
    '-' => 1,
  ),
  'humanoid' => 
  array (
    'in' => 1,
    'body' => 1,
  ),
  'appearance' => 
  array (
    'except' => 1,
  ),
  'arm.' => 
  array (
    'His' => 1,
    '' => 1,
  ),
  'fair' => 
  array (
    '' => 1,
    'though,' => 1,
    'on' => 1,
  ),
  'tousled' => 
  array (
    '' => 1,
  ),
  'random' => 
  array (
    '' => 1,
    'group' => 1,
  ),
  'directions,' => 
  array (
    '' => 1,
  ),
  'glinted' => 
  array (
    '' => 1,
  ),
  'unidentifiable,' => 
  array (
    'and' => 1,
  ),
  'chins' => 
  array (
    'were' => 1,
  ),
  'unshaven.' => 
  array (
    'A' => 1,
  ),
  'twenty-foot-high' => 
  array (
    '' => 1,
  ),
  'transparent' => 
  array (
    '' => 1,
  ),
  'globe' => 
  array (
    '' => 1,
    'bobbed' => 1,
    'and' => 1,
    'wavered' => 1,
  ),
  'floated' => 
  array (
    '' => 2,
    'through' => 1,
  ),
  'boat,' => 
  array (
    'rolling' => 1,
  ),
  'bobbing,' => 
  array (
    'glistening' => 1,
  ),
  'glistening' => 
  array (
    'in' => 1,
  ),
  'Inside' => 
  array (
    'it' => 1,
    'a' => 1,
  ),
  'semi-circular' => 
  array (
    'sofa' => 1,
  ),
  'upholstered' => 
  array (
    'in' => 1,
    'rock.' => 1,
  ),
  'glorious' => 
  array (
    'red' => 1,
    'days' => 1,
  ),
  'red' => 
  array (
    'leather:' => 1,
    'head' => 1,
    'button' => 1,
    '' => 4,
    'star' => 1,
    'lumps.' => 1,
  ),
  'leather:' => 
  array (
    'the' => 1,
  ),
  'bobbed' => 
  array (
    'and' => 2,
  ),
  'rolled,' => 
  array (
    'the' => 1,
  ),
  'stayed' => 
  array (
    'perfectly' => 1,
  ),
  'still,' => 
  array (
    '' => 1,
  ),
  'rock.' => 
  array (
    'Again,' => 1,
    'Dawn\'s' => 1,
  ),
  'Again,' => 
  array (
    'all' => 1,
    'a' => 1,
  ),
  'done' => 
  array (
    'for' => 1,
    'not' => 1,
    'it!' => 1,
    '' => 1,
    'was' => 1,
  ),
  'stepped' => 
  array (
    'through' => 2,
    'out' => 2,
    'forward' => 1,
    '' => 1,
    'down' => 1,
    'in.' => 1,
  ),
  'sofa.' => 
  array (
    'He' => 1,
  ),
  'knee.' => 
  array (
    'His' => 1,
  ),
  'about,' => 
  array (
    'smiling;' => 1,
    'but' => 1,
    '' => 2,
    'you' => 1,
    'so' => 1,
  ),
  'smiling;' => 
  array (
    'he' => 1,
  ),
  'scream.' => 
  array (
    'Water' => 1,
  ),
  'Water' => 
  array (
    'boiled' => 1,
  ),
  'boiled' => 
  array (
    'up' => 1,
    'away' => 1,
  ),
  'bubble,' => 
  array (
    '' => 1,
    'his' => 1,
  ),
  'seethed' => 
  array (
    '' => 1,
  ),
  'spouted.' => 
  array (
    '' => 1,
  ),
  'surged' => 
  array (
    'into' => 1,
    '' => 1,
  ),
  'bobbing' => 
  array (
    'and' => 1,
    'movement' => 1,
  ),
  'spout.' => 
  array (
    'Up,' => 1,
  ),
  'Up,' => 
  array (
    'up' => 1,
  ),
  'climbed,' => 
  array (
    'throwing' => 1,
    'apparently' => 1,
  ),
  'throwing' => 
  array (
    'stilts' => 1,
    '' => 1,
  ),
  'stilts' => 
  array (
    'of' => 1,
  ),
  'cliff.' => 
  array (
    'Up' => 1,
  ),
  'Up' => 
  array (
    '' => 1,
    'For' => 1,
  ),
  'jet,' => 
  array (
    'the' => 1,
  ),
  'falling' => 
  array (
    '' => 2,
    'asleep' => 1,
  ),
  'crashing' => 
  array (
    '' => 1,
  ),
  'hundreds' => 
  array (
    'of' => 1,
  ),
  'below.' => 
  array (
    'Zaphod' => 1,
  ),
  'picturing' => 
  array (
    'himself.' => 1,
  ),
  'thoroughly' => 
  array (
    'ridiculous' => 1,
    'beautiful' => 1,
    'vile.' => 1,
    'killed' => 1,
    'preoccupied' => 1,
    'squalid.' => 1,
    'rolling' => 1,
  ),
  'ridiculous' => 
  array (
    'form' => 1,
  ),
  'transport,' => 
  array (
    'but' => 1,
  ),
  'beautiful' => 
  array (
    'one.' => 1,
    'planet' => 1,
    '' => 1,
    'wrought-iron' => 1,
    'place.' => 1,
  ),
  'wavered' => 
  array (
    'for' => 1,
  ),
  'tipped' => 
  array (
    'on' => 1,
    'boots,' => 1,
  ),
  'railed' => 
  array (
    'ramp,' => 1,
  ),
  'ramp,' => 
  array (
    'rolled' => 1,
  ),
  'concave' => 
  array (
    'platform' => 1,
    '' => 1,
  ),
  'platform' => 
  array (
    'and' => 1,
  ),
  'riddled' => 
  array (
    'to' => 1,
  ),
  'halt.' => 
  array (
    'To' => 1,
    'He' => 1,
  ),
  'To' => 
  array (
    'tremendous' => 1,
    '' => 1,
    'Arthur\'s' => 1,
    'be' => 1,
    'Be' => 1,
    'Everything?' => 1,
    'the' => 1,
    'business!' => 1,
  ),
  'tremendous' => 
  array (
    'applause' => 1,
    'difficulty' => 2,
    '' => 1,
  ),
  'applause' => 
  array (
    'Zaphod' => 1,
    'to' => 1,
  ),
  'light.' => 
  array (
    'The' => 1,
    'One' => 1,
    '-' => 2,
    'Ford' => 1,
    'It' => 2,
    'Chapter' => 1,
  ),
  'arrived.' => 
  array (
    'He' => 1,
    'The' => 1,
  ),
  'raised' => 
  array (
    '' => 1,
    'her' => 1,
    'a' => 1,
    'his' => 2,
    'families' => 1,
  ),
  'hands' => 
  array (
    '' => 6,
    'over' => 1,
    'with' => 1,
  ),
  'greeting.' => 
  array (
    '-' => 1,
  ),
  'Hi,' => 
  array (
    '-' => 4,
  ),
  'government' => 
  array (
    'spider' => 1,
    'research' => 1,
    'owns' => 2,
    '' => 1,
    'screening' => 1,
  ),
  'spider' => 
  array (
    'sidled' => 1,
  ),
  'sidled' => 
  array (
    'up' => 1,
    'into' => 1,
  ),
  'attempted' => 
  array (
    'to' => 2,
    '' => 1,
  ),
  'prepared' => 
  array (
    'speech' => 1,
    'his' => 1,
    'for' => 1,
    'for.' => 1,
    'for...' => 1,
  ),
  'speech' => 
  array (
    'into' => 1,
    'and' => 1,
    'that' => 1,
    '' => 1,
    'patterns' => 1,
    'channel' => 1,
  ),
  'hands.' => 
  array (
    'Pages' => 1,
    '-' => 1,
    'Looked' => 1,
  ),
  'Pages' => 
  array (
    'three' => 1,
    'one' => 1,
  ),
  'seven' => 
  array (
    'of' => 1,
    'hundred' => 3,
    '' => 2,
    'and' => 2,
  ),
  'original' => 
  array (
    'version' => 1,
    'name' => 1,
    '' => 2,
    'entry' => 1,
    'purpose' => 1,
    'blueprints.' => 1,
  ),
  'version' => 
  array (
    'were' => 1,
  ),
  'floating' => 
  array (
    'soggily' => 1,
    '' => 1,
    'structure' => 1,
  ),
  'soggily' => 
  array (
    'on' => 1,
  ),
  'salvaged' => 
  array (
    'by' => 1,
  ),
  'Frond' => 
  array (
    '' => 2,
  ),
  'Crested' => 
  array (
    '' => 1,
    'Eagle' => 1,
  ),
  'Eagle' => 
  array (
    '' => 1,
    'had' => 1,
  ),
  'become' => 
  array (
    '' => 1,
    'captain' => 1,
    'President' => 4,
    'economists,' => 1,
    'too' => 1,
    'clear' => 1,
    'fashionable' => 1,
  ),
  'incorporated' => 
  array (
    '' => 1,
  ),
  'nest' => 
  array (
    '' => 1,
  ),
  'eagle' => 
  array (
    '' => 1,
    'to' => 1,
  ),
  'invented.' => 
  array (
    '' => 1,
  ),
  'constructed' => 
  array (
    'largely' => 1,
    'and' => 1,
    'yesterday.' => 1,
  ),
  'papier' => 
  array (
    'm@ch@' => 1,
  ),
  'm@ch@' => 
  array (
    'and' => 1,
  ),
  'impossible' => 
  array (
    'for' => 2,
    'to' => 3,
    '' => 1,
  ),
  'newly' => 
  array (
    'hatched' => 1,
    'occupied' => 1,
  ),
  'hatched' => 
  array (
    'baby' => 1,
  ),
  'baby' => 
  array (
    'eagle' => 1,
  ),
  'break' => 
  array (
    'out' => 1,
    'and' => 1,
    'the' => 1,
  ),
  'notion' => 
  array (
    'of' => 1,
  ),
  'survival' => 
  array (
    'of' => 1,
    '' => 1,
  ),
  'species' => 
  array (
    '' => 1,
    'on' => 1,
  ),
  'truck' => 
  array (
    'with' => 1,
  ),
  'needing' => 
  array (
    'his' => 1,
    'the' => 1,
  ),
  'gently' => 
  array (
    'deflected' => 1,
  ),
  'deflected' => 
  array (
    'the' => 1,
  ),
  'offered' => 
  array (
    'him' => 1,
    'Phouchg' => 1,
  ),
  'spider.' => 
  array (
    '-' => 1,
  ),
  'Everyone' => 
  array (
    'beamed' => 1,
    'gasped' => 1,
    'in' => 1,
  ),
  'beamed' => 
  array (
    'at' => 1,
  ),
  'or,' => 
  array (
    'at' => 1,
  ),
  'least,' => 
  array (
    'nearly' => 1,
    '-' => 1,
  ),
  'everyone.' => 
  array (
    'He' => 1,
    '-' => 1,
  ),
  'singled' => 
  array (
    'out' => 1,
  ),
  'Trillian' => 
  array (
    'from' => 1,
    'was' => 5,
    'wasn\'t' => 1,
    'who' => 1,
    'sat' => 2,
    'span' => 1,
    '' => 9,
    'had' => 2,
    'cocked' => 1,
    'in' => 1,
    'firmly.' => 1,
    'said' => 1,
    'to' => 1,
    'at' => 1,
    'pored' => 1,
    'gasped.' => 1,
    'wandering' => 1,
    'couldn\'t' => 1,
    'interrupted.' => 1,
    'and' => 3,
    'shivering.' => 1,
    'nervously.' => 1,
    'quietly,' => 1,
    'burst' => 1,
    'glared' => 1,
    'hugged' => 1,
    'with' => 1,
    'shrugged' => 1,
    'followed.' => 1,
    'did' => 1,
    'grabbed' => 1,
  ),
  'crowd.' => 
  array (
    'Trillian' => 1,
    'Flags,' => 1,
    '-' => 1,
    'He' => 1,
  ),
  'gird' => 
  array (
    'that' => 1,
  ),
  'picked' => 
  array (
    '' => 2,
    'up' => 6,
    'them' => 4,
    'up.' => 1,
    'me' => 1,
    'it' => 1,
  ),
  'visiting' => 
  array (
    'a' => 1,
    'tourists' => 1,
  ),
  'fun,' => 
  array (
    'incognito.' => 1,
    'though' => 1,
  ),
  'incognito.' => 
  array (
    'She' => 1,
  ),
  'She' => 
  array (
    'was' => 2,
    'just' => 1,
    'flashed' => 1,
    '' => 3,
    'sighed' => 1,
    'said,' => 1,
    'ignored' => 1,
    'scrabbled' => 1,
    'gave' => 1,
    'sat' => 1,
    'had' => 1,
    'watched' => 1,
    'wished' => 1,
    'motioned' => 1,
    'could' => 1,
    'looked' => 1,
    'screamed' => 1,
  ),
  'slim,' => 
  array (
    'darkish,' => 1,
  ),
  'darkish,' => 
  array (
    'humanoid,' => 1,
  ),
  'hair,' => 
  array (
    'a' => 1,
  ),
  'mouth,' => 
  array (
    '' => 1,
  ),
  'nob' => 
  array (
    'of' => 1,
  ),
  'ridiculously' => 
  array (
    'brown' => 1,
  ),
  'brown' => 
  array (
    'eyes.' => 1,
    'dress' => 1,
  ),
  'scarf' => 
  array (
    'knotted' => 1,
  ),
  'knotted' => 
  array (
    'in' => 1,
  ),
  'flowing' => 
  array (
    'silky' => 1,
  ),
  'silky' => 
  array (
    'brown' => 1,
  ),
  'dress' => 
  array (
    '' => 1,
    'party...' => 1,
  ),
  'Arabic.' => 
  array (
    'Not' => 1,
  ),
  'Arab' => 
  array (
    '' => 1,
  ),
  'Arabs' => 
  array (
    'had' => 1,
  ),
  'ceased' => 
  array (
    'to' => 1,
  ),
  'exist,' => 
  array (
    'and' => 2,
    '-' => 1,
  ),
  'existed' => 
  array (
    'they' => 1,
    'in' => 2,
    'anyway.' => 1,
    '' => 1,
  ),
  'Damogran.' => 
  array (
    'Trillian' => 1,
    'This,' => 1,
  ),
  'Hi' => 
  array (
    'honey,' => 1,
    'and' => 1,
    'fellas,' => 1,
    'there!' => 5,
    'gang!' => 1,
  ),
  'honey,' => 
  array (
    '-' => 1,
  ),
  'her.' => 
  array (
    'She' => 1,
    'I\'d' => 1,
  ),
  'tight' => 
  array (
    'smile' => 1,
    '' => 1,
    'ball,' => 1,
  ),
  'smile' => 
  array (
    'and' => 1,
    'again.' => 1,
    '' => 1,
    'which' => 1,
  ),
  'warmly' => 
  array (
    '-' => 1,
    '' => 1,
  ),
  'else.' => 
  array (
    '-' => 1,
    '' => 1,
    'Come' => 1,
  ),
  'knot' => 
  array (
    'of' => 1,
  ),
  'creatures' => 
  array (
    'from' => 3,
    'with' => 1,
    'you' => 1,
  ),
  'nearby' => 
  array (
    'wishing' => 1,
    'panel.' => 1,
    '' => 1,
  ),
  'wishing' => 
  array (
    'that' => 1,
  ),
  'quotes.' => 
  array (
    'He' => 1,
  ),
  'quote.' => 
  array (
    'The' => 1,
  ),
  'officials' => 
  array (
    'of' => 1,
  ),
  'party' => 
  array (
    'had' => 1,
    'and' => 1,
    'balloons' => 1,
    'found' => 1,
    'six' => 1,
  ),
  'irritably' => 
  array (
    'decided' => 1,
    'at' => 1,
    'round' => 1,
  ),
  'deliciously' => 
  array (
    'turned' => 1,
  ),
  'written' => 
  array (
    'for' => 1,
    '' => 1,
  ),
  'flipped' => 
  array (
    'the' => 1,
  ),
  'switch' => 
  array (
    'on' => 1,
    'over' => 1,
  ),
  'remote' => 
  array (
    '' => 2,
    'and' => 1,
    'that' => 1,
  ),
  'control' => 
  array (
    '' => 5,
    'seat' => 1,
    'and' => 2,
    'cabin' => 1,
    'seats' => 1,
    'panel.' => 1,
    'now.' => 1,
    'console' => 1,
  ),
  'pocket.' => 
  array (
    'Away' => 1,
    'Finally' => 1,
  ),
  'Away' => 
  array (
    'in' => 1,
  ),
  'white' => 
  array (
    'dome' => 1,
    '' => 4,
    'and' => 1,
    'holes' => 1,
    'fire.' => 1,
    'mice' => 2,
    'mice,' => 1,
    'concrete' => 1,
    'light' => 1,
    'coat' => 1,
  ),
  'dome' => 
  array (
    'that' => 1,
  ),
  'bulged' => 
  array (
    'against' => 1,
  ),
  'cracked' => 
  array (
    'down' => 1,
    'bell,' => 1,
    'it' => 1,
    '' => 1,
    'through' => 1,
  ),
  'split,' => 
  array (
    'and' => 1,
  ),
  'ground.' => 
  array (
    'Everyone' => 1,
    '-' => 1,
    'The' => 2,
    'He' => 1,
    'Twenty' => 1,
    '' => 1,
  ),
  'gasped' => 
  array (
    'although' => 1,
    'in' => 2,
    'Ford,' => 1,
  ),
  'although' => 
  array (
    'they' => 1,
  ),
  'uncovered' => 
  array (
    'a' => 1,
  ),
  'starship,' => 
  array (
    '' => 1,
  ),
  'metres' => 
  array (
    'long,' => 1,
  ),
  'shaped' => 
  array (
    '' => 1,
  ),
  'sleek' => 
  array (
    '' => 2,
  ),
  'shoe,' => 
  array (
    '' => 1,
  ),
  'beautiful.' => 
  array (
    'At' => 1,
    'Relaxing' => 1,
  ),
  'unseen,' => 
  array (
    'lay' => 1,
  ),
  'box' => 
  array (
    'which' => 1,
  ),
  'carried' => 
  array (
    'within' => 1,
    'on' => 3,
    'round' => 1,
    'on.' => 1,
    'itself.' => 1,
    'badly' => 1,
    '' => 1,
    'his' => 1,
    'with' => 1,
  ),
  'within' => 
  array (
    'it' => 1,
    'those' => 1,
    'seconds' => 2,
    'our' => 1,
  ),
  'brain-wretching' => 
  array (
    'device' => 1,
  ),
  'conceived,' => 
  array (
    '' => 1,
  ),
  'starship' => 
  array (
    'unique' => 1,
  ),
  'unique' => 
  array (
    'in' => 1,
  ),
  'history' => 
  array (
    '' => 1,
    'of' => 3,
  ),
  'ship' => 
  array (
    'had' => 1,
    'that' => 1,
    'simply' => 1,
    'during' => 1,
    'anyway.' => 1,
    'within' => 1,
    'are' => 2,
    'powered' => 1,
    'up' => 1,
    'did.' => 2,
    'by' => 1,
    '' => 5,
    'picked' => 1,
    'you\'ve' => 1,
    'an' => 1,
    'span' => 1,
    'twisted' => 1,
    'suddenly' => 1,
    'smoothly' => 1,
    'has' => 1,
    'was' => 1,
    'is' => 1,
  ),
  'named' => 
  array (
    '-' => 1,
  ),
  'Wow,' => 
  array (
    '-' => 1,
    'this' => 1,
  ),
  'else' => 
  array (
    'he' => 1,
    'is' => 1,
    'should' => 1,
    'in' => 1,
    'might' => 1,
    'out' => 1,
    'to' => 2,
    'was' => 3,
    'around' => 1,
    'had' => 1,
    'of' => 1,
  ),
  'say.' => 
  array (
    'He' => 1,
    'A' => 1,
    '-' => 1,
  ),
  'annoy' => 
  array (
    'the' => 1,
  ),
  'press.' => 
  array (
    '-' => 1,
    'Chapter' => 1,
  ),
  'Wow.' => 
  array (
    'The' => 1,
  ),
  'faces' => 
  array (
    'back' => 1,
    'and' => 1,
    '' => 1,
    'of' => 1,
    'down' => 1,
  ),
  'towards' => 
  array (
    'him' => 1,
    'his' => 2,
    'him.' => 2,
    '' => 3,
    'the' => 9,
    'me' => 1,
    'them' => 2,
    'a' => 1,
    'one' => 1,
  ),
  'expectantly.' => 
  array (
    'He' => 1,
    '-' => 1,
  ),
  'eyebrows' => 
  array (
    'and' => 2,
    '' => 1,
  ),
  'widened' => 
  array (
    'her' => 1,
  ),
  'showoff.' => 
  array (
    '-' => 1,
  ),
  'amazing,' => 
  array (
    '-' => 2,
  ),
  'truly' => 
  array (
    '' => 1,
  ),
  'amazing.' => 
  array (
    'That' => 1,
  ),
  'amazing' => 
  array (
    'I' => 1,
    'kid' => 1,
    '' => 1,
  ),
  'steal' => 
  array (
    'it.' => 2,
    'this' => 1,
    'that' => 1,
  ),
  'marvellous' => 
  array (
    'Presidential' => 1,
  ),
  'quote,' => 
  array (
    'absolutely' => 1,
  ),
  'absolutely' => 
  array (
    'true' => 1,
    'nothing' => 1,
    '' => 1,
    'assured.' => 1,
  ),
  'true' => 
  array (
    'to' => 1,
  ),
  'form.' => 
  array (
    '' => 2,
  ),
  'appreciatively,' => 
  array (
    'the' => 1,
  ),
  'newsmen' => 
  array (
    'gleefully' => 1,
  ),
  'gleefully' => 
  array (
    '' => 1,
  ),
  'punched' => 
  array (
    '' => 2,
    'up' => 1,
  ),
  'News-Matics' => 
  array (
    'and' => 1,
  ),
  'grinned.' => 
  array (
    'As' => 1,
  ),
  'unbearably' => 
  array (
    'and' => 1,
  ),
  'fingered' => 
  array (
    'the' => 1,
  ),
  'Paralyso-Matic' => 
  array (
    'bomb' => 1,
  ),
  'bomb' => 
  array (
    'that' => 1,
    'to' => 1,
  ),
  'Finally' => 
  array (
    'he' => 2,
    'Eddie' => 1,
    'I' => 1,
    'they' => 1,
  ),
  'bear' => 
  array (
    'it' => 1,
    'oceans,' => 1,
    'any' => 1,
  ),
  'more.' => 
  array (
    'He' => 2,
    'This' => 1,
  ),
  'whoop' => 
  array (
    'in' => 1,
  ),
  'major' => 
  array (
    'thirds,' => 1,
    'intestine,' => 1,
    'governments.' => 1,
    '' => 2,
    'land' => 1,
    'data' => 1,
    'screening' => 1,
    'centres' => 1,
    'award.' => 1,
  ),
  'thirds,' => 
  array (
    'threw' => 1,
  ),
  'ground' => 
  array (
    'and' => 2,
    'he' => 1,
    'they' => 1,
    '' => 1,
    'had' => 1,
    'stretched' => 1,
    'like' => 1,
  ),
  'frozen' => 
  array (
    'smiles.' => 1,
    '' => 1,
  ),
  'smiles.' => 
  array (
    'Chapter' => 1,
  ),
  5 => 
  array (
    'Prostetnic' => 1,
  ),
  'sight,' => 
  array (
    '' => 1,
  ),
  'domed' => 
  array (
    'nose' => 1,
  ),
  'rose' => 
  array (
    'high' => 1,
  ),
  'piggy' => 
  array (
    'forehead.' => 1,
    'eyes' => 1,
  ),
  'forehead.' => 
  array (
    '' => 1,
  ),
  'rubbery' => 
  array (
    'skin' => 1,
    'Vogon' => 1,
  ),
  'thick' => 
  array (
    'enough' => 1,
    'with' => 2,
    'rivulets' => 1,
    'smoke' => 1,
  ),
  'Civil' => 
  array (
    'Service' => 1,
    'Service.' => 1,
  ),
  'Service' => 
  array (
    'politics,' => 1,
  ),
  'politics,' => 
  array (
    'and' => 1,
  ),
  'waterproof' => 
  array (
    'enough' => 1,
  ),
  'survive' => 
  array (
    'indefinitely' => 1,
    'the' => 1,
    'in' => 1,
  ),
  'indefinitely' => 
  array (
    'at' => 1,
  ),
  'depths' => 
  array (
    'of' => 1,
    '' => 1,
  ),
  'ill' => 
  array (
    'effects.' => 1,
    '' => 2,
    'at' => 2,
  ),
  'effects.' => 
  array (
    'Not' => 1,
  ),
  'swimming' => 
  array (
    'of' => 1,
  ),
  'schedule' => 
  array (
    'would' => 1,
  ),
  'billions' => 
  array (
    'of' => 1,
  ),
  'ago' => 
  array (
    '' => 3,
  ),
  'crawled' => 
  array (
    'out' => 1,
    'across' => 1,
    'some' => 1,
    'up' => 1,
  ),
  'sluggish' => 
  array (
    'primeval' => 1,
    'thoughts' => 1,
  ),
  'primeval' => 
  array (
    'seas' => 1,
  ),
  'Vogsphere,' => 
  array (
    'and' => 1,
  ),
  'lain' => 
  array (
    'panting' => 1,
  ),
  'panting' => 
  array (
    'and' => 1,
    'for' => 1,
  ),
  'heaving' => 
  array (
    'on' => 1,
  ),
  'planet\'s' => 
  array (
    'virgin' => 1,
    'destruction.' => 1,
    'where' => 1,
    'surface' => 1,
  ),
  'virgin' => 
  array (
    'shores...' => 1,
  ),
  'shores...' => 
  array (
    'when' => 1,
  ),
  'bright' => 
  array (
    'young' => 1,
    'lad' => 1,
    'points' => 1,
    '' => 1,
    'colours.' => 1,
    'as' => 1,
  ),
  'young' => 
  array (
    'Vogsol' => 1,
    'Vogon' => 3,
    'student' => 1,
    'secretary' => 1,
    'Zaphod' => 1,
  ),
  'Vogsol' => 
  array (
    '' => 1,
  ),
  'morning,' => 
  array (
    'it' => 1,
    '-' => 1,
    'O' => 1,
  ),
  'forces' => 
  array (
    'of' => 1,
    '' => 2,
  ),
  'evolution' => 
  array (
    'ad' => 1,
  ),
  'ad' => 
  array (
    'simply' => 1,
    '' => 1,
  ),
  'aside' => 
  array (
    'in' => 1,
    '' => 2,
    'and' => 2,
    'the' => 1,
    'carelessly,' => 1,
  ),
  'disgust' => 
  array (
    'and' => 2,
    'they' => 1,
  ),
  'ugly' => 
  array (
    'and' => 1,
    'bulges.' => 1,
    'mess,' => 1,
    'men' => 2,
    '' => 1,
  ),
  'unfortunate' => 
  array (
    'mistake.' => 1,
    'creator.' => 1,
  ),
  'mistake.' => 
  array (
    'They' => 1,
  ),
  'evolved' => 
  array (
    'again;' => 1,
    '' => 1,
    'by' => 1,
    'and' => 1,
  ),
  'again;' => 
  array (
    'they' => 1,
  ),
  'survived.' => 
  array (
    'The' => 1,
  ),
  'tribute' => 
  array (
    '' => 1,
  ),
  'thick-willed' => 
  array (
    'slug-brained' => 1,
  ),
  'slug-brained' => 
  array (
    'stubbornness' => 1,
  ),
  'stubbornness' => 
  array (
    'of' => 1,
  ),
  'creatures.' => 
  array (
    'Evolution?' => 1,
  ),
  'Evolution?' => 
  array (
    '-' => 1,
  ),
  'themselves,' => 
  array (
    '-' => 1,
    'and' => 1,
    '' => 2,
  ),
  'needs' => 
  array (
    'it?,' => 1,
    'a' => 1,
  ),
  'it?,' => 
  array (
    '-' => 1,
  ),
  'nature' => 
  array (
    'refused' => 1,
    'of' => 1,
    '' => 1,
  ),
  'refused' => 
  array (
    'to' => 2,
  ),
  'rectify' => 
  array (
    '' => 1,
    'that' => 1,
  ),
  'grosser' => 
  array (
    'anatomical' => 1,
  ),
  'anatomical' => 
  array (
    'inconveniences' => 1,
  ),
  'inconveniences' => 
  array (
    'with' => 1,
  ),
  'surgery.' => 
  array (
    'Meanwhile,' => 1,
  ),
  'Meanwhile,' => 
  array (
    'the' => 1,
    '' => 1,
  ),
  'natural' => 
  array (
    '' => 1,
    'and' => 1,
  ),
  'Vogsphere' => 
  array (
    '' => 1,
    'whiled' => 1,
  ),
  'working' => 
  array (
    'overtime' => 1,
    'ship,' => 1,
    'though' => 1,
    'thinkers.' => 1,
  ),
  'overtime' => 
  array (
    'to' => 1,
  ),
  'earlier' => 
  array (
    'blunder.' => 1,
  ),
  'blunder.' => 
  array (
    'They' => 1,
  ),
  'brought' => 
  array (
    '' => 4,
    'together' => 1,
    'them' => 1,
    'up' => 1,
  ),
  'forth' => 
  array (
    'scintillating' => 1,
  ),
  'scintillating' => 
  array (
    'jewelled' => 2,
  ),
  'jewelled' => 
  array (
    'scuttling' => 2,
    '' => 1,
  ),
  'scuttling' => 
  array (
    'crabs,' => 1,
    'crabs' => 1,
  ),
  'crabs,' => 
  array (
    'which' => 1,
  ),
  'ate,' => 
  array (
    '' => 1,
  ),
  'smashing' => 
  array (
    'their' => 1,
    'them' => 1,
  ),
  'shells' => 
  array (
    'with' => 1,
  ),
  'mallets;' => 
  array (
    '' => 1,
  ),
  'tall' => 
  array (
    '' => 1,
    'Magrathean' => 1,
  ),
  'aspiring' => 
  array (
    '' => 1,
  ),
  'breathtaking' => 
  array (
    'slenderness' => 1,
  ),
  'slenderness' => 
  array (
    'and' => 1,
  ),
  'burned' => 
  array (
    'the' => 1,
  ),
  'crab' => 
  array (
    '' => 1,
  ),
  'meat' => 
  array (
    'with;' => 1,
    'from' => 1,
  ),
  'elegant' => 
  array (
    'gazellelike' => 1,
    'and' => 1,
  ),
  'gazellelike' => 
  array (
    'creatures' => 1,
  ),
  'silken' => 
  array (
    'coats' => 1,
  ),
  'coats' => 
  array (
    'and' => 1,
  ),
  'dewy' => 
  array (
    'eyes' => 1,
  ),
  'catch' => 
  array (
    'and' => 1,
  ),
  'transport' => 
  array (
    '' => 1,
  ),
  'backs' => 
  array (
    'would' => 1,
    'and' => 1,
  ),
  'snap' => 
  array (
    'instantly,' => 1,
  ),
  'instantly,' => 
  array (
    'but' => 1,
  ),
  'anyway.' => 
  array (
    'Thus' => 1,
    'The' => 1,
    'Guard!' => 1,
    '' => 1,
    'What\'s' => 1,
  ),
  'Thus' => 
  array (
    'the' => 1,
  ),
  'whiled' => 
  array (
    'away' => 1,
  ),
  'millennia' => 
  array (
    'until' => 1,
  ),
  'discovered' => 
  array (
    'the' => 1,
    'to' => 3,
    'by' => 1,
    '' => 2,
    'only' => 1,
    'they\'d' => 1,
  ),
  'principles' => 
  array (
    'of' => 1,
  ),
  'travel.' => 
  array (
    'Within' => 1,
  ),
  'Vog' => 
  array (
    'years' => 1,
  ),
  'migrated' => 
  array (
    '' => 1,
  ),
  'Megabrantis' => 
  array (
    'cluster,' => 1,
  ),
  'cluster,' => 
  array (
    'the' => 1,
  ),
  'hub' => 
  array (
    'of' => 1,
  ),
  'immensely' => 
  array (
    'powerful' => 1,
  ),
  'powerful' => 
  array (
    'backbone' => 1,
    'computer' => 1,
  ),
  'backbone' => 
  array (
    'of' => 1,
  ),
  'Service.' => 
  array (
    'They' => 1,
  ),
  'acquire' => 
  array (
    'learning,' => 1,
    'style' => 1,
  ),
  'learning,' => 
  array (
    'they' => 1,
  ),
  'style' => 
  array (
    'and' => 1,
    'settles' => 1,
    'of' => 1,
  ),
  'social' => 
  array (
    '' => 2,
  ),
  'grace,' => 
  array (
    'but' => 1,
  ),
  'respects' => 
  array (
    '' => 1,
  ),
  'modern' => 
  array (
    '' => 1,
  ),
  'different' => 
  array (
    '' => 1,
    'races' => 1,
    'editorships.' => 1,
    'planet.' => 1,
  ),
  'forebears.' => 
  array (
    '' => 1,
  ),
  'year' => 
  array (
    '' => 2,
  ),
  'import' => 
  array (
    '' => 1,
  ),
  'twenty-seven' => 
  array (
    '' => 1,
  ),
  'crabs' => 
  array (
    'from' => 1,
  ),
  'native' => 
  array (
    'planet' => 1,
    'of' => 1,
  ),
  'drunken' => 
  array (
    'night' => 1,
  ),
  'bits' => 
  array (
    'with' => 1,
    '' => 2,
    'of' => 4,
    'in' => 1,
  ),
  'mallets.' => 
  array (
    'Prostetnic' => 1,
  ),
  'fairly' => 
  array (
    'typical' => 1,
    '' => 1,
    'large.' => 1,
    'shaky' => 1,
    'clear' => 1,
  ),
  'typical' => 
  array (
    '' => 1,
  ),
  'vile.' => 
  array (
    'Also,' => 1,
  ),
  'Also,' => 
  array (
    'he' => 1,
  ),
  'hikers.' => 
  array (
    'Somewhere' => 1,
    '' => 1,
  ),
  'Somewhere' => 
  array (
    'in' => 3,
    '' => 1,
    'on' => 1,
  ),
  'cabin' => 
  array (
    'buried' => 1,
    '' => 3,
    'of' => 1,
    'was' => 1,
    'as' => 2,
    'and' => 1,
  ),
  'buried' => 
  array (
    '' => 2,
  ),
  'intestines' => 
  array (
    '' => 1,
  ),
  'Jeltz\'s' => 
  array (
    'flagship,' => 1,
  ),
  'flagship,' => 
  array (
    'a' => 1,
  ),
  'flared' => 
  array (
    '' => 1,
    'in' => 1,
  ),
  'nervously.' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'owner' => 
  array (
    'of' => 1,
  ),
  'Vogon,' => 
  array (
    'but' => 1,
    '' => 1,
  ),
  '<Ford' => 
  array (
    'Prefect\'s' => 1,
  ),
  'pronuncible' => 
  array (
    '' => 1,
  ),
  'obscure' => 
  array (
    'Betelgeusian' => 1,
  ),
  'Betelgeusian' => 
  array (
    'dialect,' => 1,
    '' => 1,
  ),
  'dialect,' => 
  array (
    'now' => 1,
  ),
  'extinct' => 
  array (
    '' => 1,
  ),
  'Great' => 
  array (
    '' => 1,
    'Collapsing' => 1,
    'guys,' => 1,
    'ugly' => 1,
    'things' => 1,
    'On-Turning' => 1,
    'Hyperlobic' => 2,
    'and' => 1,
    'Question...' => 1,
    'Question!' => 1,
  ),
  'Collapsing' => 
  array (
    'Hrung' => 2,
  ),
  'Hrung' => 
  array (
    'Disaster' => 1,
    'disaster,' => 1,
    'was' => 1,
    'is,' => 1,
  ),
  'Disaster' => 
  array (
    'of' => 1,
  ),
  'Gal.' => 
  array (
    '/Sid./' => 1,
  ),
  '/Sid./' => 
  array (
    'Year' => 1,
  ),
  'Year' => 
  array (
    '03758' => 1,
  ),
  '03758' => 
  array (
    '' => 1,
  ),
  'Praxibetel' => 
  array (
    'communities' => 1,
    'tongue.' => 1,
  ),
  'communities' => 
  array (
    'on' => 1,
  ),
  'Seven.' => 
  array (
    'Ford\'s' => 1,
  ),
  'father' => 
  array (
    'was' => 1,
    'eventually' => 1,
  ),
  'disaster,' => 
  array (
    'by' => 1,
  ),
  'satisfactorily' => 
  array (
    '' => 1,
    'to' => 1,
  ),
  'episode' => 
  array (
    'is' => 1,
  ),
  'shrouded' => 
  array (
    'in' => 1,
  ),
  'mystery:' => 
  array (
    '' => 1,
  ),
  'nor' => 
  array (
    'why' => 2,
    'have' => 1,
    'even' => 1,
  ),
  'collapse' => 
  array (
    'on' => 2,
  ),
  'Seven' => 
  array (
    'particularly.' => 1,
    'and' => 3,
  ),
  'particularly.' => 
  array (
    'Ford\'s' => 1,
  ),
  'father,' => 
  array (
    'magnanimously' => 1,
  ),
  'magnanimously' => 
  array (
    'waving' => 1,
  ),
  'clouds' => 
  array (
    'of' => 1,
  ),
  'inevitably' => 
  array (
    'settled' => 1,
    'became' => 1,
  ),
  'live' => 
  array (
    '' => 1,
    'population' => 1,
    'in' => 1,
  ),
  'Five' => 
  array (
    'where' => 1,
    '' => 1,
    'wild' => 1,
    'to' => 1,
    'you' => 1,
    'figures' => 1,
    'minutes' => 1,
  ),
  'fathered' => 
  array (
    'and' => 1,
  ),
  'uncled' => 
  array (
    'Ford;' => 1,
  ),
  'Ford;' => 
  array (
    'in' => 1,
  ),
  'race' => 
  array (
    'he' => 1,
    'is' => 1,
    '' => 2,
    'has' => 1,
  ),
  'christened' => 
  array (
    'him' => 1,
  ),
  'name,' => 
  array (
    '' => 1,
    'human?' => 1,
    '-' => 2,
    'but' => 1,
  ),
  'shame,' => 
  array (
    'which' => 1,
  ),
  'terminal' => 
  array (
    'disease' => 1,
    '' => 2,
  ),
  'disease' => 
  array (
    'in' => 1,
  ),
  'parts' => 
  array (
    'of' => 4,
    '' => 1,
  ),
  'kids' => 
  array (
    'at' => 1,
    'with' => 1,
    'about' => 1,
    '' => 1,
  ),
  'school' => 
  array (
    'nicknamed' => 1,
  ),
  'nicknamed' => 
  array (
    'him' => 1,
  ),
  'Ix,' => 
  array (
    '' => 1,
  ),
  'language' => 
  array (
    '' => 1,
  ),
  'translates' => 
  array (
    '' => 1,
  ),
  '"boy' => 
  array (
    '' => 1,
  ),
  'is,' => 
  array (
    'nor' => 1,
    '' => 1,
    '-' => 1,
    'you\'ll' => 1,
  ),
  'Seven">.' => 
  array (
    'He' => 1,
  ),
  'little;' => 
  array (
    '' => 1,
  ),
  'strange' => 
  array (
    'monstrous' => 1,
    'behaviour.' => 1,
    '' => 4,
    'book.' => 1,
    'new' => 2,
    'symbols' => 2,
    'and' => 1,
    'sweetmeats' => 1,
  ),
  'shadows' => 
  array (
    'loomed' => 1,
    'leaped' => 1,
  ),
  'loomed' => 
  array (
    'and' => 1,
    'again.' => 1,
    'massively' => 1,
  ),
  'leaped' => 
  array (
    'with' => 1,
    'and' => 1,
    'to' => 1,
    'in' => 1,
    'out' => 1,
  ),
  'flickering' => 
  array (
    '' => 1,
  ),
  'flame,' => 
  array (
    '' => 1,
  ),
  'Dentrassis.' => 
  array (
    '' => 1,
  ),
  'Dentrassis' => 
  array (
    'are' => 2,
    'fine,' => 1,
    'prepared' => 1,
  ),
  'tribe' => 
  array (
    'of' => 1,
    'had' => 1,
  ),
  'gourmands,' => 
  array (
    'a' => 1,
  ),
  'bunch' => 
  array (
    'whom' => 1,
    'of' => 3,
  ),
  'taken' => 
  array (
    'to' => 1,
    'on' => 1,
    'off' => 1,
    'the' => 1,
    'away,' => 1,
    'aback,' => 1,
    'as' => 1,
  ),
  'employing' => 
  array (
    'as' => 1,
  ),
  'catering' => 
  array (
    'staff' => 1,
  ),
  'staff' => 
  array (
    'on' => 1,
    '' => 1,
  ),
  'haul' => 
  array (
    'fleets,' => 1,
  ),
  'fleets,' => 
  array (
    'on' => 1,
  ),
  'strict' => 
  array (
    'understanding' => 1,
  ),
  'understanding' => 
  array (
    'that' => 1,
  ),
  'themselves' => 
  array (
    'very' => 1,
    'into' => 1,
    '(this' => 1,
    'through' => 1,
    '' => 4,
    'by' => 1,
    'in' => 1,
    'calmly' => 1,
    'deferentially' => 1,
    'off' => 1,
    'down' => 1,
  ),
  'suited' => 
  array (
    'the' => 1,
  ),
  'fine,' => 
  array (
    '' => 1,
    'really...' => 2,
  ),
  'money,' => 
  array (
    'which' => 1,
    '-' => 1,
  ),
  'hardest' => 
  array (
    'currencies' => 1,
    'to' => 1,
  ),
  'currencies' => 
  array (
    'in' => 1,
  ),
  'space,' => 
  array (
    'but' => 2,
    'or...' => 1,
    '-' => 2,
    '' => 1,
    'now' => 1,
  ),
  'loathed' => 
  array (
    '' => 1,
  ),
  'Dentrassi' => 
  array (
    'liked' => 1,
    'looked' => 1,
    'sleeping' => 1,
    'cooks' => 1,
    '' => 1,
  ),
  'annoyed' => 
  array (
    'Vogon.' => 1,
  ),
  'Vogon.' => 
  array (
    'It' => 1,
    '-' => 1,
  ),
  'piece' => 
  array (
    'of' => 2,
    '' => 2,
  ),
  'groan.' => 
  array (
    'By' => 1,
    'He' => 1,
  ),
  'shape' => 
  array (
    'moving' => 1,
    'moved' => 1,
    'of' => 1,
    '' => 1,
  ),
  'floor.' => 
  array (
    '' => 1,
    'The' => 1,
    'It\'s' => 1,
    'Trillian' => 1,
    'Arthur' => 1,
    '-' => 1,
  ),
  'Quickly' => 
  array (
    '' => 1,
  ),
  'pocket,' => 
  array (
    'found' => 1,
  ),
  'crouched' => 
  array (
    'on' => 1,
  ),
  'moved,' => 
  array (
    'and' => 1,
  ),
  'groaned' => 
  array (
    'again,' => 1,
  ),
  'muttering' => 
  array (
    'incoherently.' => 1,
    'sour' => 1,
  ),
  'incoherently.' => 
  array (
    '-' => 1,
  ),
  'Here,' => 
  array (
    'have' => 2,
    '-' => 1,
    'he' => 1,
  ),
  'some,' => 
  array (
    '-' => 1,
  ),
  'urged' => 
  array (
    'Ford,' => 1,
    'Zaphod.' => 1,
    'the' => 1,
    'Fook.' => 1,
    'Loonquawl.' => 1,
  ),
  'shaking' => 
  array (
    '' => 1,
    'his' => 1,
  ),
  'packet' => 
  array (
    '' => 1,
    'of' => 1,
  ),
  'transference' => 
  array (
    '' => 1,
  ),
  'beam' => 
  array (
    '' => 1,
    'of' => 1,
    'around.' => 1,
  ),
  'salt' => 
  array (
    '' => 1,
  ),
  'protein.' => 
  array (
    '' => 1,
  ),
  'cushioned' => 
  array (
    'your' => 1,
  ),
  'Whhhrrrr...' => 
  array (
    '-' => 1,
  ),
  'dark,' => 
  array (
    '-' => 1,
  ),
  'dark.' => 
  array (
    '-' => 1,
    '' => 1,
    'Arthur' => 1,
  ),
  'light,' => 
  array (
    '-' => 1,
    'which' => 1,
    'searing' => 1,
    'and' => 1,
  ),
  'Dark,' => 
  array (
    'no' => 1,
  ),
  'human' => 
  array (
    'beings' => 4,
    'imagination.' => 1,
    'being' => 1,
  ),
  'habit' => 
  array (
    'of' => 1,
    '' => 1,
  ),
  'continually' => 
  array (
    '' => 1,
  ),
  'stating' => 
  array (
    '' => 1,
  ),
  'repeating' => 
  array (
    'the' => 1,
  ),
  'obvious,' => 
  array (
    'as' => 1,
  ),
  'day,' => 
  array (
    'or' => 1,
    'do' => 1,
    'a' => 1,
    'Arthur\'s' => 1,
    'young' => 1,
  ),
  'You\'re' => 
  array (
    'very' => 1,
    'sure' => 1,
    'crazy,' => 1,
    'surely' => 1,
    'really' => 1,
    'safe!' => 1,
  ),
  'dear' => 
  array (
    '' => 1,
  ),
  'fallen' => 
  array (
    'down' => 1,
  ),
  'thirty-foot' => 
  array (
    'well,' => 1,
  ),
  'theory' => 
  array (
    'to' => 1,
    'in' => 1,
    '' => 2,
  ),
  'account' => 
  array (
    'for' => 1,
    'allow' => 1,
    'of' => 1,
  ),
  'behaviour.' => 
  array (
    '' => 1,
  ),
  'exercising' => 
  array (
    'their' => 2,
  ),
  'lips,' => 
  array (
    'he' => 2,
  ),
  'mouths' => 
  array (
    'probably' => 1,
  ),
  'seize' => 
  array (
    'up.' => 1,
  ),
  'After' => 
  array (
    'a' => 7,
    '' => 1,
  ),
  'months\'' => 
  array (
    'consideration' => 1,
  ),
  'consideration' => 
  array (
    'and' => 1,
  ),
  'observation' => 
  array (
    '' => 1,
    'at' => 1,
  ),
  'abandoned' => 
  array (
    'this' => 2,
  ),
  'favour' => 
  array (
    'of' => 1,
  ),
  'working.' => 
  array (
    'After' => 1,
  ),
  'obstructively' => 
  array (
    'cynical' => 1,
  ),
  'cynical' => 
  array (
    'and' => 1,
  ),
  'desperately' => 
  array (
    '' => 1,
    'to' => 1,
    'around' => 1,
    'worried' => 1,
    'by' => 1,
  ),
  'number' => 
  array (
    'of' => 3,
    'three' => 1,
    'coalesced' => 1,
    '' => 4,
    'two' => 1,
    'appeared.' => 1,
  ),
  'agreed' => 
  array (
    'with' => 1,
    'Ford.' => 2,
    'this' => 1,
    'Trillian,' => 1,
    '' => 1,
    'the' => 1,
  ),
  'helped' => 
  array (
    '' => 1,
  ),
  'feel?' => 
  array (
    '-' => 1,
  ),
  'Like' => 
  array (
    'a' => 1,
    'what?' => 1,
    'I' => 1,
  ),
  'military' => 
  array (
    'academy,' => 1,
  ),
  'academy,' => 
  array (
    '-' => 1,
  ),
  'blankly' => 
  array (
    'in' => 1,
  ),
  'darkness.' => 
  array (
    '-' => 2,
  ),
  'were,' => 
  array (
    '' => 1,
    'I' => 1,
  ),
  'weakly,' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'regret' => 
  array (
    'it?' => 1,
  ),
  'it?' => 
  array (
    'Ford' => 2,
    '-' => 26,
    'Arthur' => 1,
    '' => 2,
    'What' => 1,
    'The' => 1,
    'Second' => 1,
    'It\'s' => 1,
    'And' => 1,
    'Again,' => 1,
    'A' => 1,
    'Do' => 1,
  ),
  'We\'re' => 
  array (
    'safe,' => 1,
    'in' => 2,
    'trapped' => 1,
    'going' => 2,
    'making' => 1,
    'cornered.' => 1,
  ),
  'safe,' => 
  array (
    '-' => 1,
  ),
  'good,' => 
  array (
    '-' => 3,
  ),
  'galley' => 
  array (
    'cabin,' => 1,
    '' => 1,
  ),
  'cabin,' => 
  array (
    '' => 1,
    'brushing' => 1,
  ),
  'spaceships' => 
  array (
    'of' => 1,
  ),
  'Fleet.' => 
  array (
    '-' => 1,
  ),
  'obviously' => 
  array (
    'some' => 1,
    'quite' => 1,
    'worried' => 1,
  ),
  'usage' => 
  array (
    '' => 1,
  ),
  'safe' => 
  array (
    'that' => 1,
    '' => 1,
    'money' => 1,
  ),
  'previously' => 
  array (
    'aware' => 1,
  ),
  'switch.' => 
  array (
    'Monstrous' => 1,
    '-' => 1,
  ),
  'Monstrous' => 
  array (
    'shadows' => 1,
  ),
  'struggled' => 
  array (
    '' => 2,
    'to' => 1,
  ),
  'hugged' => 
  array (
    'himself' => 1,
    '' => 1,
    'herself,' => 1,
  ),
  'apprehensively.' => 
  array (
    'Hideous' => 1,
  ),
  'Hideous' => 
  array (
    'alien' => 1,
  ),
  'alien' => 
  array (
    'shapes' => 1,
    'underwear' => 1,
    'spaceship' => 1,
    'planet.' => 1,
    'world!..' => 1,
  ),
  'shapes' => 
  array (
    'seemed' => 1,
    'that' => 2,
    'of' => 1,
    'represented' => 1,
    '' => 1,
  ),
  'throng' => 
  array (
    'about' => 1,
  ),
  'musty' => 
  array (
    'smells' => 1,
  ),
  'smells' => 
  array (
    'which' => 1,
  ),
  'lungs' => 
  array (
    'without' => 1,
    'and' => 1,
  ),
  'identifying' => 
  array (
    'themselves,' => 1,
  ),
  'irritating' => 
  array (
    'hum' => 1,
    'light.' => 1,
    'because' => 1,
  ),
  'hum' => 
  array (
    '' => 2,
    'an' => 1,
    'and' => 1,
    'level' => 1,
    'came' => 1,
  ),
  'focusing.' => 
  array (
    '-' => 1,
  ),
  'here?' => 
  array (
    '-' => 4,
    'What\'s' => 1,
  ),
  'asked,' => 
  array (
    'shivering' => 1,
  ),
  'shivering' => 
  array (
    'slightly.' => 1,
  ),
  'slightly.' => 
  array (
    '-' => 3,
  ),
  'We' => 
  array (
    'hitched' => 1,
    'are' => 7,
    'asked' => 1,
    'know' => 1,
    'picked' => 1,
    '' => 4,
    'pass' => 1,
    'keep' => 1,
    'would' => 1,
    'could' => 2,
    'can' => 1,
    'only' => 1,
    'distinctly' => 1,
    'want' => 1,
    'demand' => 2,
    'don\'t' => 2,
    'demand,' => 1,
    'must' => 1,
    'had' => 1,
    'didn\'t' => 2,
    'thought' => 1,
    'got' => 1,
    'have,' => 1,
    'have' => 1,
  ),
  'hitched' => 
  array (
    'a' => 1,
    '' => 1,
  ),
  'lift,' => 
  array (
    '-' => 1,
  ),
  'me?' => 
  array (
    '-' => 1,
    'And' => 1,
  ),
  'thumbs' => 
  array (
    'and' => 1,
  ),
  'bug-eyed' => 
  array (
    'monster' => 1,
    'monster?' => 1,
    'monsters.' => 1,
  ),
  'monster' => 
  array (
    'stuck' => 1,
  ),
  'fellas,' => 
  array (
    '' => 1,
  ),
  'hop' => 
  array (
    '' => 1,
  ),
  'Basingstoke' => 
  array (
    'roundabout?' => 1,
  ),
  'roundabout?' => 
  array (
    '-' => 1,
  ),
  'Thumb\'s' => 
  array (
    'an' => 1,
  ),
  'sub-etha' => 
  array (
    '' => 2,
    'radio' => 1,
  ),
  'signalling' => 
  array (
    'device,' => 1,
  ),
  'device,' => 
  array (
    'the' => 1,
  ),
  'roundabout\'s' => 
  array (
    'at' => 1,
  ),
  'Barnard\'s' => 
  array (
    '' => 1,
    'Star.' => 1,
  ),
  'Star' => 
  array (
    '' => 1,
    'system.' => 1,
    'Thinker' => 1,
  ),
  'otherwise,' => 
  array (
    'that\'s' => 1,
  ),
  'right.' => 
  array (
    '-' => 1,
    'Ford' => 1,
  ),
  'monster?' => 
  array (
    '-' => 1,
  ),
  'Is' => 
  array (
    'green,' => 1,
    'that' => 6,
    'there' => 1,
    'it' => 1,
    'it?' => 1,
    'no' => 1,
  ),
  'green,' => 
  array (
    'yes.' => 1,
  ),
  'yes.' => 
  array (
    '-' => 3,
    'Actually' => 1,
  ),
  'home?' => 
  array (
    '-' => 1,
  ),
  'can\'t,' => 
  array (
    '-' => 1,
  ),
  'Shade' => 
  array (
    'your' => 1,
  ),
  'eyes...' => 
  array (
    '-' => 1,
  ),
  'Even' => 
  array (
    'Ford' => 1,
    'light,' => 1,
    'the' => 2,
    'supposing' => 1,
    '' => 1,
  ),
  'grief,' => 
  array (
    '-' => 1,
  ),
  'interior' => 
  array (
    '' => 1,
    'of' => 1,
  ),
  'saucer?' => 
  array (
    'Prostetnic' => 1,
  ),
  'heaved' => 
  array (
    'his' => 1,
    'himself' => 1,
  ),
  'bridge.' => 
  array (
    '' => 4,
    'A' => 1,
    'Here' => 1,
    'Call' => 1,
    'I' => 1,
    'Arthur' => 1,
    'As' => 1,
  ),
  'irritable' => 
  array (
    '' => 1,
  ),
  'demolishing' => 
  array (
    'populated' => 1,
  ),
  'populated' => 
  array (
    'planets.' => 1,
  ),
  'planets.' => 
  array (
    'He' => 1,
    'Arthur' => 1,
  ),
  'shout' => 
  array (
    'at' => 1,
    'because' => 1,
  ),
  'better.' => 
  array (
    '' => 1,
    'Zaphod' => 1,
    '-' => 1,
  ),
  'flopped' => 
  array (
    'as' => 1,
  ),
  'heavily' => 
  array (
    'as' => 1,
    'along' => 1,
    'edited' => 1,
    'and' => 1,
    'armoured' => 1,
  ),
  'hope' => 
  array (
    '' => 2,
    'you' => 2,
    'in' => 1,
  ),
  'complaining' => 
  array (
    'sort' => 1,
  ),
  'creak.' => 
  array (
    '-' => 1,
  ),
  'Go' => 
  array (
    'away!' => 1,
    'down' => 1,
  ),
  'away!' => 
  array (
    '-' => 1,
  ),
  'guard' => 
  array (
    'who' => 1,
    'vanished' => 1,
    'stepped' => 1,
    'back' => 1,
    'grasped' => 1,
    'dragged' => 1,
    'shouting' => 1,
    'was' => 1,
    'had' => 1,
    'seemed' => 1,
    '' => 1,
    'operated' => 1,
    'this' => 1,
  ),
  'entered' => 
  array (
    'the' => 1,
    'he' => 1,
  ),
  'bridge' => 
  array (
    'at' => 1,
    'with' => 1,
    'to' => 1,
    '' => 1,
    '-' => 1,
    'waving' => 1,
    'trying' => 1,
  ),
  'vanished' => 
  array (
    'immediately,' => 1,
    'in' => 1,
    'completely,' => 1,
    'and' => 1,
    '' => 1,
  ),
  'immediately,' => 
  array (
    'feeling' => 1,
    '' => 1,
  ),
  'relieved.' => 
  array (
    'He' => 1,
  ),
  'glad' => 
  array (
    'it' => 1,
    'you' => 1,
  ),
  'delivered' => 
  array (
    'the' => 1,
    'a' => 1,
  ),
  'report' => 
  array (
    '' => 1,
    'was' => 1,
  ),
  'received.' => 
  array (
    'The' => 1,
  ),
  'official' => 
  array (
    'release' => 1,
  ),
  'release' => 
  array (
    'which' => 1,
  ),
  'spaceship' => 
  array (
    'drive' => 1,
    '' => 3,
    'guard' => 1,
    'and' => 1,
    'except' => 1,
  ),
  'unveiled' => 
  array (
    '' => 1,
  ),
  'research' => 
  array (
    'base' => 1,
    '' => 2,
    'during' => 1,
    'laboratories' => 1,
    'programme...' => 1,
  ),
  'base' => 
  array (
    'on' => 1,
  ),
  'henceforth' => 
  array (
    '' => 1,
  ),
  'routes' => 
  array (
    'unnecessary.' => 1,
  ),
  'unnecessary.' => 
  array (
    'Another' => 1,
  ),
  'slid' => 
  array (
    'open,' => 1,
    '' => 1,
    'open.' => 2,
    'open' => 1,
  ),
  'open,' => 
  array (
    'but' => 1,
    'and' => 1,
    '' => 1,
    'Trillian' => 1,
  ),
  'captain' => 
  array (
    'didn\'t' => 1,
    'making' => 1,
    'speaking,' => 1,
    'of' => 1,
    '' => 1,
    'watched' => 1,
    'was' => 2,
  ),
  'quarters' => 
  array (
    '' => 1,
  ),
  'meals.' => 
  array (
    'A' => 1,
  ),
  'meal' => 
  array (
    'would' => 1,
    'to' => 1,
  ),
  'welcome.' => 
  array (
    'A' => 1,
    'I' => 1,
  ),
  'furry' => 
  array (
    'creature' => 1,
    '' => 2,
    'creatures' => 2,
  ),
  'creature' => 
  array (
    'bounded' => 1,
    'had' => 1,
    'to' => 1,
    'stirred' => 1,
  ),
  'bounded' => 
  array (
    'through' => 1,
  ),
  'lunch' => 
  array (
    '' => 1,
  ),
  'tray.' => 
  array (
    'It' => 1,
  ),
  'grinning' => 
  array (
    'like' => 1,
    'a' => 1,
  ),
  'maniac.' => 
  array (
    'Prostetnic' => 1,
    '-' => 1,
  ),
  'delighted.' => 
  array (
    'He' => 1,
  ),
  'pleased' => 
  array (
    'with' => 2,
    'little' => 1,
    '' => 1,
  ),
  'indeed' => 
  array (
    'about.' => 1,
    'have' => 1,
    'the' => 1,
  ),
  'think?' => 
  array (
    '-' => 1,
  ),
  'squalid,' => 
  array (
    'isn\'t' => 1,
  ),
  'grubby' => 
  array (
    'mattress,' => 1,
  ),
  'mattress,' => 
  array (
    'unwashed' => 1,
  ),
  'unwashed' => 
  array (
    'cups' => 1,
  ),
  'cups' => 
  array (
    'and' => 2,
  ),
  'unidentifiable' => 
  array (
    'bits' => 1,
  ),
  'smelly' => 
  array (
    'alien' => 1,
    'steel-lined' => 1,
  ),
  'underwear' => 
  array (
    'that' => 1,
  ),
  'cramped' => 
  array (
    'cabin.' => 1,
  ),
  'cabin.' => 
  array (
    '-' => 2,
    'With' => 1,
    'Ford\'s' => 1,
  ),
  'ship,' => 
  array (
    'you' => 1,
    'the' => 1,
    'occasionally' => 1,
    'in' => 1,
    '' => 2,
    'with' => 1,
  ),
  'see,' => 
  array (
    '-' => 5,
    'there\'s' => 1,
    'we' => 1,
    '' => 4,
    'so' => 1,
    'had' => 1,
    'what' => 1,
  ),
  'These' => 
  array (
    'are' => 1,
    'were' => 1,
    'patterns' => 1,
    'things' => 1,
    'creatures' => 1,
    'miniature' => 1,
  ),
  'sleeping' => 
  array (
    'quarters.' => 1,
  ),
  'quarters.' => 
  array (
    '-' => 1,
  ),
  'cooks,' => 
  array (
    'they' => 1,
  ),
  'confused,' => 
  array (
    '-' => 1,
  ),
  'mattresses' => 
  array (
    'and' => 2,
    '' => 1,
  ),
  'rummaged' => 
  array (
    'about' => 1,
    'around' => 1,
  ),
  'prodded' => 
  array (
    'the' => 1,
    'his' => 1,
    '' => 1,
  ),
  'mattress' => 
  array (
    'nervously' => 1,
    'with' => 1,
  ),
  'himself:' => 
  array (
    'in' => 1,
  ),
  'swamps' => 
  array (
    '' => 1,
  ),
  'Squornshellous' => 
  array (
    'Zeta' => 1,
    'mattresses' => 1,
  ),
  'Zeta' => 
  array (
    'are' => 1,
  ),
  'killed' => 
  array (
    'and' => 1,
    'on' => 1,
    'him.' => 1,
  ),
  'dried' => 
  array (
    'before' => 1,
  ),
  'service.' => 
  array (
    'Very' => 1,
  ),
  'handed' => 
  array (
    'the' => 1,
  ),
  'Hitchhiker\'s' => 
  array (
    'Guide' => 1,
  ),
  'cover,' => 
  array (
    '-' => 1,
  ),
  'Panic.' => 
  array (
    'It\'s' => 1,
    '-' => 1,
  ),
  'helpful' => 
  array (
    'or' => 1,
  ),
  'intelligible' => 
  array (
    'thing' => 1,
  ),
  'anybody\'s' => 
  array (
    'said' => 1,
  ),
  'show' => 
  array (
    'you' => 1,
    'up' => 2,
    'them' => 1,
    'you.' => 1,
    'of' => 1,
    '' => 2,
    'for' => 1,
    'me' => 1,
  ),
  'works,' => 
  array (
    '-' => 1,
  ),
  'snatched' => 
  array (
    'it' => 1,
  ),
  'holding' => 
  array (
    'it' => 1,
    'up' => 2,
    'the' => 1,
  ),
  'two-week-dead' => 
  array (
    'lark' => 1,
  ),
  'lark' => 
  array (
    'and' => 1,
  ),
  'button' => 
  array (
    'here' => 1,
    'at' => 1,
    '' => 2,
    'again.' => 1,
    'and' => 1,
    'to' => 1,
  ),
  'index.' => 
  array (
    'A' => 1,
  ),
  'screen,' => 
  array (
    'about' => 1,
    'just' => 1,
  ),
  'four,' => 
  array (
    'lit' => 1,
  ),
  'lit' => 
  array (
    'up' => 2,
  ),
  'characters' => 
  array (
    'began' => 1,
  ),
  'flicker' => 
  array (
    'across' => 1,
  ),
  'surface.' => 
  array (
    '-' => 1,
    'They' => 1,
  ),
  'Vogons,' => 
  array (
    'so' => 1,
  ),
  'enter' => 
  array (
    '' => 1,
  ),
  'fingers' => 
  array (
    'tapped' => 1,
    '' => 1,
    'along' => 1,
    'on' => 1,
  ),
  'tapped' => 
  array (
    'some' => 1,
    'irritably' => 1,
    'anything' => 1,
    'Zaphod' => 1,
    'impatiently' => 1,
  ),
  'keys.' => 
  array (
    '-' => 1,
  ),
  'are.' => 
  array (
    'The' => 1,
    '-' => 1,
    'I' => 1,
    'Perhaps' => 1,
  ),
  'Fleets' => 
  array (
    'flared' => 1,
  ),
  'screen.' => 
  array (
    'Ford' => 1,
    '-' => 4,
    'The' => 1,
    'A' => 1,
    'Clear' => 1,
    'I' => 1,
  ),
  'pressed' => 
  array (
    'a' => 1,
    'the' => 1,
    'an' => 1,
    '' => 1,
    'Ford.' => 1,
  ),
  'undulate' => 
  array (
    'across' => 1,
  ),
  'speak' => 
  array (
    'the' => 1,
    'Vogon!' => 1,
    'my' => 1,
    'when' => 1,
    'of' => 3,
  ),
  'entry' => 
  array (
    'as' => 1,
    'a' => 1,
    'for' => 2,
    'off' => 1,
    'bay' => 1,
  ),
  'quiet' => 
  array (
    'measured' => 1,
    'young' => 1,
    'glance' => 1,
  ),
  'measured' => 
  array (
    'voice.' => 1,
    '' => 1,
  ),
  'voice.' => 
  array (
    'This' => 1,
    'It' => 1,
    '-' => 4,
    'Arthur' => 1,
    'The' => 1,
    '' => 1,
  ),
  'Fleets.' => 
  array (
    'Here' => 1,
  ),
  'Here' => 
  array (
    'is' => 1,
    'was' => 1,
    'he' => 1,
    'I' => 1,
    'Vroomfondel,' => 1,
  ),
  'lift' => 
  array (
    'from' => 1,
    '' => 1,
    'then?' => 1,
    'with' => 1,
  ),
  'Vogon:' => 
  array (
    'forget' => 1,
  ),
  'forget' => 
  array (
    'it.' => 2,
    '' => 2,
    'how' => 1,
  ),
  'evil,' => 
  array (
    'but' => 1,
  ),
  'tempered,' => 
  array (
    'bureaucratic,' => 1,
  ),
  'bureaucratic,' => 
  array (
    '' => 1,
  ),
  'officious' => 
  array (
    'and' => 1,
  ),
  'callous.' => 
  array (
    '' => 1,
  ),
  'save' => 
  array (
    '' => 1,
    'life' => 1,
    'penguin,' => 1,
    'us' => 1,
    'you' => 1,
  ),
  'grandmothers' => 
  array (
    'from' => 1,
  ),
  'signed' => 
  array (
    'in' => 1,
  ),
  'triplicate,' => 
  array (
    'sent' => 1,
  ),
  'in,' => 
  array (
    'sent' => 1,
    'presumably' => 1,
    'the' => 1,
  ),
  'queried,' => 
  array (
    'lost,' => 1,
  ),
  'lost,' => 
  array (
    'found,' => 1,
  ),
  'found,' => 
  array (
    '' => 1,
  ),
  'subjected' => 
  array (
    'to' => 1,
  ),
  'inquiry,' => 
  array (
    'lost' => 1,
  ),
  'soft' => 
  array (
    '' => 2,
    'rubber' => 1,
    'glow' => 1,
    'and' => 1,
    'low' => 1,
    '-' => 1,
    'walls.' => 1,
  ),
  'peat' => 
  array (
    '' => 1,
  ),
  'recycled' => 
  array (
    'as' => 1,
  ),
  'firelighters.' => 
  array (
    '-' => 1,
  ),
  'stick' => 
  array (
    'your' => 1,
    'a' => 1,
    'to' => 2,
    'is' => 1,
  ),
  'throat,' => 
  array (
    'and' => 1,
  ),
  'irritate' => 
  array (
    '' => 1,
  ),
  'feed' => 
  array (
    '' => 2,
  ),
  'grandmother' => 
  array (
    'to' => 1,
  ),
  'Traal.' => 
  array (
    '-' => 1,
  ),
  'poetry' => 
  array (
    'at' => 1,
    'first.' => 1,
    'first...' => 1,
    'is' => 1,
    'of' => 1,
    'because' => 1,
    'to' => 1,
  ),
  'date' => 
  array (
    'now,' => 1,
  ),
  'sliding' => 
  array (
    '' => 1,
    'into' => 1,
    'door' => 1,
  ),
  'New' => 
  array (
    'Revised' => 1,
    'York' => 1,
    'York,' => 1,
    'Earth.' => 1,
  ),
  'Revised' => 
  array (
    'Edition,' => 1,
    '' => 1,
  ),
  'Edition,' => 
  array (
    'and' => 1,
  ),
  'include' => 
  array (
    'is' => 1,
    '-' => 1,
  ),
  'employ' => 
  array (
    'Dentrassi' => 1,
  ),
  'cooks' => 
  array (
    'which' => 1,
    '' => 1,
  ),
  'loophole.' => 
  array (
    'A' => 1,
  ),
  'pained' => 
  array (
    'expression' => 1,
    'look' => 1,
  ),
  'expression' => 
  array (
    'crossed' => 1,
    'of' => 1,
  ),
  'crossed' => 
  array (
    'Arthur\'s' => 1,
    'them' => 1,
    'three' => 1,
  ),
  'face.' => 
  array (
    '-' => 3,
    'A' => 1,
    '' => 1,
  ),
  'Dentrassi?' => 
  array (
    '-' => 2,
  ),
  'guys,' => 
  array (
    '-' => 5,
    'and' => 1,
    'God' => 1,
  ),
  'mixers' => 
  array (
    'and' => 1,
  ),
  'slap' => 
  array (
    '' => 1,
  ),
  'hikers' => 
  array (
    'aboard,' => 1,
  ),
  'aboard,' => 
  array (
    '' => 1,
  ),
  'partly' => 
  array (
    '' => 2,
    'of' => 2,
    'because' => 1,
    'the' => 1,
  ),
  'company,' => 
  array (
    'but' => 1,
  ),
  'annoys' => 
  array (
    'the' => 1,
  ),
  'Which' => 
  array (
    '' => 1,
    'government...' => 1,
    'one?' => 1,
    'it' => 1,
    'way' => 1,
    'would' => 1,
  ),
  'impoverished' => 
  array (
    '' => 1,
  ),
  'marvels' => 
  array (
    'of' => 2,
  ),
  'Dollars' => 
  array (
    'a' => 1,
  ),
  'Fun,' => 
  array (
    'isn\'t' => 1,
  ),
  'lost.' => 
  array (
    '-' => 1,
    'Arthur' => 1,
    '' => 1,
  ),
  'mattresses.' => 
  array (
    '-' => 1,
  ),
  'Unfortunately' => 
  array (
    'I' => 1,
  ),
  'intended,' => 
  array (
    '-' => 1,
  ),
  'week' => 
  array (
    '' => 1,
  ),
  'Easy,' => 
  array (
    'I' => 1,
  ),
  'teaser.' => 
  array (
    '-' => 1,
  ),
  'teaser?' => 
  array (
    '-' => 1,
    'Teasers' => 1,
  ),
  'Yeah.' => 
  array (
    '-' => 3,
  ),
  'is...' => 
  array (
    '-' => 4,
    'Arthur?' => 1,
    '' => 1,
  ),
  'Teasers' => 
  array (
    'are' => 1,
  ),
  'rich' => 
  array (
    'kids' => 1,
    'and' => 1,
    '' => 1,
    'idiots),' => 1,
    'enough' => 1,
    'ultrared' => 1,
    'resonant' => 1,
  ),
  'cruise' => 
  array (
    'around' => 1,
  ),
  'contact' => 
  array (
    'yet' => 1,
  ),
  'yet' => 
  array (
    'and' => 1,
    'be' => 1,
    '' => 1,
    'in' => 1,
    'I' => 1,
    'another' => 2,
  ),
  'buzz' => 
  array (
    'them.' => 2,
    'followed,' => 1,
  ),
  'Buzz' => 
  array (
    'them?' => 1,
  ),
  'them?' => 
  array (
    '-' => 2,
  ),
  'Yeah,' => 
  array (
    '-' => 7,
    'well' => 2,
    'so' => 1,
    'but' => 2,
    'just' => 1,
    'we\'ll' => 1,
    'well,' => 1,
    'I' => 2,
    'OK,' => 1,
    'why' => 1,
  ),
  'isolated' => 
  array (
    '' => 1,
  ),
  'spot' => 
  array (
    'with' => 1,
  ),
  'around,' => 
  array (
    'then' => 1,
    'shifted' => 1,
    'shouting,' => 1,
    '' => 4,
  ),
  'poor' => 
  array (
    '' => 3,
    'lad,' => 1,
    'innocent' => 1,
  ),
  'soul' => 
  array (
    '' => 2,
  ),
  'one\'s' => 
  array (
    'ever' => 1,
    'to' => 1,
    'finger' => 1,
  ),
  'strut' => 
  array (
    'up' => 1,
  ),
  'wearing' => 
  array (
    'silly' => 1,
    'digital' => 1,
    'the' => 1,
  ),
  'silly' => 
  array (
    'antennae' => 1,
    'question,' => 1,
  ),
  'antennae' => 
  array (
    'on' => 1,
  ),
  'beep' => 
  array (
    'beep' => 1,
    'noises.' => 1,
  ),
  'noises.' => 
  array (
    '' => 1,
    'Slartibartfast' => 1,
  ),
  'Rather' => 
  array (
    'childish' => 1,
  ),
  'childish' => 
  array (
    'really.' => 1,
  ),
  'leant' => 
  array (
    'back' => 1,
  ),
  'infuriatingly' => 
  array (
    'pleased' => 1,
    '' => 1,
  ),
  'insisted' => 
  array (
    'Arthur,' => 3,
    'Ford.' => 1,
    'Zaphod' => 1,
    'Zaphod.' => 2,
    'Zaphod,' => 1,
    'Lunkwill.' => 1,
    'Majikthise.' => 1,
  ),
  'question,' => 
  array (
    'but' => 1,
    'invent' => 1,
    '-' => 1,
  ),
  'rescued' => 
  array (
    'you' => 1,
    'by' => 1,
    'from' => 1,
  ),
  'Earth?' => 
  array (
    '-' => 2,
  ),
  'demolished.' => 
  array (
    '-' => 1,
  ),
  'levelly.' => 
  array (
    '-' => 1,
  ),
  'upset' => 
  array (
    'about' => 1,
    'glare' => 1,
    '' => 1,
  ),
  'that.' => 
  array (
    'Ford' => 1,
    '-' => 7,
    'Arthur' => 1,
    'I' => 1,
    'Ten' => 1,
    'The' => 1,
  ),
  'last.' => 
  array (
    '-' => 2,
  ),
  'Understand' => 
  array (
    'that!' => 2,
  ),
  'that!' => 
  array (
    '-' => 3,
    '' => 1,
  ),
  'sprang' => 
  array (
    'up.' => 1,
    'to' => 1,
    '' => 1,
  ),
  'book!' => 
  array (
    '-' => 1,
  ),
  'hissed' => 
  array (
    'urgently.' => 1,
    'Ford.' => 1,
    'at' => 1,
    'Zaphod,' => 1,
  ),
  'panicking!' => 
  array (
    '-' => 1,
  ),
  'Yes' => 
  array (
    'you' => 2,
    'it' => 1,
    'I' => 1,
    'well' => 1,
    'we' => 1,
    'sir,' => 1,
  ),
  'Alright' => 
  array (
    'so' => 1,
  ),
  'panicking,' => 
  array (
    'what' => 1,
  ),
  'do?' => 
  array (
    '-' => 4,
    '' => 1,
  ),
  'Galaxy\'s' => 
  array (
    '' => 1,
    'richest' => 1,
  ),
  'fish' => 
  array (
    'in' => 3,
    'wriggling' => 1,
    'and' => 1,
    'slithering' => 1,
    'doing' => 1,
    'is' => 1,
    '' => 1,
    'pool,' => 1,
  ),
  'ear.' => 
  array (
    '-' => 1,
    'Ford,' => 1,
  ),
  'beg' => 
  array (
    'your' => 5,
  ),
  'pardon?' => 
  array (
    '-' => 5,
  ),
  'politely' => 
  array (
    'he' => 1,
  ),
  'jar' => 
  array (
    'which' => 1,
  ),
  'wriggling' => 
  array (
    'around' => 1,
  ),
  'recognizable' => 
  array (
    'he' => 1,
    'phases,' => 1,
  ),
  'grasp' => 
  array (
    '' => 2,
  ),
  'alongside' => 
  array (
    '' => 1,
  ),
  'underwear,' => 
  array (
    '' => 1,
  ),
  'piles' => 
  array (
    '' => 1,
    'of' => 1,
  ),
  'offering' => 
  array (
    'to' => 1,
  ),
  'ear' => 
  array (
    'he' => 1,
    'for' => 1,
    'you' => 1,
  ),
  'corn' => 
  array (
    'flakes.' => 1,
  ),
  'flakes.' => 
  array (
    'He' => 1,
  ),
  'couldn\'t,' => 
  array (
    'and' => 1,
  ),
  'safe.' => 
  array (
    'Suddenly' => 1,
    '-' => 1,
    'Even' => 1,
  ),
  'violent' => 
  array (
    'noise' => 1,
  ),
  'source' => 
  array (
    'that' => 1,
    'for' => 1,
    'of' => 3,
  ),
  'identify.' => 
  array (
    'He' => 1,
  ),
  'gargle' => 
  array (
    'whilst' => 1,
    'howl' => 6,
    'gargle' => 3,
  ),
  'fighting' => 
  array (
    'off' => 1,
  ),
  'pack' => 
  array (
    'of' => 2,
  ),
  'wolves.' => 
  array (
    '-' => 1,
  ),
  'Shush!' => 
  array (
    '-' => 2,
  ),
  'Listen,' => 
  array (
    'it' => 1,
    '-' => 2,
  ),
  'Im...' => 
  array (
    'important?' => 1,
  ),
  'important?' => 
  array (
    '-' => 1,
  ),
  'announcement' => 
  array (
    'on' => 1,
  ),
  'T\'annoy.' => 
  array (
    '-' => 1,
  ),
  'Listen!' => 
  array (
    '-' => 1,
  ),
  'Vogon!' => 
  array (
    '-' => 1,
  ),
  'Just' => 
  array (
    'put' => 1,
    'don\'t' => 2,
    'someone.' => 1,
    'a' => 1,
    'very' => 1,
    'that?' => 1,
    'shut' => 1,
    'keep' => 1,
    'let' => 1,
    'before' => 1,
  ),
  'lightning' => 
  array (
    'movement,' => 1,
  ),
  'movement,' => 
  array (
    'clapped' => 1,
  ),
  'clapped' => 
  array (
    'his' => 1,
  ),
  'hand' => 
  array (
    '' => 1,
    'before' => 1,
    'in' => 1,
    'and' => 1,
    'side...' => 1,
    'just' => 1,
  ),
  'ear,' => 
  array (
    'and' => 1,
  ),
  'sickening' => 
  array (
    'sensation' => 1,
  ),
  'slithering' => 
  array (
    'deep' => 1,
  ),
  'aural' => 
  array (
    'tract.' => 1,
    'equivalent' => 1,
  ),
  'tract.' => 
  array (
    'Gasping' => 1,
  ),
  'Gasping' => 
  array (
    'with' => 1,
  ),
  'horror' => 
  array (
    'he' => 1,
    'of' => 1,
    'they' => 1,
    'and' => 1,
  ),
  'scrabbled' => 
  array (
    'at' => 2,
  ),
  'goggle-eyed' => 
  array (
    'with' => 1,
  ),
  'wonder.' => 
  array (
    'He' => 1,
    'Slowly,' => 1,
  ),
  'experiencing' => 
  array (
    'the' => 1,
  ),
  'equivalent' => 
  array (
    'of' => 3,
  ),
  'picture' => 
  array (
    '' => 1,
    'of' => 2,
    '-' => 1,
    'and' => 1,
  ),
  'silhouetted' => 
  array (
    'faces' => 1,
  ),
  'seeing' => 
  array (
    'it' => 1,
    'was' => 1,
    'a' => 1,
    'that' => 1,
  ),
  'candlestick.' => 
  array (
    '' => 1,
  ),
  'coloured' => 
  array (
    'dots' => 1,
    'flags' => 1,
  ),
  'dots' => 
  array (
    'on' => 1,
  ),
  'resolve' => 
  array (
    'themselves' => 1,
  ),
  'figure' => 
  array (
    'six' => 1,
    'into' => 1,
    'this,' => 1,
    'waving' => 1,
    'of' => 1,
    'according' => 1,
    'lying' => 1,
  ),
  'optician' => 
  array (
    '' => 1,
  ),
  'charge' => 
  array (
    'you' => 1,
  ),
  'money' => 
  array (
    'for' => 1,
    'are' => 1,
    'on' => 1,
    'and' => 1,
  ),
  'glasses.' => 
  array (
    'He' => 1,
  ),
  'listening' => 
  array (
    'to' => 2,
  ),
  'gargles,' => 
  array (
    'he' => 1,
  ),
  'semblance' => 
  array (
    'of' => 1,
  ),
  'straightforward' => 
  array (
    'English.' => 1,
  ),
  'English.' => 
  array (
    'This' => 1,
  ),
  'heard...' => 
  array (
    'Chapter' => 1,
  ),
  6 => 
  array (
    '-' => 1,
  ),
  'Howl' => 
  array (
    'howl' => 1,
  ),
  'howl' => 
  array (
    'gargle' => 6,
    'howl' => 3,
    '' => 1,
  ),
  'slurrp' => 
  array (
    '' => 1,
  ),
  'uuuurgh' => 
  array (
    '' => 1,
  ),
  'Message' => 
  array (
    'repeats.' => 1,
    'ends.' => 1,
  ),
  'repeats.' => 
  array (
    'This' => 1,
  ),
  'speaking,' => 
  array (
    'so' => 1,
    'matter' => 1,
  ),
  'whatever' => 
  array (
    'you\'re' => 1,
    'it' => 2,
    'his' => 1,
    'your' => 1,
    '' => 1,
  ),
  'attention.' => 
  array (
    'First' => 1,
    'Suddenly' => 1,
    'A' => 1,
  ),
  'instruments' => 
  array (
    'that' => 1,
    'reading' => 1,
    '' => 2,
  ),
  'hitchhikers' => 
  array (
    '' => 1,
  ),
  'aboard.' => 
  array (
    '' => 1,
  ),
  'wherever' => 
  array (
    'you' => 1,
    'they' => 1,
  ),
  'clear' => 
  array (
    'that' => 1,
    'inflection.' => 1,
    'where' => 1,
    'as' => 1,
    'shape,' => 1,
    'to' => 1,
    'idea' => 1,
    'away' => 2,
  ),
  'constructor' => 
  array (
    'ship' => 1,
  ),
  'taxi' => 
  array (
    'service' => 1,
  ),
  'service' => 
  array (
    'for' => 1,
    'we' => 1,
  ),
  'load' => 
  array (
    'of' => 1,
    '' => 1,
  ),
  'degenerate' => 
  array (
    'freeloaders.' => 1,
  ),
  'freeloaders.' => 
  array (
    'I' => 1,
  ),
  'party,' => 
  array (
    'and' => 1,
    '-' => 3,
  ),
  'ship.' => 
  array (
    '' => 1,
    '-' => 3,
    'It' => 1,
    'A' => 1,
    'The' => 1,
    'I' => 1,
    'Beside' => 1,
    'As' => 1,
  ),
  'lucky' => 
  array (
    'I' => 1,
    'it\'s' => 1,
    '' => 3,
    'lucky' => 1,
    'guys.' => 1,
    'chance' => 1,
  ),
  'Secondly,' => 
  array (
    'we' => 1,
  ),
  'journey' => 
  array (
    '' => 2,
  ),
  'Star.' => 
  array (
    'On' => 1,
  ),
  'arrival' => 
  array (
    'we' => 1,
    '' => 1,
    'on' => 1,
  ),
  'stay' => 
  array (
    'in' => 1,
  ),
  'dock' => 
  array (
    '' => 1,
  ),
  'seventy-two' => 
  array (
    '' => 1,
  ),
  'refit,' => 
  array (
    'and' => 1,
  ),
  'leave' => 
  array (
    'the' => 1,
    'is' => 1,
    'your' => 1,
    'it' => 1,
  ),
  'during' => 
  array (
    '' => 1,
    'the' => 1,
    'which' => 1,
  ),
  'repeat,' => 
  array (
    '' => 1,
  ),
  'cancelled.' => 
  array (
    'I\'ve' => 1,
  ),
  'love' => 
  array (
    '' => 1,
  ),
  'affair,' => 
  array (
    '' => 1,
    'and' => 1,
    'slate' => 1,
  ),
  'ends.' => 
  array (
    'The' => 1,
  ),
  'embarrassment' => 
  array (
    'that' => 1,
  ),
  'curled' => 
  array (
    'up' => 1,
    'himself' => 2,
  ),
  'floor' => 
  array (
    'with' => 1,
    'where' => 1,
    'again.' => 1,
    'of' => 1,
    'lay' => 1,
  ),
  'weakly.' => 
  array (
    '-' => 3,
  ),
  'Charming' => 
  array (
    'man,' => 1,
  ),
  'daughter' => 
  array (
    '' => 1,
  ),
  'forbid' => 
  array (
    'her' => 1,
  ),
  'marry' => 
  array (
    'one...' => 1,
  ),
  'one...' => 
  array (
    '-' => 1,
    'two...' => 1,
    'probability' => 1,
    'we' => 1,
  ),
  'appeal' => 
  array (
    'as' => 1,
  ),
  'road' => 
  array (
    'accident.' => 1,
    'to' => 1,
    'for' => 1,
    'in' => 1,
    'again.' => 1,
  ),
  'accident.' => 
  array (
    'No,' => 1,
  ),
  'added' => 
  array (
    'as' => 1,
    'the' => 1,
    'with' => 1,
    'Lunkwill.' => 1,
    'Deep' => 1,
    'on' => 1,
    'Arthur,' => 1,
  ),
  'uncurl' => 
  array (
    'himself,' => 1,
  ),
  'hyperspace.' => 
  array (
    '' => 2,
    '-' => 1,
    'It' => 1,
  ),
  'unpleasantly' => 
  array (
    'like' => 1,
  ),
  'drunk.' => 
  array (
    '-' => 1,
  ),
  'drunk?' => 
  array (
    '-' => 1,
  ),
  'Yeah?' => 
  array (
    '-' => 5,
    'Worth' => 1,
  ),
  'ear?' => 
  array (
    '-' => 1,
  ),
  'translating' => 
  array (
    'for' => 1,
  ),
  'Babel' => 
  array (
    'fish.' => 2,
    'fish,' => 1,
    'fish' => 2,
    '' => 1,
  ),
  'fish.' => 
  array (
    'Look' => 1,
    '-' => 3,
    'In' => 1,
  ),
  'Look' => 
  array (
    'it' => 1,
    'Zaphod,' => 1,
    'at' => 2,
    'kid,' => 1,
    'robot,' => 1,
    'why' => 1,
  ),
  'like.' => 
  array (
    'He' => 1,
    '-' => 1,
    'It' => 1,
  ),
  'tossed' => 
  array (
    'over' => 1,
    'and' => 1,
    '' => 1,
  ),
  'foetal' => 
  array (
    'ball' => 1,
  ),
  'prepare' => 
  array (
    'himself' => 1,
    'for' => 1,
  ),
  'jump.' => 
  array (
    'At' => 1,
  ),
  'leak' => 
  array (
    'out' => 1,
  ),
  'spun' => 
  array (
    'around,' => 1,
  ),
  'navel.' => 
  array (
    'They' => 1,
  ),
  'fish,' => 
  array (
    'said' => 1,
    '' => 1,
  ),
  'quietly,' => 
  array (
    '-' => 5,
    '' => 1,
  ),
  'small,' => 
  array (
    'yellow' => 1,
  ),
  'leech-like,' => 
  array (
    'and' => 1,
  ),
  'oddest' => 
  array (
    '' => 1,
    'things.' => 1,
  ),
  'Universe.' => 
  array (
    'It' => 1,
    'The' => 1,
    'Five' => 1,
    'Be' => 1,
    '-' => 1,
    'I' => 1,
  ),
  'feeds' => 
  array (
    'on' => 1,
    'should' => 1,
  ),
  'brainwave' => 
  array (
    'energy' => 2,
    'matrix' => 1,
  ),
  'energy' => 
  array (
    'not' => 1,
    'to' => 1,
    'bolt' => 1,
    'bolts' => 1,
  ),
  'carrier' => 
  array (
    'but' => 1,
    'a' => 1,
  ),
  'absorbs' => 
  array (
    '' => 1,
  ),
  'unconscious' => 
  array (
    '' => 1,
  ),
  'frequencies' => 
  array (
    '' => 1,
    'with' => 1,
  ),
  'nourish' => 
  array (
    'itself' => 1,
  ),
  'excretes' => 
  array (
    'into' => 1,
  ),
  'telepathic' => 
  array (
    'matrix' => 1,
  ),
  'matrix' => 
  array (
    'formed' => 1,
    'which' => 1,
    '' => 1,
  ),
  'combining' => 
  array (
    'the' => 1,
  ),
  'conscious' => 
  array (
    '' => 1,
  ),
  'nerve' => 
  array (
    'signals' => 1,
  ),
  'centres' => 
  array (
    '' => 1,
    'of' => 2,
  ),
  'supplied' => 
  array (
    'them.' => 1,
  ),
  'upshot' => 
  array (
    'of' => 1,
  ),
  'instantly' => 
  array (
    '' => 1,
    'under' => 1,
  ),
  'language.' => 
  array (
    'The' => 1,
  ),
  'patterns' => 
  array (
    'you' => 1,
    'quickly' => 1,
    'in' => 1,
    'that' => 1,
  ),
  'hear' => 
  array (
    'decode' => 1,
    'you' => 1,
    'around' => 1,
    'enough' => 1,
    'the' => 2,
    'what' => 1,
    '' => 2,
  ),
  'decode' => 
  array (
    'the' => 1,
  ),
  'fed' => 
  array (
    '' => 1,
    'up' => 2,
  ),
  'Now' => 
  array (
    'it' => 1,
    'Earthlings...' => 1,
    'you' => 1,
    'wait' => 1,
    '' => 1,
    '-' => 1,
    'this' => 1,
    'see' => 1,
    'either' => 1,
  ),
  'bizarrely' => 
  array (
    'improbable' => 1,
  ),
  'improbable' => 
  array (
    'coincidence' => 1,
    '' => 3,
    'you' => 1,
    'it' => 1,
    'has' => 1,
  ),
  'purely' => 
  array (
    '' => 1,
  ),
  'chance' => 
  array (
    '' => 2,
    'that' => 2,
  ),
  'thinkers' => 
  array (
    'have' => 1,
  ),
  'non-existence' => 
  array (
    'of' => 1,
  ),
  'God.' => 
  array (
    'The' => 1,
    '-' => 1,
  ),
  'argument' => 
  array (
    'goes' => 1,
    '' => 1,
    'and' => 1,
    'I' => 1,
  ),
  'goes' => 
  array (
    'something' => 1,
    'on' => 2,
    'and' => 2,
  ),
  'refuse' => 
  array (
    'to' => 1,
  ),
  'prove' => 
  array (
    'that' => 2,
  ),
  'God,' => 
  array (
    '' => 1,
    '-' => 5,
  ),
  'denies' => 
  array (
    'faith,' => 1,
  ),
  'faith,' => 
  array (
    'and' => 1,
  ),
  'faith' => 
  array (
    'I' => 1,
  ),
  'Man,' => 
  array (
    '-' => 1,
    'and' => 1,
  ),
  'giveaway,' => 
  array (
    'isn\'t' => 1,
  ),
  'chance.' => 
  array (
    'It' => 1,
  ),
  'proves' => 
  array (
    'you' => 1,
  ),
  'therefore,' => 
  array (
    'by' => 1,
  ),
  'arguments,' => 
  array (
    'you' => 1,
  ),
  'QED.' => 
  array (
    '-' => 1,
  ),
  'promptly' => 
  array (
    'vanished' => 1,
    'fell' => 1,
  ),
  'puff' => 
  array (
    'of' => 1,
  ),
  'logic.' => 
  array (
    '-' => 1,
  ),
  'easy,' => 
  array (
    '-' => 1,
  ),
  'encore' => 
  array (
    'goes' => 1,
    '' => 1,
  ),
  'gets' => 
  array (
    'himself' => 1,
  ),
  'zebra' => 
  array (
    'crossing.' => 1,
  ),
  'crossing.' => 
  array (
    '-' => 1,
  ),
  'leading' => 
  array (
    'theologians' => 1,
    'nowhere' => 1,
    'the' => 1,
    'up' => 1,
  ),
  'theologians' => 
  array (
    'claim' => 1,
  ),
  'claim' => 
  array (
    'that' => 1,
  ),
  'kidneys,' => 
  array (
    'but' => 1,
  ),
  'Colluphid' => 
  array (
    '' => 1,
  ),
  'fortune' => 
  array (
    'when' => 1,
    'to' => 1,
  ),
  'central' => 
  array (
    'theme' => 1,
  ),
  'theme' => 
  array (
    'of' => 1,
  ),
  'bestselling' => 
  array (
    'book' => 1,
  ),
  'Wraps' => 
  array (
    'It' => 1,
  ),
  'removing' => 
  array (
    '' => 1,
  ),
  'barriers' => 
  array (
    'to' => 1,
  ),
  'communication' => 
  array (
    'between' => 1,
    'mode.' => 1,
    'channel.' => 1,
  ),
  'cultures,' => 
  array (
    'has' => 1,
  ),
  'caused' => 
  array (
    'more' => 1,
    'by' => 1,
    'considerable' => 1,
  ),
  'bloddier' => 
  array (
    'wars' => 1,
  ),
  'wars' => 
  array (
    'than' => 1,
    'and' => 1,
  ),
  'creation.' => 
  array (
    'Arthur' => 1,
  ),
  'horrified' => 
  array (
    '' => 1,
  ),
  'discover' => 
  array (
    '' => 2,
    'that' => 1,
  ),
  'existed.' => 
  array (
    'The' => 1,
    'He\'d' => 1,
    'Chapter' => 1,
  ),
  'Visions' => 
  array (
    'of' => 1,
  ),
  'swam' => 
  array (
    'sickeningly' => 1,
  ),
  'sickeningly' => 
  array (
    'through' => 1,
    '' => 1,
  ),
  'nauseated' => 
  array (
    'mind.' => 1,
  ),
  'imagination' => 
  array (
    'could' => 1,
    'at' => 1,
    '-' => 1,
  ),
  'impact' => 
  array (
    'of' => 1,
    'minus' => 1,
    '' => 2,
    'cracked' => 1,
  ),
  'gone,' => 
  array (
    'it' => 1,
    '' => 1,
    'McDonald\'s' => 1,
    'all' => 1,
  ),
  'big.' => 
  array (
    'He' => 1,
    'Really' => 1,
    'You' => 1,
  ),
  'feelings' => 
  array (
    'by' => 1,
  ),
  'thinking' => 
  array (
    'that' => 1,
    'you' => 1,
    'about' => 1,
    'in' => 1,
    '' => 1,
  ),
  'parents' => 
  array (
    'and' => 1,
    'tell' => 1,
  ),
  'sister' => 
  array (
    'had' => 1,
  ),
  'reaction.' => 
  array (
    'He' => 1,
    'Then' => 1,
    'He\'d' => 1,
    'Magrathea!' => 1,
  ),
  'complete' => 
  array (
    'stranger' => 1,
    'record' => 1,
  ),
  'stranger' => 
  array (
    'he' => 1,
  ),
  'queue' => 
  array (
    'at' => 1,
    'again' => 1,
  ),
  'supermarket' => 
  array (
    '' => 2,
  ),
  'stab' => 
  array (
    '-' => 1,
  ),
  'Nelson\'s' => 
  array (
    'Column' => 3,
    '' => 1,
  ),
  'Column' => 
  array (
    'had' => 2,
    'only' => 1,
    'has' => 1,
  ),
  'gone!' => 
  array (
    'Nelson\'s' => 1,
  ),
  'outcry,' => 
  array (
    'because' => 1,
  ),
  'outcry.' => 
  array (
    '' => 1,
  ),
  'England' => 
  array (
    'only' => 1,
    'no' => 1,
    'in' => 1,
  ),
  'mind,' => 
  array (
    'stuck' => 1,
    'hey,' => 1,
    'I' => 1,
  ),
  'dank' => 
  array (
    'smelly' => 1,
  ),
  'steel-lined' => 
  array (
    'spaceship.' => 1,
    'corridor' => 1,
  ),
  'spaceship.' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'claustrophobia' => 
  array (
    'closed' => 1,
  ),
  'somehow' => 
  array (
    'he\'d' => 1,
    'looked' => 1,
    'unnaturally' => 1,
  ),
  'America,' => 
  array (
    'he' => 1,
  ),
  'smaller' => 
  array (
    'again.' => 1,
  ),
  'York' => 
  array (
    'has' => 1,
  ),
  'believed' => 
  array (
    'it' => 1,
    'that' => 1,
  ),
  'dollar,' => 
  array (
    'he' => 1,
  ),
  'sunk' => 
  array (
    'for' => 1,
    'away' => 1,
    'in' => 1,
  ),
  'ever.' => 
  array (
    'Slight' => 1,
    '-' => 1,
  ),
  'Slight' => 
  array (
    'tremor' => 1,
  ),
  'tremor' => 
  array (
    'there.' => 1,
  ),
  'Bogart' => 
  array (
    'movie' => 1,
  ),
  'movie' => 
  array (
    'has' => 1,
  ),
  'wiped,' => 
  array (
    'he' => 1,
  ),
  'nasty' => 
  array (
    'knock.' => 1,
    'bruise' => 1,
  ),
  'knock.' => 
  array (
    'McDonalds,' => 1,
  ),
  'McDonalds,' => 
  array (
    'he' => 1,
  ),
  'McDonald\'s' => 
  array (
    'hamburger.' => 1,
    'have' => 1,
  ),
  'hamburger.' => 
  array (
    'He' => 1,
  ),
  'When' => 
  array (
    'he' => 2,
    'you\'re' => 1,
    '' => 1,
    'you' => 1,
    'one' => 1,
    'they' => 1,
    'we' => 1,
    'did' => 1,
    'it' => 1,
  ),
  'sobbing' => 
  array (
    'for' => 1,
  ),
  'mother.' => 
  array (
    'He' => 1,
    'The' => 1,
  ),
  'jerked' => 
  array (
    'himself' => 1,
  ),
  'violently' => 
  array (
    'to' => 1,
    'back' => 1,
    'enough' => 1,
  ),
  'humming' => 
  array (
    '' => 1,
    'noises' => 1,
    'ironically' => 1,
    'again.' => 1,
    'was' => 1,
  ),
  'actual' => 
  array (
    'travelling-through-space' => 1,
    'minutes' => 1,
  ),
  'travelling-through-space' => 
  array (
    'part' => 1,
  ),
  'travel' => 
  array (
    'rather' => 1,
    'that' => 1,
  ),
  'trying.' => 
  array (
    '-' => 1,
  ),
  'gathering' => 
  array (
    'material' => 1,
  ),
  'material' => 
  array (
    'on' => 1,
  ),
  'extend' => 
  array (
    'the' => 1,
    'to' => 1,
  ),
  'Let' => 
  array (
    'me' => 3,
    'go' => 1,
  ),
  'edition' => 
  array (
    'then,' => 1,
    'of' => 1,
  ),
  'Yeah' => 
  array (
    'OK.' => 1,
    'yeah,' => 1,
    'well' => 1,
    'could' => 1,
  ),
  'OK.' => 
  array (
    '-' => 1,
  ),
  'grabbed' => 
  array (
    'hold' => 1,
    'for' => 1,
    'him' => 1,
    '' => 1,
  ),
  'shaking.' => 
  array (
    '' => 1,
  ),
  'relevant' => 
  array (
    'page.' => 1,
  ),
  'page.' => 
  array (
    'The' => 1,
  ),
  'swirled' => 
  array (
    'and' => 1,
    'in' => 1,
    '' => 1,
    'round' => 1,
  ),
  'resolved' => 
  array (
    'into' => 1,
    'itself' => 1,
  ),
  'print.' => 
  array (
    'Arthur' => 1,
  ),
  'doesn\'t' => 
  array (
    'have' => 1,
    '' => 2,
    'sound' => 1,
    'matter' => 1,
    'anyone' => 1,
    'fit' => 1,
    'work.' => 1,
  ),
  'entry!' => 
  array (
    '-' => 1,
  ),
  'shoulder.' => 
  array (
    '-' => 2,
  ),
  'does,' => 
  array (
    '-' => 1,
  ),
  'Eccentrica' => 
  array (
    'Gallumbits,' => 1,
    'Gallumbits' => 1,
  ),
  'Gallumbits,' => 
  array (
    '' => 1,
  ),
  'triple-breasted' => 
  array (
    '' => 1,
  ),
  'whore' => 
  array (
    '' => 1,
  ),
  'Eroticon' => 
  array (
    '6.' => 1,
  ),
  '6.' => 
  array (
    'Arthur' => 1,
  ),
  'finger,' => 
  array (
    'and' => 1,
    'till' => 1,
    'yeah?' => 1,
  ),
  'pointing.' => 
  array (
    '' => 1,
  ),
  'register,' => 
  array (
    'then' => 1,
  ),
  'blew' => 
  array (
    'up.' => 2,
    '' => 1,
  ),
  'Harmless?' => 
  array (
    'Is' => 1,
  ),
  'Harmless!' => 
  array (
    'One' => 1,
  ),
  'word!' => 
  array (
    'Ford' => 1,
  ),
  'shrugged.' => 
  array (
    '-' => 4,
  ),
  'limited' => 
  array (
    'amount' => 1,
  ),
  'book\'s' => 
  array (
    'microprocessors,' => 1,
  ),
  'microprocessors,' => 
  array (
    '-' => 1,
  ),
  'managed' => 
  array (
    'to' => 5,
    'a' => 1,
  ),
  'transmit' => 
  array (
    'a' => 1,
  ),
  'editor.' => 
  array (
    'He' => 1,
  ),
  'trim' => 
  array (
    'it' => 1,
  ),
  'improvement.' => 
  array (
    '-' => 1,
  ),
  'now?' => 
  array (
    '-' => 3,
    'For' => 1,
  ),
  'Mostly' => 
  array (
    'harmless,' => 1,
    'harmless!' => 1,
    'Harmless.' => 1,
    '' => 1,
  ),
  'harmless,' => 
  array (
    '-' => 1,
  ),
  'admitted' => 
  array (
    'Ford' => 1,
  ),
  'embarrassed' => 
  array (
    'cough.' => 1,
    'little' => 1,
  ),
  'cough.' => 
  array (
    '-' => 1,
  ),
  'harmless!' => 
  array (
    '-' => 1,
  ),
  'noise?' => 
  array (
    '-' => 1,
  ),
  'shouting,' => 
  array (
    '-' => 2,
    'pushing' => 1,
    'sure,' => 1,
  ),
  'No!' => 
  array (
    'Shut' => 1,
  ),
  'up!' => 
  array (
    '-' => 4,
  ),
  'we\'re' => 
  array (
    'in' => 2,
    'lucky' => 1,
    'unlucky?' => 1,
    'unlucky,' => 1,
    '' => 2,
    'trapped.' => 1,
    'going' => 1,
    'both' => 1,
    'on' => 1,
    'all' => 2,
    'also' => 1,
    'not' => 1,
    'straight' => 1,
    'building' => 1,
    'sick' => 1,
    'very' => 1,
  ),
  'trouble.' => 
  array (
    '-' => 1,
  ),
  'trouble!' => 
  array (
    'Outside' => 1,
  ),
  'Outside' => 
  array (
    'the' => 1,
  ),
  'marching' => 
  array (
    'feet.' => 1,
  ),
  'whispered' => 
  array (
    'Arthur.' => 2,
    'Zaphod.' => 1,
    'Ford.' => 1,
    'Ford' => 1,
  ),
  'steel' => 
  array (
    'tipped' => 1,
    'door' => 1,
    'ceiling' => 1,
    'hatchway' => 1,
    'head' => 1,
    'knees.' => 1,
    '' => 1,
    'shutter' => 1,
    'tunnels' => 1,
    'figure' => 1,
  ),
  'boots,' => 
  array (
    '-' => 1,
  ),
  'sharp' => 
  array (
    'ringing' => 1,
    'relief.' => 1,
  ),
  'ringing' => 
  array (
    'rap' => 1,
    'tones.' => 1,
  ),
  'rap' => 
  array (
    'on' => 1,
  ),
  'door.' => 
  array (
    '-' => 4,
    'Life!' => 1,
    'It' => 1,
  ),
  'throw' => 
  array (
    'us' => 2,
    'my' => 1,
    'you' => 2,
    'them' => 1,
  ),
  'unlucky?' => 
  array (
    '-' => 1,
  ),
  'unlucky,' => 
  array (
    '-' => 1,
  ),
  'grimly,' => 
  array (
    '' => 1,
  ),
  'serious' => 
  array (
    '' => 2,
  ),
  'threat' => 
  array (
    '' => 1,
    'you' => 1,
  ),
  'first...' => 
  array (
    'Chapter' => 1,
  ),
  7 => 
  array (
    'Vogon' => 1,
  ),
  'worst' => 
  array (
    'in' => 1,
    'is' => 1,
    'poetry' => 1,
  ),
  'Azagoths' => 
  array (
    'of' => 1,
  ),
  'Kria.' => 
  array (
    'During' => 1,
  ),
  'During' => 
  array (
    'a' => 1,
  ),
  'recitation' => 
  array (
    'by' => 1,
  ),
  'Poet' => 
  array (
    'Master' => 1,
  ),
  'Master' => 
  array (
    'Grunthos' => 1,
  ),
  'Grunthos' => 
  array (
    'the' => 1,
    'is' => 1,
  ),
  'Flatulent' => 
  array (
    'of' => 1,
  ),
  'poem' => 
  array (
    '"Ode' => 1,
    'and' => 1,
    'was!' => 1,
    'was' => 1,
  ),
  '"Ode' => 
  array (
    '' => 1,
  ),
  'Small' => 
  array (
    'Lump' => 1,
  ),
  'Lump' => 
  array (
    'of' => 1,
  ),
  'Putty' => 
  array (
    'I' => 1,
  ),
  'Found' => 
  array (
    'In' => 1,
  ),
  'Armpit' => 
  array (
    'One' => 1,
  ),
  'Midsummer' => 
  array (
    '' => 1,
  ),
  'Morning"' => 
  array (
    '' => 1,
  ),
  'audience' => 
  array (
    'died' => 1,
  ),
  'internal' => 
  array (
    'haemorrhaging,' => 1,
  ),
  'haemorrhaging,' => 
  array (
    '' => 1,
  ),
  'Mid-Galactic' => 
  array (
    'Arts' => 1,
  ),
  'Arts' => 
  array (
    'Nobbling' => 1,
  ),
  'Nobbling' => 
  array (
    'Council' => 1,
  ),
  'Council' => 
  array (
    'survived' => 1,
  ),
  'survived' => 
  array (
    'by' => 1,
  ),
  'gnawing' => 
  array (
    'one' => 1,
  ),
  'legs' => 
  array (
    'off.' => 1,
    '' => 2,
    'in' => 1,
  ),
  'reported' => 
  array (
    '' => 1,
  ),
  '"disappointed"' => 
  array (
    '' => 1,
  ),
  'poem\'s' => 
  array (
    'reception,' => 1,
  ),
  'reception,' => 
  array (
    'and' => 1,
  ),
  'embark' => 
  array (
    'on' => 1,
  ),
  'reading' => 
  array (
    '' => 1,
    'and' => 1,
    'off' => 1,
  ),
  'twelvebook' => 
  array (
    '' => 1,
  ),
  'epic' => 
  array (
    'entitled' => 1,
  ),
  'Favourite' => 
  array (
    'Bathtime' => 1,
  ),
  'Bathtime' => 
  array (
    'Gurgles' => 1,
  ),
  'Gurgles' => 
  array (
    'when' => 1,
  ),
  'intestine,' => 
  array (
    'in' => 1,
  ),
  'civilization,' => 
  array (
    'leapt' => 1,
  ),
  'neck' => 
  array (
    'and' => 1,
    'in' => 1,
    'of' => 1,
  ),
  'throttled' => 
  array (
    'his' => 1,
  ),
  'brain.' => 
  array (
    'The' => 1,
    '-' => 1,
  ),
  'perished' => 
  array (
    'along' => 1,
  ),
  'creator' => 
  array (
    '' => 1,
  ),
  'Paula' => 
  array (
    'Nancy' => 1,
  ),
  'Nancy' => 
  array (
    'Millstone' => 1,
  ),
  'Millstone' => 
  array (
    'Jennings' => 1,
  ),
  'Jennings' => 
  array (
    'of' => 1,
  ),
  'Greenbridge,' => 
  array (
    'Essex,' => 1,
  ),
  'Essex,' => 
  array (
    'England' => 1,
  ),
  'destruction' => 
  array (
    'of' => 2,
  ),
  'slowly.' => 
  array (
    'This' => 1,
  ),
  'remember' => 
  array (
    '' => 2,
    'I' => 1,
    'Yooden,' => 1,
  ),
  'sequence' => 
  array (
    '' => 1,
  ),
  'muscle' => 
  array (
    'movements.' => 1,
  ),
  'movements.' => 
  array (
    'He' => 1,
  ),
  'therapeutic' => 
  array (
    'yell' => 1,
  ),
  'yell' => 
  array (
    'at' => 1,
  ),
  'prisoners' => 
  array (
    'and' => 1,
    'sat' => 1,
    '' => 1,
    'to' => 1,
  ),
  'ready' => 
  array (
    'for' => 1,
    'again.' => 1,
    'to' => 3,
  ),
  'callousness.' => 
  array (
    'The' => 1,
  ),
  'Poetry' => 
  array (
    'Appreciation' => 1,
  ),
  'Appreciation' => 
  array (
    'Chairs' => 1,
  ),
  'Chairs' => 
  array (
    '-' => 1,
  ),
  'strapped' => 
  array (
    'in.' => 1,
    'to' => 1,
  ),
  'suffered' => 
  array (
    'no' => 1,
    'from' => 1,
  ),
  'illusions' => 
  array (
    'as' => 1,
  ),
  'regard' => 
  array (
    'their' => 1,
  ),
  'works' => 
  array (
    'were' => 1,
    'out.' => 1,
    '' => 1,
  ),
  'generally' => 
  array (
    'held' => 1,
    'realized' => 1,
    'thought' => 1,
    'leading' => 1,
    'weird' => 1,
  ),
  'held' => 
  array (
    'in.' => 1,
    'up' => 1,
    '' => 1,
    'their' => 1,
  ),
  'Their' => 
  array (
    '' => 1,
    'relative' => 1,
    'names' => 1,
    'waiting' => 1,
  ),
  'early' => 
  array (
    '' => 2,
    'sixties' => 1,
    'for' => 1,
  ),
  'attempts' => 
  array (
    '' => 4,
  ),
  'composition' => 
  array (
    '' => 1,
  ),
  'bludgeoning' => 
  array (
    'insistence' => 1,
  ),
  'insistence' => 
  array (
    'that' => 1,
  ),
  'cultured' => 
  array (
    '' => 1,
  ),
  'race,' => 
  array (
    'but' => 1,
  ),
  'sheer' => 
  array (
    'bloodymindedness.' => 1,
    'enormity' => 1,
    'industrial' => 1,
    'that' => 1,
  ),
  'bloodymindedness.' => 
  array (
    'The' => 1,
  ),
  'sweat' => 
  array (
    'stood' => 1,
  ),
  'brow,' => 
  array (
    'and' => 1,
  ),
  'electrodes' => 
  array (
    'strapped' => 1,
  ),
  'attached' => 
  array (
    'to' => 1,
  ),
  'battery' => 
  array (
    '' => 1,
  ),
  'equipment' => 
  array (
    '' => 1,
    'and' => 1,
    'to' => 1,
    'they' => 1,
  ),
  'imagery' => 
  array (
    '' => 1,
    'was' => 1,
  ),
  'intensifiers,' => 
  array (
    '' => 1,
  ),
  'rhythmic' => 
  array (
    '' => 2,
  ),
  'modulators,' => 
  array (
    'alliterative' => 1,
  ),
  'alliterative' => 
  array (
    'residulators' => 1,
  ),
  'residulators' => 
  array (
    'and' => 1,
  ),
  'simile' => 
  array (
    'dumpers' => 1,
  ),
  'dumpers' => 
  array (
    '-' => 1,
  ),
  'designed' => 
  array (
    '' => 4,
    'to' => 1,
    'this' => 1,
    'you' => 1,
    'for' => 1,
    'the' => 1,
  ),
  'heighten' => 
  array (
    'the' => 1,
  ),
  'experience' => 
  array (
    'of' => 1,
    'the' => 1,
    'was' => 1,
    '' => 1,
  ),
  'single' => 
  array (
    'nuance' => 1,
    'long' => 1,
    '' => 3,
    'worm' => 1,
    'word' => 1,
  ),
  'nuance' => 
  array (
    '' => 1,
  ),
  'poet\'s' => 
  array (
    'thought' => 1,
    'compassionate' => 1,
  ),
  'quivered.' => 
  array (
    'He' => 1,
  ),
  'for,' => 
  array (
    '' => 2,
  ),
  'fetid' => 
  array (
    'little' => 1,
  ),
  'passage' => 
  array (
    'of' => 1,
  ),
  'devising.' => 
  array (
    '-' => 1,
  ),
  'frettled' => 
  array (
    'gruntbuggly...' => 1,
  ),
  'gruntbuggly...' => 
  array (
    '-' => 1,
  ),
  'began.' => 
  array (
    'Spasms' => 1,
  ),
  'Spasms' => 
  array (
    'wracked' => 1,
  ),
  'wracked' => 
  array (
    'Ford\'s' => 1,
  ),
  '...thy' => 
  array (
    'micturations' => 1,
  ),
  'micturations' => 
  array (
    'are' => 1,
  ),
  'plurdled' => 
  array (
    '' => 1,
  ),
  'gabbleblotchits' => 
  array (
    '' => 1,
  ),
  'lurgid' => 
  array (
    'bee.' => 1,
  ),
  'bee.' => 
  array (
    '-' => 1,
  ),
  'Aaaaaaarggggghhhhhh!' => 
  array (
    '-' => 1,
  ),
  'wrenching' => 
  array (
    'his' => 1,
  ),
  'lumps' => 
  array (
    'of' => 2,
  ),
  'pain' => 
  array (
    'thumped' => 1,
    'in' => 1,
    '' => 1,
  ),
  'thumped' => 
  array (
    'through' => 1,
  ),
  'dimly' => 
  array (
    'see' => 1,
    'contoured.' => 1,
    '' => 1,
  ),
  'lolling' => 
  array (
    'and' => 1,
    'back' => 1,
  ),
  'seat.' => 
  array (
    'He' => 1,
    '-' => 4,
  ),
  'clenched' => 
  array (
    'his' => 1,
  ),
  'teeth.' => 
  array (
    '-' => 2,
  ),
  'Groop' => 
  array (
    'I' => 1,
  ),
  'implore' => 
  array (
    '' => 1,
  ),
  'thee,' => 
  array (
    '' => 1,
  ),
  'merciless' => 
  array (
    '' => 1,
  ),
  'foonting' => 
  array (
    'turlingdromes.' => 1,
  ),
  'turlingdromes.' => 
  array (
    'His' => 1,
  ),
  'rising' => 
  array (
    'to' => 1,
    'angrily' => 1,
  ),
  'horrible' => 
  array (
    'pitch' => 1,
  ),
  'pitch' => 
  array (
    'of' => 2,
    'and' => 1,
  ),
  'impassioned' => 
  array (
    'stridency.' => 1,
  ),
  'stridency.' => 
  array (
    '-' => 1,
  ),
  'hooptiously' => 
  array (
    'drangle' => 1,
  ),
  'drangle' => 
  array (
    'me' => 1,
  ),
  'crinkly' => 
  array (
    'bindlewurdles,|' => 1,
    'edges.' => 1,
  ),
  'bindlewurdles,|' => 
  array (
    'Or' => 1,
  ),
  'rend' => 
  array (
    'thee' => 1,
  ),
  'thee' => 
  array (
    'in' => 1,
  ),
  'gobberwarts' => 
  array (
    'with' => 1,
  ),
  'blurglecruncheon,' => 
  array (
    'see' => 1,
  ),
  'don\'t!' => 
  array (
    '-' => 2,
  ),
  'Nnnnnnnnnnyyyyyyyuuuuuuurrrrrrrggggggghhhhh!' => 
  array (
    '-' => 1,
  ),
  'cried' => 
  array (
    '' => 2,
    'Arthur' => 1,
    'Arthur.' => 1,
    'Zaphod,' => 2,
    'in' => 1,
    'the' => 3,
    'Loonquawl.' => 1,
    'Slartibartfast,' => 1,
    'Arthur,' => 1,
    'Trillian.' => 1,
  ),
  'spasm' => 
  array (
    'as' => 1,
    'of' => 1,
  ),
  'enhancement' => 
  array (
    'of' => 1,
  ),
  'line' => 
  array (
    'caught' => 1,
    'of' => 1,
  ),
  'blast' => 
  array (
    'across' => 1,
    'you' => 1,
  ),
  'limp.' => 
  array (
    'Arthur' => 1,
  ),
  'lolled.' => 
  array (
    '-' => 1,
  ),
  'Earthlings...' => 
  array (
    '-' => 1,
  ),
  'whirred' => 
  array (
    'the' => 1,
  ),
  '(he' => 
  array (
    '' => 2,
  ),
  'cared' => 
  array (
    'if' => 1,
    'to' => 2,
  ),
  'had)' => 
  array (
    '-' => 1,
  ),
  'present' => 
  array (
    '' => 2,
    'trajectory' => 1,
    'on' => 1,
    'in' => 1,
  ),
  'choice!' => 
  array (
    'Either' => 1,
  ),
  'Either' => 
  array (
    'die' => 1,
  ),
  'vacuum' => 
  array (
    'of' => 1,
    '' => 1,
  ),
  'or...' => 
  array (
    '' => 1,
  ),
  'paused' => 
  array (
    '' => 2,
    'politely,' => 1,
    'and' => 2,
    'for' => 3,
  ),
  'melodramatic' => 
  array (
    'effect,' => 1,
  ),
  'effect,' => 
  array (
    '-' => 1,
  ),
  'was!' => 
  array (
    'He' => 1,
  ),
  'leathery' => 
  array (
    'bat-shaped' => 1,
  ),
  'bat-shaped' => 
  array (
    '' => 1,
  ),
  'rasping' => 
  array (
    'for' => 1,
  ),
  'breath.' => 
  array (
    'He' => 1,
    'Ford' => 1,
  ),
  'dusty' => 
  array (
    '' => 2,
    'gloom.' => 1,
    'data' => 1,
  ),
  'parched' => 
  array (
    'mouth' => 1,
  ),
  'moaned.' => 
  array (
    'Arthur' => 1,
  ),
  'brightly:' => 
  array (
    '-' => 1,
  ),
  'Actually' => 
  array (
    'I' => 1,
    'you' => 1,
  ),
  'gaped.' => 
  array (
    'Here' => 1,
    '-' => 1,
    'With' => 1,
  ),
  'approach' => 
  array (
    'that' => 1,
  ),
  'occurred' => 
  array (
    'to' => 3,
  ),
  'eyebrow' => 
  array (
    'that' => 1,
  ),
  'obscured' => 
  array (
    '' => 1,
  ),
  'therefore' => 
  array (
    'no' => 1,
    '' => 2,
    'meaningless.' => 1,
    'I' => 1,
    'clearly' => 1,
  ),
  'good...' => 
  array (
    '-' => 2,
  ),
  'whirred,' => 
  array (
    'in' => 1,
  ),
  'considerable' => 
  array (
    'astonishment.' => 2,
    'surprise.' => 1,
    'excitement.' => 1,
    'stress,' => 1,
  ),
  'astonishment.' => 
  array (
    '-' => 4,
    'These' => 1,
  ),
  'metaphysical' => 
  array (
    'imagery' => 1,
  ),
  'effective.' => 
  array (
    'Ford' => 1,
    'Arthur' => 1,
  ),
  'organizing' => 
  array (
    'his' => 1,
  ),
  'thoughts' => 
  array (
    'around' => 1,
    '' => 1,
    'to' => 1,
    'from' => 1,
  ),
  'concept.' => 
  array (
    'Were' => 1,
  ),
  'Were' => 
  array (
    'they' => 1,
  ),
  'bareface' => 
  array (
    'their' => 1,
  ),
  'this?' => 
  array (
    '-' => 4,
    'asked' => 1,
  ),
  'continue...' => 
  array (
    '-' => 1,
  ),
  'invited' => 
  array (
    'the' => 1,
    'to' => 1,
  ),
  'Oh...' => 
  array (
    'and' => 1,
    'er,' => 2,
  ),
  'er...' => 
  array (
    '' => 1,
    'er...' => 2,
    '-' => 3,
    'The' => 1,
    'I' => 1,
    'Ford' => 1,
    'take' => 1,
    'you' => 1,
  ),
  'too,' => 
  array (
    '' => 1,
    'but' => 2,
    'materializing' => 1,
    'wrapped' => 1,
  ),
  'counterpoint' => 
  array (
    'the...' => 1,
    'the' => 1,
  ),
  'the...' => 
  array (
    'er...' => 1,
    'er..."' => 1,
    '-' => 1,
    'Contemptuous' => 1,
  ),
  'floundered.' => 
  array (
    'Ford' => 1,
  ),
  'rescue,' => 
  array (
    'hazarding' => 1,
  ),
  'hazarding' => 
  array (
    '"counterpoint' => 1,
  ),
  '"counterpoint' => 
  array (
    'the' => 1,
  ),
  'surrealism' => 
  array (
    '' => 1,
    'of' => 1,
  ),
  'underlying' => 
  array (
    'metaphor' => 1,
    'metaphor...' => 1,
  ),
  'metaphor' => 
  array (
    'of' => 1,
  ),
  'er..."' => 
  array (
    'He' => 1,
  ),
  'floundered' => 
  array (
    'too,' => 1,
  ),
  '...humanity' => 
  array (
    'of' => 1,
  ),
  'Vogonity,' => 
  array (
    '-' => 1,
  ),
  'Ah' => 
  array (
    'yes,' => 1,
    'no,' => 2,
  ),
  'Vogonity' => 
  array (
    '(sorry)' => 1,
  ),
  '(sorry)' => 
  array (
    'of' => 1,
  ),
  'compassionate' => 
  array (
    'soul,' => 1,
    '' => 1,
  ),
  'soul,' => 
  array (
    '-' => 1,
  ),
  'stretch' => 
  array (
    'now,' => 1,
    '' => 1,
  ),
  'contrives' => 
  array (
    'through' => 1,
  ),
  'medium' => 
  array (
    'of' => 1,
  ),
  'verse' => 
  array (
    'structure' => 1,
  ),
  'structure' => 
  array (
    'to' => 1,
    'he' => 1,
    'and' => 1,
    '' => 1,
    'of' => 1,
  ),
  'sublimate' => 
  array (
    'this,' => 1,
  ),
  'transcend' => 
  array (
    'that,' => 1,
  ),
  'terms' => 
  array (
    'with' => 2,
    '' => 2,
  ),
  'dichotomies' => 
  array (
    'of' => 1,
  ),
  'other,' => 
  array (
    '' => 1,
    'crossed' => 1,
  ),
  'reaching' => 
  array (
    '' => 1,
    'the' => 1,
  ),
  'triumphant' => 
  array (
    'crescendo...)' => 1,
  ),
  'crescendo...)' => 
  array (
    '-' => 1,
  ),
  'profound' => 
  array (
    '' => 1,
  ),
  'vivid' => 
  array (
    'insight' => 1,
  ),
  'insight' => 
  array (
    'into...' => 1,
  ),
  'into...' => 
  array (
    'into...' => 1,
    'er...' => 1,
  ),
  '(...' => 
  array (
    'which' => 1,
  ),
  'him.)' => 
  array (
    'Ford' => 1,
  ),
  'coup' => 
  array (
    'de' => 1,
  ),
  'de' => 
  array (
    'grace:' => 1,
  ),
  'grace:' => 
  array (
    '-' => 1,
  ),
  'Into' => 
  array (
    'whatever' => 1,
    'the' => 1,
    '' => 1,
  ),
  'about!' => 
  array (
    '-' => 1,
  ),
  'Out' => 
  array (
    '' => 1,
    'of' => 3,
  ),
  'mouth:' => 
  array (
    '-' => 1,
  ),
  'done,' => 
  array (
    'Arthur,' => 1,
    'right,' => 1,
  ),
  'perused' => 
  array (
    'them.' => 1,
  ),
  'embittered' => 
  array (
    'racial' => 1,
  ),
  'touched,' => 
  array (
    'but' => 1,
  ),
  'late.' => 
  array (
    'His' => 1,
    '-' => 1,
    'It' => 1,
  ),
  'quality' => 
  array (
    'of' => 1,
    'to' => 1,
  ),
  'cat' => 
  array (
    'snagging' => 1,
    'litter.' => 1,
  ),
  'snagging' => 
  array (
    'brushed' => 1,
  ),
  'nylon.' => 
  array (
    '-' => 1,
  ),
  'write' => 
  array (
    'poetry' => 1,
    '' => 1,
    'a' => 1,
    'novels!' => 1,
  ),
  'underneath' => 
  array (
    '' => 1,
    'it' => 1,
  ),
  'callous' => 
  array (
    'heartless' => 2,
  ),
  'heartless' => 
  array (
    'exterior' => 2,
  ),
  'exterior' => 
  array (
    'I' => 1,
    'into' => 1,
  ),
  'loved,' => 
  array (
    '-' => 1,
  ),
  'paused.' => 
  array (
    '-' => 4,
    'The' => 1,
  ),
  'right?' => 
  array (
    'Ford' => 1,
    '-' => 1,
    'The' => 1,
  ),
  'laugh.' => 
  array (
    '-' => 2,
    'Ford' => 1,
  ),
  'know...' => 
  array (
    'er...' => 1,
    'no.' => 1,
    'The' => 1,
    '-' => 1,
  ),
  'wrong,' => 
  array (
    '-' => 1,
  ),
  'relief.' => 
  array (
    '' => 1,
  ),
  'Guard!' => 
  array (
    '' => 1,
  ),
  'airlock' => 
  array (
    'and' => 2,
    '-' => 1,
    'with' => 1,
    '' => 1,
    'hatchway' => 1,
  ),
  'out!' => 
  array (
    '-' => 2,
    '' => 1,
  ),
  'yanked' => 
  array (
    'them' => 1,
  ),
  'straps' => 
  array (
    'with' => 1,
  ),
  'blubbery' => 
  array (
    'arms.' => 1,
    '' => 1,
  ),
  'arms.' => 
  array (
    '-' => 1,
  ),
  'Resistance' => 
  array (
    'is' => 5,
    'is...' => 1,
  ),
  'useless!' => 
  array (
    '-' => 4,
  ),
  'learnt' => 
  array (
    'when' => 1,
    'to' => 1,
  ),
  'joined' => 
  array (
    'the' => 1,
  ),
  'Guard' => 
  array (
    'Corps.' => 1,
  ),
  'Corps.' => 
  array (
    'The' => 1,
  ),
  'detached' => 
  array (
    'amusement' => 1,
  ),
  'amusement' => 
  array (
    'and' => 1,
  ),
  'wildly.' => 
  array (
    '-' => 3,
  ),
  'now!' => 
  array (
    '-' => 2,
  ),
  'headache!' => 
  array (
    'I' => 1,
  ),
  'heaven' => 
  array (
    '' => 1,
  ),
  'headache,' => 
  array (
    '' => 1,
  ),
  'cross' => 
  array (
    '' => 4,
    'his' => 1,
  ),
  'enjoy' => 
  array (
    'it!' => 1,
    'this' => 1,
    'it,' => 2,
    'a' => 1,
    'doing' => 1,
  ),
  'it!' => 
  array (
    'The' => 1,
    'Arthur' => 1,
    'They\'ve' => 1,
    'For' => 1,
    '-' => 1,
    'Ford' => 1,
    'That\'s' => 1,
    'Now!' => 1,
  ),
  'firmly' => 
  array (
    '' => 1,
    'under' => 1,
    'inside' => 1,
    'opposed' => 1,
  ),
  'neck,' => 
  array (
    '' => 1,
  ),
  'bowing' => 
  array (
    'deferentially' => 1,
  ),
  'deferentially' => 
  array (
    'towards' => 1,
    'before' => 1,
  ),
  'captain\'s' => 
  array (
    'back,' => 1,
  ),
  'hoiked' => 
  array (
    'them' => 1,
  ),
  'protesting' => 
  array (
    '' => 1,
  ),
  'hummed' => 
  array (
    'quietly' => 1,
    'the' => 1,
  ),
  'mused' => 
  array (
    'to' => 1,
  ),
  'fingering' => 
  array (
    'his' => 1,
  ),
  'notebook' => 
  array (
    '' => 2,
    'aside' => 1,
  ),
  'verses.' => 
  array (
    '-' => 1,
  ),
  'Hmmmm,' => 
  array (
    '-' => 1,
  ),
  'metaphor...' => 
  array (
    '-' => 1,
  ),
  'considered' => 
  array (
    'this' => 2,
    'this.' => 1,
  ),
  'grim' => 
  array (
    'smile.' => 1,
  ),
  'Death\'s' => 
  array (
    'too' => 1,
  ),
  'corridor' => 
  array (
    'echoed' => 1,
    'that' => 1,
    '' => 1,
  ),
  'echoed' => 
  array (
    'to' => 1,
  ),
  'feeble' => 
  array (
    'struggles' => 1,
    'gesture,' => 1,
    '' => 1,
  ),
  'struggles' => 
  array (
    '' => 1,
  ),
  'humanoids' => 
  array (
    'clamped' => 1,
  ),
  'clamped' => 
  array (
    'firmly' => 1,
    'round' => 1,
  ),
  'armpits.' => 
  array (
    '-' => 1,
  ),
  'great,' => 
  array (
    '-' => 1,
  ),
  'spluttered' => 
  array (
    'Arthur,' => 1,
    'and' => 1,
  ),
  'terrific.' => 
  array (
    '' => 1,
  ),
  'brute!' => 
  array (
    'The' => 1,
  ),
  'hopeful.' => 
  array (
    '-' => 1,
  ),
  'guard.' => 
  array (
    '-' => 3,
    '' => 1,
  ),
  'stammered' => 
  array (
    'Ford.' => 1,
    'Arthur.' => 1,
  ),
  'maintain' => 
  array (
    'a' => 1,
  ),
  'positive' => 
  array (
    'mental' => 2,
  ),
  'attitude' => 
  array (
    'if' => 1,
    'and' => 1,
  ),
  'complained' => 
  array (
    'Arthur,' => 1,
    'Zaphod,' => 1,
    'Arthur.' => 1,
  ),
  'demolished' => 
  array (
    '' => 1,
  ),
  'today.' => 
  array (
    '' => 1,
  ),
  'reading,' => 
  array (
    'brush' => 1,
  ),
  'dog...' => 
  array (
    'It\'s' => 1,
  ),
  'smoking' => 
  array (
    'remains' => 1,
  ),
  'remains' => 
  array (
    'of' => 1,
  ),
  'Earth!' => 
  array (
    '-' => 1,
  ),
  'gurgled' => 
  array (
    '' => 1,
  ),
  'tightened' => 
  array (
    'his' => 1,
  ),
  'grip.' => 
  array (
    '-' => 1,
  ),
  'panicking.' => 
  array (
    '-' => 2,
  ),
  'panicking?' => 
  array (
    '-' => 1,
  ),
  'snapped' => 
  array (
    '' => 1,
    'Ford.' => 1,
    'Zaphod,' => 1,
    'the' => 2,
    'off.' => 2,
  ),
  'culture' => 
  array (
    'shock.' => 1,
    'he' => 1,
  ),
  'shock.' => 
  array (
    'You' => 1,
  ),
  'wait' => 
  array (
    'till' => 1,
    'a' => 2,
    '' => 1,
  ),
  'bearings.' => 
  array (
    'Then' => 1,
  ),
  'getting' => 
  array (
    'hysterical.' => 1,
    '' => 3,
    'you' => 3,
    'quite' => 1,
    'needlessly' => 1,
  ),
  'hysterical.' => 
  array (
    'Shut' => 1,
  ),
  'think,' => 
  array (
    'but' => 1,
    '-' => 1,
    'to' => 1,
  ),
  'interrupted' => 
  array (
    'by' => 1,
    'Ford' => 1,
    '' => 1,
    'Deep' => 1,
    'Zaphod.' => 1,
  ),
  'well!' => 
  array (
    '-' => 1,
  ),
  'rest,' => 
  array (
    '-' => 1,
    'after' => 1,
  ),
  'captor\'s' => 
  array (
    'face.' => 1,
  ),
  'Do' => 
  array (
    'you' => 4,
    'we' => 2,
    'not' => 1,
  ),
  'thing?' => 
  array (
    '-' => 1,
    '' => 2,
  ),
  'suddenly.' => 
  array (
    'The' => 1,
  ),
  'stupidity' => 
  array (
    'seeped' => 1,
  ),
  'seeped' => 
  array (
    '' => 1,
  ),
  'Enjoy?' => 
  array (
    '-' => 1,
  ),
  'boomed.' => 
  array (
    '-' => 2,
  ),
  'mean?' => 
  array (
    '-' => 5,
    'Who' => 1,
    'It' => 1,
  ),
  'satisfying' => 
  array (
    'life?' => 1,
  ),
  'life?' => 
  array (
    'Stomping' => 1,
    'What' => 1,
    '' => 1,
  ),
  'Stomping' => 
  array (
    'around,' => 1,
  ),
  'pushing' => 
  array (
    'people' => 1,
  ),
  'spaceships...' => 
  array (
    'The' => 1,
    '-' => 1,
  ),
  'ceiling' => 
  array (
    'and' => 1,
    '-' => 1,
    'as' => 1,
  ),
  'other.' => 
  array (
    'His' => 1,
    'Fook' => 1,
    '-' => 3,
    'Zaphod' => 1,
  ),
  'slacked.' => 
  array (
    'Finally' => 1,
  ),
  'hours' => 
  array (
    'are' => 2,
    'to' => 1,
  ),
  'They\'d' => 
  array (
    'have' => 1,
  ),
  'doing?' => 
  array (
    '-' => 3,
  ),
  'amazed' => 
  array (
    'whisper.' => 1,
  ),
  'whisper.' => 
  array (
    '-' => 1,
  ),
  'OK?' => 
  array (
    '' => 1,
    '-' => 2,
  ),
  'resumed.' => 
  array (
    'The' => 1,
  ),
  'moiled' => 
  array (
    '' => 1,
  ),
  'murky' => 
  array (
    'depths.' => 1,
  ),
  'depths.' => 
  array (
    '-' => 1,
  ),
  'mention' => 
  array (
    '' => 1,
    'it' => 2,
  ),
  'lousy.' => 
  array (
    '' => 1,
  ),
  'Except...' => 
  array (
    '' => 1,
  ),
  'bellowed,' => 
  array (
    '-' => 1,
  ),
  'Sure,' => 
  array (
    'yes,' => 1,
  ),
  'hurriedly,' => 
  array (
    '-' => 1,
  ),
  'tell.' => 
  array (
    'But' => 1,
  ),
  'lousy,' => 
  array (
    '-' => 1,
  ),
  'reach' => 
  array (
    'their' => 1,
    'the' => 2,
    'Damogran' => 1,
    'that.' => 1,
    'of' => 1,
  ),
  'mark,' => 
  array (
    '-' => 1,
  ),
  'girls?' => 
  array (
    'The' => 1,
  ),
  'leather?' => 
  array (
    'The' => 1,
  ),
  'machismo?' => 
  array (
    'Or' => 1,
  ),
  'mindless' => 
  array (
    'tedium' => 1,
    'tedium...' => 1,
    'jerks' => 2,
  ),
  'tedium' => 
  array (
    'of' => 1,
  ),
  'presents' => 
  array (
    'an' => 1,
  ),
  'challenge?' => 
  array (
    '-' => 1,
  ),
  'Er...' => 
  array (
    '-' => 3,
    'what' => 1,
    'we\'ve' => 1,
    'Good' => 1,
  ),
  'guard,' => 
  array (
    '-' => 4,
    'and' => 1,
    'pretending' => 1,
  ),
  'dunno.' => 
  array (
    'I' => 1,
  ),
  'of...' => 
  array (
    'do' => 1,
    'yawning,' => 1,
  ),
  'aunt' => 
  array (
    'said' => 1,
  ),
  'career' => 
  array (
    'for' => 1,
    '' => 1,
  ),
  'uniform,' => 
  array (
    'the' => 1,
  ),
  'lowslung' => 
  array (
    'stun' => 1,
  ),
  'stun' => 
  array (
    'ray' => 1,
  ),
  'ray' => 
  array (
    '' => 1,
  ),
  'holster,' => 
  array (
    'the' => 1,
  ),
  'tedium...' => 
  array (
    '-' => 1,
  ),
  'argument,' => 
  array (
    '-' => 1,
  ),
  'problems.' => 
  array (
    'Arthur' => 1,
    'Chapter' => 1,
    '-' => 1,
  ),
  'had.' => 
  array (
    'Apart' => 1,
  ),
  'Apart' => 
  array (
    'from' => 2,
  ),
  'business' => 
  array (
    'with' => 1,
    '' => 3,
    'is' => 1,
  ),
  'half-throttled' => 
  array (
    '' => 1,
  ),
  'much.' => 
  array (
    '-' => 4,
    'As' => 1,
    '' => 2,
    'You' => 1,
  ),
  'Try' => 
  array (
    'and' => 1,
  ),
  'lad,' => 
  array (
    'his' => 1,
  ),
  'life\'s' => 
  array (
    '' => 1,
  ),
  'stamping' => 
  array (
    '' => 1,
    'a' => 1,
  ),
  'sure,' => 
  array (
    '-' => 4,
  ),
  'patting' => 
  array (
    'the' => 1,
    'his' => 1,
  ),
  'condescension,' => 
  array (
    '-' => 1,
  ),
  '...and' => 
  array (
    'he' => 1,
    'news' => 1,
    'then' => 1,
  ),
  'sad.' => 
  array (
    'He' => 1,
  ),
  'gesture,' => 
  array (
    'because' => 1,
    '' => 1,
  ),
  'asphyxicated' => 
  array (
    'to' => 1,
    '' => 1,
  ),
  'speak.' => 
  array (
    'Deep' => 1,
    'These' => 1,
    '-' => 1,
  ),
  'Deep' => 
  array (
    'rumblings' => 1,
    'in' => 1,
    '' => 4,
    'Thought,' => 9,
    'Thought' => 13,
    'Thought.' => 14,
    'Thought!' => 1,
  ),
  'rumblings' => 
  array (
    'of' => 1,
  ),
  'bemusement' => 
  array (
    'came' => 1,
  ),
  'Well.' => 
  array (
    'Now' => 1,
  ),
  'suppose...' => 
  array (
    '-' => 1,
  ),
  'lad!' => 
  array (
    '-' => 1,
  ),
  'encouraged' => 
  array (
    'Ford.' => 1,
  ),
  'alright,' => 
  array (
    '-' => 3,
    'I\'ve' => 1,
    'I' => 1,
    'alright,' => 1,
  ),
  'rumblings,' => 
  array (
    '-' => 1,
  ),
  'alternative?' => 
  array (
    '-' => 1,
  ),
  'brightly' => 
  array (
    'but' => 1,
    'polished' => 1,
    'and' => 1,
    'coloured' => 1,
    'dressed' => 1,
  ),
  'slowly,' => 
  array (
    '-' => 1,
    'less' => 1,
  ),
  'course!' => 
  array (
    'Tell' => 1,
  ),
  'Tell' => 
  array (
    'them,' => 1,
    'me,' => 1,
    'us!' => 2,
  ),
  'anymore.' => 
  array (
    '-' => 1,
  ),
  'add' => 
  array (
    'something' => 1,
    'up' => 1,
  ),
  'occupied' => 
  array (
    'pondering' => 1,
    'her' => 1,
    'coffin,' => 1,
  ),
  'pondering' => 
  array (
    'that' => 1,
  ),
  'Eerrrrrrmmmmmmmmmmmmmmmmmmmmm...' => 
  array (
    '-' => 1,
  ),
  'erm,' => 
  array (
    'well' => 1,
  ),
  'slipping' => 
  array (
    'away.' => 1,
    'away' => 1,
  ),
  'minute,' => 
  array (
    '-' => 1,
    'this' => 1,
  ),
  'there\'s' => 
  array (
    'more' => 1,
    'music' => 1,
    'a' => 3,
    'something' => 1,
    'an' => 1,
    'anything' => 1,
    'something.' => 1,
    'this' => 1,
    'no' => 1,
    '' => 1,
    'any' => 1,
  ),
  'see...' => 
  array (
    'But' => 1,
    'there!' => 1,
    'He' => 1,
  ),
  'renewed' => 
  array (
    '' => 1,
  ),
  'grip' => 
  array (
    '' => 1,
    'now...' => 1,
    'of' => 1,
  ),
  'purpose' => 
  array (
    'of' => 1,
    'in' => 2,
    'for' => 1,
  ),
  'lugging' => 
  array (
    'his' => 1,
  ),
  'airlock.' => 
  array (
    'He' => 1,
  ),
  'touched.' => 
  array (
    '-' => 1,
  ),
  'you,' => 
  array (
    '-' => 10,
    '' => 3,
    'you\'re' => 1,
    'sure,' => 1,
    'is' => 1,
    'Beeblebrox!' => 1,
    'metalman?' => 1,
  ),
  'shoved' => 
  array (
    'into' => 1,
  ),
  'now...' => 
  array (
    'but' => 1,
    'oh!' => 1,
  ),
  'look!' => 
  array (
    '-' => 1,
  ),
  'brightly.' => 
  array (
    '-' => 1,
  ),
  'Huhhhhgggggggnnnnnnn...' => 
  array (
    '-' => 1,
  ),
  'inflection.' => 
  array (
    '-' => 1,
  ),
  'pursued' => 
  array (
    'Ford,' => 1,
    'Arthur.' => 1,
    'a' => 1,
  ),
  'music' => 
  array (
    'and' => 1,
    'flooded' => 1,
    '' => 1,
    'floated' => 1,
  ),
  'art' => 
  array (
    'and' => 1,
    '' => 1,
  ),
  'yet!' => 
  array (
    'Arrrggghhh!' => 1,
  ),
  'Arrrggghhh!' => 
  array (
    '-' => 1,
  ),
  'useless,' => 
  array (
    '-' => 1,
  ),
  'promoted' => 
  array (
    '' => 1,
  ),
  'Senior' => 
  array (
    '' => 1,
  ),
  'Shouting' => 
  array (
    'Officer,' => 1,
  ),
  'Officer,' => 
  array (
    'and' => 1,
  ),
  'aren\'t' => 
  array (
    'usually' => 1,
    'we?' => 5,
    'they...' => 1,
  ),
  'vacancies' => 
  array (
    '' => 1,
  ),
  'non-shouting' => 
  array (
    '' => 1,
  ),
  'non-pushing-people-about' => 
  array (
    'officers,' => 1,
  ),
  'officers,' => 
  array (
    'so' => 1,
  ),
  'circular' => 
  array (
    'steel' => 1,
    '-' => 1,
    'wall' => 1,
  ),
  'massive' => 
  array (
    'strength' => 1,
    'trouble' => 1,
    'computer' => 1,
    'Pan' => 1,
  ),
  'strength' => 
  array (
    'and' => 1,
  ),
  'craft.' => 
  array (
    '' => 1,
  ),
  'operated' => 
  array (
    'a' => 1,
    'by' => 1,
  ),
  'swung' => 
  array (
    'smoothly' => 1,
    'up' => 1,
    'round' => 1,
    'through' => 1,
  ),
  'smoothly' => 
  array (
    'open.' => 1,
    '' => 1,
  ),
  'open.' => 
  array (
    '-' => 3,
    'On' => 1,
    'Still' => 1,
  ),
  'thanks' => 
  array (
    'for' => 2,
    'you' => 1,
  ),
  'interest,' => 
  array (
    '-' => 2,
  ),
  'Bye' => 
  array (
    'now.' => 1,
  ),
  'flung' => 
  array (
    'Ford' => 1,
    '' => 2,
    'itself' => 1,
  ),
  'chamber' => 
  array (
    'within.' => 1,
    'about' => 1,
    'at' => 1,
    'of' => 1,
    'Arthur' => 1,
    'we' => 1,
    '' => 1,
    'several' => 1,
  ),
  'within.' => 
  array (
    'Arthur' => 1,
    'Patterns' => 1,
  ),
  'scrambled' => 
  array (
    'round' => 1,
    'mess' => 1,
    'up' => 1,
    'down' => 1,
  ),
  'shoulder' => 
  array (
    'uselessly' => 1,
    'and' => 1,
  ),
  'uselessly' => 
  array (
    'against' => 1,
  ),
  'reclosing' => 
  array (
    'hatchway.' => 1,
  ),
  'hatchway.' => 
  array (
    '-' => 2,
  ),
  'listen,' => 
  array (
    '-' => 1,
  ),
  'about...' => 
  array (
    'here' => 1,
  ),
  'Desperately' => 
  array (
    'he' => 1,
  ),
  'offhand' => 
  array (
    '-' => 1,
  ),
  'Beethoven\'s' => 
  array (
    'Fifth.' => 1,
  ),
  'Fifth.' => 
  array (
    '-' => 1,
  ),
  'Da' => 
  array (
    'da' => 1,
  ),
  'da' => 
  array (
    'da' => 1,
    'dum!' => 1,
  ),
  'dum!' => 
  array (
    'Doesn\'t' => 1,
  ),
  'Doesn\'t' => 
  array (
    'that' => 1,
    '' => 1,
    'matter!' => 1,
    'fit' => 1,
  ),
  'stir' => 
  array (
    'anything' => 1,
  ),
  'aunt.' => 
  array (
    'If' => 1,
  ),
  'sealed' => 
  array (
    'itself' => 1,
  ),
  'tight,' => 
  array (
    'and' => 1,
    '-' => 1,
  ),
  'faint' => 
  array (
    'distant' => 1,
  ),
  'distant' => 
  array (
    '' => 2,
    'horizon' => 1,
    'fanfare;' => 1,
    'sadness' => 1,
  ),
  'ship\'s' => 
  array (
    'engines.' => 1,
    'brand' => 1,
    'drive' => 1,
    'cybernetics.' => 1,
    'controls' => 1,
    'artificial' => 1,
    'progress' => 1,
    'about' => 1,
    '' => 1,
    'intercom' => 1,
  ),
  'engines.' => 
  array (
    'They' => 1,
  ),
  'polished' => 
  array (
    'cylindrical' => 1,
    'it' => 1,
    'surface' => 1,
  ),
  'cylindrical' => 
  array (
    'chamber' => 1,
  ),
  'diameter' => 
  array (
    'and' => 1,
  ),
  'long.' => 
  array (
    '-' => 1,
  ),
  'Potentially' => 
  array (
    'bright' => 1,
  ),
  'lad' => 
  array (
    'I' => 1,
  ),
  'slumped' => 
  array (
    'against' => 3,
    'into' => 1,
  ),
  'curved' => 
  array (
    'wall.' => 1,
    'corridor' => 1,
    'steel.' => 1,
  ),
  'wall.' => 
  array (
    'Arthur' => 1,
    'In' => 1,
    'The' => 1,
    'Chapter' => 1,
    'As' => 1,
    'A' => 1,
    'They' => 1,
  ),
  'fallen.' => 
  array (
    'He' => 1,
  ),
  'panting.' => 
  array (
    '-' => 1,
  ),
  'trapped' => 
  array (
    'now' => 1,
    'in' => 1,
  ),
  'we?' => 
  array (
    '-' => 6,
    'Hey...' => 1,
    '' => 2,
  ),
  'trapped.' => 
  array (
    '-' => 1,
  ),
  'anything?' => 
  array (
    'I' => 1,
  ),
  'something,' => 
  array (
    '-' => 4,
    '' => 1,
    'and,' => 1,
  ),
  'panted' => 
  array (
    '' => 1,
  ),
  'unfortunately,' => 
  array (
    '-' => 1,
  ),
  'involved' => 
  array (
    'being' => 1,
    '' => 1,
    'suddenly' => 1,
  ),
  'airtight' => 
  array (
    'hatchway.' => 1,
  ),
  'kicked' => 
  array (
    '' => 1,
  ),
  'hatch' => 
  array (
    '' => 1,
    'please,' => 1,
    'this' => 1,
  ),
  'neat.' => 
  array (
    '-' => 1,
  ),
  'details' => 
  array (
    'yet.' => 1,
  ),
  'So...' => 
  array (
    'er,' => 1,
  ),
  'er,' => 
  array (
    'what' => 1,
    'well' => 1,
    'have' => 1,
    'really?' => 1,
    'that' => 1,
    'very' => 1,
  ),
  'happens' => 
  array (
    'next?' => 1,
  ),
  'next?' => 
  array (
    '-' => 1,
  ),
  'shoot' => 
  array (
    '' => 1,
    'you,' => 1,
    'us!' => 1,
    'them' => 1,
  ),
  'asphyxicate.' => 
  array (
    'If' => 1,
  ),
  'lungful' => 
  array (
    'of' => 2,
  ),
  'course...' => 
  array (
    '-' => 1,
  ),
  'battle' => 
  array (
    'hymn.' => 1,
    '' => 1,
    'fleets' => 1,
    'fleet' => 1,
  ),
  'hymn.' => 
  array (
    'To' => 1,
  ),
  'alien.' => 
  array (
    '-' => 1,
  ),
  'die.' => 
  array (
    '-' => 2,
  ),
  'except...' => 
  array (
    'no!' => 1,
  ),
  'no!' => 
  array (
    'Wait' => 1,
  ),
  'Wait' => 
  array (
    '' => 1,
  ),
  'minute!' => 
  array (
    '' => 1,
  ),
  'lunged' => 
  array (
    'across' => 1,
  ),
  'vision.' => 
  array (
    '' => 1,
  ),
  'switch?' => 
  array (
    '-' => 1,
  ),
  'cried.' => 
  array (
    '-' => 2,
  ),
  'Where?' => 
  array (
    '-' => 1,
  ),
  'twisting' => 
  array (
    'round.' => 1,
  ),
  'round.' => 
  array (
    '-' => 3,
  ),
  'fooling,' => 
  array (
    '-' => 1,
  ),
  'tune' => 
  array (
    'from' => 1,
  ),
  'asphyxication' => 
  array (
    'in' => 1,
  ),
  'listened' => 
  array (
    '' => 1,
    'for' => 1,
  ),
  'young.' => 
  array (
    '-' => 1,
  ),
  'Why,' => 
  array (
    'what' => 1,
    '-' => 1,
  ),
  'listen.' => 
  array (
    '-' => 1,
  ),
  'Oh.' => 
  array (
    '-' => 1,
  ),
  'humming.' => 
  array (
    '-' => 1,
  ),
  'terrific,' => 
  array (
    '-' => 2,
    'this' => 1,
  ),
  'Harmless.' => 
  array (
    'Any' => 1,
    '' => 1,
  ),
  'Any' => 
  array (
    'second' => 1,
    'one.' => 1,
    'bloody' => 1,
  ),
  'well.' => 
  array (
    'A' => 1,
    'However,' => 1,
  ),
  'motor' => 
  array (
    'whirred.' => 1,
  ),
  'whirred.' => 
  array (
    'A' => 1,
  ),
  'hiss' => 
  array (
    'built' => 1,
  ),
  'deafening' => 
  array (
    'roar' => 1,
  ),
  'roar' => 
  array (
    'of' => 1,
    '' => 1,
  ),
  'rushing' => 
  array (
    'air' => 1,
  ),
  'outer' => 
  array (
    'hatchway' => 1,
    'space' => 1,
  ),
  'blackness' => 
  array (
    '' => 1,
    'stabbed' => 1,
    'behind' => 1,
    'outside' => 1,
  ),
  'studded' => 
  array (
    '' => 1,
  ),
  'impossibly' => 
  array (
    'bright' => 1,
  ),
  'popped' => 
  array (
    'into' => 1,
    'out' => 1,
    'halfway' => 1,
  ),
  'corks' => 
  array (
    'from' => 1,
  ),
  'toy' => 
  array (
    'gun.' => 1,
    'pistols' => 1,
  ),
  'gun.' => 
  array (
    'Chapter' => 1,
    '-' => 1,
  ),
  8 => 
  array (
    'The' => 1,
  ),
  'compiled' => 
  array (
    'and' => 1,
  ),
  'recompiled' => 
  array (
    'many' => 1,
  ),
  'editorships.' => 
  array (
    'It' => 1,
  ),
  'contributions' => 
  array (
    'from' => 1,
  ),
  'countless' => 
  array (
    'numbers' => 1,
  ),
  'numbers' => 
  array (
    'of' => 1,
  ),
  'travellers' => 
  array (
    'and' => 1,
  ),
  'researchers.' => 
  array (
    'The' => 1,
  ),
  'introduction' => 
  array (
    'begins' => 1,
    'have' => 1,
  ),
  'Space,' => 
  array (
    '-' => 1,
  ),
  'Really' => 
  array (
    'big.' => 1,
  ),
  'vastly' => 
  array (
    'hugely' => 1,
  ),
  'hugely' => 
  array (
    'mindboggingly' => 1,
  ),
  'chemist,' => 
  array (
    '' => 1,
  ),
  'Listen...' => 
  array (
    '-' => 1,
  ),
  '(After' => 
  array (
    'a' => 1,
  ),
  'settles' => 
  array (
    'down' => 1,
  ),
  'fabulously' => 
  array (
    'beautiful' => 1,
  ),
  'Bethselamin' => 
  array (
    '' => 1,
  ),
  'cumulative' => 
  array (
    'erosion' => 1,
    'effect' => 1,
  ),
  'erosion' => 
  array (
    'by' => 1,
  ),
  'tourists' => 
  array (
    'a' => 1,
  ),
  'net' => 
  array (
    '' => 1,
  ),
  'imbalance' => 
  array (
    'between' => 1,
  ),
  'eat' => 
  array (
    'and' => 1,
  ),
  'excrete' => 
  array (
    'whilst' => 1,
  ),
  'surgically' => 
  array (
    'removed' => 1,
  ),
  'removed' => 
  array (
    'from' => 1,
  ),
  'bodyweight' => 
  array (
    'when' => 1,
  ),
  'leave:' => 
  array (
    'so' => 1,
  ),
  'receipt.)' => 
  array (
    'To' => 1,
  ),
  'confronted' => 
  array (
    'by' => 1,
  ),
  'enormity' => 
  array (
    'of' => 1,
  ),
  'distances' => 
  array (
    'between' => 2,
    'will' => 1,
    'in' => 1,
    'he' => 1,
  ),
  'stars,' => 
  array (
    'better' => 1,
    'and' => 2,
  ),
  'responsible' => 
  array (
    'for' => 1,
  ),
  'Guide\'s' => 
  array (
    'introduction' => 1,
  ),
  'faltered.' => 
  array (
    'Some' => 1,
  ),
  'invite' => 
  array (
    'you' => 2,
  ),
  'consider' => 
  array (
    '' => 1,
  ),
  'peanut' => 
  array (
    'in' => 1,
  ),
  'walnut' => 
  array (
    '' => 1,
  ),
  'Johannesburg,' => 
  array (
    '' => 1,
  ),
  'dizzying' => 
  array (
    'concepts.' => 1,
  ),
  'concepts.' => 
  array (
    'The' => 1,
  ),
  'truth' => 
  array (
    'is' => 1,
    '' => 1,
    'in' => 1,
  ),
  'fit' => 
  array (
    'into' => 1,
    'properly.' => 1,
    'the' => 3,
  ),
  'imagination.' => 
  array (
    'Even' => 1,
  ),
  'travels' => 
  array (
    'so' => 1,
    'at' => 1,
  ),
  'takes' => 
  array (
    'most' => 1,
    'time' => 1,
    'eight' => 1,
    'rather' => 1,
  ),
  'thousands' => 
  array (
    'of' => 1,
    '' => 1,
    'more' => 1,
  ),
  'stars.' => 
  array (
    'It' => 1,
  ),
  'Sol' => 
  array (
    'to' => 1,
  ),
  'Sol\'s' => 
  array (
    '' => 1,
  ),
  'stellar' => 
  array (
    'neighbour,' => 1,
  ),
  'neighbour,' => 
  array (
    'Alpha' => 1,
  ),
  'Proxima.' => 
  array (
    'For' => 1,
  ),
  'instance,' => 
  array (
    'takes' => 1,
    'on' => 1,
    'at' => 1,
    'the' => 1,
  ),
  'longer:' => 
  array (
    'five' => 1,
  ),
  'record' => 
  array (
    'for' => 1,
    'of' => 1,
  ),
  'total' => 
  array (
    '' => 4,
    'active' => 1,
  ),
  'seconds.' => 
  array (
    'However' => 1,
    'Please' => 1,
    '-' => 2,
  ),
  'However' => 
  array (
    'it' => 1,
  ),
  'boggling' => 
  array (
    'size' => 1,
  ),
  'chances' => 
  array (
    'of' => 2,
    '' => 1,
  ),
  'sixty-seven' => 
  array (
    'thousand' => 2,
  ),
  'against.' => 
  array (
    'By' => 1,
    'It' => 1,
    'That\'s' => 1,
    '-' => 1,
    'Zaphod' => 1,
  ),
  'telephone' => 
  array (
    'number' => 1,
    '' => 1,
    'numbers?' => 1,
    'number?' => 1,
  ),
  'Islington' => 
  array (
    'flat' => 2,
  ),
  'met' => 
  array (
    'a' => 1,
    'the' => 1,
    'Zaphod.' => 1,
    'itself' => 1,
    'when' => 1,
    '' => 1,
  ),
  'gatecrasher.' => 
  array (
    'Though' => 1,
  ),
  'Though' => 
  array (
    'the' => 1,
    'your' => 1,
    'we' => 1,
    'I' => 1,
    '' => 1,
  ),
  'demolished,' => 
  array (
    'it' => 1,
  ),
  'comforting' => 
  array (
    'to' => 1,
  ),
  'reflect' => 
  array (
    'that' => 1,
    'all' => 1,
    'on' => 1,
  ),
  'commemorated' => 
  array (
    'by' => 1,
  ),
  'twenty-nine' => 
  array (
    '' => 1,
  ),
  'rescued.' => 
  array (
    'Chapter' => 1,
  ),
  9 => 
  array (
    'A' => 1,
    'Plural' => 3,
  ),
  'computer' => 
  array (
    'chatted' => 1,
    '' => 13,
    'for' => 2,
    'continued,' => 1,
    'in' => 4,
    'had' => 1,
    'screen' => 1,
    'and' => 4,
    'brightly,' => 1,
    'started' => 1,
    'equipment.' => 1,
    'which' => 1,
    'programmers' => 1,
    'was' => 1,
    'to' => 2,
    'than' => 1,
    'is' => 1,
    'speak.' => 1,
    'that' => 1,
    'whose' => 1,
    'of' => 1,
    'matrix,' => 1,
    'programme,' => 1,
    'bank' => 3,
    'banks.' => 1,
    'data' => 1,
    'feed.' => 1,
    'at' => 1,
  ),
  'chatted' => 
  array (
    'to' => 1,
  ),
  'alarm' => 
  array (
    'as' => 2,
    'on' => 1,
  ),
  'apparent' => 
  array (
    'reason.' => 1,
    'that' => 1,
    'signal' => 1,
    'reason' => 1,
  ),
  'reason.' => 
  array (
    'This' => 1,
  ),
  'Reason' => 
  array (
    'was' => 1,
  ),
  'hole' => 
  array (
    'had' => 1,
    '' => 1,
    'if' => 1,
    'in' => 1,
  ),
  'appeared' => 
  array (
    'in' => 4,
    'to' => 4,
    'bleak' => 1,
    'perfectly' => 1,
    'by' => 1,
    '' => 1,
    'a' => 1,
    'unexpectedly' => 1,
  ),
  'nothingth' => 
  array (
    'of' => 3,
    '' => 1,
  ),
  'inch' => 
  array (
    'wide,' => 1,
    '' => 1,
  ),
  'wide,' => 
  array (
    'and' => 1,
  ),
  'hats' => 
  array (
    'and' => 1,
  ),
  'balloons' => 
  array (
    'fell' => 1,
  ),
  'universe.' => 
  array (
    '' => 1,
  ),
  'team' => 
  array (
    '' => 1,
    'on' => 1,
  ),
  'threefoot-high' => 
  array (
    'market' => 1,
  ),
  'market' => 
  array (
    'analysts' => 1,
    'prices' => 1,
    '' => 1,
  ),
  'analysts' => 
  array (
    'fell' => 1,
  ),
  'died,' => 
  array (
    'partly' => 1,
  ),
  'asphyxication,' => 
  array (
    '' => 1,
  ),
  'surprise.' => 
  array (
    'Two' => 1,
    '-' => 3,
    'Chapter' => 1,
    'Eventually' => 1,
  ),
  'thirty-nine' => 
  array (
    'thousand' => 1,
  ),
  'fried' => 
  array (
    'eggs' => 1,
    '' => 1,
  ),
  'eggs' => 
  array (
    'fell' => 1,
  ),
  'materializing' => 
  array (
    'in' => 1,
  ),
  'woobly' => 
  array (
    'heap' => 1,
  ),
  'heap' => 
  array (
    'on' => 2,
  ),
  'faminestruck' => 
  array (
    '' => 1,
  ),
  'Poghril' => 
  array (
    'in' => 1,
    'tribe' => 1,
  ),
  'Pansel' => 
  array (
    'system.' => 1,
  ),
  'system.' => 
  array (
    'The' => 2,
    'Then' => 1,
    'Arthur' => 1,
  ),
  'famine' => 
  array (
    'except' => 1,
  ),
  'cholesterol' => 
  array (
    'poisoning' => 1,
  ),
  'poisoning' => 
  array (
    'some' => 1,
  ),
  'weeks' => 
  array (
    'later.' => 1,
  ),
  'later.' => 
  array (
    'The' => 1,
    '-' => 1,
    'Arthur' => 1,
  ),
  'reverberated' => 
  array (
    'backwards' => 1,
  ),
  'forwards' => 
  array (
    '' => 1,
    'between' => 1,
  ),
  'fashion.' => 
  array (
    'Somewhere' => 1,
  ),
  'deeply' => 
  array (
    'remote' => 1,
    'shocked' => 1,
  ),
  'past' => 
  array (
    '' => 1,
    'a' => 1,
    'what' => 1,
    'few' => 1,
  ),
  'traumatized' => 
  array (
    '' => 1,
  ),
  'group' => 
  array (
    'of' => 1,
  ),
  'drifting' => 
  array (
    'through' => 1,
    '' => 1,
  ),
  'sterility' => 
  array (
    '' => 1,
  ),
  'cling' => 
  array (
    'together' => 1,
  ),
  'extraordinarily' => 
  array (
    '' => 2,
    'lonely' => 1,
  ),
  'unlikely' => 
  array (
    '' => 1,
    'things,' => 1,
  ),
  'patterns.' => 
  array (
    'These' => 1,
  ),
  '(this' => 
  array (
    'was' => 1,
  ),
  'patterns)' => 
  array (
    'and' => 1,
  ),
  'cause' => 
  array (
    'massive' => 1,
    '' => 1,
  ),
  'trouble' => 
  array (
    'on' => 1,
    'to' => 1,
    'with' => 1,
  ),
  'Event' => 
  array (
    'Maelstroms' => 1,
  ),
  'Maelstroms' => 
  array (
    'swirled' => 1,
  ),
  'vicious' => 
  array (
    'storms' => 1,
    'Kill-O-Zap' => 1,
  ),
  'storms' => 
  array (
    'of' => 1,
  ),
  'unreason' => 
  array (
    '' => 1,
  ),
  'spewed' => 
  array (
    'up' => 1,
    'out' => 1,
  ),
  'pavement.' => 
  array (
    'On' => 1,
  ),
  'pavement' => 
  array (
    '' => 1,
    'as' => 1,
    'and' => 1,
  ),
  'gulping' => 
  array (
    '' => 1,
  ),
  'half-spent' => 
  array (
    'fish.' => 1,
  ),
  'are,' => 
  array (
    '-' => 2,
  ),
  'scrabbling' => 
  array (
    'for' => 1,
  ),
  'fingerhold' => 
  array (
    '' => 1,
  ),
  'Third' => 
  array (
    'Reach' => 1,
  ),
  'Reach' => 
  array (
    'of' => 1,
  ),
  'Unknown,' => 
  array (
    '-' => 1,
  ),
  'sure.' => 
  array (
    '-' => 2,
  ),
  'Bright' => 
  array (
    'idea' => 1,
  ),
  'mine,' => 
  array (
    '-' => 1,
    'Arthur' => 1,
  ),
  'universe' => 
  array (
    '' => 1,
    'than' => 1,
    'is' => 1,
  ),
  'arched' => 
  array (
    '' => 1,
  ),
  'Various' => 
  array (
    'pretend' => 1,
  ),
  'pretend' => 
  array (
    'ones' => 1,
    'you' => 1,
  ),
  'flitted' => 
  array (
    '' => 1,
  ),
  'silently' => 
  array (
    '' => 1,
    'up' => 1,
    'through' => 1,
    'next' => 1,
  ),
  'by,' => 
  array (
    '' => 1,
  ),
  'mountain' => 
  array (
    '' => 1,
  ),
  'goats.' => 
  array (
    '' => 1,
  ),
  'Primal' => 
  array (
    '' => 1,
  ),
  'exploded,' => 
  array (
    '' => 1,
  ),
  'splattering' => 
  array (
    '' => 1,
  ),
  'space-time' => 
  array (
    '' => 1,
    'continuum' => 1,
  ),
  'gobbets' => 
  array (
    '' => 1,
  ),
  'junket.' => 
  array (
    '' => 1,
  ),
  'blossomed,' => 
  array (
    'matter' => 1,
  ),
  'shrank' => 
  array (
    'away.' => 1,
  ),
  'highest' => 
  array (
    'prime' => 1,
    'demand' => 1,
  ),
  'prime' => 
  array (
    'number' => 1,
  ),
  'coalesced' => 
  array (
    '' => 1,
  ),
  'hid' => 
  array (
    'itself' => 1,
  ),
  'astronomical.' => 
  array (
    '-' => 1,
  ),
  'worked,' => 
  array (
    '-' => 1,
  ),
  'in?' => 
  array (
    '-' => 1,
    'He' => 1,
  ),
  'pit' => 
  array (
    'of' => 1,
  ),
  'eternity' => 
  array (
    'yawned' => 1,
  ),
  'yawned' => 
  array (
    'beneath' => 1,
  ),
  'I,' => 
  array (
    '-' => 1,
    '' => 1,
  ),
  'jumped,' => 
  array (
    'froze,' => 1,
  ),
  'froze,' => 
  array (
    '' => 1,
  ),
  'quivered' => 
  array (
    '' => 1,
  ),
  'splayed' => 
  array (
    '' => 1,
  ),
  'unexpected' => 
  array (
    'directions.' => 1,
    'movement' => 1,
    'at' => 1,
  ),
  'directions.' => 
  array (
    'Arthur' => 1,
    '-' => 1,
  ),
  'god,' => 
  array (
    '-' => 1,
  ),
  'Southend.' => 
  array (
    '-' => 2,
  ),
  'Hell,' => 
  array (
    'I\'m' => 1,
    '-' => 1,
    'she' => 1,
  ),
  'relieved' => 
  array (
    'to' => 1,
    'when' => 1,
  ),
  'mad.' => 
  array (
    '-' => 3,
  ),
  'we\'d' => 
  array (
    'be' => 1,
    '' => 1,
    'all' => 2,
    'have' => 2,
  ),
  'mad,' => 
  array (
    'all' => 1,
  ),
  'considered,' => 
  array (
    'to' => 1,
  ),
  'Southend?' => 
  array (
    '-' => 1,
  ),
  'I.' => 
  array (
    '-' => 1,
  ),
  'Therefore' => 
  array (
    'we' => 1,
  ),
  'elderberry' => 
  array (
    'bush' => 1,
  ),
  'bush' => 
  array (
    '' => 1,
  ),
  'kippers?' => 
  array (
    '-' => 1,
  ),
  'someone.' => 
  array (
    '-' => 1,
  ),
  'unease' => 
  array (
    '' => 1,
  ),
  'children' => 
  array (
    'bounced' => 1,
  ),
  'bounced' => 
  array (
    'heavily' => 1,
  ),
  'sand' => 
  array (
    '' => 1,
    'Eddie.' => 1,
    'blizzard?' => 2,
  ),
  'horses' => 
  array (
    '' => 1,
  ),
  'thundered' => 
  array (
    'through' => 1,
    'towards' => 1,
  ),
  'fresh' => 
  array (
    '' => 2,
    'whalemeat.' => 1,
    'breeze' => 1,
  ),
  'supplies' => 
  array (
    '' => 1,
  ),
  'reinforced' => 
  array (
    '' => 1,
  ),
  'railings' => 
  array (
    '' => 1,
  ),
  'Uncertain' => 
  array (
    'Areas.' => 1,
  ),
  'Areas.' => 
  array (
    '-' => 1,
  ),
  'cough,' => 
  array (
    '-' => 1,
  ),
  'Southend,' => 
  array (
    'there\'s' => 1,
  ),
  'it...' => 
  array (
    '-' => 1,
  ),
  'stays' => 
  array (
    '' => 1,
  ),
  'washing' => 
  array (
    'up' => 1,
  ),
  'too.' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'Southend' => 
  array (
    'split' => 1,
    'seems' => 1,
  ),
  'split' => 
  array (
    '' => 1,
    'infinitives' => 1,
    'before' => 1,
  ),
  'equal' => 
  array (
    'segments' => 1,
  ),
  'segments' => 
  array (
    'which' => 1,
  ),
  'danced' => 
  array (
    'and' => 1,
    '' => 1,
  ),
  'span' => 
  array (
    'giddily' => 1,
    'round' => 3,
    'her' => 1,
    'around' => 1,
  ),
  'giddily' => 
  array (
    'round' => 1,
  ),
  'lewd' => 
  array (
    '' => 1,
  ),
  'licentious' => 
  array (
    'formation,' => 1,
  ),
  'formation,' => 
  array (
    '-' => 1,
  ),
  'altogether' => 
  array (
    'very' => 1,
  ),
  'Wild' => 
  array (
    'yowling' => 1,
    'cheers' => 1,
  ),
  'yowling' => 
  array (
    'noises' => 1,
  ),
  'noises' => 
  array (
    'of' => 1,
    'were' => 1,
  ),
  'pipes' => 
  array (
    'and' => 1,
  ),
  'strings' => 
  array (
    'seared' => 1,
  ),
  'seared' => 
  array (
    'through' => 1,
  ),
  'hot' => 
  array (
    'doughnuts' => 1,
    'cup' => 1,
    'tea...' => 1,
    'dog' => 1,
  ),
  'doughnuts' => 
  array (
    'popped' => 1,
  ),
  'each,' => 
  array (
    'horrid' => 1,
  ),
  'horrid' => 
  array (
    '' => 1,
  ),
  'plunged' => 
  array (
    'through' => 1,
    '' => 1,
    'into' => 2,
  ),
  'walls' => 
  array (
    '' => 2,
    'were' => 2,
    'in' => 1,
    'the' => 1,
  ),
  'sound,' => 
  array (
    '' => 2,
  ),
  'mountains' => 
  array (
    '' => 1,
    'of' => 1,
    'in' => 1,
  ),
  'archaic' => 
  array (
    'thought,' => 1,
  ),
  'valleys' => 
  array (
    'of' => 1,
    'over' => 1,
  ),
  'sessions' => 
  array (
    'and' => 1,
  ),
  'footling' => 
  array (
    '' => 1,
  ),
  'bats' => 
  array (
    '' => 1,
  ),
  'girl\'s' => 
  array (
    'voice.' => 1,
  ),
  'sensible' => 
  array (
    'voice,' => 1,
  ),
  'falling,' => 
  array (
    '-' => 2,
    '' => 1,
    'and' => 1,
  ),
  'skidded' => 
  array (
    'down' => 1,
  ),
  'voice?' => 
  array (
    '-' => 1,
  ),
  'measurement' => 
  array (
    'of' => 2,
  ),
  'probability.' => 
  array (
    '-' => 1,
  ),
  'Probability?' => 
  array (
    'What' => 1,
  ),
  'Probability.' => 
  array (
    'You' => 1,
  ),
  'one,' => 
  array (
    'three' => 1,
    'five' => 1,
    '-' => 4,
    'though' => 1,
    'and' => 1,
  ),
  'million-gallon' => 
  array (
    'vat' => 1,
  ),
  'vat' => 
  array (
    'of' => 1,
  ),
  'custard' => 
  array (
    '' => 1,
  ),
  'upended' => 
  array (
    '' => 1,
  ),
  'warning.' => 
  array (
    '-' => 1,
  ),
  'custard?' => 
  array (
    '-' => 1,
  ),
  'probability!' => 
  array (
    '-' => 1,
  ),
  'first-class' => 
  array (
    'compartment.' => 1,
  ),
  'compartment.' => 
  array (
    'Bulges' => 1,
  ),
  'Bulges' => 
  array (
    'appeared' => 1,
  ),
  'space-time.' => 
  array (
    'Great' => 1,
  ),
  'bulges.' => 
  array (
    '-' => 1,
  ),
  'Haaaauuurrgghhh...' => 
  array (
    '-' => 1,
  ),
  'softening' => 
  array (
    '' => 1,
  ),
  'bending' => 
  array (
    'in' => 1,
  ),
  'unusual' => 
  array (
    'directions.' => 1,
  ),
  'melting' => 
  array (
    'away...' => 1,
  ),
  'away...' => 
  array (
    '' => 1,
  ),
  'swirling...' => 
  array (
    'a' => 1,
  ),
  'dustbowl...' => 
  array (
    'my' => 1,
  ),
  'sunset...' => 
  array (
    'my' => 1,
  ),
  'arm\'s' => 
  array (
    'come' => 1,
  ),
  'frightening' => 
  array (
    'thought' => 1,
  ),
  'him:' => 
  array (
    '-' => 1,
  ),
  'operate' => 
  array (
    'my' => 1,
  ),
  'wound' => 
  array (
    'his' => 1,
  ),
  'direction.' => 
  array (
    '-' => 2,
    'The' => 1,
  ),
  'turning' => 
  array (
    'into' => 1,
    'back' => 1,
    '' => 1,
    'round' => 1,
  ),
  'penguin.' => 
  array (
    'Stop' => 1,
  ),
  'Stop' => 
  array (
    'it.' => 1,
    '' => 1,
  ),
  'Again' => 
  array (
    'came' => 1,
    'a' => 1,
    'they' => 1,
  ),
  'seventy-five' => 
  array (
    '' => 1,
  ),
  'falling.' => 
  array (
    'Ford' => 1,
    'The' => 1,
  ),
  'waddled' => 
  array (
    'around' => 1,
  ),
  'pond' => 
  array (
    'in' => 1,
  ),
  'furious' => 
  array (
    'circle.' => 1,
  ),
  'circle.' => 
  array (
    '-' => 1,
  ),
  'quacked.' => 
  array (
    '-' => 1,
  ),
  'stopping' => 
  array (
    'it?' => 1,
  ),
  'Please' => 
  array (
    'relax,' => 1,
    'do' => 2,
    'relax.' => 1,
    '' => 1,
  ),
  'relax,' => 
  array (
    '-' => 1,
  ),
  'pleasantly,' => 
  array (
    'like' => 1,
  ),
  'stewardess' => 
  array (
    'in' => 1,
  ),
  'airliner' => 
  array (
    'with' => 1,
  ),
  'wing' => 
  array (
    'and' => 1,
    '' => 1,
  ),
  'engines' => 
  array (
    'one' => 1,
    'back' => 1,
    'cut' => 1,
  ),
  'fire,' => 
  array (
    '-' => 1,
  ),
  'point!' => 
  array (
    '-' => 1,
  ),
  'raged' => 
  array (
    'Ford.' => 1,
  ),
  'penguin,' => 
  array (
    'and' => 1,
  ),
  'colleague' => 
  array (
    'here' => 1,
  ),
  'rapidly' => 
  array (
    'running' => 1,
    '' => 1,
  ),
  'limbs!' => 
  array (
    '-' => 1,
  ),
  'Admittedly,' => 
  array (
    '-' => 1,
  ),
  'they\'re' => 
  array (
    'longer' => 1,
    'on' => 1,
    'going' => 1,
    'just' => 2,
    'shooting' => 1,
  ),
  'anything,' => 
  array (
    '-' => 1,
  ),
  'squawked' => 
  array (
    'Ford' => 1,
    'a' => 1,
  ),
  'avian' => 
  array (
    'fury,' => 1,
  ),
  'fury,' => 
  array (
    '-' => 1,
  ),
  'ought' => 
  array (
    'to' => 2,
  ),
  'us?' => 
  array (
    'The' => 1,
    '' => 1,
    '-' => 1,
  ),
  'giant' => 
  array (
    'petit' => 1,
  ),
  'petit' => 
  array (
    'four' => 1,
  ),
  'lolloped' => 
  array (
    '' => 1,
  ),
  'Welcome,' => 
  array (
    '-' => 2,
  ),
  'Starship' => 
  array (
    'Heart' => 1,
  ),
  'alarmed,' => 
  array (
    '-' => 1,
    'I' => 1,
  ),
  'initial' => 
  array (
    'ill' => 1,
  ),
  'death' => 
  array (
    'at' => 1,
    '' => 2,
  ),
  'improbability' => 
  array (
    'level' => 1,
    '' => 2,
    'generator,' => 1,
  ),
  'level' => 
  array (
    'of' => 1,
    '' => 2,
    'in' => 1,
  ),
  'seventy-six' => 
  array (
    'thousand' => 2,
  ),
  'possibly' => 
  array (
    'much' => 1,
    'get' => 1,
    'one' => 1,
  ),
  'higher.' => 
  array (
    'We' => 1,
  ),
  'cruising' => 
  array (
    'at' => 1,
    'down' => 1,
  ),
  'twenty-five' => 
  array (
    'thousand' => 1,
  ),
  'restoring' => 
  array (
    'normality' => 1,
  ),
  'normality' => 
  array (
    'just' => 1,
  ),
  'luminous' => 
  array (
    'pink' => 1,
  ),
  'pink' => 
  array (
    'cubicle.' => 1,
    'cubicle' => 1,
    'little' => 1,
    '' => 1,
  ),
  'cubicle.' => 
  array (
    'Ford' => 1,
  ),
  'excited.' => 
  array (
    '-' => 2,
  ),
  'Arthur!' => 
  array (
    '-' => 2,
    'You\'re' => 1,
  ),
  'fantastic!' => 
  array (
    'We\'ve' => 1,
  ),
  'powered' => 
  array (
    'by' => 1,
  ),
  'Infinite' => 
  array (
    'Improbability' => 2,
    '' => 2,
  ),
  'Improbability' => 
  array (
    'Drive!' => 1,
    '' => 7,
    'Drive.' => 1,
    'Physics.' => 1,
    'it' => 1,
    'Drive' => 3,
    'Drive,' => 1,
    'flight' => 2,
    'of' => 1,
    'physics).' => 1,
    'data,' => 1,
    'drive?' => 1,
    'Factor,' => 1,
  ),
  'Drive!' => 
  array (
    'This' => 1,
    '' => 1,
  ),
  'incredible!' => 
  array (
    '' => 1,
  ),
  'rumors' => 
  array (
    'about' => 1,
  ),
  'before!' => 
  array (
    'They' => 1,
  ),
  'officially' => 
  array (
    '' => 1,
  ),
  'denied,' => 
  array (
    '' => 1,
  ),
  'Arthur?' => 
  array (
    'What\'s' => 1,
  ),
  'happening?' => 
  array (
    'Arthur' => 1,
    'it' => 1,
  ),
  'jammed' => 
  array (
    'himself' => 1,
  ),
  'cubicle,' => 
  array (
    'trying' => 1,
  ),
  'closed,' => 
  array (
    'but' => 1,
  ),
  'fitting.' => 
  array (
    '' => 1,
  ),
  'Tiny' => 
  array (
    '' => 1,
  ),
  'squeezing' => 
  array (
    'themselves' => 1,
  ),
  'cracks,' => 
  array (
    'their' => 1,
  ),
  'inkstained;' => 
  array (
    'tiny' => 1,
  ),
  'voices' => 
  array (
    'chattered' => 1,
    'in' => 1,
  ),
  'chattered' => 
  array (
    'insanely.' => 1,
    'with' => 1,
    'the' => 2,
  ),
  'insanely.' => 
  array (
    'Arthur' => 1,
  ),
  'infinite' => 
  array (
    'number' => 1,
    'improbability' => 1,
    'delta' => 1,
    'majesty' => 1,
    'and' => 1,
    'reaches' => 1,
  ),
  'monkeys' => 
  array (
    '' => 2,
  ),
  'script' => 
  array (
    'for' => 1,
  ),
  'Hamlet' => 
  array (
    'they\'ve' => 1,
  ),
  'they\'ve' => 
  array (
    'worked' => 1,
    'given' => 1,
  ),
  10 => 
  array (
    'The' => 1,
  ),
  'Drive' => 
  array (
    '' => 2,
    'prototype' => 1,
    'switch' => 1,
    'for' => 1,
  ),
  'method' => 
  array (
    '' => 1,
  ),
  'vast' => 
  array (
    'interstellar' => 1,
    'majority' => 1,
    'dark' => 1,
    'crescent' => 1,
    '' => 1,
    'tract' => 1,
    'and' => 1,
    'hyperintelligent' => 1,
  ),
  'second,' => 
  array (
    'without' => 1,
    'and' => 1,
  ),
  'tedious' => 
  array (
    'mucking' => 1,
  ),
  'mucking' => 
  array (
    'about' => 1,
  ),
  'chance,' => 
  array (
    '' => 1,
  ),
  'developed' => 
  array (
    '' => 1,
  ),
  'governable' => 
  array (
    'form' => 1,
  ),
  'propulsion' => 
  array (
    'by' => 1,
  ),
  'Government\'s' => 
  array (
    '' => 1,
  ),
  'This,' => 
  array (
    'briefly,' => 1,
    '-' => 1,
  ),
  'briefly,' => 
  array (
    'is' => 1,
    'you' => 1,
  ),
  'discovery.' => 
  array (
    'The' => 1,
  ),
  'generating' => 
  array (
    'small' => 1,
  ),
  'amounts' => 
  array (
    'of' => 1,
  ),
  'finite' => 
  array (
    'improbability' => 2,
    'improbability.' => 1,
  ),
  'hooking' => 
  array (
    'the' => 1,
  ),
  'logic' => 
  array (
    'circuits' => 1,
    '' => 1,
  ),
  'circuits' => 
  array (
    'of' => 1,
    'cut' => 2,
    'chattered' => 1,
    '' => 1,
    'sprang' => 1,
    'are' => 1,
  ),
  'Bambleweeny' => 
  array (
    57 => 1,
  ),
  57 => 
  array (
    'SubMeson' => 1,
  ),
  'SubMeson' => 
  array (
    'Brain' => 1,
  ),
  'Brain' => 
  array (
    'to' => 1,
  ),
  'atomic' => 
  array (
    'vector' => 1,
  ),
  'vector' => 
  array (
    'plotter' => 1,
  ),
  'plotter' => 
  array (
    'suspended' => 1,
  ),
  'suspended' => 
  array (
    'in' => 2,
  ),
  'strong' => 
  array (
    'Brownian' => 1,
    '' => 1,
    'desire' => 1,
  ),
  'Brownian' => 
  array (
    'Motion' => 1,
  ),
  'Motion' => 
  array (
    'producer' => 1,
  ),
  'producer' => 
  array (
    '' => 1,
  ),
  '(say' => 
  array (
    'a' => 1,
  ),
  'tea)' => 
  array (
    '' => 1,
  ),
  'generators' => 
  array (
    'were' => 1,
  ),
  'ice' => 
  array (
    'at' => 1,
  ),
  'parties' => 
  array (
    'by' => 1,
  ),
  'molecules' => 
  array (
    'in' => 1,
  ),
  'hostess\'s' => 
  array (
    'undergarments' => 1,
  ),
  'undergarments' => 
  array (
    'leap' => 1,
  ),
  'leap' => 
  array (
    'simultaneously' => 1,
    'out' => 1,
  ),
  'simultaneously' => 
  array (
    'one' => 1,
    'spewed' => 1,
  ),
  'left,' => 
  array (
    'in' => 1,
  ),
  'accordance' => 
  array (
    'with' => 1,
  ),
  'Theory' => 
  array (
    'of' => 1,
  ),
  'Indeterminacy.' => 
  array (
    'Many' => 1,
  ),
  'respectable' => 
  array (
    'physicists' => 2,
  ),
  'physicists' => 
  array (
    'said' => 1,
    'who' => 1,
  ),
  'debasement' => 
  array (
    'of' => 1,
  ),
  'science,' => 
  array (
    'but' => 1,
  ),
  'parties.' => 
  array (
    'Another' => 1,
  ),
  'failure' => 
  array (
    '' => 1,
  ),
  'encountered' => 
  array (
    'in' => 1,
  ),
  'construct' => 
  array (
    'a' => 1,
  ),
  'machine' => 
  array (
    '' => 2,
    'was' => 2,
    'is' => 1,
    'which' => 1,
    'goes' => 1,
    'only' => 1,
  ),
  'generate' => 
  array (
    '' => 1,
  ),
  'needed' => 
  array (
    '' => 1,
  ),
  'flip' => 
  array (
    '' => 1,
    'through' => 1,
  ),
  'mind-paralysing' => 
  array (
    'distances' => 1,
  ),
  'grumpily' => 
  array (
    'announced' => 1,
  ),
  'impossible.' => 
  array (
    'Then,' => 1,
  ),
  'Then,' => 
  array (
    'one' => 1,
    'after' => 1,
  ),
  'student' => 
  array (
    'who' => 1,
    'at' => 1,
  ),
  'unsuccessful' => 
  array (
    'party' => 1,
  ),
  'reasoning' => 
  array (
    'this' => 1,
    'to' => 1,
  ),
  'way:' => 
  array (
    'If,' => 1,
  ),
  'If,' => 
  array (
    'he' => 1,
  ),
  'virtual' => 
  array (
    'impossibility,' => 1,
    'imprisonment' => 1,
  ),
  'logically' => 
  array (
    'be' => 1,
  ),
  'improbability.' => 
  array (
    'So' => 1,
  ),
  'order' => 
  array (
    'to' => 3,
    'that' => 2,
  ),
  'generator,' => 
  array (
    'give' => 1,
  ),
  'tea...' => 
  array (
    'and' => 1,
  ),
  'on!' => 
  array (
    'He' => 1,
    '-' => 1,
  ),
  'create' => 
  array (
    'the' => 1,
    'an' => 1,
  ),
  'sought' => 
  array (
    'after' => 1,
    '' => 1,
  ),
  'golden' => 
  array (
    '' => 1,
    'sky...' => 1,
  ),
  'generator' => 
  array (
    'out' => 1,
  ),
  'air.' => 
  array (
    'It' => 1,
    'Arthur' => 1,
    'The' => 1,
    '-' => 1,
  ),
  'awarded' => 
  array (
    'the' => 1,
  ),
  'Institute\'s' => 
  array (
    'Prize' => 1,
  ),
  'Prize' => 
  array (
    'for' => 1,
  ),
  'Extreme' => 
  array (
    'Cleverness' => 1,
  ),
  'Cleverness' => 
  array (
    'he' => 1,
  ),
  'lynched' => 
  array (
    'by' => 1,
    'aren\'t' => 1,
  ),
  'rampaging' => 
  array (
    'mob' => 1,
  ),
  'mob' => 
  array (
    'of' => 2,
  ),
  'smartass.' => 
  array (
    'Chapter' => 1,
  ),
  11 => 
  array (
    'The' => 1,
  ),
  'Improbability-proof' => 
  array (
    'control' => 1,
  ),
  'conventional' => 
  array (
    'spaceship' => 1,
    'meaning' => 1,
    'photon' => 1,
  ),
  'new.' => 
  array (
    'Some' => 1,
  ),
  'seats' => 
  array (
    'hadn\'t' => 1,
  ),
  'wrapping' => 
  array (
    'taken' => 1,
  ),
  'white,' => 
  array (
    'oblong,' => 1,
  ),
  'oblong,' => 
  array (
    'and' => 1,
  ),
  'smallish' => 
  array (
    'restaurant.' => 1,
    'chambers' => 1,
  ),
  'restaurant.' => 
  array (
    'In' => 1,
  ),
  'oblong:' => 
  array (
    'the' => 1,
  ),
  'raked' => 
  array (
    'round' => 1,
  ),
  'parallel' => 
  array (
    'curve,' => 1,
  ),
  'curve,' => 
  array (
    'and' => 1,
  ),
  'angles' => 
  array (
    'and' => 1,
    'the' => 1,
  ),
  'corners' => 
  array (
    'were' => 1,
  ),
  'contoured' => 
  array (
    'in' => 1,
  ),
  'excitingly' => 
  array (
    'chunky' => 2,
    'purposeful,' => 1,
  ),
  'shapes.' => 
  array (
    'The' => 1,
  ),
  'deal' => 
  array (
    'simpler' => 1,
    'with' => 1,
    'heavier' => 1,
  ),
  'simpler' => 
  array (
    'and' => 1,
  ),
  'ordinary' => 
  array (
    'three-dimensional' => 1,
  ),
  'three-dimensional' => 
  array (
    'oblong' => 1,
  ),
  'oblong' => 
  array (
    'rom,' => 1,
  ),
  'rom,' => 
  array (
    '' => 1,
  ),
  'designers' => 
  array (
    'would' => 1,
  ),
  'miserable.' => 
  array (
    '' => 1,
  ),
  'purposeful,' => 
  array (
    'with' => 1,
  ),
  'video' => 
  array (
    'screens' => 1,
  ),
  'screens' => 
  array (
    'ranged' => 1,
    '' => 4,
    'again' => 1,
  ),
  'ranged' => 
  array (
    '' => 1,
    'in' => 1,
  ),
  'guidance' => 
  array (
    'system' => 1,
    'system,' => 1,
    'rocked' => 1,
    'system.' => 1,
    'systems.' => 1,
  ),
  'panels' => 
  array (
    '' => 3,
    'slid' => 1,
  ),
  'wall,' => 
  array (
    '' => 1,
  ),
  'banks' => 
  array (
    '' => 3,
    'and' => 1,
  ),
  'computers' => 
  array (
    'set' => 1,
    'ranged' => 1,
    'to' => 1,
    'were' => 1,
    'usually' => 1,
  ),
  'convex' => 
  array (
    'wall.' => 1,
  ),
  'humped,' => 
  array (
    '' => 1,
  ),
  'gleaming' => 
  array (
    'brushed' => 1,
    '' => 2,
    'equipment' => 1,
  ),
  'hanging' => 
  array (
    'loosely' => 1,
  ),
  'loosely' => 
  array (
    'between' => 1,
  ),
  'knees.' => 
  array (
    'It' => 1,
  ),
  'new,' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'beautifully' => 
  array (
    'constructed' => 1,
    '' => 1,
  ),
  'properly.' => 
  array (
    'In' => 1,
    'Then' => 1,
  ),
  'bearing' => 
  array (
    '' => 1,
  ),
  'paced' => 
  array (
    'nervously' => 1,
  ),
  'brushing' => 
  array (
    'his' => 1,
  ),
  'giggling' => 
  array (
    'with' => 1,
  ),
  'excitement.' => 
  array (
    'Trillian' => 1,
    '-' => 3,
    'It' => 1,
    'Near' => 1,
  ),
  'hunched' => 
  array (
    'over' => 1,
    'in' => 1,
    '' => 1,
    'posture' => 1,
  ),
  'clump' => 
  array (
    'of' => 1,
  ),
  'figures.' => 
  array (
    'Her' => 1,
    '-' => 1,
    '' => 1,
  ),
  'Her' => 
  array (
    'voice' => 1,
  ),
  'Tannoy' => 
  array (
    'system' => 1,
  ),
  'falling...' => 
  array (
    '' => 1,
    'three' => 1,
  ),
  'two...' => 
  array (
    'one...' => 1,
  ),
  'probability' => 
  array (
    'factor' => 1,
    'forecast' => 1,
    'a' => 1,
    'and' => 1,
  ),
  'factor' => 
  array (
    'of' => 1,
  ),
  'normality,' => 
  array (
    'I' => 1,
  ),
  'repeat' => 
  array (
    'we' => 1,
  ),
  'normality.' => 
  array (
    '-' => 1,
  ),
  'microphone' => 
  array (
    'off' => 1,
  ),
  'continued:' => 
  array (
    '-' => 2,
  ),
  'Anything' => 
  array (
    'you' => 1,
  ),
  'cope' => 
  array (
    '' => 2,
  ),
  'problem.' => 
  array (
    'Please' => 1,
  ),
  'relax.' => 
  array (
    'You' => 1,
    'Zaphod' => 1,
  ),
  'soon.' => 
  array (
    'Zaphod' => 1,
  ),
  'annoyance:' => 
  array (
    '-' => 1,
  ),
  'Trillian?' => 
  array (
    'Trillian' => 1,
  ),
  'guys' => 
  array (
    'we' => 2,
    'I' => 1,
    'that' => 1,
  ),
  'Section' => 
  array (
    'ZZ9' => 1,
    '5a,' => 1,
  ),
  'ZZ9' => 
  array (
    'Plural' => 1,
  ),
  'Plural' => 
  array (
    'Z' => 4,
  ),
  'Z' => 
  array (
    'Alpha.' => 3,
    'finally' => 1,
    'Alpha?' => 1,
    'mean?' => 1,
  ),
  'Alpha.' => 
  array (
    '-' => 2,
    'ZZ' => 1,
  ),
  'Trillian,' => 
  array (
    '' => 2,
    'turning' => 1,
    '-' => 9,
    'and' => 1,
    'can' => 1,
  ),
  'Zaphod,' => 
  array (
    '-' => 27,
    'and' => 3,
    'this' => 1,
    'he' => 1,
    '' => 4,
    'thumping' => 1,
    'relaxing.' => 1,
    'hardly' => 1,
    'blearily.' => 1,
    'goggle-eyed.' => 1,
    'attacking' => 1,
    'running' => 1,
  ),
  'wise' => 
  array (
    '' => 1,
  ),
  'circumstances?' => 
  array (
    '' => 1,
  ),
  'everything,' => 
  array (
    'we' => 1,
  ),
  'police' => 
  array (
    '' => 1,
    'it' => 1,
  ),
  'pick' => 
  array (
    'up' => 1,
    'them' => 2,
    '' => 1,
  ),
  'OK,' => 
  array (
    'so' => 2,
    'OK...' => 1,
    '-' => 4,
    'OK,' => 1,
    'Ford,' => 1,
    'sure' => 1,
    '' => 1,
    'here' => 1,
    'this' => 1,
  ),
  'style,' => 
  array (
    'but' => 1,
  ),
  'minus' => 
  array (
    'several' => 1,
    'one,' => 1,
    'forty-five' => 1,
    '' => 1,
    'twenty' => 1,
    'five' => 1,
  ),
  'thinking,' => 
  array (
    'yeah?' => 1,
  ),
  'yeah?' => 
  array (
    'He' => 1,
    'Ford' => 1,
    '-' => 2,
  ),
  'panel.' => 
  array (
    'Trillian' => 1,
    'The' => 3,
    '-' => 1,
  ),
  'Zaphod\'s' => 
  array (
    '' => 2,
    'jist' => 1,
    'door.' => 1,
    'told' => 1,
    'heads' => 1,
    'faces.' => 1,
    'voice.' => 1,
  ),
  'dash,' => 
  array (
    'bravado,' => 1,
  ),
  'bravado,' => 
  array (
    'conceit' => 1,
  ),
  'conceit' => 
  array (
    '-' => 1,
  ),
  'mechanically' => 
  array (
    '' => 1,
  ),
  'inept' => 
  array (
    'and' => 1,
  ),
  'easily' => 
  array (
    'blow' => 1,
  ),
  'blow' => 
  array (
    'the' => 1,
    '' => 1,
  ),
  'extravagant' => 
  array (
    '' => 1,
  ),
  'gesture.' => 
  array (
    '' => 1,
  ),
  'significance' => 
  array (
    '' => 1,
    'whatsoever.' => 1,
  ),
  'unprotected' => 
  array (
    '' => 1,
  ),
  'space...' => 
  array (
    'you' => 1,
  ),
  'such,' => 
  array (
    'but...' => 2,
  ),
  'such?' => 
  array (
    'Not' => 1,
    'But?' => 1,
  ),
  'But?' => 
  array (
    '-' => 1,
  ),
  'cocked' => 
  array (
    '' => 1,
    'hat.' => 1,
  ),
  'side.' => 
  array (
    '-' => 1,
  ),
  'dead.' => 
  array (
    '-' => 1,
    'A' => 1,
    'Ford' => 1,
    'In' => 1,
  ),
  'You\'d' => 
  array (
    'been' => 1,
  ),
  'die?' => 
  array (
    '-' => 1,
    'Why' => 1,
  ),
  'Anyway,' => 
  array (
    '-' => 1,
  ),
  'controls,' => 
  array (
    '-' => 1,
  ),
  'Huh?' => 
  array (
    '-' => 3,
  ),
  'Whilst' => 
  array (
    'we' => 1,
  ),
  'Drive.' => 
  array (
    '-' => 1,
  ),
  'incredible.' => 
  array (
    '-' => 1,
  ),
  'Zaphod.' => 
  array (
    'Just' => 1,
    '-' => 37,
    'He' => 1,
    'Ford' => 1,
    '' => 4,
    'The' => 1,
  ),
  'improbable.' => 
  array (
    '-' => 1,
  ),
  'yeah.' => 
  array (
    '-' => 2,
  ),
  'arm,' => 
  array (
    '-' => 1,
    'and' => 1,
  ),
  'aliens.' => 
  array (
    'They\'re' => 1,
  ),
  'expect.' => 
  array (
    'I\'ll' => 1,
    'But' => 1,
  ),
  'bring' => 
  array (
    'them' => 1,
    'the' => 1,
  ),
  'Hey' => 
  array (
    'Marvin!' => 1,
    'doll,' => 1,
    'this' => 1,
    '' => 1,
    'come' => 1,
    'listen!' => 1,
    'Earthman?' => 1,
  ),
  'Marvin!' => 
  array (
    'In' => 1,
    '-' => 2,
  ),
  'corner,' => 
  array (
    'the' => 1,
    '' => 1,
  ),
  'robot\'s' => 
  array (
    'head' => 1,
    '' => 1,
  ),
  'wobbled' => 
  array (
    'about' => 1,
  ),
  'imperceptibly.' => 
  array (
    'It' => 1,
  ),
  'pounds' => 
  array (
    'heavier' => 1,
    'of' => 1,
  ),
  'heavier' => 
  array (
    'that' => 1,
    'and' => 1,
  ),
  'observer' => 
  array (
    'would' => 1,
  ),
  'heroic' => 
  array (
    'effort' => 1,
  ),
  'effort' => 
  array (
    '' => 1,
    'to' => 1,
  ),
  'room.' => 
  array (
    '' => 1,
    '-' => 2,
    'Arthur' => 1,
  ),
  'depressed,' => 
  array (
    '' => 2,
  ),
  'Its' => 
  array (
    'voice' => 1,
    'crew' => 1,
    'main' => 1,
  ),
  'hopeless.' => 
  array (
    '-' => 1,
  ),
  'muttered' => 
  array (
    'Zaphod' => 2,
    'embarrassed' => 1,
    'Arthur' => 1,
    'Zaphod,' => 1,
    'Ford,' => 2,
    'Arthur.' => 1,
    'to' => 2,
    'Phouchg' => 1,
    'Frankie' => 1,
  ),
  'tone,' => 
  array (
    '' => 1,
  ),
  'here\'s' => 
  array (
    'something' => 1,
  ),
  'occupy' => 
  array (
    'you' => 1,
  ),
  'things.' => 
  array (
    '-' => 4,
    'All' => 1,
  ),
  'droned' => 
  array (
    'Marvin,' => 1,
  ),
  'Marvin,' => 
  array (
    '-' => 9,
    '' => 1,
    'who' => 1,
  ),
  'exceptionally' => 
  array (
    '' => 1,
  ),
  'warned' => 
  array (
    'Trillian.' => 1,
    'Majikthise,' => 1,
  ),
  'Trillian.' => 
  array (
    '-' => 13,
    'The' => 1,
    'She' => 1,
    '' => 1,
  ),
  'bay' => 
  array (
    'and' => 1,
    '' => 1,
  ),
  'aliens' => 
  array (
    '' => 1,
    '-' => 1,
    'now,' => 1,
  ),
  'surveillance.' => 
  array (
    'With' => 1,
  ),
  'microsecond' => 
  array (
    'pause,' => 1,
  ),
  'pause,' => 
  array (
    'and' => 2,
  ),
  'calculated' => 
  array (
    'micromodulation' => 1,
    'the' => 1,
  ),
  'micromodulation' => 
  array (
    '' => 1,
  ),
  'timbre' => 
  array (
    '-' => 1,
  ),
  'offence' => 
  array (
    '' => 1,
  ),
  'Marvin' => 
  array (
    'managed' => 1,
    'like' => 1,
    'turned' => 1,
    'flashed' => 1,
    'regarded' => 1,
    'ignored' => 1,
    'stomped' => 1,
    'and' => 2,
    'trudged' => 1,
    'stopped,' => 1,
    'eyed' => 2,
    'was' => 2,
    'who' => 2,
    '' => 2,
    'started' => 1,
    'dolefully,' => 1,
    'assured' => 1,
  ),
  'convey' => 
  array (
    'his' => 1,
  ),
  'utter' => 
  array (
    'contempt' => 1,
    'blackness' => 1,
  ),
  'contempt' => 
  array (
    'and' => 1,
  ),
  'firmly.' => 
  array (
    '-' => 2,
    'Both' => 1,
  ),
  'Marvin.' => 
  array (
    'Zaphod' => 1,
    '-' => 9,
  ),
  'She\'s' => 
  array (
    'not' => 1,
  ),
  'asking' => 
  array (
    'you' => 1,
    'is...' => 1,
    'Zaphod,' => 1,
    'if' => 1,
  ),
  'shouted,' => 
  array (
    '-' => 2,
  ),
  'tolling' => 
  array (
    'of' => 1,
  ),
  'bell,' => 
  array (
    '' => 1,
  ),
  'Good...' => 
  array (
    '-' => 1,
  ),
  'great...' => 
  array (
    'thank' => 1,
  ),
  'you...' => 
  array (
    'Marvin' => 1,
    'Someone' => 1,
    'there' => 1,
  ),
  'flat-topped' => 
  array (
    '' => 1,
  ),
  'triangular' => 
  array (
    '' => 1,
  ),
  'I?' => 
  array (
    '-' => 4,
    'Hello?' => 1,
    'Calm' => 1,
    'Wow!' => 1,
    'And' => 1,
    'What' => 1,
  ),
  'pathetically.' => 
  array (
    '-' => 1,
  ),
  'lilted' => 
  array (
    'Trillian,' => 2,
  ),
  'really...' => 
  array (
    '-' => 2,
    'just' => 1,
  ),
  'lilt' => 
  array (
    'continued,' => 1,
  ),
  'comes' => 
  array (
    'naturally' => 1,
    'together.' => 1,
    'a' => 1,
    '' => 1,
  ),
  'naturally' => 
  array (
    'and' => 1,
    'came' => 1,
    'assumed' => 1,
    'tenable' => 1,
  ),
  'fine.' => 
  array (
    '-' => 1,
  ),
  'mind?' => 
  array (
    '-' => 1,
  ),
  'probed' => 
  array (
    'Marvin.' => 1,
  ),
  'life.' => 
  array (
    '-' => 3,
    'He' => 1,
    'And' => 1,
    'How' => 1,
    '' => 1,
  ),
  'look.' => 
  array (
    '-' => 2,
    'Trillian' => 1,
    'He' => 1,
    '' => 1,
  ),
  'Life,' => 
  array (
    '-' => 2,
    '' => 3,
    'the' => 5,
  ),
  'hopelessly' => 
  array (
    'on' => 1,
    'round' => 1,
  ),
  'heel' => 
  array (
    'and' => 1,
  ),
  'lugged' => 
  array (
    'himself' => 1,
  ),
  'satisfied' => 
  array (
    'hum' => 1,
    'sigh-like' => 1,
    'himself' => 1,
  ),
  'click' => 
  array (
    'the' => 1,
  ),
  'Encyclopaedia' => 
  array (
    'Galactica' => 2,
  ),
  'defines' => 
  array (
    'a' => 2,
    'the' => 1,
  ),
  'mechanical' => 
  array (
    'apparatus' => 1,
  ),
  'apparatus' => 
  array (
    'designed' => 1,
  ),
  'marketing' => 
  array (
    '' => 4,
  ),
  'division' => 
  array (
    '' => 3,
    'of' => 1,
  ),
  'Sirius' => 
  array (
    'Cybernetics' => 3,
    '' => 4,
    'Tau' => 1,
  ),
  'Cybernetics' => 
  array (
    'Corporation' => 4,
    'Corporation,' => 1,
    '' => 2,
  ),
  'Corporation' => 
  array (
    'defines' => 1,
    'as' => 2,
    'robots' => 1,
    '' => 2,
  ),
  '"Your' => 
  array (
    'Plastic' => 1,
  ),
  'Plastic' => 
  array (
    'Pal' => 1,
  ),
  'Pal' => 
  array (
    'Who\'s' => 1,
  ),
  'Who\'s' => 
  array (
    'Fun' => 1,
    '' => 1,
  ),
  'Fun' => 
  array (
    '' => 1,
  ),
  'Be' => 
  array (
    'With".' => 1,
    'the' => 1,
  ),
  'With".' => 
  array (
    'The' => 1,
  ),
  '"a' => 
  array (
    'bunch' => 2,
  ),
  'jerks' => 
  array (
    'who\'ll' => 1,
    'who' => 1,
  ),
  'who\'ll' => 
  array (
    'be' => 1,
  ),
  'revolution' => 
  array (
    'comes",' => 1,
    'came".' => 1,
  ),
  'comes",' => 
  array (
    'with' => 1,
  ),
  'footnote' => 
  array (
    'to' => 1,
  ),
  'editors' => 
  array (
    '' => 1,
    'like' => 1,
  ),
  'welcome' => 
  array (
    '' => 1,
  ),
  'applications' => 
  array (
    '' => 1,
  ),
  'interested' => 
  array (
    'in' => 1,
  ),
  'post' => 
  array (
    'of' => 1,
  ),
  'robotics' => 
  array (
    'correspondent.' => 1,
  ),
  'correspondent.' => 
  array (
    'Curiously' => 1,
  ),
  'fall' => 
  array (
    'through' => 1,
    'apart' => 1,
  ),
  'warp' => 
  array (
    'from' => 1,
  ),
  'future' => 
  array (
    '' => 1,
    'lives...' => 1,
    'time,' => 1,
    'probability' => 1,
  ),
  'defined' => 
  array (
    '' => 1,
    'areas' => 1,
    'as' => 1,
  ),
  'came".' => 
  array (
    'The' => 1,
  ),
  'cubicle' => 
  array (
    'had' => 1,
  ),
  'existence,' => 
  array (
    'the' => 1,
  ),
  'dimension.' => 
  array (
    '' => 1,
    'It' => 1,
  ),
  'embarkation' => 
  array (
    'area' => 1,
  ),
  'area' => 
  array (
    'of' => 1,
    'stood' => 1,
    '' => 1,
  ),
  'smart.' => 
  array (
    '-' => 1,
  ),
  'brand' => 
  array (
    'new,' => 1,
  ),
  'tell?' => 
  array (
    '-' => 1,
  ),
  'exotic' => 
  array (
    'device' => 1,
    '' => 2,
    'dishes,' => 1,
  ),
  'measuring' => 
  array (
    'the' => 1,
    'equipment' => 1,
  ),
  'age' => 
  array (
    'of' => 1,
  ),
  'metal?' => 
  array (
    '-' => 1,
  ),
  'sales' => 
  array (
    'brochure' => 1,
    'brochure,' => 1,
    'brochure.' => 1,
  ),
  'brochure' => 
  array (
    'lying' => 1,
  ),
  '`the' => 
  array (
    'Universe' => 1,
  ),
  'yours\'' => 
  array (
    'stuff.' => 1,
  ),
  'stuff.' => 
  array (
    'Ah!' => 1,
    'Ford' => 1,
    'So' => 1,
    'The' => 1,
  ),
  'Ah!' => 
  array (
    'Look,' => 1,
  ),
  'jabbed' => 
  array (
    'at' => 1,
    'a' => 1,
  ),
  'pages' => 
  array (
    'and' => 1,
  ),
  'showed' => 
  array (
    'it' => 1,
    '' => 3,
    'up' => 2,
  ),
  'says:' => 
  array (
    'Sensational' => 1,
  ),
  'Sensational' => 
  array (
    'new' => 1,
  ),
  'breakthrough' => 
  array (
    'in' => 1,
  ),
  'Physics.' => 
  array (
    '' => 1,
  ),
  'reaches' => 
  array (
    'Infinite' => 1,
    'of' => 2,
  ),
  'passes' => 
  array (
    '' => 2,
  ),
  'envy' => 
  array (
    'of' => 1,
  ),
  'governments.' => 
  array (
    '' => 1,
  ),
  'league' => 
  array (
    'stuff.' => 1,
  ),
  'hunted' => 
  array (
    'excitedly' => 1,
  ),
  'excitedly' => 
  array (
    '' => 1,
    'over' => 1,
  ),
  'technical' => 
  array (
    '' => 1,
  ),
  'specs' => 
  array (
    '' => 1,
  ),
  'occasionally' => 
  array (
    'gasping' => 1,
    'rent' => 1,
  ),
  'gasping' => 
  array (
    'with' => 1,
    '' => 1,
  ),
  'astrotechnology' => 
  array (
    'had' => 1,
  ),
  'ahead' => 
  array (
    'during' => 1,
  ),
  'exile.' => 
  array (
    'Arthur' => 1,
  ),
  'while,' => 
  array (
    'but' => 1,
  ),
  'unable' => 
  array (
    'to' => 4,
    '' => 1,
  ),
  'majority' => 
  array (
    'of' => 1,
  ),
  'wander,' => 
  array (
    'trailing' => 1,
  ),
  'trailing' => 
  array (
    'his' => 1,
  ),
  'bank,' => 
  array (
    'he' => 1,
  ),
  'invitingly' => 
  array (
    'large' => 1,
  ),
  'panel' => 
  array (
    'lit' => 1,
    '' => 1,
  ),
  'engrossed' => 
  array (
    'in' => 1,
  ),
  'brochure,' => 
  array (
    '-' => 1,
  ),
  'cybernetics.' => 
  array (
    '' => 1,
  ),
  'generation' => 
  array (
    '' => 1,
    'product' => 1,
  ),
  'robots' => 
  array (
    'and' => 1,
    'with' => 1,
    'hate' => 1,
  ),
  'computers,' => 
  array (
    '' => 1,
  ),
  'GPP' => 
  array (
    'feature.' => 1,
    'feature?' => 1,
  ),
  'feature.' => 
  array (
    '-' => 1,
  ),
  'feature?' => 
  array (
    '-' => 1,
  ),
  'Genuine' => 
  array (
    'People' => 2,
  ),
  'Personalities.' => 
  array (
    '-' => 1,
  ),
  'ghastly.' => 
  array (
    'A' => 1,
    '' => 1,
  ),
  'hopeless' => 
  array (
    'and' => 1,
  ),
  'accompanied' => 
  array (
    'by' => 1,
  ),
  'clanking' => 
  array (
    'sound.' => 1,
  ),
  'abject' => 
  array (
    '' => 1,
    'poverty.' => 1,
  ),
  'doorway.' => 
  array (
    '-' => 1,
    'They' => 1,
  ),
  'Ghastly,' => 
  array (
    '-' => 1,
  ),
  'Absolutely' => 
  array (
    'ghastly.' => 1,
  ),
  'stepping' => 
  array (
    '' => 1,
  ),
  'irony' => 
  array (
    'circuits' => 1,
  ),
  'modulator' => 
  array (
    '' => 1,
  ),
  'mimicked' => 
  array (
    '' => 1,
    'Marvin.' => 2,
  ),
  'brochure.' => 
  array (
    '-' => 1,
  ),
  'doors' => 
  array (
    '' => 1,
  ),
  'cheerful' => 
  array (
    'and' => 1,
    'excited' => 1,
  ),
  'sunny' => 
  array (
    'disposition.' => 1,
  ),
  'disposition.' => 
  array (
    'It' => 1,
  ),
  'done.' => 
  array (
    'As' => 1,
  ),
  'sigh-like' => 
  array (
    'quality' => 1,
  ),
  'Hummmmmmmyummmmmmm' => 
  array (
    'ah!' => 1,
  ),
  'ah!' => 
  array (
    '-' => 1,
  ),
  'regarded' => 
  array (
    'it' => 1,
    'Arthur' => 1,
  ),
  'loathing' => 
  array (
    '' => 1,
  ),
  'tinkered' => 
  array (
    'with' => 1,
  ),
  'concept' => 
  array (
    'of' => 1,
  ),
  'directing' => 
  array (
    'physical' => 1,
  ),
  'violence' => 
  array (
    'against' => 1,
  ),
  'Further' => 
  array (
    'circuits' => 1,
    '' => 1,
  ),
  'saying,' => 
  array (
    'Why' => 1,
    '-' => 2,
    'they' => 1,
  ),
  'bother?' => 
  array (
    'What\'s' => 1,
  ),
  'point?' => 
  array (
    'Nothing' => 1,
    'Out' => 1,
    '-' => 1,
    '' => 1,
  ),
  'Nothing' => 
  array (
    'is' => 1,
    'unexpected' => 1,
  ),
  'amused' => 
  array (
    'themselves' => 1,
  ),
  'analysing' => 
  array (
    'the' => 1,
  ),
  'molecular' => 
  array (
    'components' => 1,
  ),
  'components' => 
  array (
    'of' => 1,
    'and' => 1,
  ),
  'humanoids\'' => 
  array (
    'brain' => 1,
  ),
  'cells.' => 
  array (
    'For' => 1,
  ),
  'hydrogen' => 
  array (
    'emissions' => 1,
  ),
  'emissions' => 
  array (
    'in' => 1,
  ),
  'surrounding' => 
  array (
    'cubic' => 1,
  ),
  'cubic' => 
  array (
    'parsec' => 1,
  ),
  'parsec' => 
  array (
    'of' => 1,
  ),
  'boredom.' => 
  array (
    'A' => 1,
  ),
  'despair' => 
  array (
    'shook' => 1,
  ),
  'turned.' => 
  array (
    '-' => 1,
    'His' => 1,
  ),
  'droned,' => 
  array (
    '-' => 1,
  ),
  'ordered' => 
  array (
    'to' => 1,
  ),
  'am,' => 
  array (
    'brain' => 1,
  ),
  'Call' => 
  array (
    'that' => 1,
  ),
  'satisfaction?' => 
  array (
    '\'Cos' => 1,
  ),
  '\'Cos' => 
  array (
    'I' => 1,
  ),
  'walked' => 
  array (
    'back' => 1,
    'along' => 1,
    'to' => 1,
    '' => 1,
    'into' => 1,
    'out' => 1,
    'sadly' => 1,
    'towards' => 1,
  ),
  'hated' => 
  array (
    'door.' => 1,
    'humans' => 1,
    '' => 1,
    'me' => 1,
  ),
  'excuse' => 
  array (
    'me,' => 3,
  ),
  'following' => 
  array (
    'after' => 1,
    'facts' => 1,
  ),
  'owns' => 
  array (
    'this' => 1,
    'it,' => 1,
    'up,' => 1,
  ),
  'ship?' => 
  array (
    'Marvin' => 1,
    '-' => 2,
  ),
  'muttered,' => 
  array (
    '-' => 2,
  ),
  'intolerable' => 
  array (
    'air' => 1,
  ),
  'smugness' => 
  array (
    'it' => 1,
  ),
  'generates.' => 
  array (
    'With' => 1,
  ),
  'ingratiating' => 
  array (
    'little' => 1,
  ),
  'whine' => 
  array (
    'the' => 1,
  ),
  'slit' => 
  array (
    'open' => 1,
    'back' => 1,
  ),
  'clicks' => 
  array (
    'and' => 1,
  ),
  'whirrs.' => 
  array (
    '-' => 1,
  ),
  'Corporation,' => 
  array (
    '-' => 1,
  ),
  'trudged' => 
  array (
    'desolately' => 1,
    'on' => 1,
    'back' => 1,
  ),
  'desolately' => 
  array (
    'up' => 1,
  ),
  'stretched' => 
  array (
    'out' => 1,
    '' => 1,
  ),
  'Let\'s' => 
  array (
    'build' => 1,
    'get' => 1,
  ),
  'Personalities,' => 
  array (
    '-' => 1,
  ),
  'personality' => 
  array (
    'prototype.' => 1,
    '' => 1,
    'that' => 1,
  ),
  'prototype.' => 
  array (
    'You' => 1,
  ),
  'disclaimers.' => 
  array (
    '-' => 1,
  ),
  'hate' => 
  array (
    'that' => 1,
    'me.' => 2,
    '' => 1,
  ),
  'government...' => 
  array (
    '-' => 1,
  ),
  'robot,' => 
  array (
    '-' => 2,
    'the' => 1,
  ),
  'stolen.' => 
  array (
    '-' => 1,
    'Arthur' => 1,
  ),
  'Stolen?' => 
  array (
    '-' => 2,
  ),
  'by?' => 
  array (
    '-' => 1,
  ),
  'separate' => 
  array (
    'and' => 1,
    'cabins' => 1,
  ),
  'distinct' => 
  array (
    'expressions' => 1,
    'and' => 1,
  ),
  'expressions' => 
  array (
    'of' => 1,
  ),
  'amazement' => 
  array (
    'piled' => 1,
  ),
  'piled' => 
  array (
    'up' => 1,
  ),
  'jumbled' => 
  array (
    'mess.' => 1,
  ),
  'mess.' => 
  array (
    'His' => 1,
  ),
  'leg,' => 
  array (
    'which' => 1,
  ),
  'mid' => 
  array (
    'stride,' => 1,
  ),
  'stride,' => 
  array (
    'seemed' => 1,
  ),
  'difficulty' => 
  array (
    'in' => 1,
    'with' => 2,
    '' => 1,
  ),
  'finding' => 
  array (
    'the' => 1,
    'names' => 1,
    'out' => 1,
    'that' => 1,
    '' => 1,
  ),
  'entangle' => 
  array (
    'some' => 1,
  ),
  'dartoid' => 
  array (
    'muscles.' => 1,
  ),
  'muscles.' => 
  array (
    '-' => 1,
  ),
  'Beeblebrox...?' => 
  array (
    '-' => 1,
  ),
  'Sorry,' => 
  array (
    'did' => 1,
    'I' => 1,
  ),
  'wrong?' => 
  array (
    '-' => 1,
  ),
  'dragging' => 
  array (
    '' => 1,
  ),
  'regardless.' => 
  array (
    '-' => 1,
  ),
  'Pardon' => 
  array (
    'me' => 1,
  ),
  'breathing,' => 
  array (
    'which' => 1,
  ),
  'anyway' => 
  array (
    '' => 1,
  ),
  'bother' => 
  array (
    'to' => 1,
    'please,' => 1,
    '' => 1,
    'competing' => 1,
    'if' => 1,
  ),
  'oh' => 
  array (
    'God' => 1,
    'well,' => 1,
  ),
  'depressed.' => 
  array (
    'Here\'s' => 1,
    '-' => 1,
  ),
  'self-satisfied' => 
  array (
    'door.' => 1,
  ),
  'Life!' => 
  array (
    'Don\'t' => 1,
    '-' => 1,
  ),
  'mentioned' => 
  array (
    'it,' => 1,
  ),
  'irritably.' => 
  array (
    '-' => 1,
  ),
  12 => 
  array (
    'A' => 1,
  ),
  'loud' => 
  array (
    'clatter' => 1,
    'hailer' => 2,
    '' => 1,
  ),
  'clatter' => 
  array (
    'of' => 1,
  ),
  'gunk' => 
  array (
    'music' => 1,
    '' => 1,
  ),
  'flooded' => 
  array (
    'through' => 1,
    'with' => 1,
  ),
  'searched' => 
  array (
    'the' => 1,
  ),
  'wavebands' => 
  array (
    'for' => 1,
  ),
  'news' => 
  array (
    'of' => 1,
    '' => 3,
    'story' => 1,
    'bulletin' => 1,
  ),
  'operate.' => 
  array (
    '' => 1,
  ),
  'radios' => 
  array (
    '' => 1,
  ),
  'pressing' => 
  array (
    'buttons' => 1,
  ),
  'dials;' => 
  array (
    '' => 1,
  ),
  'technology' => 
  array (
    '' => 1,
  ),
  'sophisticated' => 
  array (
    '' => 1,
    'attempt' => 1,
  ),
  'controls' => 
  array (
    '' => 1,
    'again.' => 1,
    'had' => 1,
    '-' => 1,
  ),
  'touch-sensitive' => 
  array (
    '-' => 1,
  ),
  'merely' => 
  array (
    'had' => 1,
    '' => 2,
    'a' => 1,
    'the' => 1,
  ),
  'fingers;' => 
  array (
    'now' => 1,
  ),
  'general' => 
  array (
    'direction' => 1,
  ),
  'direction' => 
  array (
    '' => 1,
    'all' => 1,
    'lay' => 1,
    'whence' => 1,
  ),
  'hope.' => 
  array (
    'It' => 1,
    'Knocking' => 1,
  ),
  'saved' => 
  array (
    'a' => 1,
    'him' => 1,
    'our' => 1,
  ),
  'muscular' => 
  array (
    'expenditure' => 1,
  ),
  'expenditure' => 
  array (
    'of' => 1,
  ),
  'course,' => 
  array (
    'but' => 2,
    'the' => 1,
    'no' => 1,
    'and' => 1,
    'after' => 1,
  ),
  'programme.' => 
  array (
    'Zaphod' => 1,
  ),
  'channel' => 
  array (
    'switched' => 1,
    'again.' => 1,
  ),
  'switched' => 
  array (
    'again.' => 1,
    '' => 1,
  ),
  'background' => 
  array (
    'to' => 1,
  ),
  'announcement.' => 
  array (
    '' => 1,
  ),
  'edited' => 
  array (
    'to' => 1,
    '' => 1,
  ),
  'rhythms' => 
  array (
    'of' => 1,
  ),
  'music.' => 
  array (
    '-' => 1,
  ),
  'band,' => 
  array (
    'broadcasting' => 1,
  ),
  'broadcasting' => 
  array (
    'around' => 1,
  ),
  'galaxy' => 
  array (
    'around' => 1,
    '' => 1,
  ),
  'clock,' => 
  array (
    '-' => 1,
  ),
  'intelligent' => 
  array (
    '' => 1,
    'than' => 4,
    'life' => 1,
    'that' => 1,
    'caring' => 1,
  ),
  'everywhere...' => 
  array (
    'and' => 1,
  ),
  'rocks' => 
  array (
    '' => 1,
  ),
  'together,' => 
  array (
    'guys.' => 1,
  ),
  'guys.' => 
  array (
    'And' => 1,
    '-' => 2,
  ),
  'tonight' => 
  array (
    'is' => 1,
  ),
  'sensational' => 
  array (
    '' => 1,
  ),
  'theft' => 
  array (
    'of' => 1,
  ),
  'prototype' => 
  array (
    'ship' => 1,
  ),
  'question' => 
  array (
    'everyone\'s' => 1,
    'is' => 2,
    'which' => 1,
    'of' => 2,
    'is.' => 1,
    'actually' => 1,
    '' => 1,
    'Why' => 1,
    'Where' => 1,
  ),
  'everyone\'s' => 
  array (
    'asking' => 1,
    '' => 1,
    'attention.' => 1,
  ),
  'flipped?' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'invented' => 
  array (
    '' => 1,
  ),
  'Blaster,' => 
  array (
    '' => 1,
  ),
  'ex-confidence' => 
  array (
    '' => 1,
  ),
  'trickster,' => 
  array (
    '' => 1,
  ),
  'described' => 
  array (
    '' => 1,
    'myself' => 1,
    'it.' => 1,
  ),
  'Gallumbits' => 
  array (
    'as' => 1,
  ),
  'Best' => 
  array (
    'Bang' => 1,
  ),
  'Bang' => 
  array (
    'since' => 1,
    'itself?' => 1,
  ),
  'Big' => 
  array (
    '' => 1,
    'Bang' => 1,
  ),
  'One,' => 
  array (
    '' => 1,
  ),
  'voted' => 
  array (
    'the' => 1,
  ),
  'Wort' => 
  array (
    'Dressed' => 1,
  ),
  'Dressed' => 
  array (
    'Sentinent' => 1,
  ),
  'Sentinent' => 
  array (
    'Being' => 1,
  ),
  'Being' => 
  array (
    '' => 1,
  ),
  'Known' => 
  array (
    '' => 1,
  ),
  'seventh' => 
  array (
    'time...' => 1,
  ),
  'time...' => 
  array (
    'has' => 1,
  ),
  'private' => 
  array (
    'brain' => 1,
  ),
  'care' => 
  array (
    'specialist' => 1,
    'to' => 3,
    '' => 1,
    'of' => 1,
  ),
  'specialist' => 
  array (
    'Gag' => 1,
    'industry:' => 1,
  ),
  'Gag' => 
  array (
    'Halfrunt...' => 1,
  ),
  'Halfrunt...' => 
  array (
    '-' => 1,
  ),
  'dived' => 
  array (
    '' => 2,
    'screaming' => 1,
  ),
  'broke' => 
  array (
    'in,' => 1,
    'down,' => 1,
    'out' => 1,
  ),
  'presumably' => 
  array (
    '' => 2,
    'simultaneously.' => 1,
    'on' => 1,
  ),
  'Halfrunt.' => 
  array (
    '' => 1,
  ),
  'Vell,' => 
  array (
    'Zaphod\'s' => 1,
  ),
  'jist' => 
  array (
    'zis' => 1,
  ),
  'zis' => 
  array (
    'guy' => 1,
  ),
  'guy' => 
  array (
    'you' => 1,
    'boring' => 1,
    'we' => 1,
  ),
  'know?' => 
  array (
    '-' => 3,
    'How' => 1,
  ),
  'electric' => 
  array (
    'pencil' => 1,
    'death' => 1,
    'barrage.' => 1,
  ),
  'pencil' => 
  array (
    'flew' => 1,
    'sat' => 1,
    'away.' => 1,
  ),
  'flew' => 
  array (
    'across' => 1,
    'on' => 1,
    'open' => 1,
    'straight' => 1,
  ),
  'radio\'s' => 
  array (
    '' => 1,
  ),
  'on/off' => 
  array (
    '' => 1,
  ),
  'sensitive' => 
  array (
    'airspace.' => 1,
    'panel' => 1,
  ),
  'airspace.' => 
  array (
    'Zaphod' => 1,
  ),
  'glared' => 
  array (
    '' => 1,
    'at' => 2,
    'an' => 1,
  ),
  'pencil.' => 
  array (
    '-' => 1,
  ),
  'for?' => 
  array (
    'Trillian' => 1,
    '-' => 2,
  ),
  'tapping' => 
  array (
    'her' => 1,
  ),
  'screenful' => 
  array (
    'of' => 1,
  ),
  'Worth' => 
  array (
    'interrupting' => 1,
  ),
  'interrupting' => 
  array (
    'a' => 1,
  ),
  'bulletin' => 
  array (
    'about' => 1,
  ),
  'insecure.' => 
  array (
    'We' => 1,
  ),
  'drop' => 
  array (
    'your' => 1,
    'in.' => 1,
  ),
  'ego' => 
  array (
    'for' => 1,
    'around,' => 1,
  ),
  'moment?' => 
  array (
    'This' => 1,
  ),
  'laughed.' => 
  array (
    '-' => 1,
    'He' => 1,
  ),
  'guys...' => 
  array (
    '-' => 2,
  ),
  'guys?' => 
  array (
    '-' => 2,
  ),
  'yeah,' => 
  array (
    '-' => 3,
    'tail.' => 1,
  ),
  'sector' => 
  array (
    'ZZ' => 1,
    'you' => 1,
  ),
  'ZZ' => 
  array (
    9 => 3,
  ),
  'blinked.' => 
  array (
    'Trillian' => 1,
  ),
  'Does' => 
  array (
    'that' => 2,
    'anyone' => 1,
    '' => 1,
  ),
  'Mmmmm,' => 
  array (
    '-' => 1,
  ),
  'Alpha?' => 
  array (
    '-' => 1,
  ),
  'one?' => 
  array (
    '-' => 2,
  ),
  'difficulties' => 
  array (
    '' => 1,
  ),
  'relationship' => 
  array (
    '' => 3,
  ),
  'learning' => 
  array (
    '' => 2,
    'to' => 1,
  ),
  'distinguish' => 
  array (
    '' => 1,
  ),
  'outrageously' => 
  array (
    'stupid' => 1,
  ),
  'hide' => 
  array (
    '' => 1,
    'it' => 1,
  ),
  'stupid.' => 
  array (
    'He' => 1,
  ),
  'renowned' => 
  array (
    'for' => 1,
  ),
  'clever' => 
  array (
    '' => 1,
    'hyperintelligent' => 1,
  ),
  'hence' => 
  array (
    'the' => 1,
  ),
  'act.' => 
  array (
    'He' => 1,
  ),
  'proffered' => 
  array (
    'people' => 1,
  ),
  'puzzled' => 
  array (
    'rather' => 1,
  ),
  'contemptuous.' => 
  array (
    '' => 1,
  ),
  'stupid,' => 
  array (
    'but' => 1,
  ),
  'argue' => 
  array (
    'about' => 1,
  ),
  'map' => 
  array (
    'on' => 1,
  ),
  'visiscreen' => 
  array (
    'so' => 1,
  ),
  'wanting' => 
  array (
    '' => 1,
  ),
  'There,' => 
  array (
    '-' => 1,
    'what' => 1,
  ),
  'pointed,' => 
  array (
    '-' => 1,
  ),
  'Hey...' => 
  array (
    'Yeah!' => 1,
    'er,' => 1,
    'er...' => 1,
  ),
  'Yeah!' => 
  array (
    '-' => 1,
  ),
  'what?' => 
  array (
    'Parts' => 1,
    '-' => 4,
    'A' => 1,
    'Conkers.' => 1,
  ),
  'Parts' => 
  array (
    'of' => 1,
  ),
  'calmly,' => 
  array (
    '-' => 1,
  ),
  'originally' => 
  array (
    'picked' => 1,
  ),
  'wild.' => 
  array (
    '' => 1,
  ),
  'zapped' => 
  array (
    'straight' => 1,
  ),
  'middle' => 
  array (
    'of' => 2,
  ),
  'Horsehead' => 
  array (
    'Nebula.' => 2,
    'Nebula,' => 1,
  ),
  'Nebula.' => 
  array (
    'How' => 1,
    'One' => 1,
  ),
  'nowhere.' => 
  array (
    'She' => 1,
    'The' => 1,
  ),
  'Drive,' => 
  array (
    '-' => 1,
  ),
  'patiently.' => 
  array (
    '-' => 1,
  ),
  'explained' => 
  array (
    'it' => 1,
    'the' => 1,
    'Zaphod.' => 1,
    'angrily,' => 1,
    '' => 1,
    'my' => 1,
  ),
  'pass' => 
  array (
    'through' => 3,
    '' => 1,
    'me' => 1,
  ),
  'Universe,' => 
  array (
    'you' => 1,
    '' => 1,
    'and' => 2,
  ),
  'Picking' => 
  array (
    'someone' => 1,
  ),
  'from?' => 
  array (
    'That\'s' => 1,
    'You' => 1,
  ),
  'too...' => 
  array (
    'I' => 1,
    'large.' => 1,
  ),
  'Computer!' => 
  array (
    'The' => 2,
    '-' => 5,
  ),
  'Shipboard' => 
  array (
    '' => 1,
  ),
  'Computer' => 
  array (
    '' => 1,
    'console' => 1,
  ),
  'controlled' => 
  array (
    '' => 1,
  ),
  'permeated' => 
  array (
    '' => 1,
  ),
  'particle' => 
  array (
    '' => 1,
    'throughout' => 1,
  ),
  'mode.' => 
  array (
    '-' => 1,
    'After' => 1,
  ),
  'there!' => 
  array (
    '-' => 4,
    'This' => 1,
    'What' => 1,
    'The' => 1,
  ),
  'ribbon' => 
  array (
    'of' => 1,
  ),
  'ticker' => 
  array (
    'tape' => 2,
    'tape).' => 1,
  ),
  'tape' => 
  array (
    'just' => 1,
    'said,' => 1,
    'that\'s' => 1,
  ),
  'record.' => 
  array (
    'The' => 1,
  ),
  'brash' => 
  array (
    '' => 1,
  ),
  'cheery' => 
  array (
    '' => 1,
  ),
  'detergent.' => 
  array (
    '-' => 1,
  ),
  'solve' => 
  array (
    'it.' => 1,
    'their' => 1,
  ),
  'paper.' => 
  array (
    '-' => 1,
  ),
  'Sure' => 
  array (
    'thing,' => 2,
  ),
  'thing,' => 
  array (
    '-' => 2,
    'guys,' => 1,
    'and' => 1,
  ),
  'computer,' => 
  array (
    'spilling' => 1,
    '' => 3,
    '-' => 5,
    'punching' => 1,
    'I' => 1,
    'take' => 1,
    'stamping' => 1,
    'the' => 1,
  ),
  'spilling' => 
  array (
    'out' => 1,
  ),
  'waste' => 
  array (
    'bin' => 1,
  ),
  'bin' => 
  array (
    'at' => 1,
  ),
  'understand.' => 
  array (
    'If' => 1,
  ),
  'want...' => 
  array (
    '-' => 1,
  ),
  'snatching' => 
  array (
    'up' => 1,
  ),
  'console.' => 
  array (
    '-' => 3,
    'Lights' => 1,
  ),
  'OK...' => 
  array (
    '-' => 1,
  ),
  'hurt' => 
  array (
    'tone' => 1,
  ),
  'pored' => 
  array (
    'over' => 1,
  ),
  'figures' => 
  array (
    '' => 3,
    'that' => 1,
    'wandered' => 1,
    'pounded' => 1,
  ),
  'flight' => 
  array (
    'path' => 2,
    'paths' => 1,
  ),
  'path' => 
  array (
    'scanner' => 1,
    'screen.' => 1,
  ),
  'scanner' => 
  array (
    'flashed' => 1,
  ),
  'view' => 
  array (
    'what' => 1,
    'of' => 3,
  ),
  'rescue' => 
  array (
    'was?' => 1,
  ),
  'was?' => 
  array (
    '-' => 1,
  ),
  'constant' => 
  array (
    '-' => 1,
    'bickering' => 1,
  ),
  ',' => 
  array (
    'said' => 1,
  ),
  'high.' => 
  array (
    'They\'re' => 1,
  ),
  'relative' => 
  array (
    'to' => 2,
    'velocity' => 1,
  ),
  'up...' => 
  array (
    'Trillian' => 1,
  ),
  'tow-to-the' => 
  array (
    'powerof-Infinity-minus-one' => 1,
  ),
  'powerof-Infinity-minus-one' => 
  array (
    '' => 1,
  ),
  '(an' => 
  array (
    '' => 1,
    'Antarean' => 1,
  ),
  'meaning' => 
  array (
    'in' => 1,
    'now.' => 1,
    'of' => 1,
    '' => 1,
  ),
  'physics).' => 
  array (
    '-' => 1,
  ),
  '...it\'s' => 
  array (
    'pretty' => 1,
  ),
  'low,' => 
  array (
    '-' => 1,
  ),
  'quizzically.' => 
  array (
    '-' => 1,
  ),
  'whack' => 
  array (
    '' => 1,
  ),
  'accounted' => 
  array (
    '' => 1,
  ),
  'balance' => 
  array (
    '' => 1,
  ),
  'sum.' => 
  array (
    'Zaphod' => 1,
  ),
  'scribbled' => 
  array (
    'a' => 1,
  ),
  'sums,' => 
  array (
    'crossed' => 1,
  ),
  'Bat\'s' => 
  array (
    'dots,' => 1,
  ),
  'dots,' => 
  array (
    'I' => 1,
  ),
  'irritation' => 
  array (
    'and' => 1,
  ),
  'gritted' => 
  array (
    '' => 1,
  ),
  '(ticker' => 
  array (
    'tape,' => 1,
  ),
  'tape,' => 
  array (
    'ticker' => 1,
    '-' => 1,
  ),
  'tape).' => 
  array (
    '' => 1,
  ),
  'nicer' => 
  array (
    'and' => 2,
  ),
  'nicer...' => 
  array (
    '-' => 1,
  ),
  'forecast' => 
  array (
    'based' => 1,
  ),
  'based' => 
  array (
    'on...' => 1,
  ),
  'on...' => 
  array (
    '-' => 1,
  ),
  'data,' => 
  array (
    'yeah.' => 1,
  ),
  'notion.' => 
  array (
    'Did' => 1,
  ),
  'lives' => 
  array (
    'are' => 1,
    'underground.' => 1,
    '' => 1,
  ),
  'governed' => 
  array (
    'by' => 1,
    'the' => 1,
  ),
  'numbers?' => 
  array (
    'A' => 1,
  ),
  'gasped.' => 
  array (
    'She' => 1,
  ),
  'Telephone' => 
  array (
    'number?' => 1,
  ),
  'number?' => 
  array (
    '-' => 1,
    'Numbers' => 1,
  ),
  'Numbers' => 
  array (
    'flashed' => 1,
  ),
  'politely,' => 
  array (
    'but' => 1,
  ),
  'wretched' => 
  array (
    'robot.' => 1,
    'thing' => 1,
  ),
  'robot.' => 
  array (
    'Can' => 1,
  ),
  'monitor' => 
  array (
    'cameras?' => 1,
    'screens.' => 1,
  ),
  'cameras?' => 
  array (
    'Chapter' => 1,
  ),
  13 => 
  array (
    'Marvin' => 1,
  ),
  'corridor,' => 
  array (
    'still' => 1,
    'followed' => 1,
  ),
  'moaning.' => 
  array (
    '-' => 1,
  ),
  'diodes' => 
  array (
    'down' => 1,
  ),
  'side...' => 
  array (
    '-' => 1,
    '' => 1,
  ),
  'No?' => 
  array (
    '-' => 1,
  ),
  'grimly' => 
  array (
    'as' => 1,
  ),
  'Really?' => 
  array (
    '-' => 1,
  ),
  'replaced' => 
  array (
    'but' => 1,
  ),
  'listens.' => 
  array (
    '-' => 1,
  ),
  'imagine.' => 
  array (
    'Vague' => 1,
  ),
  'Vague' => 
  array (
    'whistling' => 1,
  ),
  'whistling' => 
  array (
    'and' => 1,
    'roaring' => 1,
    'the' => 1,
  ),
  'Beeblebrox...' => 
  array (
    'Suddenly' => 1,
  ),
  'stopped,' => 
  array (
    'and' => 2,
    'there' => 1,
    '-' => 1,
  ),
  'hand.' => 
  array (
    '-' => 2,
    '' => 1,
  ),
  'course?' => 
  array (
    '-' => 1,
  ),
  'doors.' => 
  array (
    'There' => 1,
  ),
  'corridor.' => 
  array (
    '' => 1,
  ),
  'eyed' => 
  array (
    'it' => 1,
    'him' => 1,
  ),
  'suspiciously.' => 
  array (
    '-' => 1,
  ),
  'impatiently.' => 
  array (
    '-' => 1,
  ),
  'through?' => 
  array (
    '-' => 2,
  ),
  'entrance' => 
  array (
    'to' => 1,
  ),
  'Probably' => 
  array (
    '' => 1,
  ),
  'demand' => 
  array (
    'that' => 4,
    'admission!' => 1,
    'that.' => 1,
    'is' => 2,
    'solid' => 1,
    '' => 1,
  ),
  'intellectual' => 
  array (
    'capacities' => 1,
  ),
  'capacities' => 
  array (
    'today' => 1,
  ),
  'shouldn\'t' => 
  array (
    'wonder.' => 1,
  ),
  'Slowly,' => 
  array (
    'with' => 1,
    'the' => 1,
    'nervously,' => 1,
  ),
  'loathing,' => 
  array (
    'he' => 1,
  ),
  'hunter' => 
  array (
    'stalking' => 1,
  ),
  'stalking' => 
  array (
    'his' => 1,
  ),
  'prey.' => 
  array (
    'Suddenly' => 1,
  ),
  'happy.' => 
  array (
    'Deep' => 1,
  ),
  'Marvin\'s' => 
  array (
    'thorax' => 1,
    'voice' => 1,
  ),
  'thorax' => 
  array (
    'gears' => 1,
  ),
  'gears' => 
  array (
    'ground.' => 1,
  ),
  'Funny,' => 
  array (
    '-' => 1,
  ),
  'intoned' => 
  array (
    'funerally,' => 1,
    'Deep' => 2,
  ),
  'funerally,' => 
  array (
    '-' => 1,
  ),
  'does.' => 
  array (
    'He' => 1,
    '-' => 1,
    'It\'s' => 1,
  ),
  'shrugging' => 
  array (
    '' => 1,
  ),
  'shoulders.' => 
  array (
    '' => 1,
  ),
  'suppose' => 
  array (
    'you' => 1,
    '' => 1,
    'I\'d' => 1,
    'there\'s' => 1,
  ),
  'rust,' => 
  array (
    'or' => 1,
  ),
  'standing?' => 
  array (
    '-' => 1,
  ),
  'Marvin?' => 
  array (
    '-' => 1,
  ),
  'laughing.' => 
  array (
    '-' => 1,
  ),
  'What\'s...?' => 
  array (
    '-' => 1,
  ),
  'Shhh,' => 
  array (
    '-' => 2,
  ),
  'chair' => 
  array (
    'with' => 1,
    'which' => 1,
    'and' => 1,
  ),
  'console' => 
  array (
    '' => 1,
    'with' => 1,
    'was' => 1,
    'blotched' => 1,
  ),
  'picking' => 
  array (
    '' => 1,
  ),
  'teeth' => 
  array (
    'in' => 1,
    'picked.' => 1,
    'with' => 1,
  ),
  'right-hand' => 
  array (
    'head' => 2,
    '' => 1,
  ),
  'preoccupied' => 
  array (
    'with' => 1,
  ),
  'task,' => 
  array (
    'but' => 1,
    'O' => 1,
  ),
  'left-hand' => 
  array (
    '' => 1,
  ),
  'broad,' => 
  array (
    'relaxed,' => 1,
  ),
  'relaxed,' => 
  array (
    'nonchalant' => 1,
  ),
  'nonchalant' => 
  array (
    'grin.' => 1,
  ),
  'large.' => 
  array (
    '' => 1,
    'We' => 1,
  ),
  'jaw' => 
  array (
    '' => 1,
  ),
  'flapped' => 
  array (
    'about' => 1,
  ),
  'loose' => 
  array (
    'end' => 1,
  ),
  'while.' => 
  array (
    'The' => 1,
    'For' => 1,
  ),
  'peculiar' => 
  array (
    'man' => 1,
    'arrival,' => 1,
    '' => 1,
  ),
  'lazy' => 
  array (
    'wave' => 1,
  ),
  'appalling' => 
  array (
    'affectation' => 1,
    'mess' => 1,
    'surface' => 1,
  ),
  'affectation' => 
  array (
    'of' => 1,
  ),
  'nonchalance' => 
  array (
    'said,' => 1,
  ),
  'hi,' => 
  array (
    'how' => 1,
  ),
  'Glad' => 
  array (
    'you' => 1,
  ),
  'outcooled.' => 
  array (
    '-' => 1,
  ),
  'drawled,' => 
  array (
    '-' => 1,
  ),
  'suits' => 
  array (
    'you.' => 1,
  ),
  'goggled' => 
  array (
    'at' => 1,
  ),
  'guy?' => 
  array (
    '-' => 1,
  ),
  'Know' => 
  array (
    'him!' => 1,
  ),
  'him!' => 
  array (
    '-' => 1,
  ),
  'he\'s...' => 
  array (
    '-' => 1,
  ),
  'paused,' => 
  array (
    'and' => 2,
    '' => 1,
  ),
  'introductions' => 
  array (
    'the' => 1,
  ),
  'casually,' => 
  array (
    'said' => 1,
  ),
  '"hi"' => 
  array (
    'and' => 1,
  ),
  'picked.' => 
  array (
    'Ford' => 1,
  ),
  'semi-cousin' => 
  array (
    'Zaphod' => 1,
    'that' => 1,
  ),
  'Beeb...' => 
  array (
    '-' => 1,
  ),
  'met,' => 
  array (
    '-' => 1,
    '' => 1,
  ),
  'sharply.' => 
  array (
    'When' => 1,
    '-' => 3,
    'He' => 1,
  ),
  'lane' => 
  array (
    '' => 1,
  ),
  'change' => 
  array (
    'down' => 1,
    'of' => 1,
  ),
  'fourth' => 
  array (
    'to' => 1,
  ),
  'thus' => 
  array (
    'making' => 1,
    'was' => 1,
    'were' => 1,
  ),
  'engine' => 
  array (
    'leap' => 1,
  ),
  'bonnet' => 
  array (
    '' => 1,
  ),
  'mess,' => 
  array (
    'it' => 1,
    '' => 1,
  ),
  'tends' => 
  array (
    'to' => 1,
    '' => 1,
  ),
  'stride' => 
  array (
    'in' => 1,
  ),
  'remark' => 
  array (
    'threw' => 1,
    'would' => 1,
  ),
  'his.' => 
  array (
    '-' => 1,
  ),
  'Err...' => 
  array (
    'what?' => 1,
  ),
  'we\'ve' => 
  array (
    'met.' => 1,
    'got' => 5,
    '' => 1,
  ),
  'met.' => 
  array (
    'Zaphod' => 1,
    '-' => 1,
  ),
  'awkward' => 
  array (
    'start' => 1,
    'hunched' => 1,
    'silence.' => 1,
    'silence' => 1,
  ),
  'surprise' => 
  array (
    'and' => 1,
  ),
  'gum' => 
  array (
    'sharply.' => 1,
  ),
  'rounded' => 
  array (
    'on' => 1,
  ),
  'flash' => 
  array (
    'in' => 1,
    'of' => 1,
    'came' => 1,
  ),
  'resent' => 
  array (
    '' => 1,
  ),
  'lumbered' => 
  array (
    'himself' => 1,
  ),
  'ignorant' => 
  array (
    'primitive' => 1,
  ),
  'Ilford-based' => 
  array (
    'gnat' => 1,
  ),
  'Peking.' => 
  array (
    '-' => 1,
  ),
  'met?' => 
  array (
    '' => 1,
  ),
  'demanded.' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'Martin' => 
  array (
    '' => 1,
  ),
  'Smith' => 
  array (
    '' => 1,
  ),
  'Croydon.' => 
  array (
    '-' => 1,
  ),
  'care,' => 
  array (
    '-' => 1,
  ),
  'coldly.' => 
  array (
    'We\'ve' => 1,
  ),
  'say...' => 
  array (
    'Phil?' => 1,
  ),
  'Phil?' => 
  array (
    '-' => 1,
  ),
  'What!' => 
  array (
    '-' => 2,
  ),
  'remind' => 
  array (
    'me,' => 1,
  ),
  'species.' => 
  array (
    '-' => 1,
  ),
  'Cool' => 
  array (
    'it' => 1,
  ),
  'demanded' => 
  array (
    'Ford.' => 1,
    'Arthur.' => 2,
    'conkers.' => 1,
    'Trillian.' => 1,
  ),
  'deterred.' => 
  array (
    '-' => 1,
  ),
  'ago.' => 
  array (
    'On' => 1,
  ),
  'Earth...' => 
  array (
    'England...' => 1,
    '-' => 1,
  ),
  'England...' => 
  array (
    'Zaphod' => 1,
  ),
  'tight-lipped' => 
  array (
    'smile.' => 1,
  ),
  'London,' => 
  array (
    '-' => 1,
  ),
  'Islington.' => 
  array (
    '-' => 1,
  ),
  'guilty' => 
  array (
    'start,' => 1,
  ),
  'start,' => 
  array (
    '-' => 1,
  ),
  'party.' => 
  array (
    'This' => 1,
  ),
  'not,' => 
  array (
    '-' => 3,
    'I' => 1,
  ),
  'breezily.' => 
  array (
    '-' => 1,
  ),
  'somewhere...' => 
  array (
    '-' => 1,
  ),
  'years!' => 
  array (
    '-' => 1,
  ),
  'Looking' => 
  array (
    'about,' => 1,
    'up' => 1,
  ),
  'gatecrashed' => 
  array (
    'a' => 1,
  ),
  'persisted' => 
  array (
    'Arthur,' => 2,
  ),
  'trembling' => 
  array (
    'with' => 1,
  ),
  'anger,' => 
  array (
    '-' => 1,
  ),
  'fancy' => 
  array (
    'dress' => 1,
  ),
  'party...' => 
  array (
    '-' => 1,
  ),
  'girl...' => 
  array (
    'oh' => 1,
  ),
  'smoke' => 
  array (
    'anyway...' => 1,
    'that' => 1,
    '' => 1,
  ),
  'anyway...' => 
  array (
    '-' => 1,
  ),
  'sulking' => 
  array (
    'about' => 1,
    'machine.' => 1,
  ),
  'lady?' => 
  array (
    '-' => 1,
  ),
  'somebody.' => 
  array (
    'Well' => 1,
  ),
  'evening.' => 
  array (
    'Hell,' => 1,
  ),
  'Beautiful,' => 
  array (
    'charming,' => 1,
  ),
  'charming,' => 
  array (
    'devastatingly' => 1,
    '' => 1,
  ),
  'devastatingly' => 
  array (
    'intelligent,' => 1,
  ),
  'intelligent,' => 
  array (
    'at' => 1,
    'and' => 1,
  ),
  'plying' => 
  array (
    'her' => 1,
  ),
  'yours' => 
  array (
    'barges' => 1,
  ),
  'barges' => 
  array (
    'up' => 1,
  ),
  'doll,' => 
  array (
    'is' => 1,
  ),
  'boring' => 
  array (
    'you?' => 1,
  ),
  'instead?' => 
  array (
    'I\'m' => 1,
    'They' => 1,
  ),
  'Zaphod?' => 
  array (
    '-' => 2,
  ),
  'glaring' => 
  array (
    'at' => 1,
  ),
  'foolish.' => 
  array (
    '-' => 1,
  ),
  'Phil,' => 
  array (
    'but...' => 1,
  ),
  'admit' => 
  array (
    'he' => 1,
    'that' => 1,
  ),
  'wandering' => 
  array (
    'into' => 1,
  ),
  'sight' => 
  array (
    'at' => 1,
    'behind' => 1,
    '' => 1,
  ),
  'ton' => 
  array (
    'of' => 1,
  ),
  'seconds,' => 
  array (
    'and' => 1,
    '-' => 1,
    'guys...' => 1,
    'it\'s' => 1,
  ),
  'mess' => 
  array (
    'of' => 2,
  ),
  'words.' => 
  array (
    '-' => 1,
  ),
  'Tricia' => 
  array (
    'McMillian?' => 1,
  ),
  'McMillian?' => 
  array (
    '-' => 1,
  ),
  'Same' => 
  array (
    'as' => 1,
  ),
  'lift.' => 
  array (
    '' => 1,
  ),
  'degree' => 
  array (
    'in' => 1,
  ),
  'Maths' => 
  array (
    'and' => 1,
  ),
  'astrophysics' => 
  array (
    'what' => 1,
  ),
  'dole' => 
  array (
    'queue' => 1,
  ),
  'Monday.' => 
  array (
    '-' => 1,
  ),
  'Infinity' => 
  array (
    'minus' => 1,
    '' => 1,
  ),
  'sum' => 
  array (
    'now' => 1,
  ),
  'complete.' => 
  array (
    'Zaphod' => 1,
  ),
  'drive?' => 
  array (
    '-' => 1,
  ),
  'probably,' => 
  array (
    'I\'m' => 1,
  ),
  'afraid,' => 
  array (
    '-' => 1,
    'guys,' => 1,
  ),
  14 => 
  array (
    'The' => 1,
  ),
  'fled' => 
  array (
    'on' => 1,
  ),
  'photon' => 
  array (
    'drive.' => 1,
    'is' => 1,
  ),
  'drive.' => 
  array (
    'Its' => 1,
  ),
  'crew' => 
  array (
    'of' => 1,
    '' => 1,
    'were' => 1,
    'sustained' => 1,
    'is' => 1,
    'to' => 1,
    'as' => 1,
    'was' => 1,
  ),
  'knowing' => 
  array (
    '' => 1,
    'you' => 1,
    'what' => 1,
  ),
  'volition' => 
  array (
    '' => 1,
  ),
  'physics' => 
  array (
    '' => 1,
  ),
  'relationships' => 
  array (
    'between' => 2,
  ),
  'susceptible' => 
  array (
    '' => 1,
  ),
  'molecules.' => 
  array (
    'As' => 1,
  ),
  'artificial' => 
  array (
    'night' => 1,
    'dinosaur' => 1,
  ),
  'grateful' => 
  array (
    '' => 1,
  ),
  'retire' => 
  array (
    'to' => 1,
  ),
  'cabins' => 
  array (
    'and' => 1,
  ),
  'rationalize' => 
  array (
    'their' => 1,
  ),
  'thoughts.' => 
  array (
    'Trillian' => 1,
  ),
  'sleep.' => 
  array (
    'She' => 1,
    'He' => 2,
    'In' => 1,
    '-' => 1,
  ),
  'couch' => 
  array (
    'and' => 1,
  ),
  'cage' => 
  array (
    'which' => 1,
    'and' => 1,
    'of' => 2,
  ),
  'contained' => 
  array (
    'her' => 1,
  ),
  'links' => 
  array (
    'with' => 1,
  ),
  'mice' => 
  array (
    'that' => 1,
    'scurrying' => 1,
    'have' => 1,
    'were' => 2,
    'would' => 1,
    'and' => 1,
    'will' => 1,
    'on' => 1,
    'sitting' => 1,
    'I' => 1,
    'scuttled' => 1,
    'bristled.' => 1,
    'old' => 1,
    '' => 1,
    'sniffed' => 1,
  ),
  'bring.' => 
  array (
    'She' => 1,
  ),
  'expected' => 
  array (
    '' => 1,
  ),
  'disturbed' => 
  array (
    'by' => 2,
    'only' => 1,
  ),
  'negative' => 
  array (
    '' => 1,
  ),
  'reaction' => 
  array (
    '' => 1,
  ),
  'destruction.' => 
  array (
    'It' => 1,
    '-' => 2,
  ),
  'unreal' => 
  array (
    'and' => 1,
  ),
  'scurrying' => 
  array (
    'round' => 1,
  ),
  'treadwheels' => 
  array (
    '' => 1,
  ),
  'charted' => 
  array (
    'the' => 1,
  ),
  'progress' => 
  array (
    'through' => 1,
  ),
  'vague' => 
  array (
    'nagging' => 1,
    '' => 1,
  ),
  'nagging' => 
  array (
    'feeling' => 1,
    'little' => 1,
  ),
  're-awakened' => 
  array (
    'by' => 1,
  ),
  'Somehow' => 
  array (
    'it' => 1,
  ),
  'conform' => 
  array (
    '' => 1,
  ),
  'see.' => 
  array (
    'Ford' => 2,
    '-' => 3,
  ),
  'excited' => 
  array (
    'about' => 2,
    'people.' => 1,
    'children.' => 1,
  ),
  'imprisonment' => 
  array (
    'were' => 1,
  ),
  'over,' => 
  array (
    '' => 1,
    'and' => 1,
  ),
  'Knocking' => 
  array (
    'about' => 1,
  ),
  'promised' => 
  array (
    'to' => 1,
  ),
  'faintly' => 
  array (
    'odd' => 1,
    'irritated' => 1,
  ),
  'frankly' => 
  array (
    'astonishing,' => 1,
    'gives' => 1,
  ),
  'astonishing,' => 
  array (
    'as' => 1,
  ),
  'manner' => 
  array (
    'of' => 1,
    'disconcerting.' => 1,
  ),
  'post.' => 
  array (
    'Was' => 1,
  ),
  'Was' => 
  array (
    'there' => 1,
    'it?' => 1,
  ),
  'all:' => 
  array (
    'he' => 1,
  ),
  'unfathomably' => 
  array (
    'into' => 1,
  ),
  'attacked' => 
  array (
    'everything' => 1,
    'once' => 1,
  ),
  'genius' => 
  array (
    '' => 1,
  ),
  'naive' => 
  array (
    'incompetence' => 1,
  ),
  'incompetence' => 
  array (
    'and' => 1,
  ),
  'which.' => 
  array (
    'Arthur' => 1,
  ),
  'slept:' => 
  array (
    'he' => 1,
  ),
  'tired.' => 
  array (
    'There' => 1,
  ),
  'tap' => 
  array (
    'at' => 1,
  ),
  'Zaphod...?' => 
  array (
    '-' => 1,
  ),
  'keyboard.' => 
  array (
    'He' => 1,
  ),
  'compose' => 
  array (
    'a' => 1,
  ),
  'vitriolic' => 
  array (
    'enough' => 1,
  ),
  'robe' => 
  array (
    'round' => 1,
  ),
  'instruments.' => 
  array (
    '-' => 2,
  ),
  'See?' => 
  array (
    'The' => 1,
  ),
  'orbit,' => 
  array (
    '-' => 1,
  ),
  'saying.' => 
  array (
    '' => 1,
  ),
  'coordinates' => 
  array (
    'you' => 1,
    '' => 1,
  ),
  'predicted.' => 
  array (
    'Zaphod' => 1,
  ),
  'hissed.' => 
  array (
    '-' => 1,
  ),
  'series' => 
  array (
    'of' => 3,
  ),
  'recognize' => 
  array (
    'those' => 1,
    'that' => 1,
  ),
  'coordinates?' => 
  array (
    '-' => 1,
  ),
  'No.' => 
  array (
    '-' => 6,
    'Never' => 1,
    'That\'s' => 1,
    'They' => 1,
  ),
  'clue.' => 
  array (
    'Computer!' => 1,
  ),
  'gang!' => 
  array (
    '-' => 1,
  ),
  'enthused' => 
  array (
    'the' => 2,
  ),
  'sociable' => 
  array (
    'isn\'t' => 1,
  ),
  'screens.' => 
  array (
    'Light' => 1,
    'There' => 1,
    '' => 1,
  ),
  'sank.' => 
  array (
    '' => 1,
  ),
  'Pinpoints' => 
  array (
    '' => 1,
  ),
  'consoles' => 
  array (
    'and' => 1,
    'sprang' => 1,
  ),
  'pairs' => 
  array (
    '' => 1,
  ),
  'external' => 
  array (
    'monitor' => 1,
    'computer' => 1,
  ),
  'Recognize' => 
  array (
    'that?' => 1,
    'it?' => 1,
  ),
  'see?' => 
  array (
    '-' => 1,
  ),
  'cloud.' => 
  array (
    '-' => 1,
  ),
  'blank' => 
  array (
    'screen?' => 1,
  ),
  'screen?' => 
  array (
    '-' => 1,
  ),
  'nebula' => 
  array (
    'is' => 1,
    'it' => 1,
  ),
  'childishly' => 
  array (
    'so.' => 1,
  ),
  'much!' => 
  array (
    '-' => 1,
  ),
  'cloud?' => 
  array (
    '-' => 1,
  ),
  'stars?' => 
  array (
    'No' => 1,
  ),
  'planets?' => 
  array (
    '-' => 1,
  ),
  'rotate' => 
  array (
    '' => 1,
  ),
  'angle' => 
  array (
    '' => 1,
    'between' => 1,
  ),
  'vision' => 
  array (
    '' => 1,
  ),
  'oneeighty' => 
  array (
    'degrees' => 1,
  ),
  'degrees' => 
  array (
    'and' => 2,
    'starboard.' => 1,
    'of' => 1,
  ),
  'happening,' => 
  array (
    'then' => 1,
  ),
  'brightness' => 
  array (
    'glowed' => 1,
  ),
  'glowed' => 
  array (
    'at' => 1,
  ),
  'plate' => 
  array (
    'crept' => 1,
  ),
  'crept' => 
  array (
    'across' => 2,
    'up' => 1,
    'imperceptibly' => 1,
    'over' => 1,
  ),
  'binary' => 
  array (
    '' => 1,
    'sunrise' => 1,
  ),
  'sliced' => 
  array (
    'into' => 1,
  ),
  'glare' => 
  array (
    'shading' => 1,
    'at' => 1,
  ),
  'shading' => 
  array (
    'away' => 1,
  ),
  'black,' => 
  array (
    'the' => 1,
  ),
  'thumping' => 
  array (
    'the' => 1,
  ),
  'That...' => 
  array (
    '-' => 1,
  ),
  15 => 
  array (
    '(Excerpt' => 1,
  ),
  '(Excerpt' => 
  array (
    'from' => 1,
  ),
  'Page' => 
  array (
    '' => 1,
  ),
  '634784,' => 
  array (
    'Section' => 1,
  ),
  '5a,' => 
  array (
    'Entry:' => 1,
  ),
  'Entry:' => 
  array (
    'Magrathea)' => 1,
  ),
  'Magrathea)' => 
  array (
    'Far' => 1,
  ),
  'mists' => 
  array (
    'of' => 1,
    'swirled' => 1,
  ),
  'days' => 
  array (
    'of' => 2,
    'spirits' => 1,
  ),
  'former' => 
  array (
    'Galactic' => 2,
  ),
  'Empire,' => 
  array (
    'life' => 1,
  ),
  'wild,' => 
  array (
    'rich' => 1,
  ),
  'tax' => 
  array (
    'free.' => 1,
    'exile,' => 1,
    'before' => 1,
  ),
  'free.' => 
  array (
    'Mighty' => 1,
  ),
  'Mighty' => 
  array (
    '' => 1,
  ),
  'starships' => 
  array (
    '' => 1,
  ),
  'plied' => 
  array (
    '' => 1,
  ),
  'suns,' => 
  array (
    '' => 1,
  ),
  'seeking' => 
  array (
    'adventure' => 1,
  ),
  'adventure' => 
  array (
    'and' => 1,
  ),
  'reward' => 
  array (
    'amongst' => 1,
  ),
  'amongst' => 
  array (
    'the' => 2,
  ),
  'spirits' => 
  array (
    'were' => 1,
  ),
  'brave,' => 
  array (
    'the' => 1,
  ),
  'stakes' => 
  array (
    'were' => 1,
  ),
  'high,' => 
  array (
    'men' => 1,
  ),
  'women' => 
  array (
    'were' => 1,
    'standing' => 1,
    '' => 1,
  ),
  'women,' => 
  array (
    'and' => 1,
  ),
  'Centauri.' => 
  array (
    'And' => 1,
  ),
  'dared' => 
  array (
    '' => 1,
  ),
  'unknown' => 
  array (
    'terrors,' => 1,
  ),
  'terrors,' => 
  array (
    'to' => 1,
  ),
  'deeds,' => 
  array (
    'to' => 1,
  ),
  'boldly' => 
  array (
    'split' => 1,
  ),
  'infinitives' => 
  array (
    '' => 1,
  ),
  'Empire' => 
  array (
    'forged.' => 1,
    'collapsed,' => 1,
    'stored' => 1,
  ),
  'forged.' => 
  array (
    'Many' => 1,
  ),
  'extremely' => 
  array (
    '' => 1,
    'fortunate' => 1,
    'odd.' => 1,
  ),
  'rich,' => 
  array (
    '' => 1,
  ),
  'ashamed' => 
  array (
    'of' => 1,
  ),
  'speaking' => 
  array (
    '' => 1,
  ),
  'richest' => 
  array (
    '' => 1,
    'men' => 1,
    'planet' => 1,
  ),
  'merchants' => 
  array (
    'life' => 1,
  ),
  'niggly,' => 
  array (
    '' => 1,
  ),
  'imagine' => 
  array (
    'that' => 1,
  ),
  'fault' => 
  array (
    '' => 1,
  ),
  'worlds' => 
  array (
    'they\'d' => 1,
  ),
  'satisfactory:' => 
  array (
    '' => 1,
  ),
  'climate' => 
  array (
    'wasn\'t' => 1,
  ),
  'afternoon,' => 
  array (
    'or' => 1,
  ),
  'pink.' => 
  array (
    'And' => 1,
  ),
  'created' => 
  array (
    'the' => 2,
  ),
  'conditions' => 
  array (
    'for' => 1,
    'are' => 1,
  ),
  'industry:' => 
  array (
    'custom-made' => 1,
  ),
  'custom-made' => 
  array (
    'luxury' => 1,
    'planets' => 1,
  ),
  'luxury' => 
  array (
    'planet' => 1,
    'commodity' => 1,
  ),
  'building.' => 
  array (
    'The' => 1,
  ),
  'industry' => 
  array (
    'was' => 1,
  ),
  'Magrathea,' => 
  array (
    '' => 1,
    '-' => 1,
    'and' => 1,
  ),
  'sucked' => 
  array (
    'matter' => 1,
  ),
  'holes' => 
  array (
    'in' => 1,
  ),
  'planets,' => 
  array (
    'platinum' => 1,
    'soft' => 1,
  ),
  'platinum' => 
  array (
    'planets,' => 1,
  ),
  'earthquakes' => 
  array (
    '' => 1,
  ),
  'lovingly' => 
  array (
    'made' => 1,
  ),
  'exacting' => 
  array (
    'standards' => 1,
  ),
  'standards' => 
  array (
    'that' => 1,
  ),
  'venture' => 
  array (
    'that' => 1,
  ),
  'Magrathea' => 
  array (
    'itself' => 2,
    '' => 3,
    'from' => 1,
    'nonsense' => 1,
    'is' => 2,
    'thanks' => 1,
    'which' => 1,
    '-' => 1,
    'Arthur' => 1,
    'awakes.' => 1,
    'can' => 1,
    'by' => 1,
  ),
  'reduced' => 
  array (
    '' => 1,
  ),
  'poverty.' => 
  array (
    'And' => 1,
  ),
  'collapsed,' => 
  array (
    'and' => 2,
  ),
  'sullen' => 
  array (
    'silence' => 1,
  ),
  'worlds,' => 
  array (
    'disturbed' => 1,
  ),
  'pen' => 
  array (
    'scratchings' => 1,
  ),
  'scratchings' => 
  array (
    'of' => 1,
  ),
  'scholars' => 
  array (
    'as' => 1,
  ),
  'laboured' => 
  array (
    '' => 1,
  ),
  'smug' => 
  array (
    'little' => 1,
  ),
  'treaties' => 
  array (
    'on' => 1,
  ),
  'planned' => 
  array (
    'political' => 1,
  ),
  'economy.' => 
  array (
    'Magrathea' => 1,
  ),
  'disappeared' => 
  array (
    'and' => 1,
    'again.' => 2,
    'from' => 1,
  ),
  'obscurity' => 
  array (
    'of' => 1,
  ),
  'legend.' => 
  array (
    'In' => 1,
  ),
  'enlightened' => 
  array (
    'days' => 1,
    'liberal' => 1,
  ),
  'believes' => 
  array (
    'a' => 1,
    'in.' => 1,
  ),
  16 => 
  array (
    'Arthur' => 1,
  ),
  'awoke' => 
  array (
    'to' => 1,
  ),
  'crazy,' => 
  array (
    'Zaphod,' => 1,
    'right?' => 1,
  ),
  'myth,' => 
  array (
    '' => 1,
  ),
  'fairy' => 
  array (
    'story,' => 1,
  ),
  'story,' => 
  array (
    'it\'s' => 1,
  ),
  'grow' => 
  array (
    'up' => 1,
    'from' => 1,
  ),
  'economists,' => 
  array (
    'it\'s...' => 1,
  ),
  'it\'s...' => 
  array (
    '-' => 1,
  ),
  'currently' => 
  array (
    '' => 2,
    'converging' => 1,
    'one' => 1,
    'plunged' => 1,
  ),
  'orbit' => 
  array (
    '' => 2,
    'at' => 1,
    'round' => 1,
  ),
  'personally' => 
  array (
    'be' => 1,
  ),
  'ship...' => 
  array (
    '-' => 1,
  ),
  'Eddie' => 
  array (
    'your' => 1,
    'if' => 1,
    'wailed.' => 1,
    'sternly.' => 1,
    '' => 1,
    'after' => 1,
  ),
  'shipboard' => 
  array (
    'computer,' => 1,
  ),
  'bundle' => 
  array (
    'of' => 1,
  ),
  'kicks' => 
  array (
    'out' => 1,
  ),
  'programme' => 
  array (
    'you' => 1,
    'will' => 1,
    'like' => 1,
  ),
  'inquiringly' => 
  array (
    'at' => 1,
  ),
  'motioned' => 
  array (
    'him' => 2,
  ),
  'Computer,' => 
  array (
    '' => 3,
    '-' => 1,
  ),
  'trajectory' => 
  array (
    'is.' => 1,
    '' => 1,
  ),
  'feller,' => 
  array (
    '-' => 1,
  ),
  'burbled,' => 
  array (
    '-' => 1,
  ),
  'altitude' => 
  array (
    'of' => 1,
  ),
  'legendary' => 
  array (
    '' => 1,
    'Magrathea.' => 1,
  ),
  'Magrathea.' => 
  array (
    '-' => 3,
    'The' => 2,
    'He' => 1,
    'Not' => 1,
    '' => 1,
  ),
  'Proving' => 
  array (
    'nothing,' => 1,
  ),
  'weight.' => 
  array (
    '-' => 1,
  ),
  'punching' => 
  array (
    '' => 1,
  ),
  'tickertape.' => 
  array (
    '-' => 1,
  ),
  'problems' => 
  array (
    '' => 3,
    'connected' => 1,
    'of' => 1,
    'on' => 2,
  ),
  'decimal' => 
  array (
    'places' => 1,
  ),
  'places' => 
  array (
    'if' => 1,
  ),
  'help.' => 
  array (
    'Trillian' => 1,
  ),
  'interrupted.' => 
  array (
    '-' => 1,
  ),
  'swinging' => 
  array (
    '' => 1,
  ),
  'daylight' => 
  array (
    'side' => 1,
  ),
  'adding,' => 
  array (
    '-' => 1,
  ),
  'turns' => 
  array (
    'out' => 1,
  ),
  'predicted' => 
  array (
    '' => 1,
  ),
  'anyone,' => 
  array (
    'it\'s' => 1,
  ),
  'lump' => 
  array (
    'of' => 2,
  ),
  'Dawn\'s' => 
  array (
    'coming' => 1,
  ),
  'let\'s' => 
  array (
    'at' => 1,
    'call' => 2,
    '' => 1,
  ),
  'I...' => 
  array (
    '-' => 1,
    'er...' => 1,
  ),
  'featureless' => 
  array (
    'mass' => 1,
  ),
  'mass' => 
  array (
    'once' => 1,
  ),
  'silence,' => 
  array (
    'but' => 1,
    '' => 1,
  ),
  'fidgety' => 
  array (
    '' => 1,
  ),
  'traversing' => 
  array (
    'the' => 1,
  ),
  'us...' => 
  array (
    '-' => 1,
    '' => 1,
  ),
  'restore' => 
  array (
    'a' => 1,
  ),
  'occasion' => 
  array (
    '' => 1,
  ),
  'Magrathea!' => 
  array (
    'He' => 1,
    '-' => 1,
  ),
  'piqued' => 
  array (
    '' => 1,
  ),
  'sceptical' => 
  array (
    'reaction.' => 1,
  ),
  'seasoned' => 
  array (
    '' => 1,
  ),
  'tramp' => 
  array (
    '' => 1,
  ),
  'shiver' => 
  array (
    'at' => 1,
  ),
  'spectacular' => 
  array (
    'drama' => 1,
  ),
  'drama' => 
  array (
    'of' => 1,
  ),
  'sunrise' => 
  array (
    'seen' => 1,
    'is' => 1,
  ),
  'stabbed' => 
  array (
    'a' => 1,
  ),
  'blinding' => 
  array (
    '' => 1,
  ),
  'sideways' => 
  array (
    '' => 1,
  ),
  'blade,' => 
  array (
    'and' => 1,
  ),
  'suns' => 
  array (
    '' => 2,
    'blazed' => 1,
    'now' => 1,
    'set' => 1,
  ),
  'visible,' => 
  array (
    '' => 1,
    'and' => 1,
  ),
  'furnaces' => 
  array (
    '' => 1,
  ),
  'searing' => 
  array (
    'the' => 1,
  ),
  'horizon' => 
  array (
    'with' => 1,
    '' => 1,
  ),
  'fire.' => 
  array (
    '' => 1,
  ),
  'Fierce' => 
  array (
    '' => 1,
  ),
  'shafts' => 
  array (
    '' => 1,
  ),
  'streaked' => 
  array (
    'through' => 1,
    'along' => 1,
  ),
  'atmosphere' => 
  array (
    'beneath' => 1,
    'and' => 2,
    'towards' => 1,
    'was' => 1,
    'of' => 1,
  ),
  'dawn!..' => 
  array (
    '' => 1,
  ),
  'twin' => 
  array (
    '' => 1,
  ),
  'Soulianis' => 
  array (
    'and' => 2,
  ),
  'Rahm!..' => 
  array (
    '-' => 1,
  ),
  'whatever,' => 
  array (
    '-' => 1,
  ),
  'quietly.' => 
  array (
    '-' => 4,
    'This' => 1,
  ),
  'Rahm!' => 
  array (
    '-' => 1,
  ),
  'blazed' => 
  array (
    'into' => 1,
  ),
  'ghostly' => 
  array (
    '' => 1,
  ),
  'bridge:' => 
  array (
    'Marvin' => 1,
  ),
  'ironically' => 
  array (
    'because' => 1,
  ),
  'humans' => 
  array (
    'so' => 1,
    '' => 1,
  ),
  'gazed' => 
  array (
    'at' => 2,
    '' => 1,
    'levelly' => 1,
  ),
  'spectacle' => 
  array (
    'of' => 1,
  ),
  'burnt' => 
  array (
    'inside' => 1,
    '' => 1,
  ),
  'irritated' => 
  array (
    'him' => 1,
  ),
  'impose' => 
  array (
    'some' => 1,
  ),
  'ludicrous' => 
  array (
    'fantasy' => 1,
  ),
  'fantasy' => 
  array (
    'on' => 1,
  ),
  'scene' => 
  array (
    'to' => 1,
    'vanished' => 1,
    'around' => 1,
  ),
  'nonsense' => 
  array (
    'seemed' => 1,
  ),
  'juvenile.' => 
  array (
    'Isn\'t' => 1,
  ),
  'fairies' => 
  array (
    'at' => 1,
  ),
  'too?' => 
  array (
    'All' => 1,
  ),
  'edged' => 
  array (
    'up' => 1,
  ),
  'whispered.' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'Apparently' => 
  array (
    'Magrathea' => 1,
  ),
  'legend' => 
  array (
    'from' => 1,
  ),
  'Bit' => 
  array (
    'like' => 1,
    '' => 1,
  ),
  'Atlantis' => 
  array (
    'on' => 1,
  ),
  'legends' => 
  array (
    '' => 1,
  ),
  'Magratheans' => 
  array (
    'used' => 1,
    '' => 1,
  ),
  'manufacture' => 
  array (
    'planets.' => 1,
  ),
  'missing' => 
  array (
    '' => 1,
  ),
  'tea' => 
  array (
    'on' => 1,
  ),
  'spaceship?' => 
  array (
    '-' => 1,
  ),
  'unfolding' => 
  array (
    'beneath' => 1,
  ),
  'orbital' => 
  array (
    'path.' => 1,
  ),
  'pyrotechnics' => 
  array (
    'of' => 1,
  ),
  'dawn' => 
  array (
    'were' => 1,
  ),
  'bleak' => 
  array (
    'and' => 1,
  ),
  'forbidding' => 
  array (
    'in' => 1,
  ),
  'common' => 
  array (
    'light' => 1,
  ),
  'grey,' => 
  array (
    '' => 1,
    'bits' => 1,
  ),
  'contoured.' => 
  array (
    'It' => 1,
  ),
  'crypt.' => 
  array (
    '' => 1,
  ),
  'promising' => 
  array (
    'features' => 1,
  ),
  'appear' => 
  array (
    'on' => 1,
  ),
  'ravines,' => 
  array (
    '' => 1,
  ),
  'mountains,' => 
  array (
    'maybe' => 1,
  ),
  'cities' => 
  array (
    '-' => 1,
  ),
  'approached' => 
  array (
    '' => 1,
    'the' => 1,
    'it,' => 1,
  ),
  'lines' => 
  array (
    '' => 1,
  ),
  'soften' => 
  array (
    'and' => 1,
  ),
  'blur' => 
  array (
    'into' => 1,
    'that' => 1,
    'of' => 1,
  ),
  'anonymity' => 
  array (
    'and' => 1,
  ),
  'transpire.' => 
  array (
    '' => 1,
  ),
  'blurred' => 
  array (
    'by' => 1,
  ),
  'movement' => 
  array (
    'of' => 2,
    'out' => 1,
    'Zaphod' => 1,
  ),
  'stagnant' => 
  array (
    'air' => 1,
  ),
  'century' => 
  array (
    'upon' => 1,
    'or' => 1,
  ),
  'upon' => 
  array (
    'century.' => 1,
    '' => 2,
    'us,' => 1,
  ),
  'century.' => 
  array (
    'Clearly,' => 1,
  ),
  'Clearly,' => 
  array (
    'it' => 1,
  ),
  'old.' => 
  array (
    'A' => 1,
    'It' => 1,
  ),
  'grey' => 
  array (
    'landscape' => 1,
    'robe.' => 1,
    'lights' => 1,
  ),
  'landscape' => 
  array (
    '' => 2,
    'on' => 1,
  ),
  'immensity' => 
  array (
    'of' => 1,
  ),
  'presence.' => 
  array (
    'He' => 1,
  ),
  'supposing' => 
  array (
    'it' => 1,
    'there\'s' => 1,
    'this' => 1,
    '' => 1,
  ),
  'isn\'t,' => 
  array (
    '-' => 1,
  ),
  'anyway?' => 
  array (
    'There\'s' => 1,
  ),
  'surface,' => 
  array (
    '-' => 1,
  ),
  'industrial' => 
  array (
    'archaeology' => 1,
  ),
  'archaeology' => 
  array (
    'of' => 1,
  ),
  'after?' => 
  array (
    'One' => 1,
  ),
  'at,' => 
  array (
    'but' => 1,
    '-' => 1,
    'were' => 1,
    'yeah?' => 1,
  ),
  'airily,' => 
  array (
    '-' => 1,
  ),
  'curiosity,' => 
  array (
    '' => 1,
  ),
  'adventure,' => 
  array (
    'but' => 1,
  ),
  'fame' => 
  array (
    'and' => 1,
  ),
  'money...' => 
  array (
    'Ford' => 1,
  ),
  'faintest' => 
  array (
    'idea' => 1,
  ),
  'shivering.' => 
  array (
    '-' => 1,
  ),
  'notice,' => 
  array (
    '-' => 1,
  ),
  'wealth' => 
  array (
    '' => 1,
    'were' => 1,
  ),
  'stored' => 
  array (
    'on' => 1,
    'there' => 1,
  ),
  'afford' => 
  array (
    '' => 1,
    'our' => 1,
  ),
  'frumpy.' => 
  array (
    'Bullshit,' => 1,
  ),
  'Bullshit,' => 
  array (
    'thought' => 1,
  ),
  'civilization' => 
  array (
    '' => 1,
    'could' => 1,
  ),
  'dust,' => 
  array (
    '' => 1,
  ),
  'exceedingly' => 
  array (
    'unlikely' => 1,
  ),
  'things,' => 
  array (
    'there' => 1,
  ),
  'treasures' => 
  array (
    '' => 1,
  ),
  'suspense' => 
  array (
    'is' => 1,
    'since' => 1,
  ),
  'killing' => 
  array (
    'me,' => 1,
  ),
  'testily.' => 
  array (
    'Stress' => 1,
  ),
  'Stress' => 
  array (
    'and' => 1,
  ),
  'tension' => 
  array (
    'are' => 1,
    'was' => 1,
  ),
  'exacerbated' => 
  array (
    'that' => 1,
  ),
  'facts' => 
  array (
    'will' => 1,
  ),
  'revealed' => 
  array (
    '' => 1,
    'in' => 1,
    'him' => 1,
  ),
  'advance.' => 
  array (
    'The' => 1,
  ),
  'deadly' => 
  array (
    'missile' => 1,
    'nuclear' => 1,
  ),
  'missile' => 
  array (
    'attack' => 1,
  ),
  'attack' => 
  array (
    '' => 1,
    'of' => 2,
    'on' => 1,
  ),
  'shortly' => 
  array (
    '' => 1,
    'before' => 1,
  ),
  'launched' => 
  array (
    '' => 1,
  ),
  'automatic' => 
  array (
    'defence' => 1,
    'system,' => 1,
  ),
  'defence' => 
  array (
    'system' => 1,
    'shields' => 1,
    'stations!' => 1,
  ),
  'result' => 
  array (
    '' => 2,
    'that' => 1,
    'of' => 1,
  ),
  'breakage' => 
  array (
    '' => 1,
  ),
  'micecage,' => 
  array (
    'the' => 1,
  ),
  'bruising' => 
  array (
    'of' => 1,
  ),
  'somebody\'s' => 
  array (
    'upper' => 1,
  ),
  'upper' => 
  array (
    'arm,' => 1,
    '' => 2,
  ),
  'untimely' => 
  array (
    'creation' => 1,
  ),
  'demise' => 
  array (
    'of' => 1,
  ),
  'bowl' => 
  array (
    'of' => 5,
  ),
  'petunias' => 
  array (
    'and' => 2,
    'as' => 1,
    '' => 1,
  ),
  'innocent' => 
  array (
    'sperm' => 1,
    'creature' => 1,
  ),
  'sperm' => 
  array (
    'whale.' => 1,
    'whale' => 1,
    '' => 1,
  ),
  'whale.' => 
  array (
    'In' => 1,
  ),
  'mystery' => 
  array (
    'should' => 1,
  ),
  'preserved,' => 
  array (
    '' => 1,
  ),
  'revelation' => 
  array (
    'will' => 1,
  ),
  'concerning' => 
  array (
    '' => 1,
  ),
  'sustained' => 
  array (
    '' => 1,
    'a' => 1,
    'horrific' => 1,
  ),
  'bruise.' => 
  array (
    'This' => 1,
  ),
  'safely' => 
  array (
    'be' => 1,
  ),
  17 => 
  array (
    'After' => 1,
  ),
  'shaky' => 
  array (
    'start' => 1,
  ),
  'reassemble' => 
  array (
    'itself' => 1,
  ),
  'shellshocked' => 
  array (
    'fragments' => 1,
  ),
  'fragments' => 
  array (
    '' => 2,
  ),
  'previous' => 
  array (
    '' => 1,
  ),
  'Nutri-Matic' => 
  array (
    'machine' => 1,
    '' => 1,
  ),
  'provided' => 
  array (
    '' => 1,
  ),
  'almost,' => 
  array (
    '' => 2,
  ),
  'quite,' => 
  array (
    'entirely' => 1,
    '' => 1,
  ),
  'functioned' => 
  array (
    'was' => 1,
  ),
  'interesting.' => 
  array (
    'When' => 1,
  ),
  'instant' => 
  array (
    '' => 1,
    'as' => 1,
    'he' => 1,
  ),
  'detailed' => 
  array (
    'examination' => 1,
  ),
  'examination' => 
  array (
    'of' => 1,
    'revealed' => 1,
  ),
  'subject\'s' => 
  array (
    'taste' => 1,
    'metabolism' => 1,
    'brain' => 1,
  ),
  'taste' => 
  array (
    'buds,' => 1,
    'centres' => 1,
  ),
  'buds,' => 
  array (
    'a' => 1,
  ),
  'spectroscopic' => 
  array (
    'analysis' => 1,
  ),
  'analysis' => 
  array (
    '' => 1,
  ),
  'metabolism' => 
  array (
    'and' => 1,
  ),
  'experimental' => 
  array (
    '' => 1,
  ),
  'neural' => 
  array (
    'pathways' => 1,
  ),
  'pathways' => 
  array (
    'to' => 1,
  ),
  'cupful' => 
  array (
    'of' => 1,
  ),
  'manufactured' => 
  array (
    '' => 1,
  ),
  'complaints' => 
  array (
    'department' => 1,
  ),
  'covers' => 
  array (
    'all' => 1,
  ),
  'masses' => 
  array (
    'of' => 1,
  ),
  'Tau' => 
  array (
    'Star' => 1,
  ),
  'drank' => 
  array (
    'the' => 1,
  ),
  'reviving.' => 
  array (
    'He' => 1,
  ),
  'barren' => 
  array (
    '' => 2,
    'dust' => 1,
  ),
  'greyness' => 
  array (
    'slide' => 1,
  ),
  'slide' => 
  array (
    'past.' => 1,
    'rule.' => 1,
  ),
  'past.' => 
  array (
    'It' => 1,
  ),
  'safe?' => 
  array (
    '-' => 1,
  ),
  'Magrathea\'s' => 
  array (
    'been' => 1,
  ),
  'ghosts' => 
  array (
    '' => 1,
  ),
  'families' => 
  array (
    'by' => 1,
    'were' => 1,
  ),
  'thrilled' => 
  array (
    'suddenly' => 1,
  ),
  'fanfare;' => 
  array (
    '' => 1,
  ),
  'hollow,' => 
  array (
    'reedy,' => 1,
    'reedy' => 1,
  ),
  'reedy,' => 
  array (
    'insubstantial' => 1,
  ),
  'insubstantial' => 
  array (
    'sound.' => 1,
  ),
  'preceded' => 
  array (
    'a' => 1,
  ),
  'reedy' => 
  array (
    'and' => 1,
  ),
  'insubstantial.' => 
  array (
    'The' => 1,
  ),
  'Greetings' => 
  array (
    'to' => 1,
  ),
  'five-million-year-old' => 
  array (
    'tape' => 1,
  ),
  'broadcast' => 
  array (
    '' => 1,
  ),
  'us.' => 
  array (
    '-' => 1,
    'Arthur' => 1,
    'This' => 1,
    '' => 1,
  ),
  'recording?' => 
  array (
    '-' => 1,
  ),
  'carrying' => 
  array (
    'on.' => 1,
  ),
  'courteous,' => 
  array (
    'almost' => 1,
  ),
  'underscored' => 
  array (
    'with' => 1,
  ),
  'unmistakable' => 
  array (
    'menace.' => 1,
  ),
  'menace.' => 
  array (
    '-' => 1,
  ),
  'recorded' => 
  array (
    'announcement,' => 1,
    'message.' => 1,
    '' => 1,
  ),
  'announcement,' => 
  array (
    '-' => 1,
  ),
  'commercial' => 
  array (
    'council' => 1,
  ),
  'esteemed' => 
  array (
    'visit...' => 1,
  ),
  'visit...' => 
  array (
    '("A' => 1,
  ),
  '("A' => 
  array (
    'voice' => 1,
  ),
  'Magrathea!"' => 
  array (
    'shouted' => 1,
  ),
  '"OK,' => 
  array (
    '' => 1,
  ),
  'OK,"' => 
  array (
    '' => 1,
  ),
  'Ford.)' => 
  array (
    '-' => 1,
  ),
  '...but' => 
  array (
    'regrets,' => 1,
  ),
  'regrets,' => 
  array (
    '-' => 1,
  ),
  'contacted,' => 
  array (
    '' => 1,
  ),
  'kindly' => 
  array (
    'speak' => 1,
    'manner' => 1,
  ),
  'tone.' => 
  array (
    'A' => 1,
  ),
  'followed,' => 
  array (
    'then' => 1,
  ),
  'rid' => 
  array (
    'of' => 1,
  ),
  'us,' => 
  array (
    '-' => 3,
    'get' => 1,
    'said' => 1,
    '' => 1,
    'so' => 1,
  ),
  'recording,' => 
  array (
    '-' => 1,
  ),
  'Got' => 
  array (
    '' => 1,
  ),
  'computer?' => 
  array (
    '-' => 2,
  ),
  'waited.' => 
  array (
    'After' => 2,
    '-' => 2,
    'Suddenly' => 1,
  ),
  'fanfare' => 
  array (
    'once' => 1,
    'was' => 1,
  ),
  'assure' => 
  array (
    'you' => 1,
    '' => 1,
  ),
  'resumed' => 
  array (
    'announcements' => 1,
  ),
  'announcements' => 
  array (
    'will' => 1,
  ),
  'fashionable' => 
  array (
    '' => 1,
    'and' => 1,
  ),
  'magazines' => 
  array (
    '' => 1,
  ),
  'supplements,' => 
  array (
    'when' => 1,
  ),
  'clients' => 
  array (
    'will' => 1,
    'for' => 1,
    'from' => 1,
  ),
  'select' => 
  array (
    '' => 1,
  ),
  'contemporary' => 
  array (
    'geography.' => 1,
  ),
  'geography.' => 
  array (
    '-' => 1,
  ),
  'menace' => 
  array (
    'in' => 1,
  ),
  'sharper' => 
  array (
    'edge.' => 1,
  ),
  'edge.' => 
  array (
    '-' => 1,
  ),
  'Meanwhile' => 
  array (
    'we' => 1,
  ),
  'leave.' => 
  array (
    'Now.' => 1,
  ),
  'companions.' => 
  array (
    '-' => 1,
  ),
  'suggested.' => 
  array (
    '-' => 1,
  ),
  'Shhh!' => 
  array (
    '-' => 1,
  ),
  'tense?' => 
  array (
    '-' => 1,
  ),
  'interested!' => 
  array (
    '-' => 1,
  ),
  'descent' => 
  array (
    'into' => 1,
  ),
  'landing.' => 
  array (
    'This' => 1,
  ),
  'perfunctory,' => 
  array (
    '' => 1,
  ),
  'distinctly' => 
  array (
    'cold.' => 1,
    'designed' => 1,
  ),
  'cold.' => 
  array (
    '-' => 1,
    'Zaphod' => 1,
  ),
  'gratifying,' => 
  array (
    '-' => 1,
  ),
  'enthusiasm' => 
  array (
    '' => 1,
  ),
  'continues' => 
  array (
    'unabated,' => 1,
  ),
  'unabated,' => 
  array (
    'and' => 1,
  ),
  'guided' => 
  array (
    'missiles' => 1,
  ),
  'missiles' => 
  array (
    'currently' => 1,
    '' => 1,
    'do' => 1,
    'again.' => 1,
    'loomed' => 1,
    'banked' => 1,
  ),
  'converging' => 
  array (
    'with' => 1,
    'tunnels.' => 1,
  ),
  'enthusiastic' => 
  array (
    'clients,' => 1,
    'about' => 1,
  ),
  'clients,' => 
  array (
    'and' => 1,
  ),
  'armed' => 
  array (
    'nuclear' => 1,
    'than' => 1,
  ),
  'nuclear' => 
  array (
    'warheads' => 1,
    'missiles' => 1,
  ),
  'warheads' => 
  array (
    'are' => 1,
  ),
  'courtesy' => 
  array (
    '' => 1,
  ),
  'detail.' => 
  array (
    '' => 1,
  ),
  'custom' => 
  array (
    'in' => 1,
  ),
  'lives...' => 
  array (
    'thank' => 1,
  ),
  'heads?' => 
  array (
    'That\'s' => 1,
  ),
  'millions' => 
  array (
    'of' => 1,
    '' => 1,
    'later,' => 1,
  ),
  'apply' => 
  array (
    '' => 1,
  ),
  'missiles?' => 
  array (
    '-' => 2,
  ),
  'Missiles?' => 
  array (
    'Don\'t' => 1,
  ),
  'rear' => 
  array (
    '' => 1,
  ),
  'Clear' => 
  array (
    'in' => 1,
  ),
  'darts' => 
  array (
    'were' => 1,
  ),
  'magnification' => 
  array (
    '' => 1,
  ),
  'focus' => 
  array (
    '-' => 1,
    'on' => 1,
  ),
  'rockets' => 
  array (
    'thundering' => 1,
  ),
  'thundering' => 
  array (
    'through' => 1,
  ),
  'suddenness' => 
  array (
    'of' => 1,
  ),
  'shocking.' => 
  array (
    '-' => 1,
  ),
  'applying' => 
  array (
    '' => 1,
  ),
  'terrific!' => 
  array (
    '-' => 1,
  ),
  'kill' => 
  array (
    'us!' => 1,
    'a' => 1,
  ),
  'us!' => 
  array (
    '-' => 3,
    'There' => 1,
    'Suddenly' => 1,
  ),
  'Terrific,' => 
  array (
    '-' => 1,
  ),
  'means?' => 
  array (
    '-' => 1,
  ),
  'something!' => 
  array (
    '-' => 1,
    'Perhaps' => 1,
  ),
  'Second' => 
  array (
    'by' => 1,
  ),
  'image' => 
  array (
    'of' => 1,
    '' => 1,
    'appeared' => 1,
  ),
  'larger.' => 
  array (
    'They' => 1,
  ),
  'homing' => 
  array (
    'course' => 1,
  ),
  'warheads,' => 
  array (
    'head' => 1,
  ),
  'cool,' => 
  array (
    '-' => 1,
  ),
  'all?' => 
  array (
    '-' => 1,
  ),
  'to...' => 
  array (
    'er...' => 1,
    '-' => 1,
  ),
  'evasive' => 
  array (
    'action!' => 1,
    '' => 1,
  ),
  'action!' => 
  array (
    '-' => 1,
  ),
  'access' => 
  array (
    'of' => 1,
  ),
  'panic.' => 
  array (
    '-' => 1,
  ),
  'action' => 
  array (
    '' => 1,
  ),
  'take?' => 
  array (
    '-' => 1,
  ),
  '...or' => 
  array (
    'something,' => 1,
  ),
  '...er...' => 
  array (
    '-' => 1,
  ),
  'jamming' => 
  array (
    'my' => 1,
  ),
  'brightly,' => 
  array (
    '-' => 1,
  ),
  'forty-five' => 
  array (
    'seconds.' => 1,
  ),
  'decisive' => 
  array (
    '' => 1,
  ),
  'directions' => 
  array (
    'simultaneously.' => 1,
  ),
  'simultaneously.' => 
  array (
    '-' => 2,
    '' => 1,
    'He' => 1,
  ),
  'Right!' => 
  array (
    '-' => 2,
  ),
  'manual' => 
  array (
    'control' => 2,
  ),
  'fly' => 
  array (
    'her?' => 1,
    'another' => 1,
  ),
  'her?' => 
  array (
    '-' => 1,
  ),
  'pleasantly.' => 
  array (
    '-' => 1,
  ),
  'relaxing.' => 
  array (
    '-' => 1,
  ),
  'either,' => 
  array (
    '-' => 1,
  ),
  'assert' => 
  array (
    'himself.' => 1,
  ),
  'guessed' => 
  array (
    'that,' => 1,
    '(quite' => 1,
  ),
  'OK' => 
  array (
    'computer,' => 1,
    'Beeblebrox,' => 1,
    'baby,' => 1,
  ),
  'Several' => 
  array (
    'large' => 1,
    'tunnels' => 1,
  ),
  'desk' => 
  array (
    'panels' => 1,
    '' => 1,
    'was' => 1,
  ),
  'showering' => 
  array (
    '' => 1,
  ),
  'expanded' => 
  array (
    'polystyrene' => 1,
  ),
  'polystyrene' => 
  array (
    'packaging' => 1,
  ),
  'packaging' => 
  array (
    'and' => 1,
  ),
  'balls' => 
  array (
    'of' => 1,
  ),
  'rolled-up' => 
  array (
    '' => 1,
  ),
  'cellophane:' => 
  array (
    '' => 1,
  ),
  'retro' => 
  array (
    'thrust' => 1,
  ),
  'thrust' => 
  array (
    'and' => 1,
  ),
  'starboard.' => 
  array (
    'Or' => 1,
  ),
  'something...' => 
  array (
    '-' => 2,
  ),
  'luck' => 
  array (
    'guys,' => 1,
  ),
  'chirped' => 
  array (
    '' => 1,
  ),
  'seconds...' => 
  array (
    'Ford' => 1,
  ),
  'immediate' => 
  array (
    'sense' => 1,
  ),
  'those.' => 
  array (
    '' => 1,
  ),
  'rocked' => 
  array (
    'jets' => 1,
  ),
  'jets' => 
  array (
    'tried' => 1,
  ),
  'push' => 
  array (
    'it' => 1,
  ),
  'released' => 
  array (
    'half' => 1,
  ),
  'arc' => 
  array (
    '' => 1,
    'and' => 1,
  ),
  'come,' => 
  array (
    'straight' => 1,
    'presumably' => 1,
  ),
  'oncoming' => 
  array (
    'missiles.' => 1,
  ),
  'missiles.' => 
  array (
    'Air' => 1,
  ),
  'Air' => 
  array (
    'cushions' => 1,
  ),
  'cushions' => 
  array (
    'ballooned' => 1,
  ),
  'ballooned' => 
  array (
    'out' => 1,
  ),
  'inertial' => 
  array (
    '' => 1,
  ),
  'flattened' => 
  array (
    'and' => 1,
    '' => 1,
    'out' => 1,
  ),
  'squirming' => 
  array (
    'for' => 1,
    'like' => 1,
  ),
  'breath,' => 
  array (
    'unable' => 1,
    'Vroomfondel' => 1,
  ),
  'move.' => 
  array (
    'Zaphod' => 1,
  ),
  'desperation' => 
  array (
    'and' => 1,
  ),
  'savage' => 
  array (
    'kick' => 1,
  ),
  'lever' => 
  array (
    'that' => 1,
    'snapped' => 1,
  ),
  'sharply' => 
  array (
    'and' => 1,
    '' => 1,
    'round' => 1,
    'armed' => 1,
  ),
  'rocketed' => 
  array (
    'upwards.' => 1,
    'them' => 1,
  ),
  'hurled' => 
  array (
    'violently' => 1,
    'itself' => 1,
    '' => 1,
  ),
  'section' => 
  array (
    '' => 2,
    'in' => 1,
    '8A.' => 1,
    'of' => 1,
  ),
  'combined' => 
  array (
    'result' => 1,
  ),
  'guide' => 
  array (
    'started' => 1,
    'your' => 1,
  ),
  'listen' => 
  array (
    'about' => 1,
    'to' => 1,
    'good!' => 1,
  ),
  'ways' => 
  array (
    '' => 1,
  ),
  'smuggling' => 
  array (
    '' => 1,
  ),
  'Antarean' => 
  array (
    'parakeet' => 1,
    '' => 1,
  ),
  'parakeet' => 
  array (
    'glands' => 1,
    '' => 1,
  ),
  'glands' => 
  array (
    'out' => 1,
  ),
  'Antares' => 
  array (
    '(an' => 1,
  ),
  'gland' => 
  array (
    '' => 1,
  ),
  'revolting' => 
  array (
    'but' => 1,
  ),
  'cocktail' => 
  array (
    '' => 1,
  ),
  'delicacy' => 
  array (
    '' => 1,
  ),
  'sums' => 
  array (
    'of' => 1,
  ),
  'idiots' => 
  array (
    '' => 1,
  ),
  'impress' => 
  array (
    'other' => 1,
  ),
  'idiots),' => 
  array (
    'and' => 1,
  ),
  'stone.' => 
  array (
    'It' => 1,
  ),
  'bruise' => 
  array (
    'to' => 1,
  ),
  'emphasized' => 
  array (
    'because,' => 1,
  ),
  'because,' => 
  array (
    'as' => 1,
  ),
  'revealed,' => 
  array (
    'they' => 1,
  ),
  'otherwise' => 
  array (
    '' => 1,
    'known' => 1,
  ),
  'unharmed' => 
  array (
    'and' => 1,
  ),
  'safety' => 
  array (
    'of' => 1,
  ),
  'assured.' => 
  array (
    '-' => 1,
  ),
  'Impact' => 
  array (
    'minus' => 2,
  ),
  'dive' => 
  array (
    '' => 1,
  ),
  'sing.' => 
  array (
    '-' => 1,
  ),
  'storm...' => 
  array (
    '-' => 2,
  ),
  'whined' => 
  array (
    'nasally,' => 1,
  ),
  'nasally,' => 
  array (
    '-' => 1,
  ),
  'high...' => 
  array (
    'Zaphod' => 1,
  ),
  'din' => 
  array (
    'of' => 1,
  ),
  'assumed' => 
  array (
    'was' => 1,
    '' => 1,
  ),
  'don\'t...' => 
  array (
    'be' => 1,
  ),
  'afraid...' => 
  array (
    'of' => 1,
  ),
  'dark!' => 
  array (
    '-' => 1,
  ),
  'wailed.' => 
  array (
    'The' => 1,
  ),
  'flattening' => 
  array (
    'out' => 1,
  ),
  'upside' => 
  array (
    'down' => 1,
  ),
  'systems.' => 
  array (
    '-' => 1,
  ),
  'crooned' => 
  array (
    'Eddie.' => 1,
  ),
  'Eddie.' => 
  array (
    'The' => 1,
    'A' => 1,
    'Arthur' => 1,
    '' => 1,
  ),
  '...is' => 
  array (
    'a' => 1,
    'Slartibartfast.' => 1,
  ),
  'sky...' => 
  array (
    'But' => 1,
  ),
  'corrected' => 
  array (
    'their' => 1,
  ),
  'paths' => 
  array (
    'to' => 1,
  ),
  'erratically' => 
  array (
    'weaving' => 1,
  ),
  'weaving' => 
  array (
    'ship,' => 1,
    'their' => 1,
  ),
  'songs' => 
  array (
    '' => 1,
  ),
  'lark...' => 
  array (
    '' => 1,
  ),
  'fellas...' => 
  array (
    'Walk' => 1,
  ),
  'Walk' => 
  array (
    'on' => 2,
    'on,' => 1,
  ),
  'wind...' => 
  array (
    'The' => 1,
  ),
  'screeching' => 
  array (
    'arc' => 1,
  ),
  'pursuit.' => 
  array (
    '-' => 1,
  ),
  'definitely' => 
  array (
    'going' => 1,
    '' => 1,
    'is' => 1,
  ),
  'rain...' => 
  array (
    '-' => 1,
  ),
  'crazy?' => 
  array (
    '-' => 2,
  ),
  'Without' => 
  array (
    '' => 1,
  ),
  'proper' => 
  array (
    '' => 1,
  ),
  'programming' => 
  array (
    'anything' => 1,
  ),
  'happen.' => 
  array (
    '-' => 1,
    'Ford' => 1,
  ),
  'stage?' => 
  array (
    '-' => 1,
  ),
  'dreams' => 
  array (
    'be' => 1,
  ),
  'blown...' => 
  array (
    '-' => 1,
  ),
  'moulded' => 
  array (
    'contouring' => 1,
    'into' => 1,
  ),
  'contouring' => 
  array (
    'where' => 1,
  ),
  'heart...' => 
  array (
    '-' => 1,
  ),
  'Drive?' => 
  array (
    '-' => 1,
  ),
  'alone...' => 
  array (
    'Impact' => 1,
  ),
  'bless...' => 
  array (
    'You\'ll' => 1,
  ),
  'ne...' => 
  array (
    'ver...' => 1,
  ),
  'ver...' => 
  array (
    'walk...' => 1,
  ),
  'walk...' => 
  array (
    'alone!' => 1,
  ),
  'alone!' => 
  array (
    '-' => 1,
  ),
  'mid-mangling' => 
  array (
    '' => 1,
  ),
  'explosion' => 
  array (
    '' => 1,
    'in' => 1,
  ),
  18 => 
  array (
    'And' => 1,
  ),
  'normally' => 
  array (
    '' => 1,
  ),
  'fetchingly' => 
  array (
    'redesigned' => 1,
  ),
  'redesigned' => 
  array (
    'interior.' => 1,
  ),
  'interior.' => 
  array (
    'It' => 1,
  ),
  'somewhat' => 
  array (
    'larger,' => 1,
    'the' => 1,
  ),
  'larger,' => 
  array (
    '' => 1,
  ),
  'delicate' => 
  array (
    'pastel' => 1,
    'traceries' => 1,
  ),
  'pastel' => 
  array (
    'shades' => 1,
  ),
  'shades' => 
  array (
    'of' => 2,
  ),
  'blue.' => 
  array (
    'In' => 1,
  ),
  'centre' => 
  array (
    'a' => 1,
    'lay' => 1,
  ),
  'staircase,' => 
  array (
    'leading' => 1,
    'a' => 1,
  ),
  'spray' => 
  array (
    'of' => 1,
  ),
  'ferns' => 
  array (
    'and' => 1,
  ),
  'flowers' => 
  array (
    '' => 1,
  ),
  'stone' => 
  array (
    'sundial' => 1,
  ),
  'sundial' => 
  array (
    'pedestal' => 1,
  ),
  'pedestal' => 
  array (
    'housed' => 1,
  ),
  'housed' => 
  array (
    '' => 1,
  ),
  'terminal.' => 
  array (
    'Cunningly' => 1,
  ),
  'Cunningly' => 
  array (
    'deployed' => 1,
  ),
  'deployed' => 
  array (
    'lighting' => 1,
    '' => 1,
  ),
  'lighting' => 
  array (
    'and' => 1,
    'was' => 1,
  ),
  'mirrors' => 
  array (
    'created' => 1,
    '' => 1,
    'showed' => 1,
  ),
  'illusion' => 
  array (
    '' => 1,
  ),
  'conservatory' => 
  array (
    'overlooking' => 1,
    'area' => 1,
  ),
  'overlooking' => 
  array (
    'a' => 1,
  ),
  'exquisitely' => 
  array (
    '' => 1,
  ),
  'manicured' => 
  array (
    'garden.' => 1,
  ),
  'garden.' => 
  array (
    'Around' => 1,
  ),
  'Around' => 
  array (
    'the' => 1,
  ),
  'periphery' => 
  array (
    'of' => 1,
  ),
  'marble-topped' => 
  array (
    'tables' => 1,
  ),
  'tables' => 
  array (
    'on' => 1,
    'screaming' => 1,
    'and' => 2,
  ),
  'intricately' => 
  array (
    'beautiful' => 1,
  ),
  'wrought-iron' => 
  array (
    'legs.' => 1,
  ),
  'legs.' => 
  array (
    'As' => 1,
  ),
  'marble' => 
  array (
    '' => 1,
  ),
  'touched' => 
  array (
    'them' => 1,
    'a' => 2,
  ),
  'materialized' => 
  array (
    '' => 1,
  ),
  'correct' => 
  array (
    'angles' => 1,
  ),
  'data' => 
  array (
    'readouts,' => 1,
    'banks' => 1,
    'banks.' => 1,
    '' => 1,
    'process' => 1,
    'bank' => 1,
  ),
  'readouts,' => 
  array (
    'though' => 1,
  ),
  'from.' => 
  array (
    'It' => 1,
  ),
  'sensationally' => 
  array (
    'beautiful.' => 1,
  ),
  'Relaxing' => 
  array (
    'in' => 1,
  ),
  'wickerwork' => 
  array (
    'sun' => 1,
  ),
  'chair,' => 
  array (
    'Zaphod' => 1,
  ),
  'happened?' => 
  array (
    '-' => 3,
  ),
  'lounging' => 
  array (
    '' => 1,
  ),
  'pool,' => 
  array (
    '-' => 1,
  ),
  'here...' => 
  array (
    '-' => 1,
  ),
  'potted' => 
  array (
    'plant' => 1,
  ),
  'plant' => 
  array (
    'there' => 1,
  ),
  'chilled' => 
  array (
    'Pan' => 1,
  ),
  'Exactly' => 
  array (
    'where' => 1,
  ),
  'think...' => 
  array (
    '-' => 1,
  ),
  'blighted' => 
  array (
    '' => 1,
    'landscape' => 1,
    'land.' => 1,
  ),
  'scooted' => 
  array (
    'along' => 1,
  ),
  'astounding' => 
  array (
    'image' => 1,
  ),
  'mirrors.' => 
  array (
    '-' => 1,
  ),
  'appear,' => 
  array (
    '-' => 1,
  ),
  'doubtfully,' => 
  array (
    '-' => 1,
  ),
  'whale...' => 
  array (
    '-' => 1,
  ),
  'Factor,' => 
  array (
    '-' => 1,
  ),
  'Eddie,' => 
  array (
    'who' => 1,
    'shocked,' => 1,
  ),
  'changed' => 
  array (
    '' => 1,
  ),
  'Earthman?' => 
  array (
    '-' => 2,
    'You' => 1,
  ),
  'was...' => 
  array (
    '-' => 1,
  ),
  'Turn' => 
  array (
    'on' => 1,
  ),
  'activating' => 
  array (
    'the' => 1,
  ),
  'proofing' => 
  array (
    'screens.' => 1,
  ),
  'kid' => 
  array (
    '' => 1,
    'he\'d' => 1,
  ),
  'lives,' => 
  array (
    'you' => 1,
    '' => 1,
  ),
  'then.' => 
  array (
    '' => 1,
    '-' => 1,
    'Quite' => 1,
  ),
  'But...' => 
  array (
    '-' => 2,
  ),
  'forgotten' => 
  array (
    '' => 1,
  ),
  'whale' => 
  array (
    'had' => 1,
    'before' => 1,
    'any' => 1,
    '' => 2,
  ),
  'tenable' => 
  array (
    'position' => 1,
  ),
  'position' => 
  array (
    'for' => 1,
    'you' => 1,
  ),
  'whale,' => 
  array (
    '' => 1,
  ),
  'identity' => 
  array (
    'as' => 1,
  ),
  'Ah!..' => 
  array (
    'What\'s' => 1,
  ),
  'Calm' => 
  array (
    'down,' => 1,
  ),
  'oh!' => 
  array (
    'this' => 1,
  ),
  'sensation,' => 
  array (
    'what' => 1,
  ),
  'yawning,' => 
  array (
    'tingling' => 1,
  ),
  'tingling' => 
  array (
    'sensation' => 1,
  ),
  'my...' => 
  array (
    '' => 1,
    'well' => 1,
  ),
  'names' => 
  array (
    'for' => 1,
    'were' => 1,
  ),
  'headway' => 
  array (
    'in' => 1,
  ),
  'shall' => 
  array (
    'call' => 2,
    'zap' => 1,
    '' => 1,
    'take' => 1,
    'design' => 1,
    'name' => 1,
    'be' => 1,
    'probably' => 1,
    'we' => 1,
  ),
  'stomach.' => 
  array (
    'Good.' => 1,
  ),
  'Good.' => 
  array (
    'Ooooh,' => 1,
  ),
  'Ooooh,' => 
  array (
    'it\'s' => 1,
  ),
  'strong.' => 
  array (
    'And' => 1,
  ),
  'hey,' => 
  array (
    '' => 1,
    'this' => 1,
    'why' => 1,
  ),
  'roaring' => 
  array (
    'sound' => 1,
  ),
  'head?' => 
  array (
    'Perhaps' => 1,
  ),
  'wind!' => 
  array (
    'Is' => 1,
  ),
  'name?' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'It\'ll' => 
  array (
    '' => 1,
    'all' => 1,
    'take' => 1,
  ),
  'do...' => 
  array (
    'perhaps' => 1,
  ),
  'certainly' => 
  array (
    'seems' => 1,
    'being' => 1,
  ),
  'Hey!' => 
  array (
    'What\'s' => 2,
    'I' => 1,
  ),
  'This...' => 
  array (
    '' => 1,
  ),
  'tail' => 
  array (
    '-' => 1,
  ),
  'tail.' => 
  array (
    'Hey!' => 1,
  ),
  'thrash' => 
  array (
    'it' => 1,
  ),
  'Wow!' => 
  array (
    'Wow!' => 1,
    'That' => 1,
  ),
  'feels' => 
  array (
    'great!' => 1,
  ),
  'great!' => 
  array (
    'Doesn\'t' => 1,
  ),
  'achieve' => 
  array (
    '' => 1,
  ),
  'coherent' => 
  array (
    'picture' => 1,
  ),
  'exciting,' => 
  array (
    'so' => 1,
  ),
  'dizzy' => 
  array (
    'with' => 1,
  ),
  'anticipation...' => 
  array (
    'Or' => 1,
  ),
  'wind?' => 
  array (
    'There' => 1,
  ),
  'wow!' => 
  array (
    'Hey!' => 1,
  ),
  'fast?' => 
  array (
    'Very' => 1,
  ),
  'round,' => 
  array (
    'it' => 1,
  ),
  'like...' => 
  array (
    'ow...' => 1,
    'it\'s' => 1,
  ),
  'ow...' => 
  array (
    'ound...' => 1,
  ),
  'ound...' => 
  array (
    'round...' => 1,
  ),
  'round...' => 
  array (
    'ground!' => 1,
  ),
  'ground!' => 
  array (
    'That\'s' => 1,
    'I' => 1,
  ),
  'thud,' => 
  array (
    'was' => 1,
  ),
  'speculated' => 
  array (
    'that' => 1,
  ),
  19 => 
  array (
    '-' => 1,
  ),
  'distaste' => 
  array (
    'at' => 1,
  ),
  'posture' => 
  array (
    '' => 1,
  ),
  'palm' => 
  array (
    'tree.' => 1,
    'tree' => 1,
  ),
  'tree.' => 
  array (
    'Zaphod' => 1,
  ),
  'mirror' => 
  array (
    '' => 1,
  ),
  'presented' => 
  array (
    '' => 1,
  ),
  'panoramic' => 
  array (
    'view' => 1,
  ),
  'landed.' => 
  array (
    '-' => 1,
  ),
  'Paranoid' => 
  array (
    'Android,' => 1,
  ),
  'Android,' => 
  array (
    '-' => 1,
  ),
  'manically' => 
  array (
    'depressed' => 3,
  ),
  'depressed' => 
  array (
    'robot?' => 2,
    '' => 1,
    'robot' => 1,
  ),
  'robot?' => 
  array (
    '-' => 1,
    'No,' => 1,
  ),
  'problems,' => 
  array (
    '' => 1,
  ),
  'addressing' => 
  array (
    'a' => 1,
    'the' => 2,
  ),
  'coffin,' => 
  array (
    '-' => 1,
  ),
  'answer.' => 
  array (
    'It' => 1,
    'But,' => 1,
    'I' => 1,
    'Why?' => 1,
    'They' => 1,
    '-' => 1,
  ),
  'headache' => 
  array (
    'just' => 1,
  ),
  'level.' => 
  array (
    'Trillian' => 1,
  ),
  'escaped!' => 
  array (
    '-' => 1,
  ),
  'An' => 
  array (
    'expression' => 1,
    'icy' => 1,
    'underground' => 1,
    '' => 2,
    'automatic' => 1,
    'awesome' => 1,
    'answer' => 1,
  ),
  'concern' => 
  array (
    'failed' => 1,
  ),
  'Nuts' => 
  array (
    'to' => 1,
  ),
  'mice,' => 
  array (
    '-' => 1,
    '' => 1,
  ),
  'commanded' => 
  array (
    'greater' => 1,
  ),
  'greater' => 
  array (
    'attention' => 1,
    'analyst' => 1,
  ),
  'independent' => 
  array (
    'observers)' => 1,
  ),
  'observers)' => 
  array (
    'the' => 1,
  ),
  'second.' => 
  array (
    '-' => 1,
  ),
  'boys.' => 
  array (
    'The' => 1,
  ),
  'familiar,' => 
  array (
    '' => 1,
  ),
  'different.' => 
  array (
    '' => 1,
  ),
  'matriarchal' => 
  array (
    'twang.' => 1,
  ),
  'twang.' => 
  array (
    'It' => 1,
  ),
  'puzzlement.' => 
  array (
    '-' => 1,
  ),
  'emergency' => 
  array (
    'back-up' => 1,
  ),
  'back-up' => 
  array (
    'personality' => 1,
    'of' => 1,
  ),
  'Eddie\'s' => 
  array (
    'new' => 1,
  ),
  'warm,' => 
  array (
    'and' => 1,
  ),
  'playing' => 
  array (
    'with' => 1,
  ),
  'naughty' => 
  array (
    'bug-eyed' => 1,
  ),
  'monsters.' => 
  array (
    'Zaphod' => 1,
  ),
  'impatiently' => 
  array (
    'on' => 1,
    'at' => 1,
    'around' => 1,
  ),
  'hatch.' => 
  array (
    '-' => 1,
  ),
  'rule.' => 
  array (
    '-' => 1,
  ),
  'exit' => 
  array (
    'hatch' => 2,
  ),
  'angry.' => 
  array (
    '-' => 1,
  ),
  'whoever' => 
  array (
    'said' => 1,
    '' => 1,
  ),
  'synapses' => 
  array (
    'closed.' => 1,
    'and' => 1,
  ),
  'closed.' => 
  array (
    '-' => 1,
  ),
  'bulkhead' => 
  array (
    'and' => 1,
  ),
  'count' => 
  array (
    'to' => 1,
    'all' => 1,
  ),
  'ten.' => 
  array (
    'He' => 1,
  ),
  'sentinent' => 
  array (
    'life' => 1,
  ),
  'counting' => 
  array (
    '' => 1,
    'quietly.' => 1,
  ),
  'demonstrate' => 
  array (
    'their' => 1,
  ),
  'independence' => 
  array (
    'of' => 1,
  ),
  'computers.' => 
  array (
    '-' => 1,
    'When' => 1,
  ),
  'sternly.' => 
  array (
    '-' => 2,
  ),
  'Computer...' => 
  array (
    '-' => 3,
  ),
  'Zaphod...' => 
  array (
    '-' => 1,
  ),
  'waiting,' => 
  array (
    '' => 1,
  ),
  'necessary...' => 
  array (
    '-' => 1,
  ),
  'competing' => 
  array (
    'with' => 1,
  ),
  'ground,' => 
  array (
    '-' => 1,
    'the' => 1,
  ),
  'zap' => 
  array (
    'straight' => 1,
  ),
  'reprogram' => 
  array (
    'you' => 1,
  ),
  'axe,' => 
  array (
    'got' => 1,
  ),
  'shocked,' => 
  array (
    'paused' => 1,
  ),
  'aggressive' => 
  array (
    'thing' => 1,
  ),
  'Blood...' => 
  array (
    'blood...' => 1,
  ),
  'blood...' => 
  array (
    'blood...' => 2,
    'Finally' => 1,
  ),
  'opened.' => 
  array (
    'An' => 1,
  ),
  'icy' => 
  array (
    'wind' => 1,
  ),
  'wind' => 
  array (
    'ripped' => 1,
    'stung' => 1,
  ),
  'ripped' => 
  array (
    'into' => 1,
  ),
  'ramp' => 
  array (
    'on' => 1,
  ),
  'tears,' => 
  array (
    'I' => 1,
  ),
  'response' => 
  array (
    'to' => 1,
  ),
  'command' => 
  array (
    'that' => 1,
  ),
  20 => 
  array (
    'Five' => 1,
  ),
  'Bits' => 
  array (
    'of' => 1,
  ),
  'dullish' => 
  array (
    'grey,' => 1,
    '' => 1,
  ),
  'brown,' => 
  array (
    '' => 1,
  ),
  'dried-out' => 
  array (
    'marsh,' => 1,
  ),
  'marsh,' => 
  array (
    'now' => 1,
  ),
  'vegetation' => 
  array (
    'and' => 1,
  ),
  'covered' => 
  array (
    'with' => 1,
    'in' => 1,
  ),
  'layer' => 
  array (
    'of' => 1,
  ),
  'thick.' => 
  array (
    '' => 1,
  ),
  'stalked' => 
  array (
    '' => 2,
  ),
  'stung' => 
  array (
    'Arthur\'s' => 1,
    'most' => 1,
  ),
  'ears,' => 
  array (
    'and' => 1,
  ),
  'stale' => 
  array (
    'thin' => 1,
  ),
  'clasped' => 
  array (
    'his' => 1,
  ),
  'fantastic...' => 
  array (
    '-' => 1,
  ),
  'rattled' => 
  array (
    '' => 1,
  ),
  'Sound' => 
  array (
    'carried' => 1,
  ),
  'atmosphere.' => 
  array (
    '-' => 1,
  ),
  'Desolate' => 
  array (
    'hole' => 1,
  ),
  'litter.' => 
  array (
    '-' => 1,
  ),
  'mounting' => 
  array (
    'irritation.' => 1,
  ),
  'systems' => 
  array (
    'of' => 1,
  ),
  'dump' => 
  array (
    'like' => 1,
    'though.' => 1,
  ),
  'castaway?' => 
  array (
    'Not' => 1,
  ),
  'evidence.' => 
  array (
    'He' => 1,
    'So' => 1,
  ),
  'stooped' => 
  array (
    'down' => 1,
  ),
  'clot' => 
  array (
    'of' => 1,
  ),
  'earth,' => 
  array (
    'but' => 1,
  ),
  'understand,' => 
  array (
    'this' => 1,
  ),
  'planet...' => 
  array (
    'a' => 1,
  ),
  'world!..' => 
  array (
    'Pity' => 1,
  ),
  'Pity' => 
  array (
    'it\'s' => 1,
  ),
  'herself,' => 
  array (
    'shivered' => 1,
  ),
  'shivered' => 
  array (
    'and' => 1,
    'involuntarily' => 1,
    'with' => 1,
  ),
  'sworn' => 
  array (
    'she' => 1,
  ),
  'eye,' => 
  array (
    'but' => 1,
  ),
  'silent,' => 
  array (
    'a' => 1,
    'even' => 1,
  ),
  'yards' => 
  array (
    'or' => 1,
    '' => 3,
    'in' => 1,
    'away.' => 1,
  ),
  'ridge' => 
  array (
    'of' => 2,
  ),
  'join' => 
  array (
    'him.' => 1,
  ),
  'excited,' => 
  array (
    'but' => 1,
    '-' => 1,
  ),
  'thinnish' => 
  array (
    'atmosphere' => 1,
  ),
  'wind.' => 
  array (
    'As' => 1,
  ),
  'higher' => 
  array (
    'ground' => 1,
  ),
  'crater' => 
  array (
    'about' => 1,
    'the' => 1,
    '' => 1,
  ),
  'wide.' => 
  array (
    'Round' => 1,
  ),
  'Round' => 
  array (
    'the' => 1,
  ),
  'sloping' => 
  array (
    '' => 1,
  ),
  'spattered' => 
  array (
    '' => 1,
  ),
  'lumps.' => 
  array (
    'They' => 1,
  ),
  'piece.' => 
  array (
    'It' => 1,
  ),
  'wet.' => 
  array (
    '' => 1,
  ),
  'rubbery.' => 
  array (
    'With' => 1,
  ),
  'whalemeat.' => 
  array (
    'At' => 1,
  ),
  'crater\'s' => 
  array (
    'lip' => 1,
  ),
  'lip' => 
  array (
    'they' => 1,
  ),
  'pointing' => 
  array (
    'into' => 1,
    'out.' => 1,
    'at' => 1,
  ),
  'crater.' => 
  array (
    'In' => 1,
    '-' => 2,
    'He' => 3,
    'Because' => 1,
  ),
  'carcass' => 
  array (
    'of' => 1,
  ),
  'lonely' => 
  array (
    'sperm' => 1,
    'stuck' => 1,
  ),
  'disappointed' => 
  array (
    'with' => 1,
  ),
  'lot.' => 
  array (
    'The' => 1,
    'I' => 1,
  ),
  'involuntary' => 
  array (
    'spasms' => 1,
  ),
  'spasms' => 
  array (
    'of' => 1,
  ),
  'Trillian\'s' => 
  array (
    'throat.' => 1,
  ),
  'bury' => 
  array (
    'it?' => 1,
  ),
  'murmured' => 
  array (
    'Arthur,' => 1,
  ),
  'hadn\'t.' => 
  array (
    '-' => 1,
  ),
  'Come,' => 
  array (
    '-' => 3,
  ),
  'severe' => 
  array (
    'distaste.' => 1,
  ),
  'distaste.' => 
  array (
    '-' => 1,
  ),
  'hesitated.' => 
  array (
    '-' => 1,
  ),
  'In?' => 
  array (
    '-' => 1,
  ),
  'horror.' => 
  array (
    '-' => 2,
    '' => 1,
  ),
  'planet!' => 
  array (
    'An' => 1,
  ),
  'underground' => 
  array (
    'passage.' => 1,
  ),
  'passage.' => 
  array (
    'The' => 1,
  ),
  'force' => 
  array (
    'of' => 1,
  ),
  'whale\'s' => 
  array (
    'impact' => 1,
    'graveyard' => 1,
  ),
  'trod' => 
  array (
    'these' => 1,
  ),
  'itself...' => 
  array (
    'Marvin' => 1,
  ),
  'ironical' => 
  array (
    'humming' => 1,
  ),
  'shudders' => 
  array (
    'of' => 1,
  ),
  'incline' => 
  array (
    'into' => 1,
  ),
  'crater,' => 
  array (
    'trying' => 1,
    '-' => 1,
  ),
  'creator.' => 
  array (
    '-' => 1,
  ),
  'dolefully,' => 
  array (
    '-' => 1,
  ),
  'caved' => 
  array (
    'in' => 1,
  ),
  'revealing' => 
  array (
    '' => 1,
  ),
  'network' => 
  array (
    'of' => 1,
  ),
  'galleries' => 
  array (
    'and' => 1,
  ),
  'passages,' => 
  array (
    'now' => 1,
  ),
  'obstructed' => 
  array (
    '' => 1,
  ),
  'collapsed' => 
  array (
    'rubble' => 1,
    'on' => 1,
  ),
  'entrails.' => 
  array (
    'Zaphod' => 1,
  ),
  'clearing' => 
  array (
    'a' => 1,
  ),
  'Dank' => 
  array (
    'air' => 1,
  ),
  'wafted' => 
  array (
    '' => 1,
  ),
  'recesses,' => 
  array (
    'and' => 1,
  ),
  'torch' => 
  array (
    'into' => 1,
    '' => 1,
  ),
  'visible' => 
  array (
    'in' => 1,
  ),
  'gloom.' => 
  array (
    '-' => 1,
    '' => 1,
  ),
  'According' => 
  array (
    'to' => 1,
  ),
  'legends,' => 
  array (
    '-' => 1,
  ),
  'underground.' => 
  array (
    '-' => 1,
  ),
  'Why\'s' => 
  array (
    'that?' => 1,
  ),
  'polluted' => 
  array (
    'or' => 1,
  ),
  'overpopulated?' => 
  array (
    '-' => 1,
  ),
  'peering' => 
  array (
    'nervously' => 1,
  ),
  'kid,' => 
  array (
    'I' => 1,
  ),
  'promise' => 
  array (
    'you' => 1,
  ),
  'population' => 
  array (
    'of' => 1,
  ),
  'nil' => 
  array (
    'plus' => 1,
  ),
  'plus' => 
  array (
    '' => 1,
  ),
  'hey' => 
  array (
    'Earthman...' => 1,
  ),
  'Earthman...' => 
  array (
    '-' => 1,
    'can' => 1,
  ),
  'passageway.' => 
  array (
    'OK?' => 1,
  ),
  'Guard?' => 
  array (
    '-' => 1,
  ),
  'safety,' => 
  array (
    'OK?' => 1,
  ),
  'Whose?' => 
  array (
    'Yours' => 1,
  ),
  'Yours' => 
  array (
    'or' => 1,
  ),
  'mine?' => 
  array (
    '-' => 1,
  ),
  'lad.' => 
  array (
    'OK,' => 1,
  ),
  'passage,' => 
  array (
    '' => 1,
  ),
  'assured' => 
  array (
    'him,' => 1,
  ),
  'will.' => 
  array (
    'In' => 1,
  ),
  'view.' => 
  array (
    'Arthur' => 1,
  ),
  'stamped' => 
  array (
    'around' => 1,
  ),
  'huff,' => 
  array (
    'and' => 1,
  ),
  'graveyard' => 
  array (
    'is' => 1,
  ),
  'stamp' => 
  array (
    'around' => 1,
  ),
  'balefully' => 
  array (
    'for' => 1,
  ),
  'marched' => 
  array (
    'quickly' => 1,
    'on' => 1,
  ),
  'passageway,' => 
  array (
    '' => 1,
  ),
  'hell,' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'striding' => 
  array (
    '' => 1,
  ),
  'purposefully.' => 
  array (
    '' => 1,
  ),
  'tiles' => 
  array (
    'and' => 1,
    'gave' => 1,
  ),
  'touch,' => 
  array (
    'the' => 1,
  ),
  'decay.' => 
  array (
    '-' => 1,
  ),
  'inhabited' => 
  array (
    '' => 1,
    'by' => 2,
  ),
  'strode' => 
  array (
    'on' => 1,
  ),
  'dirt' => 
  array (
    'and' => 1,
  ),
  'debris' => 
  array (
    '' => 1,
    'and' => 1,
  ),
  'littered' => 
  array (
    'the' => 1,
  ),
  'tile' => 
  array (
    'floor.' => 1,
  ),
  'reminded' => 
  array (
    'unavoidably' => 1,
  ),
  'unavoidably' => 
  array (
    'of' => 1,
  ),
  'Underground,' => 
  array (
    '' => 1,
  ),
  'squalid.' => 
  array (
    'At' => 1,
  ),
  'intervals' => 
  array (
    'along' => 1,
  ),
  'mosaics' => 
  array (
    '' => 1,
  ),
  'angular' => 
  array (
    'patterns' => 1,
  ),
  'colours.' => 
  array (
    'Trillian' => 1,
  ),
  'studied' => 
  array (
    'one' => 1,
  ),
  'interpret' => 
  array (
    'any' => 1,
  ),
  'symbols' => 
  array (
    'are?' => 1,
    'of' => 1,
  ),
  'are?' => 
  array (
    '-' => 1,
  ),
  'kind,' => 
  array (
    '-' => 1,
  ),
  'glancing' => 
  array (
    'back.' => 1,
  ),
  'hurried' => 
  array (
    'after' => 1,
    'over' => 1,
    'back' => 1,
  ),
  'doorway' => 
  array (
    'led' => 1,
  ),
  'chambers' => 
  array (
    'which' => 1,
  ),
  'derelict' => 
  array (
    '' => 1,
  ),
  'equipment.' => 
  array (
    'He' => 1,
  ),
  'followed.' => 
  array (
    '-' => 1,
  ),
  'Magrathea...' => 
  array (
    '-' => 1,
  ),
  'atlas,' => 
  array (
    'that\'s' => 1,
  ),
  'Research.' => 
  array (
    'Government' => 1,
  ),
  'archives.' => 
  array (
    'Detective' => 1,
  ),
  'Detective' => 
  array (
    'work.' => 1,
  ),
  'work.' => 
  array (
    'Few' => 1,
    '-' => 1,
  ),
  'Few' => 
  array (
    '' => 1,
  ),
  'guesses.' => 
  array (
    'Easy.' => 1,
  ),
  'Easy.' => 
  array (
    '-' => 1,
  ),
  'stole' => 
  array (
    'the' => 1,
    'it' => 1,
  ),
  'with?' => 
  array (
    '-' => 1,
  ),
  'things?' => 
  array (
    '-' => 1,
  ),
  'not?' => 
  array (
    '-' => 1,
    'They' => 1,
  ),
  'Because...' => 
  array (
    'because...' => 1,
  ),
  'because...' => 
  array (
    'I' => 1,
  ),
  'ruled' => 
  array (
    'out' => 1,
  ),
  'yet,' => 
  array (
    '-' => 1,
    '' => 1,
    'then' => 1,
    'so' => 1,
  ),
  'current' => 
  array (
    'conditions.' => 1,
    'conditions' => 1,
  ),
  'conditions.' => 
  array (
    'And' => 1,
  ),
  'nobody' => 
  array (
    'said' => 1,
  ),
  'worry.' => 
  array (
    '-' => 1,
  ),
  'friend,' => 
  array (
    'if' => 1,
  ),
  'eventually.' => 
  array (
    '-' => 1,
  ),
  'wait...' => 
  array (
    'I\'ll' => 1,
  ),
  'freewheel' => 
  array (
    'a' => 1,
  ),
  'and,' => 
  array (
    'hey,' => 1,
    '' => 1,
    'you' => 1,
  ),
  'happens,' => 
  array (
    '' => 1,
  ),
  'easy.' => 
  array (
    '' => 1,
  ),
  'decide' => 
  array (
    'to' => 3,
  ),
  'happens.' => 
  array (
    'Yeah,' => 1,
  ),
  'Galacticredit' => 
  array (
    'card' => 1,
  ),
  'card' => 
  array (
    'which' => 1,
  ),
  'cheques.' => 
  array (
    'And' => 1,
  ),
  'whenever' => 
  array (
    'I' => 1,
  ),
  'something?' => 
  array (
    '-' => 1,
  ),
  'desire' => 
  array (
    'just' => 1,
  ),
  'worrying' => 
  array (
    'about' => 1,
  ),
  'using' => 
  array (
    '' => 1,
  ),
  'ideas' => 
  array (
    'with,' => 1,
    'together' => 1,
  ),
  'purpose,' => 
  array (
    'which' => 1,
  ),
  'check.' => 
  array (
    '-' => 1,
  ),
  'medical' => 
  array (
    '' => 1,
    'officers' => 1,
    'equipment' => 1,
  ),
  'plugged' => 
  array (
    '' => 1,
    'myself' => 1,
  ),
  'encephelographic' => 
  array (
    'screen.' => 1,
  ),
  'screening' => 
  array (
    'test' => 1,
    'tests.' => 1,
    'tests' => 1,
  ),
  'test' => 
  array (
    'on' => 1,
  ),
  'tests' => 
  array (
    'I' => 1,
    'and' => 1,
  ),
  'officers' => 
  array (
    'before' => 1,
  ),
  'nomination' => 
  array (
    'for' => 1,
  ),
  'ratified.' => 
  array (
    'They' => 1,
  ),
  'clever,' => 
  array (
    'imaginative,' => 1,
  ),
  'imaginative,' => 
  array (
    'irresponsible,' => 1,
  ),
  'irresponsible,' => 
  array (
    'untrustworthy,' => 1,
  ),
  'untrustworthy,' => 
  array (
    'extrovert,' => 1,
  ),
  'extrovert,' => 
  array (
    '' => 1,
  ),
  'guessed.' => 
  array (
    'And' => 1,
    'It' => 1,
  ),
  'anomalies.' => 
  array (
    'So' => 1,
  ),
  'inventing' => 
  array (
    'further' => 1,
  ),
  'tests,' => 
  array (
    'completely' => 1,
    'learning' => 1,
  ),
  'random.' => 
  array (
    'Nothing.' => 1,
    'The' => 1,
  ),
  'superimposing' => 
  array (
    'the' => 1,
  ),
  'results' => 
  array (
    'from' => 2,
    '' => 1,
  ),
  'silly,' => 
  array (
    'because' => 1,
  ),
  'paranoia.' => 
  array (
    'Last' => 1,
    'Everyone' => 1,
  ),
  'packed' => 
  array (
    '' => 1,
  ),
  'superimposed' => 
  array (
    'picture' => 1,
  ),
  'filter.' => 
  array (
    '' => 1,
  ),
  'superstitious' => 
  array (
    'about' => 1,
  ),
  'kid?' => 
  array (
    'I' => 1,
    '-' => 1,
  ),
  'pilot' => 
  array (
    'on' => 1,
  ),
  'scouts?' => 
  array (
    'Ford' => 1,
  ),
  'nodded.' => 
  array (
    '-' => 1,
  ),
  'related' => 
  array (
    'only' => 1,
    'the' => 1,
  ),
  'bastard' => 
  array (
    'had' => 1,
    'was.' => 1,
  ),
  'cauterized' => 
  array (
    '' => 1,
    'synapses.' => 1,
  ),
  'electronically' => 
  array (
    'traumatised' => 1,
  ),
  'traumatised' => 
  array (
    'those' => 1,
  ),
  'cerebellum.' => 
  array (
    'Ford' => 1,
  ),
  'aghast.' => 
  array (
    'Trillian' => 1,
    '-' => 1,
  ),
  'white.' => 
  array (
    '-' => 1,
  ),
  'Somebody' => 
  array (
    'did' => 1,
  ),
  'who?' => 
  array (
    'Or' => 1,
    '-' => 1,
  ),
  'guess.' => 
  array (
    'But' => 1,
    'When' => 1,
  ),
  'initials' => 
  array (
    '' => 1,
  ),
  'synapses.' => 
  array (
    'They' => 1,
  ),
  'begin' => 
  array (
    'to' => 4,
    '' => 1,
  ),
  'crawl.' => 
  array (
    '-' => 1,
  ),
  'Initials?' => 
  array (
    'Burnt' => 1,
  ),
  'Burnt' => 
  array (
    'into' => 1,
  ),
  'brain?' => 
  array (
    '-' => 1,
  ),
  'they,' => 
  array (
    'for' => 1,
  ),
  'sake?' => 
  array (
    'Zaphod' => 1,
  ),
  'Z.B.,' => 
  array (
    '-' => 1,
  ),
  'shutter' => 
  array (
    '' => 1,
  ),
  'chamber.' => 
  array (
    '-' => 1,
  ),
  'later,' => 
  array (
    '-' => 1,
    'on' => 1,
    'the' => 1,
  ),
  21 => 
  array (
    'On' => 1,
  ),
  'moodily.' => 
  array (
    'Ford' => 1,
  ),
  'thoughtfully' => 
  array (
    'left' => 1,
  ),
  'unevenly' => 
  array (
    'edited' => 1,
  ),
  'passages' => 
  array (
    'that' => 1,
  ),
  'across)' => 
  array (
    'supposedly' => 1,
  ),
  'supposedly' => 
  array (
    'relates' => 1,
  ),
  'relates' => 
  array (
    '' => 1,
  ),
  'experiences' => 
  array (
    'of' => 1,
  ),
  'Veet' => 
  array (
    'Voojagig,' => 1,
    'Voojagig' => 1,
  ),
  'Voojagig,' => 
  array (
    'a' => 1,
  ),
  'University' => 
  array (
    'of' => 1,
    'burst' => 1,
  ),
  'Maximegalon,' => 
  array (
    'who' => 1,
  ),
  'academic' => 
  array (
    'career' => 1,
  ),
  'studying' => 
  array (
    '' => 1,
  ),
  'philology,' => 
  array (
    '' => 1,
  ),
  'transformational' => 
  array (
    '' => 1,
  ),
  'ethics' => 
  array (
    '' => 1,
  ),
  'harmonic' => 
  array (
    '' => 1,
  ),
  'historical' => 
  array (
    'perception,' => 1,
  ),
  'perception,' => 
  array (
    'and' => 1,
  ),
  'obsessed' => 
  array (
    '' => 1,
  ),
  'biros' => 
  array (
    '' => 1,
    'would' => 1,
  ),
  'period' => 
  array (
    'of' => 1,
  ),
  'painstaking' => 
  array (
    'research' => 1,
  ),
  'visited' => 
  array (
    'all' => 1,
  ),
  'biro' => 
  array (
    '' => 1,
    'life' => 1,
    'equivalent' => 1,
    'business.' => 1,
  ),
  'loss' => 
  array (
    '' => 1,
  ),
  'quaint' => 
  array (
    'little' => 1,
  ),
  'cosmos,' => 
  array (
    '' => 1,
  ),
  'humanoids,' => 
  array (
    'reptiloids,' => 1,
  ),
  'reptiloids,' => 
  array (
    'fishoids,' => 1,
  ),
  'fishoids,' => 
  array (
    'walking' => 1,
  ),
  'walking' => 
  array (
    'treeoids' => 1,
  ),
  'treeoids' => 
  array (
    'and' => 1,
  ),
  'superintelligent' => 
  array (
    'shades' => 1,
  ),
  'blue,' => 
  array (
    'there' => 1,
  ),
  'unattended' => 
  array (
    'biros' => 1,
  ),
  'way,' => 
  array (
    'slipping' => 1,
    '' => 1,
    '-' => 1,
  ),
  'wormholes' => 
  array (
    'in' => 1,
  ),
  'uniquely' => 
  array (
    'biroid' => 1,
  ),
  'biroid' => 
  array (
    '' => 1,
  ),
  'lifestyle,' => 
  array (
    '' => 2,
    '-' => 1,
  ),
  'responding' => 
  array (
    '' => 1,
  ),
  'biro-oriented' => 
  array (
    '' => 1,
  ),
  'stimuli,' => 
  array (
    '' => 1,
  ),
  'theories' => 
  array (
    'go' => 1,
    '' => 1,
  ),
  'fine' => 
  array (
    '' => 1,
    'white' => 1,
  ),
  'Voojagig' => 
  array (
    'suddenly' => 1,
    'had' => 1,
  ),
  'claimed' => 
  array (
    'to' => 1,
    'for' => 1,
    'repeatedly' => 1,
  ),
  'limousine' => 
  array (
    '' => 1,
  ),
  'family' => 
  array (
    '' => 1,
  ),
  'cheap' => 
  array (
    '' => 1,
  ),
  'retractables,' => 
  array (
    'whereupon' => 1,
  ),
  'whereupon' => 
  array (
    'he' => 1,
  ),
  'wrote' => 
  array (
    '' => 1,
  ),
  'exile,' => 
  array (
    'which' => 1,
  ),
  'usual' => 
  array (
    '' => 1,
  ),
  'fate' => 
  array (
    '' => 1,
    'eventually' => 1,
  ),
  'reserved' => 
  array (
    '' => 1,
  ),
  'determined' => 
  array (
    'to' => 1,
  ),
  'fool' => 
  array (
    'of' => 1,
  ),
  'public.' => 
  array (
    'When' => 1,
  ),
  'expedition' => 
  array (
    'was' => 1,
  ),
  'spatial' => 
  array (
    '' => 1,
  ),
  'asteroid' => 
  array (
    'inhabited' => 1,
  ),
  'solitary' => 
  array (
    'old' => 1,
  ),
  'repeatedly' => 
  array (
    '' => 1,
  ),
  'true,' => 
  array (
    'though' => 1,
  ),
  'lying.' => 
  array (
    'There' => 1,
  ),
  'did,' => 
  array (
    'however,' => 1,
  ),
  'remain' => 
  array (
    'the' => 1,
  ),
  'mysterious' => 
  array (
    '60,000' => 1,
    '-' => 1,
  ),
  '60,000' => 
  array (
    'Altairan' => 1,
  ),
  'yearly' => 
  array (
    'into' => 1,
  ),
  'Brantisvogan' => 
  array (
    'bank' => 1,
  ),
  'bank' => 
  array (
    '' => 1,
    'with.' => 1,
    'and' => 2,
    'in' => 1,
    'was' => 1,
  ),
  'account,' => 
  array (
    '' => 1,
  ),
  'profitable' => 
  array (
    'second-hand' => 1,
  ),
  'second-hand' => 
  array (
    'biro' => 1,
  ),
  'inert.' => 
  array (
    'Arthur' => 1,
  ),
  'magnificently' => 
  array (
    'over' => 1,
  ),
  'nobody.' => 
  array (
    '-' => 1,
  ),
  'Night\'s' => 
  array (
    'falling,' => 1,
  ),
  'faintly,' => 
  array (
    'but' => 1,
  ),
  'seen.' => 
  array (
    'The' => 1,
    'This' => 1,
  ),
  'obediently' => 
  array (
    'looked' => 1,
  ),
  'Wretched' => 
  array (
    'isn\'t' => 1,
  ),
  'sunset!' => 
  array (
    'I\'ve' => 1,
  ),
  'wildest' => 
  array (
    'dreams...' => 1,
    'dreams.' => 1,
  ),
  'dreams...' => 
  array (
    'the' => 1,
  ),
  'suns!' => 
  array (
    'It' => 1,
  ),
  'boiling' => 
  array (
    'into' => 1,
  ),
  'rubbish.' => 
  array (
    '-' => 1,
  ),
  'home,' => 
  array (
    '-' => 1,
  ),
  'persevered' => 
  array (
    'Arthur,' => 1,
  ),
  'awful.' => 
  array (
    '-' => 1,
  ),
  'oceans?' => 
  array (
    '-' => 1,
  ),
  'sigh,' => 
  array (
    '' => 1,
  ),
  'oceans...' => 
  array (
    '-' => 1,
  ),
  'Can\'t' => 
  array (
    'bear' => 1,
  ),
  'inquired' => 
  array (
    'Arthur,' => 1,
    'Deep' => 2,
  ),
  'robots?' => 
  array (
    '-' => 1,
  ),
  'Hate' => 
  array (
    'them,' => 1,
  ),
  'going?' => 
  array (
    'Arthur' => 1,
  ),
  'walk,' => 
  array (
    '-' => 1,
  ),
  'blame' => 
  array (
    'you,' => 1,
  ),
  'counted' => 
  array (
    '' => 1,
  ),
  'ninety-seven' => 
  array (
    'thousand' => 1,
  ),
  'sheep' => 
  array (
    'before' => 1,
  ),
  'asleep' => 
  array (
    'again' => 1,
    'inside' => 1,
  ),
  'circulation' => 
  array (
    'a' => 1,
  ),
  'moon,' => 
  array (
    'nightfall' => 1,
  ),
  'nightfall' => 
  array (
    'was' => 1,
  ),
  'rapid' => 
  array (
    'and' => 1,
  ),
  'practically' => 
  array (
    'walked' => 1,
    'choked.' => 1,
  ),
  22 => 
  array (
    'He' => 1,
  ),
  'glimmers' => 
  array (
    'of' => 1,
  ),
  'horizon.' => 
  array (
    'He' => 1,
  ),
  'tallish,' => 
  array (
    'elderly' => 1,
  ),
  'elderly' => 
  array (
    'and' => 1,
  ),
  'dressed' => 
  array (
    'in' => 1,
    '' => 1,
    'dais' => 1,
    'men' => 1,
  ),
  'robe.' => 
  array (
    'When' => 1,
  ),
  'distinguished,' => 
  array (
    'careworn' => 1,
  ),
  'careworn' => 
  array (
    'but' => 1,
  ),
  'unkind,' => 
  array (
    'the' => 1,
  ),
  'yelp' => 
  array (
    'of' => 1,
  ),
  'Eventually' => 
  array (
    'the' => 1,
    'of' => 1,
  ),
  'completely,' => 
  array (
    '' => 1,
  ),
  'illuminated' => 
  array (
    'from' => 1,
    'by' => 1,
  ),
  'somewhere,' => 
  array (
    '' => 1,
  ),
  'hovercraft,' => 
  array (
    'Arthur' => 1,
  ),
  'shed' => 
  array (
    '' => 1,
  ),
  'dim' => 
  array (
    'pool' => 1,
    'irritating' => 1,
  ),
  'pool' => 
  array (
    'of' => 1,
  ),
  'sadly' => 
  array (
    'it' => 1,
    'out' => 1,
  ),
  'seemed.' => 
  array (
    '-' => 1,
  ),
  'visit' => 
  array (
    'our' => 1,
  ),
  'Who...' => 
  array (
    'who' => 1,
  ),
  'important,' => 
  array (
    '-' => 2,
  ),
  'Conversation' => 
  array (
    '' => 1,
  ),
  'rush' => 
  array (
    'at.' => 1,
  ),
  'awkward.' => 
  array (
    '-' => 1,
  ),
  'me...' => 
  array (
    '-' => 1,
  ),
  'lamely.' => 
  array (
    'The' => 1,
  ),
  'eyebrows.' => 
  array (
    '-' => 1,
  ),
  'Hmmmm?' => 
  array (
    '-' => 1,
  ),
  'harm' => 
  array (
    'you.' => 1,
  ),
  'missiles...' => 
  array (
    '-' => 1,
  ),
  'chuckled' => 
  array (
    'slightly.' => 1,
  ),
  'sigh.' => 
  array (
    '' => 1,
  ),
  'Ancient' => 
  array (
    'computers' => 1,
    'history,' => 1,
  ),
  'bowels' => 
  array (
    'of' => 2,
  ),
  'tick' => 
  array (
    'away' => 1,
  ),
  'millennia,' => 
  array (
    'and' => 1,
  ),
  'ages' => 
  array (
    'hang' => 1,
  ),
  'banks.' => 
  array (
    'I' => 1,
    'At' => 1,
  ),
  'pot' => 
  array (
    'shot' => 1,
    '' => 1,
  ),
  'relieve' => 
  array (
    'the' => 1,
  ),
  'monotony.' => 
  array (
    'He' => 1,
  ),
  'gravely' => 
  array (
    'at' => 1,
  ),
  'science' => 
  array (
    'you' => 1,
  ),
  'really?' => 
  array (
    '-' => 1,
  ),
  'man\'s' => 
  array (
    'curious,' => 1,
    '' => 2,
    'finger,' => 1,
  ),
  'curious,' => 
  array (
    'kindly' => 1,
  ),
  'disconcerting.' => 
  array (
    '-' => 1,
  ),
  'felling' => 
  array (
    'of' => 1,
  ),
  'adultery' => 
  array (
    'who' => 1,
  ),
  'woman\'s' => 
  array (
    '' => 1,
  ),
  'husband' => 
  array (
    'wanders' => 1,
  ),
  'wanders' => 
  array (
    'into' => 1,
  ),
  'changes' => 
  array (
    'his' => 1,
  ),
  'trousers,' => 
  array (
    'passes' => 1,
  ),
  'idle' => 
  array (
    '' => 1,
  ),
  'remarks' => 
  array (
    'about' => 1,
  ),
  'leaves' => 
  array (
    'again.' => 1,
  ),
  'polite' => 
  array (
    'concern.' => 1,
  ),
  'concern.' => 
  array (
    '-' => 1,
  ),
  'expecting' => 
  array (
    'to' => 1,
  ),
  'fact.' => 
  array (
    'I' => 1,
    '' => 1,
  ),
  'Dead?' => 
  array (
    '-' => 1,
  ),
  'gracious' => 
  array (
    'no,' => 1,
  ),
  'slept.' => 
  array (
    '-' => 1,
  ),
  'Slept?' => 
  array (
    '-' => 1,
  ),
  'incredulously.' => 
  array (
    '-' => 1,
  ),
  'economic' => 
  array (
    'recession' => 1,
    'recession?' => 1,
  ),
  'recession' => 
  array (
    'you' => 1,
    'came' => 1,
  ),
  'unconcerned' => 
  array (
    'about' => 1,
  ),
  'not.' => 
  array (
    '-' => 2,
  ),
  'recession?' => 
  array (
    '-' => 1,
  ),
  'economy' => 
  array (
    'collapsed,' => 1,
    'enough' => 1,
  ),
  'commodity' => 
  array (
    'you' => 1,
  ),
  'solemnly.' => 
  array (
    '-' => 1,
  ),
  'gathered...' => 
  array (
    '-' => 1,
  ),
  'Fascinating' => 
  array (
    'trade,' => 1,
  ),
  'trade,' => 
  array (
    '-' => 1,
  ),
  'wistful' => 
  array (
    'look' => 2,
  ),
  'eyes,' => 
  array (
    '-' => 1,
    'it' => 1,
  ),
  'coastlines' => 
  array (
    'was' => 1,
  ),
  'favourite.' => 
  array (
    '' => 1,
  ),
  'Used' => 
  array (
    '' => 1,
  ),
  'endless' => 
  array (
    'fun' => 1,
  ),
  'fjords...' => 
  array (
    'so' => 1,
  ),
  'thread' => 
  array (
    'again,' => 1,
  ),
  'slept' => 
  array (
    'through' => 1,
  ),
  'programmed' => 
  array (
    '' => 2,
  ),
  'revive' => 
  array (
    'us' => 1,
    '' => 1,
  ),
  'stifled' => 
  array (
    'a' => 1,
  ),
  'yawn' => 
  array (
    'and' => 1,
  ),
  'index' => 
  array (
    'linked' => 1,
  ),
  'linked' => 
  array (
    'to' => 1,
    'through' => 1,
  ),
  'stock' => 
  array (
    'market' => 1,
  ),
  'prices' => 
  array (
    'you' => 1,
  ),
  'revived' => 
  array (
    'when' => 1,
    'from' => 1,
  ),
  'everybody' => 
  array (
    'else' => 1,
    'does.' => 1,
  ),
  'rebuilt' => 
  array (
    '' => 1,
  ),
  'expensive' => 
  array (
    'services.' => 1,
  ),
  'services.' => 
  array (
    'Arthur,' => 1,
  ),
  'regular' => 
  array (
    'Guardian' => 1,
  ),
  'Guardian' => 
  array (
    'reader,' => 1,
  ),
  'reader,' => 
  array (
    'was' => 1,
  ),
  'shocked' => 
  array (
    'at' => 1,
  ),
  'behave' => 
  array (
    'isn\'t' => 1,
  ),
  'mildly.' => 
  array (
    '-' => 4,
  ),
  'touch.' => 
  array (
    'He' => 1,
  ),
  'yours?' => 
  array (
    '-' => 1,
  ),
  'metallic' => 
  array (
    'voice' => 1,
  ),
  'mine.' => 
  array (
    '-' => 1,
    'Won' => 1,
  ),
  'machine.' => 
  array (
    '-' => 1,
  ),
  'Bring' => 
  array (
    'it,' => 1,
  ),
  'slope' => 
  array (
    'making' => 1,
  ),
  'lame,' => 
  array (
    'which' => 1,
  ),
  'wasn\'t.' => 
  array (
    '-' => 1,
  ),
  'thoughts,' => 
  array (
    '-' => 1,
    '' => 1,
  ),
  'afoot.' => 
  array (
    '-' => 1,
  ),
  'which,' => 
  array (
    'though' => 1,
  ),
  'given,' => 
  array (
    'now' => 1,
  ),
  'laboriously' => 
  array (
    'and' => 1,
  ),
  'trudging' => 
  array (
    'off' => 1,
  ),
  'sour' => 
  array (
    'nothings' => 1,
  ),
  'nothings' => 
  array (
    'to' => 1,
  ),
  'Late?' => 
  array (
    '-' => 1,
  ),
  'human?' => 
  array (
    '-' => 1,
  ),
  'Late,' => 
  array (
    'as' => 1,
  ),
  'Dentarthurdent,' => 
  array (
    '-' => 1,
  ),
  'tired' => 
  array (
    'old' => 1,
  ),
  'myself,' => 
  array (
    'but' => 1,
  ),
  'person,' => 
  array (
    '-' => 1,
  ),
  'embarrassment.' => 
  array (
    '' => 1,
  ),
  'go?' => 
  array (
    '-' => 1,
  ),
  'aircar,' => 
  array (
    '-' => 1,
    '' => 1,
  ),
  'motioning' => 
  array (
    'Arthur' => 1,
  ),
  'five-million-year' => 
  array (
    'slumber.' => 1,
  ),
  'slumber.' => 
  array (
    'Magrathea' => 1,
  ),
  'awakes.' => 
  array (
    'Arthur' => 1,
  ),
  'seated' => 
  array (
    'himself' => 1,
    'themselves' => 1,
  ),
  'strangeness' => 
  array (
    'of' => 1,
  ),
  'unsettled' => 
  array (
    'him.' => 1,
  ),
  'glow' => 
  array (
    '' => 1,
    'of' => 3,
  ),
  'instrument' => 
  array (
    'panel.' => 2,
  ),
  'way?' => 
  array (
    '-' => 1,
  ),
  'Slartibartfast.' => 
  array (
    'Arthur' => 1,
    '-' => 1,
    'It' => 1,
  ),
  'choked.' => 
  array (
    '-' => 1,
  ),
  'spluttered.' => 
  array (
    '-' => 1,
  ),
  'Slartibartfast,' => 
  array (
    '-' => 8,
    'making' => 1,
    'aghast.' => 1,
  ),
  'repeated' => 
  array (
    'the' => 1,
  ),
  'Slartibartfast?' => 
  array (
    'The' => 1,
  ),
  'gravely.' => 
  array (
    '-' => 1,
  ),
  'aircar' => 
  array (
    'sailed' => 1,
    'coasted' => 1,
    'emerged' => 1,
    'attained,' => 1,
    'flew' => 1,
    'round' => 1,
    'trip' => 1,
    'that' => 1,
    'was' => 1,
    'rocketed' => 1,
    'flung' => 1,
  ),
  'sailed' => 
  array (
    'through' => 2,
    'straight' => 1,
  ),
  'night.' => 
  array (
    'Chapter' => 1,
    'It' => 1,
  ),
  23 => 
  array (
    'It' => 1,
  ),
  'seem.' => 
  array (
    'For' => 1,
  ),
  'dolphins' => 
  array (
    'because' => 1,
    '' => 2,
    'had' => 1,
  ),
  'achieved' => 
  array (
    '' => 1,
    'some' => 1,
  ),
  'wheel,' => 
  array (
    'New' => 1,
  ),
  'York,' => 
  array (
    'wars' => 1,
  ),
  'muck' => 
  array (
    'about' => 1,
  ),
  'conversely,' => 
  array (
    '' => 1,
  ),
  'precisely' => 
  array (
    'the' => 1,
    'what' => 1,
  ),
  'reasons.' => 
  array (
    'Curiously' => 1,
  ),
  'impending' => 
  array (
    'destruction' => 1,
  ),
  'alert' => 
  array (
    'mankind' => 1,
  ),
  'mankind' => 
  array (
    '' => 1,
  ),
  'danger;' => 
  array (
    '' => 1,
  ),
  'communications' => 
  array (
    '' => 1,
  ),
  'misinterpreted' => 
  array (
    'as' => 1,
    '' => 1,
    'this' => 1,
  ),
  'amusing' => 
  array (
    'attempts' => 1,
  ),
  'punch' => 
  array (
    '' => 1,
  ),
  'footballs' => 
  array (
    '' => 1,
  ),
  'whistle' => 
  array (
    '' => 1,
  ),
  'tidbits,' => 
  array (
    'so' => 1,
  ),
  'dolphin' => 
  array (
    'message' => 1,
  ),
  'surprisingly' => 
  array (
    'sophisticated' => 1,
  ),
  'double-backwardssomersault' => 
  array (
    '' => 1,
  ),
  'hoop' => 
  array (
    'whilst' => 1,
  ),
  '"Star' => 
  array (
    'Sprangled' => 1,
  ),
  'Sprangled' => 
  array (
    'Banner",' => 1,
  ),
  'Banner",' => 
  array (
    'but' => 1,
  ),
  'dolphins,' => 
  array (
    'and' => 1,
  ),
  'behavioural' => 
  array (
    '' => 1,
    'research,' => 1,
  ),
  'laboratories' => 
  array (
    'running' => 1,
  ),
  'wheels' => 
  array (
    '' => 1,
  ),
  'conducting' => 
  array (
    '' => 1,
  ),
  'frighteningly' => 
  array (
    'elegant' => 1,
  ),
  'experiments' => 
  array (
    'on' => 1,
    '' => 1,
  ),
  'according' => 
  array (
    '' => 1,
    'to' => 1,
  ),
  'creatures\'' => 
  array (
    'plans.' => 1,
  ),
  'plans.' => 
  array (
    'Chapter' => 1,
  ),
  24 => 
  array (
    'Silently' => 1,
  ),
  'Silently' => 
  array (
    'the' => 1,
  ),
  'darkness,' => 
  array (
    'a' => 1,
  ),
  'Magrathean' => 
  array (
    'night.' => 1,
    'man' => 1,
    '' => 1,
  ),
  'swiftly.' => 
  array (
    'Arthur\'s' => 1,
  ),
  'companion' => 
  array (
    'seemed' => 1,
  ),
  'occasions' => 
  array (
    'to' => 1,
  ),
  'engage' => 
  array (
    'him' => 1,
  ),
  'comfortable' => 
  array (
    '' => 1,
  ),
  'gauge' => 
  array (
    'the' => 1,
  ),
  'speed' => 
  array (
    'at' => 1,
    '' => 2,
    'and' => 1,
    'he' => 1,
    'of' => 1,
    'taken' => 1,
  ),
  'travelling,' => 
  array (
    '' => 1,
  ),
  'absolute' => 
  array (
    'and' => 1,
  ),
  'denied' => 
  array (
    'any' => 1,
  ),
  'reference' => 
  array (
    'points.' => 1,
  ),
  'points.' => 
  array (
    'The' => 1,
  ),
  'motion' => 
  array (
    'was' => 1,
  ),
  'travelling' => 
  array (
    'towards' => 1,
    'at' => 1,
    '' => 1,
  ),
  'colossal' => 
  array (
    'speed,' => 1,
    'speed' => 1,
  ),
  'speed,' => 
  array (
    'and' => 1,
  ),
  'peered' => 
  array (
    'at' => 1,
    'through' => 1,
  ),
  'discern' => 
  array (
    '' => 1,
  ),
  'shape,' => 
  array (
    'and' => 1,
  ),
  'aircraft' => 
  array (
    '' => 1,
  ),
  'dipped' => 
  array (
    '' => 1,
  ),
  'downwards' => 
  array (
    'in' => 1,
  ),
  'collision' => 
  array (
    '' => 1,
  ),
  'velocity' => 
  array (
    'seemed' => 1,
    'measure,' => 1,
  ),
  'unbelievable,' => 
  array (
    'and' => 1,
  ),
  'breath' => 
  array (
    'before' => 1,
    'evaporated' => 1,
    'evaporates' => 1,
    'and' => 1,
  ),
  'insane' => 
  array (
    'silver' => 1,
    'blur' => 1,
  ),
  'surround' => 
  array (
    '' => 1,
  ),
  'dwindling' => 
  array (
    '' => 1,
  ),
  'tunnel' => 
  array (
    'in' => 1,
    'down' => 1,
  ),
  'stationary' => 
  array (
    '' => 1,
  ),
  'tunnel.' => 
  array (
    'The' => 1,
  ),
  'shooting,' => 
  array (
    '' => 1,
  ),
  'terror.' => 
  array (
    'After' => 1,
  ),
  'judge,' => 
  array (
    'he' => 1,
  ),
  'sensed' => 
  array (
    'a' => 1,
  ),
  'subsidence' => 
  array (
    'in' => 1,
  ),
  'gradually' => 
  array (
    'gliding' => 1,
  ),
  'gliding' => 
  array (
    'to' => 1,
    'through' => 1,
  ),
  'gentle' => 
  array (
    'halt.' => 1,
  ),
  'tunnel,' => 
  array (
    'threading' => 1,
  ),
  'threading' => 
  array (
    'and' => 1,
  ),
  'crisscross' => 
  array (
    'warren' => 1,
  ),
  'warren' => 
  array (
    'of' => 1,
  ),
  'tunnels.' => 
  array (
    'When' => 1,
  ),
  'steel.' => 
  array (
    'Several' => 1,
  ),
  'tunnels' => 
  array (
    'also' => 1,
    'that' => 1,
  ),
  'terminus' => 
  array (
    'here,' => 1,
  ),
  'farther' => 
  array (
    'end' => 1,
  ),
  'circle' => 
  array (
    '' => 1,
    'of' => 1,
  ),
  'tricks' => 
  array (
    '' => 1,
  ),
  '(quite' => 
  array (
    'wrongly)' => 1,
  ),
  'wrongly)' => 
  array (
    'that' => 1,
  ),
  'ultra' => 
  array (
    'violet.' => 1,
  ),
  'violet.' => 
  array (
    'Slartibartfast' => 1,
  ),
  'Slartibartfast' => 
  array (
    'turned' => 1,
    'touched' => 1,
    'as' => 1,
    'cheerfully.' => 1,
    'coughed' => 2,
    'had' => 2,
    'was' => 1,
    '' => 2,
  ),
  'solemn' => 
  array (
    'old' => 1,
  ),
  'Earthman,' => 
  array (
    '-' => 5,
    'the' => 1,
    '' => 1,
  ),
  'gently,' => 
  array (
    '-' => 1,
  ),
  'clearer' => 
  array (
    '' => 1,
  ),
  'warn' => 
  array (
    'you' => 1,
    '' => 1,
  ),
  'literally' => 
  array (
    'exist' => 1,
  ),
  'gateway' => 
  array (
    'into' => 1,
    'through' => 1,
    'back' => 1,
  ),
  'tract' => 
  array (
    'of' => 1,
  ),
  'disturb' => 
  array (
    'you.' => 1,
  ),
  'reassuringly.' => 
  array (
    '-' => 1,
  ),
  'scares' => 
  array (
    'the' => 1,
  ),
  'willies' => 
  array (
    'out' => 1,
  ),
  'Hold' => 
  array (
    'tight.' => 1,
  ),
  'tight.' => 
  array (
    'The' => 1,
  ),
  'car' => 
  array (
    'shot' => 1,
    'and' => 1,
  ),
  'infinity' => 
  array (
    'looked' => 1,
    '' => 2,
    'far' => 1,
    'itself.' => 1,
    'of' => 1,
  ),
  'uninteresting.' => 
  array (
    'Looking' => 1,
  ),
  'meaningless.' => 
  array (
    'The' => 1,
  ),
  'emerged' => 
  array (
    'was' => 1,
    'into' => 1,
  ),
  'infinite,' => 
  array (
    'it' => 1,
  ),
  'big,' => 
  array (
    'so' => 1,
    '' => 1,
  ),
  'span,' => 
  array (
    'as,' => 1,
  ),
  'as,' => 
  array (
    'travelling' => 1,
  ),
  'attained,' => 
  array (
    'they' => 1,
  ),
  'climbed' => 
  array (
    '' => 1,
  ),
  'invisible' => 
  array (
    'pinprick' => 1,
    'to' => 1,
  ),
  'pinprick' => 
  array (
    'in' => 1,
  ),
  'shimmering' => 
  array (
    'wall' => 1,
  ),
  'defied' => 
  array (
    'the' => 1,
  ),
  'seduced' => 
  array (
    'it' => 1,
  ),
  'defeated' => 
  array (
    '' => 1,
  ),
  'paralysingly' => 
  array (
    'vast' => 1,
  ),
  'top,' => 
  array (
    '' => 1,
    'as' => 1,
  ),
  'sides' => 
  array (
    'passed' => 1,
  ),
  'sight.' => 
  array (
    'The' => 1,
  ),
  'vertigo' => 
  array (
    '' => 1,
  ),
  'flat.' => 
  array (
    'It' => 1,
  ),
  'finest' => 
  array (
    '' => 2,
  ),
  'laser' => 
  array (
    'measuring' => 1,
  ),
  'detect' => 
  array (
    'that' => 1,
  ),
  'infinity,' => 
  array (
    'as' => 1,
  ),
  'dizzily' => 
  array (
    'away,' => 1,
  ),
  'planed' => 
  array (
    '' => 1,
  ),
  'side,' => 
  array (
    '' => 1,
  ),
  'curved.' => 
  array (
    'It' => 1,
  ),
  'thirteen' => 
  array (
    'light' => 1,
  ),
  'hollow' => 
  array (
    'sphere,' => 1,
    'laugh.' => 1,
  ),
  'sphere,' => 
  array (
    'a' => 1,
  ),
  'sphere' => 
  array (
    'over' => 1,
    'within.' => 1,
  ),
  'unimaginable' => 
  array (
    'light.' => 1,
  ),
  'speck' => 
  array (
    '' => 1,
  ),
  'imperceptibly' => 
  array (
    'forward' => 1,
  ),
  'mindboggling' => 
  array (
    'space,' => 1,
  ),
  'welcome,' => 
  array (
    '-' => 1,
  ),
  'factory' => 
  array (
    'floor.' => 1,
  ),
  'Ranged' => 
  array (
    '' => 1,
  ),
  'neither' => 
  array (
    'judge' => 1,
  ),
  'judge' => 
  array (
    'nor' => 1,
  ),
  'guess' => 
  array (
    'at,' => 1,
    'at' => 1,
  ),
  'suspensions,' => 
  array (
    'delicate' => 1,
  ),
  'traceries' => 
  array (
    'of' => 1,
  ),
  'shadowy' => 
  array (
    'spherical' => 1,
  ),
  'spherical' => 
  array (
    'shapes' => 1,
  ),
  'words,' => 
  array (
    '' => 1,
    'part' => 1,
    '-' => 1,
  ),
  'starting' => 
  array (
    'it' => 1,
  ),
  'heavens' => 
  array (
    'no,' => 1,
  ),
  'support' => 
  array (
    'us' => 1,
  ),
  'awakened' => 
  array (
    '' => 1,
  ),
  'commission' => 
  array (
    'for' => 1,
  ),
  'very...' => 
  array (
    'special' => 1,
  ),
  'structures' => 
  array (
    'that' => 1,
  ),
  'betrayed' => 
  array (
    'any' => 1,
  ),
  'activity' => 
  array (
    '' => 1,
  ),
  'however' => 
  array (
    'a' => 1,
    'the' => 1,
  ),
  'arced' => 
  array (
    '' => 1,
  ),
  'stark' => 
  array (
    'relief' => 1,
  ),
  'relief' => 
  array (
    'the' => 1,
  ),
  'Patterns' => 
  array (
    'that' => 1,
  ),
  'knew,' => 
  array (
    'rough' => 1,
  ),
  'blobby' => 
  array (
    'shapes' => 1,
  ),
  'familiar' => 
  array (
    'to' => 1,
  ),
  'furniture' => 
  array (
    'of' => 1,
  ),
  'stunned' => 
  array (
    'silence' => 1,
  ),
  'images' => 
  array (
    '' => 1,
  ),
  'rushed' => 
  array (
    '' => 1,
    'out' => 1,
  ),
  'settle' => 
  array (
    'down' => 1,
  ),
  'Part' => 
  array (
    'of' => 1,
  ),
  'represented' => 
  array (
    'whilst' => 1,
  ),
  'sensibly' => 
  array (
    'refused' => 1,
  ),
  'countenance' => 
  array (
    'the' => 1,
  ),
  'abdicated' => 
  array (
    '' => 1,
  ),
  'responsibility' => 
  array (
    '' => 1,
  ),
  'doubt.' => 
  array (
    '-' => 1,
  ),
  'Mark' => 
  array (
    'Two' => 1,
  ),
  'cheerfully.' => 
  array (
    '-' => 1,
  ),
  'blueprints.' => 
  array (
    'There' => 1,
  ),
  'pause.' => 
  array (
    '-' => 2,
  ),
  'control,' => 
  array (
    '-' => 1,
  ),
  'originally...' => 
  array (
    'made' => 1,
  ),
  'place...' => 
  array (
    '' => 1,
  ),
  'Norway?' => 
  array (
    '-' => 1,
  ),
  'didn\'t.' => 
  array (
    '-' => 1,
  ),
  'Pity,' => 
  array (
    '-' => 2,
  ),
  'Won' => 
  array (
    '' => 1,
  ),
  'award' => 
  array (
    'you' => 1,
    'for' => 1,
  ),
  'Lovely' => 
  array (
    'crinkly' => 1,
  ),
  'edges.' => 
  array (
    '' => 1,
  ),
  'upset!' => 
  array (
    '-' => 1,
  ),
  'mattered' => 
  array (
    'so' => 1,
  ),
  'shocking' => 
  array (
    'cock-up.' => 1,
  ),
  'cock-up.' => 
  array (
    '-' => 1,
  ),
  'furious.' => 
  array (
    '-' => 1,
  ),
  'furious?' => 
  array (
    '-' => 1,
  ),
  'dogs' => 
  array (
    '' => 1,
  ),
  'cats' => 
  array (
    '' => 1,
  ),
  'duckbilled' => 
  array (
    'platypuses,' => 1,
  ),
  'platypuses,' => 
  array (
    'but...' => 1,
  ),
  'mad' => 
  array (
    'now?' => 1,
    'monkey.' => 1,
  ),
  'patiently' => 
  array (
    'to' => 1,
  ),
  'commissioned,' => 
  array (
    'paid' => 1,
  ),
  'mice.' => 
  array (
    'It' => 1,
    '' => 1,
    'His' => 1,
  ),
  'destroyed' => 
  array (
    'five' => 1,
    'the' => 1,
    '' => 1,
  ),
  'completion' => 
  array (
    '' => 1,
  ),
  'built,' => 
  array (
    'and' => 1,
  ),
  'Mice?' => 
  array (
    '-' => 1,
  ),
  'Indeed' => 
  array (
    'Earthman.' => 1,
  ),
  'sorry' => 
  array (
    '-' => 1,
  ),
  'cheese' => 
  array (
    'fixation' => 1,
    'and' => 1,
  ),
  'fixation' => 
  array (
    'and' => 1,
  ),
  'sixties' => 
  array (
    'sit' => 1,
    '' => 1,
  ),
  'coms?' => 
  array (
    'Slartibartfast' => 1,
  ),
  'coughed' => 
  array (
    'politely.' => 2,
  ),
  'politely.' => 
  array (
    '-' => 2,
  ),
  'follow' => 
  array (
    'your' => 1,
  ),
  'mode' => 
  array (
    '' => 1,
  ),
  'speech.' => 
  array (
    'Remember' => 1,
  ),
  'Remember' => 
  array (
    'I' => 1,
  ),
  'coms' => 
  array (
    '' => 1,
  ),
  'appear.' => 
  array (
    'They' => 1,
  ),
  'protrusion' => 
  array (
    'into' => 1,
  ),
  'hyperintelligent' => 
  array (
    'pandimensional' => 2,
    'pan-dimensional' => 1,
  ),
  'pandimensional' => 
  array (
    'beings.' => 1,
    '' => 1,
  ),
  'beings.' => 
  array (
    'The' => 1,
    '' => 1,
    'Presumably' => 1,
  ),
  'squeaking' => 
  array (
    'is' => 1,
  ),
  'front.' => 
  array (
    'The' => 1,
  ),
  'sympathetic' => 
  array (
    'frown' => 1,
  ),
  'frown' => 
  array (
    'continued.' => 1,
  ),
  'afraid.' => 
  array (
    'Arthur' => 1,
  ),
  'cleared.' => 
  array (
    '-' => 1,
  ),
  'misunderstanding' => 
  array (
    '' => 1,
  ),
  'research,' => 
  array (
    'Pavlov' => 1,
    '' => 1,
  ),
  'Pavlov' => 
  array (
    '' => 1,
  ),
  'sorts' => 
  array (
    'of' => 2,
  ),
  'ring' => 
  array (
    'bells,' => 1,
  ),
  'bells,' => 
  array (
    'run' => 1,
  ),
  'mazes' => 
  array (
    'and' => 1,
  ),
  'examined.' => 
  array (
    '' => 1,
  ),
  'observations' => 
  array (
    'of' => 1,
  ),
  'behaviour' => 
  array (
    'we' => 1,
  ),
  'learn' => 
  array (
    'all' => 1,
    'once' => 1,
  ),
  'own...' => 
  array (
    'Arthur\'s' => 1,
  ),
  'tailed' => 
  array (
    'off.' => 1,
  ),
  'Such' => 
  array (
    'subtlety...' => 1,
    'a' => 1,
  ),
  'subtlety...' => 
  array (
    '-' => 1,
  ),
  'admire' => 
  array (
    'it.' => 1,
  ),
  'disguise' => 
  array (
    'their' => 1,
  ),
  'natures,' => 
  array (
    'and' => 1,
  ),
  'thinking.' => 
  array (
    'Suddenly' => 1,
    'Here' => 1,
  ),
  'maze' => 
  array (
    '' => 1,
  ),
  'eating' => 
  array (
    '' => 1,
  ),
  'cheese,' => 
  array (
    'unexpectedly' => 1,
  ),
  'unexpectedly' => 
  array (
    'dropping' => 1,
    'to' => 1,
  ),
  'dropping' => 
  array (
    'dead' => 1,
  ),
  'myxomatosis,' => 
  array (
    '-' => 1,
  ),
  'enormous.' => 
  array (
    'He' => 1,
  ),
  'effect.' => 
  array (
    '-' => 1,
  ),
  'pan-dimensional' => 
  array (
    '' => 1,
    'universe' => 1,
  ),
  'Your' => 
  array (
    '' => 1,
    'task,' => 1,
    'arrival' => 1,
  ),
  'organic' => 
  array (
    '' => 1,
    'life' => 1,
    'part' => 2,
  ),
  'tenmillion-year' => 
  array (
    'research' => 1,
  ),
  'programme...' => 
  array (
    '-' => 1,
  ),
  'Time,' => 
  array (
    '-' => 1,
  ),
  25 => 
  array (
    'There' => 1,
  ),
  'connected' => 
  array (
    'with' => 1,
    'up' => 1,
  ),
  'life,' => 
  array (
    'of' => 1,
    '-' => 1,
  ),
  'born?' => 
  array (
    'Why' => 1,
  ),
  'watches?' => 
  array (
    'Many' => 1,
  ),
  '(whose' => 
  array (
    '' => 1,
  ),
  'manifestation' => 
  array (
    '' => 1,
  ),
  'dissimilar' => 
  array (
    'to' => 1,
  ),
  'own)' => 
  array (
    'got' => 1,
  ),
  'bickering' => 
  array (
    'about' => 1,
  ),
  'interrupt' => 
  array (
    'their' => 1,
  ),
  'favourite' => 
  array (
    'pastime' => 1,
  ),
  'pastime' => 
  array (
    'of' => 1,
  ),
  'Brockian' => 
  array (
    'Ultra' => 1,
  ),
  'Ultra' => 
  array (
    'Cricket' => 1,
  ),
  'Cricket' => 
  array (
    '(a' => 1,
  ),
  'hitting' => 
  array (
    'people' => 1,
  ),
  'readily' => 
  array (
    'apparent' => 1,
  ),
  'away)' => 
  array (
    'that' => 1,
  ),
  'stupendous' => 
  array (
    '' => 1,
  ),
  'super' => 
  array (
    '' => 1,
  ),
  'rice' => 
  array (
    'pudding' => 1,
  ),
  'pudding' => 
  array (
    'and' => 1,
  ),
  'income' => 
  array (
    'tax' => 1,
  ),
  'city.' => 
  array (
    'Its' => 1,
  ),
  'installed' => 
  array (
    '' => 1,
  ),
  'specially' => 
  array (
    '' => 1,
  ),
  'executive' => 
  array (
    'office,' => 1,
    '' => 1,
  ),
  'office,' => 
  array (
    'mounted' => 1,
  ),
  'mounted' => 
  array (
    'on' => 1,
    '' => 1,
  ),
  'ultramahagony' => 
  array (
    'topped' => 1,
    'desk' => 1,
  ),
  'topped' => 
  array (
    'with' => 1,
  ),
  'ultrared' => 
  array (
    '' => 1,
  ),
  'leather.' => 
  array (
    '' => 1,
  ),
  'carpeting' => 
  array (
    '' => 1,
  ),
  'discreetly' => 
  array (
    'sumptuous,' => 1,
    'into' => 1,
  ),
  'sumptuous,' => 
  array (
    'exotic' => 1,
  ),
  'plants' => 
  array (
    '' => 1,
  ),
  'tastefully' => 
  array (
    '' => 1,
  ),
  'engraved' => 
  array (
    '' => 1,
  ),
  'prints' => 
  array (
    '' => 1,
  ),
  'principal' => 
  array (
    'computer' => 1,
  ),
  'programmers' => 
  array (
    'and' => 1,
    'with' => 1,
    'sat' => 1,
  ),
  'liberally' => 
  array (
    'about' => 1,
  ),
  'stately' => 
  array (
    'windows' => 1,
    '' => 1,
  ),
  'tree-lined' => 
  array (
    '' => 1,
  ),
  'square.' => 
  array (
    'On' => 1,
  ),
  'On-Turning' => 
  array (
    'two' => 1,
  ),
  'soberly' => 
  array (
    '' => 1,
  ),
  'brief' => 
  array (
    'cases' => 1,
    '' => 1,
    'nod' => 1,
  ),
  'cases' => 
  array (
    'arrived' => 1,
    'and' => 1,
  ),
  'shown' => 
  array (
    'discreetly' => 1,
  ),
  'office.' => 
  array (
    '' => 1,
  ),
  'represent' => 
  array (
    'their' => 1,
  ),
  'conducted' => 
  array (
    'themselves' => 1,
  ),
  'calmly' => 
  array (
    'and' => 1,
  ),
  'desk,' => 
  array (
    'opened' => 1,
  ),
  'leather-bound' => 
  array (
    'notebooks.' => 1,
  ),
  'notebooks.' => 
  array (
    'Their' => 1,
  ),
  'Lunkwill' => 
  array (
    'and' => 3,
    'leaned' => 2,
    'cleared' => 1,
    'motioned' => 1,
  ),
  'Fook.' => 
  array (
    'For' => 1,
    '-' => 3,
  ),
  'respectful' => 
  array (
    '' => 1,
  ),
  'exchanging' => 
  array (
    'a' => 1,
  ),
  'glance' => 
  array (
    'with' => 1,
  ),
  'Fook,' => 
  array (
    'Lunkwill' => 1,
    '-' => 1,
  ),
  'leaned' => 
  array (
    'forward' => 3,
  ),
  'subtlest' => 
  array (
    'of' => 1,
  ),
  'hums' => 
  array (
    'indicated' => 1,
  ),
  'indicated' => 
  array (
    'that' => 1,
  ),
  'active' => 
  array (
    'mode.' => 1,
  ),
  'pause' => 
  array (
    'it' => 1,
    'whilst' => 1,
  ),
  'spoke' => 
  array (
    'to' => 1,
    '' => 1,
  ),
  'resonant' => 
  array (
    'and' => 1,
  ),
  'deep.' => 
  array (
    'It' => 1,
  ),
  'task' => 
  array (
    'for' => 1,
    'we' => 1,
  ),
  'Thought,' => 
  array (
    '' => 3,
    '-' => 6,
    'and' => 1,
    'with' => 1,
  ),
  'Space' => 
  array (
    'have' => 1,
    'and' => 1,
  ),
  'existence?' => 
  array (
    'Lunkwill' => 1,
  ),
  'Fook' => 
  array (
    'glanced' => 2,
    'leaning' => 1,
    'was' => 1,
    'sighed' => 1,
    'composed' => 1,
    'with' => 1,
    'blinked' => 1,
  ),
  'O' => 
  array (
    'Computer...' => 1,
    'Deep' => 2,
    'people' => 1,
  ),
  'Lunkwill,' => 
  array (
    'worried.' => 1,
    'rising' => 1,
  ),
  'best.' => 
  array (
    'Deep' => 1,
  ),
  'addressed' => 
  array (
    'the' => 1,
  ),
  'greatest,' => 
  array (
    '-' => 1,
  ),
  'am.' => 
  array (
    'Another' => 1,
    '-' => 1,
  ),
  'programmers.' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'mistake,' => 
  array (
    '-' => 1,
    'and' => 1,
  ),
  'Milliard' => 
  array (
    'Gargantubrain' => 1,
    'Gargantubrain?' => 1,
  ),
  'Gargantubrain' => 
  array (
    'which' => 1,
  ),
  'millisecond?' => 
  array (
    '-' => 1,
  ),
  'Gargantubrain?' => 
  array (
    '-' => 1,
  ),
  'Thought' => 
  array (
    '' => 1,
    'haughtily.' => 1,
    'thoroughly' => 1,
    'with' => 2,
    'Computer,' => 1,
    'paused' => 1,
    'is' => 1,
    'at' => 1,
    'majestically.' => 1,
    'mildly.' => 1,
    'pondered' => 2,
    'designed' => 1,
  ),
  'unconcealed' => 
  array (
    'contempt.' => 1,
  ),
  'contempt.' => 
  array (
    '-' => 1,
  ),
  'abacus' => 
  array (
    '-' => 1,
  ),
  'leaning' => 
  array (
    'anxiously' => 1,
  ),
  'anxiously' => 
  array (
    'forward,' => 1,
  ),
  'forward,' => 
  array (
    '-' => 1,
  ),
  'analyst' => 
  array (
    'than' => 1,
  ),
  'Googleplex' => 
  array (
    'Star' => 1,
  ),
  'Thinker' => 
  array (
    'in' => 1,
  ),
  'Seventh' => 
  array (
    '' => 1,
  ),
  'Ingenuity' => 
  array (
    'which' => 1,
  ),
  'calculate' => 
  array (
    'the' => 2,
    '-' => 1,
  ),
  'five-week' => 
  array (
    'Dangrabad' => 1,
    'sand' => 1,
  ),
  'Dangrabad' => 
  array (
    'Beta' => 1,
  ),
  'Beta' => 
  array (
    'sand' => 1,
  ),
  'blizzard?' => 
  array (
    '-' => 2,
  ),
  'haughtily.' => 
  array (
    '-' => 1,
  ),
  'contemplated' => 
  array (
    'the' => 1,
  ),
  'vectors' => 
  array (
    'of' => 1,
  ),
  'itself?' => 
  array (
    'Molest' => 1,
  ),
  'Molest' => 
  array (
    'me' => 1,
  ),
  'pocket' => 
  array (
    'calculator' => 1,
    'money.' => 1,
  ),
  'calculator' => 
  array (
    'stuff.' => 1,
  ),
  'fiendish' => 
  array (
    '' => 1,
  ),
  'disputant' => 
  array (
    '' => 1,
  ),
  'Hyperlobic' => 
  array (
    'Omni-Cognate' => 2,
  ),
  'Omni-Cognate' => 
  array (
    'Neutron' => 2,
  ),
  'Neutron' => 
  array (
    '' => 2,
  ),
  'Wrangler' => 
  array (
    '' => 1,
  ),
  'Ciceronicus' => 
  array (
    '' => 1,
  ),
  '12,' => 
  array (
    '' => 1,
  ),
  'Magic' => 
  array (
    'and' => 1,
  ),
  'Indefatigable?' => 
  array (
    '-' => 1,
  ),
  'Wrangler,' => 
  array (
    '' => 1,
  ),
  'r\'s,' => 
  array (
    '-' => 1,
  ),
  'MegaDonkey' => 
  array (
    '-' => 1,
  ),
  'persuade' => 
  array (
    '' => 1,
  ),
  'what,' => 
  array (
    '-' => 1,
  ),
  'problem?' => 
  array (
    '-' => 2,
  ),
  'magnificent' => 
  array (
    '' => 1,
  ),
  'tones.' => 
  array (
    '-' => 2,
  ),
  'Time.' => 
  array (
    '-' => 1,
  ),
  'second?' => 
  array (
    '-' => 1,
    'You\'re' => 1,
  ),
  'Lunkwill.' => 
  array (
    '-' => 5,
  ),
  'surely' => 
  array (
    'not' => 1,
    'that\'s' => 1,
  ),
  'Multicorticoid' => 
  array (
    '' => 1,
  ),
  'Perspicutron' => 
  array (
    'Titan' => 1,
  ),
  'Titan' => 
  array (
    'Muller' => 1,
  ),
  'Muller' => 
  array (
    'are' => 1,
  ),
  'Pondermatic?' => 
  array (
    'Or' => 1,
  ),
  'Contemptuous' => 
  array (
    'lights' => 1,
  ),
  'computer\'s' => 
  array (
    'console.' => 1,
  ),
  'spare' => 
  array (
    '' => 1,
  ),
  'unit' => 
  array (
    '' => 1,
  ),
  'cybernetic' => 
  array (
    'simpletons!' => 1,
  ),
  'simpletons!' => 
  array (
    '-' => 1,
  ),
  'losing' => 
  array (
    'patience.' => 1,
  ),
  'patience.' => 
  array (
    'He' => 1,
  ),
  'needlessly' => 
  array (
    'messianic.' => 1,
  ),
  'messianic.' => 
  array (
    '-' => 1,
  ),
  'teeming' => 
  array (
    'circuitry' => 1,
  ),
  'circuitry' => 
  array (
    'I' => 1,
  ),
  'navigate' => 
  array (
    'the' => 1,
    'its' => 1,
  ),
  'streams' => 
  array (
    '' => 1,
  ),
  'operational' => 
  array (
    'parameters' => 2,
    'matrix.' => 1,
  ),
  'parameters' => 
  array (
    'I' => 2,
  ),
  'worthy' => 
  array (
    'to' => 2,
  ),
  'calculate,' => 
  array (
    'but' => 1,
  ),
  'design.' => 
  array (
    'Fook' => 1,
  ),
  'question?' => 
  array (
    '-' => 2,
  ),
  'wait.' => 
  array (
    '-' => 1,
  ),
  'speak?' => 
  array (
    '-' => 1,
  ),
  'Thought.' => 
  array (
    '-' => 11,
    'Lunkwill' => 1,
    'They' => 2,
  ),
  'Ask' => 
  array (
    'what' => 1,
  ),
  'function.' => 
  array (
    'Speak.' => 1,
  ),
  'Speak.' => 
  array (
    'They' => 1,
  ),
  'composed' => 
  array (
    'himself.' => 1,
    '' => 1,
    'themselves,' => 1,
  ),
  '...the' => 
  array (
    'Answer!' => 1,
  ),
  'Answer!' => 
  array (
    '-' => 1,
    'Hurrahs' => 1,
  ),
  'answer?' => 
  array (
    '-' => 3,
  ),
  'Universe!' => 
  array (
    '-' => 1,
  ),
  'Everything!' => 
  array (
    '-' => 2,
    'As' => 1,
  ),
  'chorus.' => 
  array (
    'Deep' => 1,
    '-' => 1,
  ),
  'reflection.' => 
  array (
    '-' => 1,
  ),
  'Tricky,' => 
  array (
    '-' => 2,
  ),
  'finally.' => 
  array (
    '-' => 1,
  ),
  'significant' => 
  array (
    'pause.' => 1,
    'without' => 1,
  ),
  'breathless' => 
  array (
    'excitement.' => 1,
  ),
  'Everything.' => 
  array (
    'There' => 1,
  ),
  'commotion' => 
  array (
    'destroyed' => 1,
  ),
  'moment:' => 
  array (
    'the' => 1,
  ),
  'coarse' => 
  array (
    'faded-blue' => 1,
  ),
  'faded-blue' => 
  array (
    'robes' => 1,
  ),
  'robes' => 
  array (
    'and' => 1,
  ),
  'Cruxwan' => 
  array (
    'University' => 1,
  ),
  'thrusting' => 
  array (
    'aside' => 1,
  ),
  'ineffectual' => 
  array (
    '' => 1,
  ),
  'flunkies' => 
  array (
    'who' => 1,
  ),
  'admission!' => 
  array (
    '-' => 1,
  ),
  'younger' => 
  array (
    'of' => 1,
    '' => 1,
    'one.' => 1,
  ),
  'elbowing' => 
  array (
    'a' => 1,
  ),
  'secretary' => 
  array (
    'in' => 1,
  ),
  'older' => 
  array (
    'one,' => 1,
    'one.' => 1,
  ),
  'junior' => 
  array (
    'programmer' => 1,
  ),
  'programmer' => 
  array (
    'back' => 1,
  ),
  'angrily' => 
  array (
    'from' => 1,
  ),
  'want?' => 
  array (
    '-' => 1,
  ),
  'Majikthise!' => 
  array (
    '-' => 1,
  ),
  'Vroomfondel!' => 
  array (
    '-' => 2,
  ),
  'Majikthise' => 
  array (
    'turned' => 1,
    '' => 1,
  ),
  'Vroomfondel.' => 
  array (
    '-' => 2,
  ),
  'angrily,' => 
  array (
    '-' => 1,
  ),
  'Alright!' => 
  array (
    '-' => 1,
  ),
  'Vroomfondel' => 
  array (
    'banging' => 1,
    'shouted,' => 1,
    'waving' => 1,
    'in' => 1,
    'and' => 1,
  ),
  'banging' => 
  array (
    'on' => 1,
  ),
  'desk.' => 
  array (
    '' => 1,
  ),
  'Vroomfondel,' => 
  array (
    'and' => 1,
    '-' => 2,
    'why' => 1,
  ),
  'demand,' => 
  array (
    'that' => 1,
    '-' => 1,
  ),
  'solid' => 
  array (
    '' => 1,
    'facts!' => 2,
    'facts.' => 1,
    'glass' => 1,
    'gold' => 1,
    'gold.' => 1,
    'blaze' => 1,
    'silver' => 1,
    'world' => 1,
  ),
  'fact!' => 
  array (
    '' => 1,
  ),
  'facts!' => 
  array (
    '-' => 1,
    'What' => 1,
  ),
  'demand!' => 
  array (
    'Scarcely' => 1,
  ),
  'Scarcely' => 
  array (
    'pausing' => 1,
  ),
  'pausing' => 
  array (
    'for' => 1,
    'to' => 1,
  ),
  'absence' => 
  array (
    '' => 1,
  ),
  'facts.' => 
  array (
    'I' => 1,
  ),
  'devil' => 
  array (
    'are' => 1,
  ),
  'outraged' => 
  array (
    'Fook.' => 1,
  ),
  'We,' => 
  array (
    '-' => 1,
  ),
  'Majikthise,' => 
  array (
    '-' => 3,
    '' => 1,
    'the' => 1,
  ),
  'Philosophers.' => 
  array (
    '-' => 1,
  ),
  'warning' => 
  array (
    'finger' => 1,
  ),
  'Majikthise.' => 
  array (
    '-' => 1,
    '' => 1,
    'So' => 1,
  ),
  'representatives' => 
  array (
    '' => 1,
  ),
  'Amalgamated' => 
  array (
    '' => 1,
  ),
  'Union' => 
  array (
    '' => 1,
  ),
  'Philosophers,' => 
  array (
    '' => 1,
  ),
  'Sages,' => 
  array (
    'Luminaries' => 1,
  ),
  'Luminaries' => 
  array (
    'and' => 1,
  ),
  'Other' => 
  array (
    'Thinking' => 1,
  ),
  'Thinking' => 
  array (
    'Persons,' => 1,
  ),
  'Persons,' => 
  array (
    'and' => 1,
  ),
  'mate,' => 
  array (
    '' => 1,
    'you' => 1,
  ),
  'demarcation,' => 
  array (
    'that\'s' => 1,
  ),
  'problem!' => 
  array (
    '-' => 2,
  ),
  'demarcation' => 
  array (
    'may' => 1,
  ),
  'adding' => 
  array (
    '' => 1,
  ),
  'eternal' => 
  array (
    'verities' => 1,
  ),
  'verities' => 
  array (
    'thank' => 1,
  ),
  'check' => 
  array (
    'your' => 1,
  ),
  'legal' => 
  array (
    'position' => 1,
  ),
  'mate.' => 
  array (
    '' => 1,
  ),
  'Under' => 
  array (
    '' => 1,
  ),
  'law' => 
  array (
    '' => 1,
  ),
  'Quest' => 
  array (
    'for' => 1,
  ),
  'Ultimate' => 
  array (
    'Truth' => 1,
    'Question' => 4,
    'Question?' => 1,
    'Answer,' => 1,
    'Question.' => 1,
  ),
  'Truth' => 
  array (
    'is' => 1,
  ),
  'inalienable' => 
  array (
    '' => 1,
  ),
  'prerogative' => 
  array (
    '' => 1,
  ),
  'thinkers.' => 
  array (
    'Any' => 1,
  ),
  'finds' => 
  array (
    '' => 1,
  ),
  'bleeding' => 
  array (
    '' => 1,
  ),
  'morning?' => 
  array (
    '-' => 1,
  ),
  'right!' => 
  array (
    '-' => 1,
    '' => 1,
  ),
  'rigidly' => 
  array (
    '' => 1,
  ),
  'areas' => 
  array (
    'of' => 1,
  ),
  'uncertainty!' => 
  array (
    'Suddenly' => 1,
  ),
  'stentorian' => 
  array (
    'voice' => 1,
  ),
  'boomed' => 
  array (
    'across' => 1,
  ),
  'Might' => 
  array (
    'I' => 1,
  ),
  'strike!' => 
  array (
    '-' => 1,
  ),
  'national' => 
  array (
    'Philosopher\'s' => 1,
  ),
  'Philosopher\'s' => 
  array (
    'strike' => 1,
  ),
  'strike' => 
  array (
    'on' => 1,
  ),
  'hands!' => 
  array (
    'The' => 1,
  ),
  'increased' => 
  array (
    '' => 1,
  ),
  'ancillary' => 
  array (
    'bass' => 1,
  ),
  'bass' => 
  array (
    'driver' => 1,
  ),
  'units,' => 
  array (
    '' => 1,
  ),
  'sedately' => 
  array (
    '' => 1,
  ),
  'varnished' => 
  array (
    '' => 1,
  ),
  'speakers' => 
  array (
    'around' => 1,
  ),
  'Thought\'s' => 
  array (
    '' => 1,
  ),
  'irrevocably' => 
  array (
    'committed' => 1,
  ),
  'committed' => 
  array (
    'to' => 1,
    'suicide,' => 1,
  ),
  'calculating' => 
  array (
    'the' => 1,
  ),
  'Question' => 
  array (
    'of' => 2,
    '' => 1,
    'to' => 1,
    'in' => 1,
    'that' => 1,
  ),
  'attention,' => 
  array (
    '' => 1,
  ),
  'continuing' => 
  array (
    '' => 1,
  ),
  'run.' => 
  array (
    'Fook' => 1,
  ),
  'watch.' => 
  array (
    '-' => 1,
  ),
  'years!..' => 
  array (
    '-' => 1,
  ),
  'declaimed' => 
  array (
    'Deep' => 1,
  ),
  'occurs' => 
  array (
    'to' => 1,
  ),
  'publicity' => 
  array (
    'for' => 1,
  ),
  'philosophy' => 
  array (
    'in' => 1,
  ),
  'general.' => 
  array (
    'Everyone\'s' => 1,
  ),
  'Everyone\'s' => 
  array (
    'going' => 1,
  ),
  'capitalize' => 
  array (
    'on' => 1,
  ),
  'media' => 
  array (
    '' => 1,
  ),
  'yourself?' => 
  array (
    '' => 1,
  ),
  'disagreeing' => 
  array (
    'with' => 1,
  ),
  'slagging' => 
  array (
    'each' => 1,
  ),
  'press,' => 
  array (
    'you' => 1,
  ),
  'gravy' => 
  array (
    'train' => 1,
  ),
  'train' => 
  array (
    '' => 1,
  ),
  'philosophers' => 
  array (
    'gaped' => 1,
  ),
  'gaped' => 
  array (
    'at' => 3,
  ),
  'Bloody' => 
  array (
    'hell,' => 1,
  ),
  'Dunno,' => 
  array (
    '-' => 3,
    'do' => 1,
  ),
  'awed' => 
  array (
    'whisper,' => 1,
  ),
  'trained' => 
  array (
    'Majikthise.' => 1,
    'for' => 1,
  ),
  'heels' => 
  array (
    'and' => 1,
  ),
  'lifestyle' => 
  array (
    'beyond' => 1,
    'otherwise.' => 1,
    'drifted' => 1,
    '' => 1,
  ),
  'dreams.' => 
  array (
    'Chapter' => 1,
  ),
  26 => 
  array (
    '-' => 1,
  ),
  'salutary,' => 
  array (
    '-' => 1,
  ),
  'salient' => 
  array (
    'points' => 1,
  ),
  'Answer,' => 
  array (
    'allow' => 1,
    'a' => 1,
  ),
  'study' => 
  array (
    'where' => 1,
    'was' => 1,
    'the' => 1,
  ),
  'events' => 
  array (
    'yourself' => 1,
  ),
  'Sens-O-Tape' => 
  array (
    'records.' => 1,
  ),
  'records.' => 
  array (
    'That' => 1,
  ),
  'stroll' => 
  array (
    '' => 1,
  ),
  'completed' => 
  array (
    'I\'m' => 1,
  ),
  'burying' => 
  array (
    'the' => 1,
  ),
  'dinosaur' => 
  array (
    'skeletons' => 1,
  ),
  'skeletons' => 
  array (
    'in' => 1,
  ),
  'crust' => 
  array (
    '' => 1,
  ),
  'Tertiary' => 
  array (
    'and' => 1,
  ),
  'Quarternary' => 
  array (
    'Periods' => 1,
  ),
  'Periods' => 
  array (
    'of' => 1,
  ),
  'Cenozoic' => 
  array (
    '' => 1,
  ),
  'Era' => 
  array (
    '' => 1,
  ),
  'same.' => 
  array (
    '-' => 1,
  ),
  'mind-numbing' => 
  array (
    'wall.' => 1,
  ),
  27 => 
  array (
    'Slartibartfast\'s' => 1,
  ),
  'Slartibartfast\'s' => 
  array (
    'study' => 1,
  ),
  'library.' => 
  array (
    'The' => 1,
  ),
  'Terribly' => 
  array (
    'unfortunate,' => 1,
  ),
  'unfortunate,' => 
  array (
    '-' => 1,
  ),
  'diode' => 
  array (
    '' => 1,
  ),
  'life-support' => 
  array (
    'computers.' => 1,
    '' => 1,
  ),
  'cleaning' => 
  array (
    '' => 1,
  ),
  'bodies,' => 
  array (
    'that\'s' => 1,
  ),
  'plug' => 
  array (
    'you' => 1,
  ),
  'gestured' => 
  array (
    'Arthur' => 1,
  ),
  'rib' => 
  array (
    'cage' => 2,
  ),
  'stegosaurus.' => 
  array (
    '-' => 1,
  ),
  'stegosaurus,' => 
  array (
    '-' => 1,
  ),
  'pottered' => 
  array (
    'about' => 1,
  ),
  'fishing' => 
  array (
    'bits' => 1,
  ),
  'wire' => 
  array (
    'out' => 1,
    'end' => 1,
  ),
  'tottering' => 
  array (
    'piles' => 1,
  ),
  'drawing' => 
  array (
    'instruments.' => 1,
  ),
  'these,' => 
  array (
    '-' => 1,
  ),
  'stripped' => 
  array (
    'wire' => 1,
  ),
  'bird' => 
  array (
    'flew' => 1,
  ),
  'mid-air' => 
  array (
    'and' => 1,
  ),
  'treelined' => 
  array (
    'city' => 1,
  ),
  'square,' => 
  array (
    'and' => 1,
  ),
  'eye' => 
  array (
    'could' => 1,
    'Phouchg' => 1,
    'and' => 1,
  ),
  'concrete' => 
  array (
    'buildings' => 1,
  ),
  'airy' => 
  array (
    '' => 1,
  ),
  'design' => 
  array (
    '' => 2,
    'this' => 1,
    'awards.' => 2,
    'coastlines.' => 1,
  ),
  'wear' => 
  array (
    '-' => 1,
  ),
  'stained' => 
  array (
    '' => 1,
  ),
  'shining,' => 
  array (
    'a' => 1,
  ),
  'breeze' => 
  array (
    'danced' => 1,
    'and' => 1,
  ),
  'trees,' => 
  array (
    'and' => 1,
  ),
  'thronged' => 
  array (
    'with' => 1,
  ),
  'band' => 
  array (
    'was' => 1,
  ),
  'playing,' => 
  array (
    'brightly' => 1,
  ),
  'flags' => 
  array (
    'were' => 1,
  ),
  'fluttering' => 
  array (
    '' => 1,
  ),
  'carnival' => 
  array (
    'was' => 1,
  ),
  'rang' => 
  array (
    'out' => 1,
  ),
  'dais' => 
  array (
    'before' => 1,
    '' => 1,
  ),
  'dominated' => 
  array (
    'the' => 1,
  ),
  'Tannoy.' => 
  array (
    '-' => 1,
  ),
  'waiting' => 
  array (
    'in' => 1,
    'had' => 1,
    'room' => 1,
    'for' => 1,
    '' => 2,
  ),
  'Shadow' => 
  array (
    'of' => 1,
  ),
  'Thought!' => 
  array (
    '-' => 1,
  ),
  'Honoured' => 
  array (
    'Descendants' => 1,
  ),
  'Descendants' => 
  array (
    'of' => 1,
  ),
  'Truly' => 
  array (
    'Interesting' => 1,
  ),
  'Interesting' => 
  array (
    'Pundits' => 1,
  ),
  'Pundits' => 
  array (
    'the' => 1,
  ),
  'known...' => 
  array (
    '' => 1,
  ),
  'Waiting' => 
  array (
    'is' => 1,
  ),
  'over!' => 
  array (
    'Wild' => 1,
  ),
  'cheers' => 
  array (
    'broke' => 1,
  ),
  'Flags,' => 
  array (
    '' => 1,
  ),
  'streamers' => 
  array (
    '' => 1,
  ),
  'wolf' => 
  array (
    'whistles' => 1,
  ),
  'whistles' => 
  array (
    'sailed' => 1,
  ),
  'narrower' => 
  array (
    'streets' => 1,
  ),
  'centipedes' => 
  array (
    'rolled' => 1,
  ),
  'frantically' => 
  array (
    'waving' => 1,
  ),
  'Hopefully' => 
  array (
    'Enlightening' => 1,
  ),
  'Enlightening' => 
  array (
    'Day!' => 1,
  ),
  'Day!' => 
  array (
    '-' => 1,
  ),
  'cheer' => 
  array (
    'leader.' => 1,
  ),
  'leader.' => 
  array (
    '-' => 1,
  ),
  'Day' => 
  array (
    'of' => 1,
  ),
  'Hurrahs' => 
  array (
    'burst' => 1,
  ),
  'ecstatic' => 
  array (
    'crowd.' => 1,
  ),
  'cosmically' => 
  array (
    'speaking,' => 1,
  ),
  'work?' => 
  array (
    'For' => 1,
    '-' => 1,
  ),
  'plain' => 
  array (
    'and' => 1,
  ),
  'erupted' => 
  array (
    'once' => 1,
  ),
  'speaker' => 
  array (
    '' => 1,
  ),
  'panic' => 
  array (
    'as' => 1,
  ),
  'touching' => 
  array (
    'it.' => 1,
  ),
  'remarked' => 
  array (
    'on' => 1,
  ),
  'arrival,' => 
  array (
    'which' => 1,
  ),
  'surprising' => 
  array (
    'as' => 1,
  ),
  'projection' => 
  array (
    '' => 1,
  ),
  'six-track' => 
  array (
    'seventy-millimetre' => 1,
  ),
  'seventy-millimetre' => 
  array (
    'into' => 1,
  ),
  'hat.' => 
  array (
    'The' => 1,
  ),
  'cleaned' => 
  array (
    '' => 1,
  ),
  'regularly' => 
  array (
    'every' => 1,
  ),
  'worn' => 
  array (
    '' => 1,
  ),
  'edges,' => 
  array (
    '' => 1,
  ),
  'carpet' => 
  array (
    'a' => 1,
  ),
  'faded' => 
  array (
    '' => 1,
  ),
  'sparkling' => 
  array (
    'glory' => 1,
  ),
  'glory' => 
  array (
    'on' => 1,
  ),
  'desk\'s' => 
  array (
    'leather' => 1,
  ),
  'severely' => 
  array (
    'dressed' => 1,
  ),
  'respectfully' => 
  array (
    '' => 1,
  ),
  'materialize' => 
  array (
    'in' => 1,
  ),
  'Loonquawl,' => 
  array (
    'and' => 1,
    '-' => 1,
  ),
  'assimilate' => 
  array (
    'this' => 1,
  ),
  'Phouchg' => 
  array (
    'appeared' => 1,
    '' => 1,
    'weakly.' => 1,
    'flinging' => 1,
    'gaped' => 1,
  ),
  'Seventy-five' => 
  array (
    'thousand' => 1,
  ),
  'ago,' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'ancestors' => 
  array (
    '' => 1,
  ),
  'program' => 
  array (
    'in' => 1,
    'was' => 1,
    'it' => 1,
  ),
  'motion,' => 
  array (
    '-' => 1,
  ),
  'awesome' => 
  array (
    'prospect,' => 1,
  ),
  'prospect,' => 
  array (
    'Phouchg,' => 1,
  ),
  'Phouchg,' => 
  array (
    '-' => 2,
  ),
  'recording' => 
  array (
    'with' => 1,
    'he' => 1,
  ),
  'subtitles.' => 
  array (
    '-' => 1,
  ),
  'hear,' => 
  array (
    '-' => 1,
  ),
  'Life!..' => 
  array (
    '-' => 1,
  ),
  'Universe!..' => 
  array (
    '-' => 1,
  ),
  'Loonquawl.' => 
  array (
    '-' => 4,
    'Deep' => 1,
  ),
  'Everything!..' => 
  array (
    '-' => 1,
  ),
  'Loonquawl' => 
  array (
    'with' => 1,
    '' => 1,
    'too' => 1,
  ),
  'preparing' => 
  array (
    'to' => 1,
  ),
  'speak!' => 
  array (
    'There' => 1,
  ),
  'expectant' => 
  array (
    'pause' => 1,
    'faces' => 1,
  ),
  'Lights' => 
  array (
    'flashed' => 1,
  ),
  'experimentally' => 
  array (
    'and' => 1,
  ),
  'businesslike' => 
  array (
    'pattern.' => 1,
  ),
  'pattern.' => 
  array (
    'A' => 1,
  ),
  'channel.' => 
  array (
    '-' => 1,
  ),
  'nervously,' => 
  array (
    '' => 1,
    'he' => 1,
  ),
  'have...' => 
  array (
    'er,' => 1,
  ),
  'majestically.' => 
  array (
    '-' => 1,
  ),
  'expectancy.' => 
  array (
    'Their' => 1,
  ),
  'vain.' => 
  array (
    '-' => 1,
  ),
  'Phouchg.' => 
  array (
    '-' => 2,
  ),
  'confirmed' => 
  array (
    'Deep' => 1,
  ),
  'Everything?' => 
  array (
    'To' => 1,
    '-' => 2,
  ),
  'Both' => 
  array (
    'of' => 1,
    'men' => 1,
  ),
  'preparation' => 
  array (
    'for' => 1,
  ),
  'selected' => 
  array (
    'at' => 1,
  ),
  'birth' => 
  array (
    '' => 1,
  ),
  'witness' => 
  array (
    'the' => 1,
  ),
  'answer,' => 
  array (
    'but' => 1,
  ),
  'children.' => 
  array (
    '-' => 1,
  ),
  'Now?' => 
  array (
    '-' => 2,
  ),
  'Now,' => 
  array (
    '-' => 2,
    'Earth' => 1,
    'listen' => 1,
  ),
  'licked' => 
  array (
    'their' => 1,
  ),
  'lips.' => 
  array (
    '-' => 1,
  ),
  'matter!' => 
  array (
    '-' => 1,
  ),
  'Now!' => 
  array (
    '-' => 1,
  ),
  'Yes!' => 
  array (
    'Now...' => 1,
    '-' => 1,
    'Deep' => 1,
    '' => 1,
  ),
  'Now...' => 
  array (
    '-' => 1,
  ),
  'fidgeted.' => 
  array (
    'The' => 1,
  ),
  'unbearable.' => 
  array (
    '-' => 1,
  ),
  'observed' => 
  array (
    'Deep' => 1,
  ),
  'Answer' => 
  array (
    'to' => 2,
  ),
  'Question...' => 
  array (
    '-' => 1,
  ),
  'Yes!..' => 
  array (
    '-' => 3,
  ),
  'Everything...' => 
  array (
    '-' => 1,
    '' => 2,
  ),
  'Is...' => 
  array (
    '-' => 2,
  ),
  'Yes!!!?..' => 
  array (
    '-' => 1,
  ),
  'Forty-two,' => 
  array (
    '-' => 1,
    'then' => 1,
  ),
  'majesty' => 
  array (
    'and' => 1,
  ),
  'calm.' => 
  array (
    'Chapter' => 1,
  ),
  28 => 
  array (
    'It' => 1,
  ),
  'spoke.' => 
  array (
    'Out' => 1,
  ),
  'tense' => 
  array (
    'expectant' => 1,
  ),
  'outside.' => 
  array (
    '-' => 1,
  ),
  'tough' => 
  array (
    'assignment,' => 1,
  ),
  'assignment,' => 
  array (
    '-' => 1,
  ),
  'Forty-two!' => 
  array (
    '-' => 1,
  ),
  'years\'' => 
  array (
    'work?' => 1,
  ),
  'thoroughly,' => 
  array (
    '-' => 1,
  ),
  'honest' => 
  array (
    '' => 1,
  ),
  'Question!' => 
  array (
    'The' => 1,
  ),
  'howled' => 
  array (
    'Loonquawl.' => 1,
    '' => 1,
  ),
  'suffers' => 
  array (
    '' => 1,
  ),
  'fools' => 
  array (
    'gladly,' => 1,
  ),
  'gladly,' => 
  array (
    '-' => 1,
  ),
  'stupefied' => 
  array (
    'silence' => 1,
  ),
  'Exactly!' => 
  array (
    '-' => 1,
  ),
  'means.' => 
  array (
    '-' => 1,
  ),
  'flinging' => 
  array (
    '' => 1,
  ),
  'wiping' => 
  array (
    'away' => 1,
  ),
  'tear.' => 
  array (
    '-' => 1,
  ),
  'Question?' => 
  array (
    '-' => 2,
  ),
  'pondered' => 
  array (
    'this' => 2,
  ),
  'Finally:' => 
  array (
    '-' => 1,
  ),
  'chairs' => 
  array (
    'in' => 1,
  ),
  'despair.' => 
  array (
    '-' => 1,
  ),
  'Who?' => 
  array (
    '-' => 1,
  ),
  'non-existent' => 
  array (
    'scalp' => 1,
  ),
  'scalp' => 
  array (
    'begin' => 1,
  ),
  'crawl' => 
  array (
    'as' => 1,
  ),
  'inexorably' => 
  array (
    'forward' => 1,
  ),
  'console,' => 
  array (
    'but' => 1,
  ),
  'dramatic' => 
  array (
    'zoom' => 1,
  ),
  'zoom' => 
  array (
    'on' => 1,
  ),
  'assumed.' => 
  array (
    '-' => 1,
  ),
  'regaining' => 
  array (
    '' => 1,
  ),
  'accustomed' => 
  array (
    '' => 1,
  ),
  'declamatory' => 
  array (
    'tones.' => 1,
  ),
  'complexity' => 
  array (
    'that' => 1,
  ),
  'matrix.' => 
  array (
    'And' => 1,
  ),
  'yourselves' => 
  array (
    'shall' => 1,
    '' => 1,
  ),
  'ten-million-year' => 
  array (
    'program!' => 1,
  ),
  'program!' => 
  array (
    'Yes!' => 1,
  ),
  'unto' => 
  array (
    '' => 1,
  ),
  'called...' => 
  array (
    'The' => 1,
  ),
  'incisions' => 
  array (
    'appeared' => 1,
  ),
  'body.' => 
  array (
    'Loonquawl' => 1,
  ),
  'horrific' => 
  array (
    'gashed' => 1,
  ),
  'gashed' => 
  array (
    '' => 1,
  ),
  'blotched' => 
  array (
    'and' => 1,
  ),
  'cracked,' => 
  array (
    '' => 1,
  ),
  'flickered' => 
  array (
    'and' => 1,
    '' => 1,
  ),
  'crumbled' => 
  array (
    'and' => 1,
  ),
  'crashed' => 
  array (
    'upwards' => 1,
  ),
  'upwards' => 
  array (
    'into' => 1,
  ),
  'ceiling...' => 
  array (
    'Slartibartfast' => 1,
  ),
  'wires.' => 
  array (
    '-' => 1,
  ),
  'End' => 
  array (
    'of' => 2,
  ),
  'explained.' => 
  array (
    'Chapter' => 1,
  ),
  29 => 
  array (
    '-' => 1,
  ),
  'Zaphod!' => 
  array (
    'Wake' => 1,
  ),
  'Wake' => 
  array (
    'up!' => 1,
  ),
  'Mmmmmwwwwwerrrrr?' => 
  array (
    '-' => 1,
  ),
  'Would' => 
  array (
    'it' => 1,
  ),
  'pleasure?' => 
  array (
    '-' => 1,
  ),
  'blearily.' => 
  array (
    '-' => 1,
  ),
  'Nor' => 
  array (
    'me.' => 1,
  ),
  'bugging' => 
  array (
    '' => 1,
  ),
  'double' => 
  array (
    'dose' => 1,
  ),
  'dose' => 
  array (
    'of' => 1,
  ),
  'gas,' => 
  array (
    '-' => 1,
  ),
  'windpipes.' => 
  array (
    '-' => 1,
  ),
  'talking,' => 
  array (
    '-' => 1,
  ),
  'ground?' => 
  array (
    'It\'s' => 1,
  ),
  'hard.' => 
  array (
    '-' => 1,
  ),
  'gold,' => 
  array (
    '-' => 1,
  ),
  'balletic' => 
  array (
    'movement' => 1,
  ),
  'scanning' => 
  array (
    'the' => 1,
  ),
  'horizon,' => 
  array (
    'because' => 1,
  ),
  'direction,' => 
  array (
    'perfectly' => 1,
  ),
  'solid.' => 
  array (
    'It' => 1,
  ),
  'gleamed' => 
  array (
    'like...' => 1,
    'like' => 1,
  ),
  'gleams' => 
  array (
    '' => 1,
  ),
  'goggle-eyed.' => 
  array (
    '-' => 1,
  ),
  'catalogue.' => 
  array (
    '-' => 1,
  ),
  'catalogue,' => 
  array (
    '-' => 1,
  ),
  'knees' => 
  array (
    'and' => 1,
  ),
  'poked' => 
  array (
    '' => 1,
    'around' => 1,
  ),
  'fingernail.' => 
  array (
    'It' => 2,
  ),
  'mark' => 
  array (
    '' => 1,
  ),
  'shiny,' => 
  array (
    '' => 1,
  ),
  'evaporated' => 
  array (
    'off' => 1,
  ),
  'evaporates' => 
  array (
    'off' => 1,
  ),
  'gold.' => 
  array (
    '-' => 1,
  ),
  'yelling' => 
  array (
    'till' => 1,
  ),
  'catalogue' => 
  array (
    'to' => 1,
    'number' => 1,
    '' => 2,
  ),
  'Sens-O-Tape.' => 
  array (
    'Zaphod' => 1,
  ),
  'bitterly.' => 
  array (
    '-' => 1,
  ),
  'shit,' => 
  array (
    '-' => 1,
  ),
  'else\'s.' => 
  array (
    '-' => 1,
  ),
  'huff.' => 
  array (
    '-' => 1,
  ),
  'Hallmark,' => 
  array (
    '-' => 1,
  ),
  'earlier,' => 
  array (
    '-' => 1,
  ),
  'knee' => 
  array (
    'deep' => 1,
  ),
  'Fish?' => 
  array (
    '-' => 1,
  ),
  'platinum.' => 
  array (
    '' => 1,
  ),
  'dull.' => 
  array (
    '' => 1,
  ),
  'Seas' => 
  array (
    'of' => 1,
  ),
  'looked.' => 
  array (
    '-' => 1,
  ),
  'pretty,' => 
  array (
    '-' => 1,
  ),
  'petulantly.' => 
  array (
    'In' => 1,
  ),
  'appeared.' => 
  array (
    'It' => 1,
  ),
  'changed,' => 
  array (
    'and' => 1,
  ),
  'went,' => 
  array (
    '-' => 1,
  ),
  'Yuch.' => 
  array (
    'The' => 1,
  ),
  'purple.' => 
  array (
    'The' => 1,
  ),
  'beach' => 
  array (
    'they' => 1,
    'table' => 1,
  ),
  'pebbles' => 
  array (
    '' => 1,
  ),
  'precious' => 
  array (
    '' => 1,
  ),
  'stones.' => 
  array (
    '' => 1,
  ),
  'undulating' => 
  array (
    '' => 1,
  ),
  'peaks.' => 
  array (
    'Nearby' => 1,
  ),
  'Nearby' => 
  array (
    'stood' => 1,
  ),
  'table' => 
  array (
    'with' => 1,
    'as' => 1,
    '' => 1,
    'in' => 1,
  ),
  'frilly' => 
  array (
    '' => 1,
  ),
  'mauve' => 
  array (
    '' => 1,
  ),
  'parasol' => 
  array (
    '' => 1,
  ),
  'tassles.' => 
  array (
    'In' => 1,
  ),
  'appeared,' => 
  array (
    'replacing' => 1,
  ),
  'replacing' => 
  array (
    'the' => 1,
  ),
  'number.' => 
  array (
    '' => 1,
  ),
  'tastes,' => 
  array (
    'Magrathea' => 1,
  ),
  'cater' => 
  array (
    'for' => 1,
  ),
  'proud.' => 
  array (
    'And' => 1,
  ),
  'naked' => 
  array (
    'women' => 1,
  ),
  'parachutes.' => 
  array (
    'In' => 1,
  ),
  'springtime' => 
  array (
    '' => 1,
  ),
  'meadow' => 
  array (
    'full' => 1,
  ),
  'cows.' => 
  array (
    '-' => 1,
  ),
  'Ow!' => 
  array (
    '-' => 1,
  ),
  'brains!' => 
  array (
    '-' => 1,
  ),
  'scenes' => 
  array (
    'that' => 1,
  ),
  'detected' => 
  array (
    '' => 1,
    'the' => 1,
  ),
  'tests.' => 
  array (
    'And' => 1,
  ),
  'myself.' => 
  array (
    'Pretty' => 1,
  ),
  'Pretty' => 
  array (
    'crazy,' => 1,
  ),
  'agreement.' => 
  array (
    '-' => 1,
  ),
  'reckon,' => 
  array (
    'what\'s' => 1,
  ),
  'myself?' => 
  array (
    '' => 1,
  ),
  'Obviously.' => 
  array (
    'But' => 1,
  ),
  'Shortly' => 
  array (
    'after' => 1,
  ),
  'Yooden' => 
  array (
    'Vranx.' => 1,
    '' => 1,
    'died' => 1,
    'told' => 1,
    'talking' => 1,
  ),
  'Vranx.' => 
  array (
    'You' => 1,
  ),
  'Yooden,' => 
  array (
    'Ford?' => 1,
  ),
  'kids,' => 
  array (
    '' => 1,
  ),
  'captain.' => 
  array (
    'He' => 1,
  ),
  'gas.' => 
  array (
    'He' => 1,
  ),
  'conkers' => 
  array (
    'when' => 1,
    'of' => 1,
  ),
  'bust' => 
  array (
    'your' => 1,
    'our' => 1,
  ),
  'megafreighter.' => 
  array (
    'Said' => 1,
  ),
  'Said' => 
  array (
    'you' => 1,
  ),
  'history,' => 
  array (
    '-' => 1,
  ),
  'megafreighters' => 
  array (
    'used' => 1,
    'had' => 1,
  ),
  'bulky' => 
  array (
    'trade' => 1,
  ),
  'trade' => 
  array (
    'between' => 1,
  ),
  'Centre' => 
  array (
    'and' => 1,
  ),
  'scouts' => 
  array (
    'used' => 1,
  ),
  'markets' => 
  array (
    'and' => 1,
  ),
  'Arcturans' => 
  array (
    '' => 1,
  ),
  'supply' => 
  array (
    'them.' => 1,
  ),
  'pirates' => 
  array (
    'before' => 1,
  ),
  'Dordellis' => 
  array (
    'wars,' => 1,
  ),
  'wars,' => 
  array (
    'and' => 1,
  ),
  'equipped' => 
  array (
    '' => 1,
  ),
  'fantastic' => 
  array (
    'defence' => 1,
  ),
  'shields' => 
  array (
    'known' => 1,
  ),
  'science.' => 
  array (
    '' => 1,
  ),
  'brutes' => 
  array (
    'of' => 1,
  ),
  'huge.' => 
  array (
    'In' => 1,
  ),
  'eclipse' => 
  array (
    'the' => 1,
  ),
  'decides' => 
  array (
    '' => 1,
  ),
  'raid' => 
  array (
    '' => 1,
  ),
  'tri-jet' => 
  array (
    'scooter' => 1,
    '' => 1,
  ),
  'scooter' => 
  array (
    'designed' => 1,
  ),
  'stratosphere' => 
  array (
    'work,' => 1,
  ),
  'kid.' => 
  array (
    'I' => 1,
  ),
  'crazier' => 
  array (
    'than' => 1,
  ),
  'monkey.' => 
  array (
    'I' => 1,
  ),
  'ride' => 
  array (
    'because' => 1,
  ),
  'fake' => 
  array (
    'evidence.' => 1,
    'a' => 1,
  ),
  'happens?' => 
  array (
    'We' => 1,
  ),
  'souped' => 
  array (
    'up' => 1,
  ),
  'parsecs' => 
  array (
    'in' => 1,
  ),
  'weeks,' => 
  array (
    'bust' => 1,
  ),
  'megafreighter' => 
  array (
    '' => 1,
  ),
  'how,' => 
  array (
    'marched' => 1,
  ),
  'pistols' => 
  array (
    'and' => 1,
  ),
  'conkers.' => 
  array (
    'A' => 1,
  ),
  'wilder' => 
  array (
    'thing' => 1,
  ),
  'known.' => 
  array (
    'Lost' => 1,
  ),
  'Lost' => 
  array (
    'me' => 1,
  ),
  'year\'s' => 
  array (
    'pocket' => 1,
  ),
  'money.' => 
  array (
    'For' => 1,
  ),
  'Conkers.' => 
  array (
    '-' => 1,
  ),
  'guy,' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'Vranx,' => 
  array (
    '' => 1,
  ),
  'food,' => 
  array (
    'booze' => 1,
  ),
  'booze' => 
  array (
    '-' => 1,
  ),
  'stuff' => 
  array (
    'from' => 1,
  ),
  'weird' => 
  array (
    '' => 1,
    'and' => 1,
  ),
  'incredible' => 
  array (
    'time.' => 1,
  ),
  'teleported' => 
  array (
    'us' => 1,
  ),
  'maximum' => 
  array (
    '' => 1,
  ),
  'security' => 
  array (
    '' => 1,
  ),
  'prison.' => 
  array (
    'He' => 1,
  ),
  'guy.' => 
  array (
    'Went' => 1,
  ),
  'Dark' => 
  array (
    '' => 1,
  ),
  'elephantine' => 
  array (
    '' => 1,
  ),
  'lurked' => 
  array (
    '' => 1,
  ),
  'indistinctly' => 
  array (
    '' => 1,
  ),
  'shadows.' => 
  array (
    'The' => 1,
  ),
  'rent' => 
  array (
    'with' => 1,
  ),
  'illusory' => 
  array (
    '' => 1,
    'beings.' => 1,
  ),
  'murdering' => 
  array (
    'other' => 1,
  ),
  'Presumably' => 
  array (
    'enough' => 1,
  ),
  'paying' => 
  array (
    'proposition.' => 1,
  ),
  'proposition.' => 
  array (
    '-' => 1,
  ),
  'idea?' => 
  array (
    '-' => 1,
  ),
  'stealing' => 
  array (
    'it' => 1,
  ),
  'launching' => 
  array (
    'ceremony.' => 1,
  ),
  'ceremony.' => 
  array (
    'Ford' => 1,
  ),
  'roared' => 
  array (
    '' => 1,
  ),
  'laughter.' => 
  array (
    '-' => 1,
  ),
  'walls.' => 
  array (
    '-' => 1,
  ),
  'consciously' => 
  array (
    'known' => 1,
  ),
  'passed.' => 
  array (
    'I' => 1,
  ),
  'mucked' => 
  array (
    'about' => 1,
  ),
  'talker.' => 
  array (
    '-' => 1,
  ),
  'inkling' => 
  array (
    'of' => 1,
  ),
  'doubts' => 
  array (
    'seemed' => 1,
  ),
  'minds.' => 
  array (
    '-' => 1,
  ),
  'last,' => 
  array (
    '-' => 1,
  ),
  'letting' => 
  array (
    'myself' => 1,
  ),
  'secrets.' => 
  array (
    'Still,' => 1,
  ),
  'Still,' => 
  array (
    '-' => 1,
  ),
  'reflection,' => 
  array (
    '-' => 1,
  ),
  'spit' => 
  array (
    'a' => 1,
  ),
  'rat.' => 
  array (
    'A' => 1,
  ),
  'plush' => 
  array (
    'waiting' => 1,
  ),
  'glass-top' => 
  array (
    '' => 1,
  ),
  'awards.' => 
  array (
    'A' => 1,
    '' => 1,
    'Half' => 1,
  ),
  30 => 
  array (
    '-' => 1,
  ),
  'perfunctory' => 
  array (
    'attempt' => 1,
  ),
  'study.' => 
  array (
    'He' => 1,
  ),
  'pile,' => 
  array (
    'but' => 1,
  ),
  'pile' => 
  array (
    'which' => 1,
    'of' => 1,
  ),
  'completed,' => 
  array (
    '-' => 1,
  ),
  'unbitterly.' => 
  array (
    '-' => 1,
  ),
  'Ten' => 
  array (
    'million' => 1,
    '' => 1,
  ),
  'conceive' => 
  array (
    'of' => 1,
  ),
  'span?' => 
  array (
    'A' => 1,
  ),
  'galactic' => 
  array (
    'civilization' => 1,
  ),
  'worm' => 
  array (
    'five' => 1,
  ),
  'Gone.' => 
  array (
    '-' => 1,
  ),
  'bureaucracy' => 
  array (
    'for' => 1,
  ),
  'added.' => 
  array (
    '-' => 1,
  ),
  'thoughtfully,' => 
  array (
    '-' => 1,
  ),
  'explains' => 
  array (
    'a' => 1,
  ),
  'unaccountable' => 
  array (
    '' => 1,
  ),
  'sinister,' => 
  array (
    'and' => 1,
  ),
  'Everyone?' => 
  array (
    '-' => 1,
  ),
  'Maybe.' => 
  array (
    'Who' => 1,
  ),
  'cares?' => 
  array (
    '-' => 1,
  ),
  'tired,' => 
  array (
    '-' => 1,
  ),
  'absurdly' => 
  array (
    'remote' => 1,
  ),
  'occupied.' => 
  array (
    'Look' => 1,
  ),
  'me:' => 
  array (
    'I' => 1,
  ),
  'coastlines.' => 
  array (
    'I' => 1,
  ),
  'Norway.' => 
  array (
    'He' => 1,
  ),
  'perspex' => 
  array (
    'block' => 1,
    '' => 1,
  ),
  'block' => 
  array (
    'with' => 1,
  ),
  'model' => 
  array (
    'of' => 1,
  ),
  'Norway' => 
  array (
    'moulded' => 1,
  ),
  'Where\'s' => 
  array (
    'the' => 1,
    '' => 1,
  ),
  'fjords' => 
  array (
    'in' => 1,
    'again' => 1,
    'then.' => 1,
  ),
  'fleeting' => 
  array (
    '' => 1,
  ),
  'award.' => 
  array (
    'He' => 1,
  ),
  'shrug' => 
  array (
    '' => 1,
  ),
  'carelessly,' => 
  array (
    'but' => 1,
  ),
  'carelessly' => 
  array (
    'that' => 1,
  ),
  'soft.' => 
  array (
    '-' => 1,
  ),
  'replacement' => 
  array (
    'Earth' => 1,
  ),
  'Africa' => 
  array (
    'to' => 1,
  ),
  'fashioned' => 
  array (
    'enough' => 1,
  ),
  'lovely' => 
  array (
    'baroque' => 1,
  ),
  'baroque' => 
  array (
    'feel' => 1,
  ),
  'continent.' => 
  array (
    'And' => 1,
  ),
  'equatorial' => 
  array (
    '' => 1,
  ),
  'Equatorial!' => 
  array (
    '-' => 1,
  ),
  'matter?' => 
  array (
    '' => 1,
  ),
  'Science' => 
  array (
    '' => 1,
  ),
  'falls' => 
  array (
    'down' => 1,
  ),
  'sympathy.' => 
  array (
    '-' => 1,
  ),
  'otherwise.' => 
  array (
    'Somewhere' => 1,
  ),
  'flashed.' => 
  array (
    '-' => 1,
  ),
  'hailed,' => 
  array (
    'so' => 1,
  ),
  'gather,' => 
  array (
    'as' => 1,
  ),
  'event' => 
  array (
    '' => 1,
  ),
  'two?' => 
  array (
    '-' => 1,
  ),
  'coincidences,' => 
  array (
    '-' => 1,
  ),
  'carelessly.' => 
  array (
    'He' => 1,
  ),
  'follow.' => 
  array (
    'Arthur' => 1,
  ),
  'more,' => 
  array (
    'and' => 1,
  ),
  'sweaty' => 
  array (
    'dishevelled' => 1,
  ),
  'dishevelled' => 
  array (
    'clothes' => 1,
  ),
  'clothes' => 
  array (
    'he' => 1,
  ),
  'morning.' => 
  array (
    '-' => 1,
  ),
  'joking.' => 
  array (
    'Chapter' => 1,
  ),
  31 => 
  array (
    'It' => 1,
  ),
  'costs' => 
  array (
    '' => 1,
  ),
  'scale' => 
  array (
    'of' => 1,
    'the' => 1,
  ),
  'appreciated.' => 
  array (
    'For' => 1,
  ),
  'freak' => 
  array (
    'wormhole' => 1,
  ),
  'wormhole' => 
  array (
    '' => 1,
  ),
  'continuum' => 
  array (
    'and' => 1,
  ),
  'warlike' => 
  array (
    'beings' => 1,
  ),
  'poised' => 
  array (
    'on' => 1,
    'to' => 1,
    'and' => 1,
  ),
  'brink' => 
  array (
    '' => 1,
  ),
  'frightful' => 
  array (
    'interstellar' => 1,
  ),
  'battle.' => 
  array (
    'The' => 1,
  ),
  'opposing' => 
  array (
    'leaders' => 1,
    'battle' => 1,
  ),
  'leaders' => 
  array (
    'were' => 1,
  ),
  'meeting' => 
  array (
    'for' => 1,
    'no' => 1,
  ),
  'dreadful' => 
  array (
    'silence' => 1,
    'insult' => 1,
  ),
  'conference' => 
  array (
    'table' => 1,
    'table.' => 1,
  ),
  'commander' => 
  array (
    'of' => 1,
  ),
  'Vl\'hurgs,' => 
  array (
    'resplendent' => 1,
  ),
  'shorts,' => 
  array (
    '' => 1,
  ),
  'levelly' => 
  array (
    'at' => 1,
  ),
  'G\'Gugvuntt' => 
  array (
    'leader' => 1,
  ),
  'leader' => 
  array (
    'squatting' => 1,
  ),
  'squatting' => 
  array (
    'opposite' => 1,
    'down' => 1,
  ),
  'sweet-smelling' => 
  array (
    '' => 1,
  ),
  'steam,' => 
  array (
    '' => 1,
  ),
  'horribly' => 
  array (
    'beweaponed' => 1,
  ),
  'beweaponed' => 
  array (
    'star' => 1,
  ),
  'cruisers' => 
  array (
    'poised' => 1,
  ),
  'unleash' => 
  array (
    'electric' => 1,
  ),
  'command,' => 
  array (
    'challenged' => 1,
  ),
  'challenged' => 
  array (
    'the' => 1,
  ),
  'vile' => 
  array (
    'creature' => 1,
  ),
  'stirred' => 
  array (
    'in' => 1,
  ),
  'sickly' => 
  array (
    'broiling' => 1,
  ),
  'broiling' => 
  array (
    'vapour,' => 1,
  ),
  'vapour,' => 
  array (
    'and' => 1,
  ),
  'table.' => 
  array (
    'Unfortunately,' => 1,
    'He' => 1,
  ),
  'Unfortunately,' => 
  array (
    'in' => 1,
  ),
  'Vl\'hurg' => 
  array (
    '' => 1,
  ),
  'insult' => 
  array (
    'imaginable,' => 1,
  ),
  'imaginable,' => 
  array (
    'and' => 1,
  ),
  'wage' => 
  array (
    '' => 1,
  ),
  'war' => 
  array (
    'for' => 1,
  ),
  'decimated' => 
  array (
    '' => 1,
  ),
  'fleets' => 
  array (
    'settled' => 1,
  ),
  'remaining' => 
  array (
    'differences' => 1,
  ),
  'differences' => 
  array (
    'in' => 1,
  ),
  'launch' => 
  array (
    'a' => 1,
  ),
  'joint' => 
  array (
    'attack' => 1,
  ),
  'positively' => 
  array (
    'identified' => 1,
  ),
  'identified' => 
  array (
    'as' => 1,
  ),
  'offending' => 
  array (
    'remark.' => 1,
  ),
  'remark.' => 
  array (
    'For' => 1,
  ),
  'wastes' => 
  array (
    'of' => 1,
  ),
  'due' => 
  array (
    '' => 1,
  ),
  'miscalculation' => 
  array (
    'of' => 1,
  ),
  'swallowed' => 
  array (
    'by' => 1,
  ),
  'dog.' => 
  array (
    'Those' => 1,
  ),
  'Those' => 
  array (
    'who' => 1,
    'glaciers' => 1,
  ),
  'complex' => 
  array (
    'interplay' => 1,
  ),
  'interplay' => 
  array (
    'of' => 1,
  ),
  'powerless' => 
  array (
    'to' => 1,
  ),
  'prevent' => 
  array (
    'it.' => 1,
  ),
  'trip' => 
  array (
    'brought' => 1,
  ),
  'glass-topped' => 
  array (
    'tables' => 1,
  ),
  'Almost' => 
  array (
    '' => 1,
  ),
  'entered.' => 
  array (
    '-' => 1,
  ),
  'safe!' => 
  array (
    '-' => 1,
  ),
  'startled.' => 
  array (
    '-' => 1,
  ),
  'subdued' => 
  array (
    'and' => 1,
  ),
  'decked' => 
  array (
    'out' => 1,
  ),
  'dishes,' => 
  array (
    'strange' => 1,
  ),
  'sweetmeats' => 
  array (
    'and' => 1,
  ),
  'bizarre' => 
  array (
    'fruits.' => 1,
  ),
  'fruits.' => 
  array (
    '' => 1,
  ),
  'attacking' => 
  array (
    'a' => 1,
  ),
  'boneful' => 
  array (
    'of' => 1,
  ),
  'grilled' => 
  array (
    'muscle,' => 1,
  ),
  'muscle,' => 
  array (
    '' => 1,
  ),
  'guests' => 
  array (
    'here' => 1,
  ),
  'gassing' => 
  array (
    'us' => 1,
  ),
  'zapping' => 
  array (
    'our' => 1,
  ),
  'hoiking' => 
  array (
    'out' => 1,
  ),
  'evil' => 
  array (
    'smelling' => 1,
    'grin,' => 1,
  ),
  'smelling' => 
  array (
    'meat' => 1,
  ),
  'bowl,' => 
  array (
    '-' => 1,
  ),
  'Vegan' => 
  array (
    'Rhino\'s' => 1,
  ),
  'Rhino\'s' => 
  array (
    'cutlet.' => 1,
  ),
  'cutlet.' => 
  array (
    'It\'s' => 1,
  ),
  'delicious' => 
  array (
    'if' => 1,
  ),
  'Hosts?' => 
  array (
    '-' => 1,
  ),
  'hosts?' => 
  array (
    'I' => 1,
  ),
  'any...' => 
  array (
    'A' => 1,
  ),
  'Welcome' => 
  array (
    'to' => 1,
  ),
  'lunch,' => 
  array (
    'Earth' => 1,
  ),
  'creature.' => 
  array (
    'Arthur' => 1,
  ),
  'Ugh!' => 
  array (
    '-' => 1,
  ),
  'table!' => 
  array (
    'There' => 1,
  ),
  'pointedly' => 
  array (
    'at' => 1,
  ),
  'Oh!' => 
  array (
    '-' => 1,
  ),
  'realization.' => 
  array (
    '-' => 1,
  ),
  'for...' => 
  array (
    '-' => 1,
  ),
  'introduce' => 
  array (
    'you,' => 1,
  ),
  'Benji' => 
  array (
    'mouse.' => 1,
    'mouse' => 1,
    'firmly.' => 1,
    'mouse,' => 1,
    '' => 2,
    'and' => 1,
    'considered' => 1,
  ),
  'mouse.' => 
  array (
    '-' => 1,
    'The' => 1,
    '' => 1,
  ),
  'whiskers' => 
  array (
    '' => 1,
    'in' => 1,
  ),
  'stroked' => 
  array (
    '' => 1,
  ),
  'whisky-glass' => 
  array (
    '' => 1,
  ),
  'Frankie' => 
  array (
    'mouse.' => 1,
    '' => 1,
    'interrupting,' => 1,
    'mouse,' => 2,
    'said:' => 1,
    'baby,' => 1,
  ),
  'mouse' => 
  array (
    'said,' => 1,
    '' => 1,
  ),
  'Pleased' => 
  array (
    'to' => 1,
  ),
  'likewise.' => 
  array (
    'Arthur' => 1,
  ),
  'they...' => 
  array (
    '-' => 1,
  ),
  'tiniest' => 
  array (
    'resigned' => 1,
  ),
  'shrug.' => 
  array (
    '-' => 2,
  ),
  'grated' => 
  array (
    'Arcturan' => 1,
  ),
  'Megadonkey?' => 
  array (
    '' => 1,
  ),
  'aback,' => 
  array (
    '-' => 1,
  ),
  'necessary,' => 
  array (
    '-' => 1,
  ),
  'swivelled' => 
  array (
    'his' => 1,
  ),
  'destroyed.' => 
  array (
    '-' => 1,
  ),
  'glaciers' => 
  array (
    'poised' => 1,
    'are' => 1,
  ),
  'Africa!' => 
  array (
    '-' => 1,
  ),
  'skiing' => 
  array (
    '' => 1,
    'on' => 1,
  ),
  'holiday' => 
  array (
    '' => 1,
  ),
  'dismantle' => 
  array (
    'them,' => 1,
  ),
  'Frankie,' => 
  array (
    'acidly.' => 1,
    '-' => 3,
    '' => 2,
  ),
  'acidly.' => 
  array (
    '-' => 1,
  ),
  'Skiing' => 
  array (
    'holiday!' => 1,
  ),
  'holiday!' => 
  array (
    '-' => 1,
  ),
  'art!' => 
  array (
    '' => 1,
    '-' => 1,
  ),
  'Elegantly' => 
  array (
    '' => 1,
  ),
  'sculptured' => 
  array (
    '' => 1,
  ),
  'contours,' => 
  array (
    '' => 1,
  ),
  'soaring' => 
  array (
    '' => 1,
  ),
  'pinnacles' => 
  array (
    '' => 1,
  ),
  'ice,' => 
  array (
    '' => 1,
  ),
  'majestic' => 
  array (
    'ravines!' => 1,
  ),
  'ravines!' => 
  array (
    'It' => 1,
  ),
  'sacrilege' => 
  array (
    'to' => 1,
  ),
  'coldly,' => 
  array (
    '-' => 1,
  ),
  'goodbye' => 
  array (
    'Earthman,' => 1,
  ),
  'nod' => 
  array (
    'to' => 1,
  ),
  'company' => 
  array (
    '' => 1,
  ),
  'mouse,' => 
  array (
    '-' => 2,
    '' => 1,
  ),
  'clinked' => 
  array (
    'their' => 1,
  ),
  'business!' => 
  array (
    '-' => 1,
  ),
  'Benji.' => 
  array (
    'Ford' => 1,
    '-' => 5,
  ),
  'proposing' => 
  array (
    'a' => 1,
  ),
  'toast,' => 
  array (
    '-' => 1,
  ),
  'scuttled' => 
  array (
    'impatiently' => 1,
    'round' => 1,
  ),
  'transports.' => 
  array (
    'Finally' => 1,
  ),
  'creature,' => 
  array (
    '-' => 1,
  ),
  'have,' => 
  array (
    'as' => 1,
  ),
  'Question.' => 
  array (
    '-' => 1,
  ),
  'interrupting,' => 
  array (
    '-' => 1,
  ),
  'Forty-Two...' => 
  array (
    '' => 1,
  ),
  'Frankie.' => 
  array (
    '-' => 2,
    'He' => 1,
  ),
  'brutally' => 
  array (
    'honest.' => 1,
  ),
  'honest.' => 
  array (
    'And' => 1,
  ),
  'sick' => 
  array (
    '' => 1,
  ),
  'prospect' => 
  array (
    '' => 1,
  ),
  'whinnet-ridden' => 
  array (
    'Vogons' => 1,
  ),
  'heeby' => 
  array (
    'jeebies,' => 1,
  ),
  'jeebies,' => 
  array (
    'you' => 1,
  ),
  'holiday,' => 
  array (
    'and' => 1,
  ),
  'manipulated' => 
  array (
    '' => 1,
  ),
  'offices' => 
  array (
    'of' => 1,
  ),
  'friends.' => 
  array (
    '-' => 1,
  ),
  'dimension,' => 
  array (
    '-' => 1,
  ),
  'Since' => 
  array (
    'when,' => 1,
    'he' => 1,
  ),
  'when,' => 
  array (
    '-' => 1,
  ),
  'murine' => 
  array (
    'colleague,' => 1,
  ),
  'colleague,' => 
  array (
    '' => 1,
  ),
  'offer' => 
  array (
    'of' => 1,
  ),
  'enormously' => 
  array (
    'fat' => 1,
  ),
  'contract' => 
  array (
    '' => 1,
  ),
  '5D' => 
  array (
    '' => 1,
  ),
  'chat' => 
  array (
    '' => 1,
  ),
  'lecture' => 
  array (
    'circuit' => 1,
  ),
  'circuit' => 
  array (
    'back' => 1,
  ),
  'dimensional' => 
  array (
    'neck' => 1,
  ),
  'woods,' => 
  array (
    '' => 1,
  ),
  'inclined' => 
  array (
    'to' => 1,
  ),
  'would,' => 
  array (
    'wouldn\'t' => 1,
    '-' => 1,
  ),
  'promptingly.' => 
  array (
    '-' => 1,
  ),
  'shot.' => 
  array (
    'Arthur' => 1,
  ),
  'product' => 
  array (
    'you' => 1,
    'of' => 1,
  ),
  'ideally' => 
  array (
    'we' => 1,
  ),
  'studio' => 
  array (
    'looking' => 1,
  ),
  'mentioning' => 
  array (
    'that' => 1,
  ),
  'Everything,' => 
  array (
    'and' => 1,
  ),
  'show\'s' => 
  array (
    'probably' => 1,
  ),
  'short.' => 
  array (
    'No' => 1,
  ),
  'follow-up,' => 
  array (
    'you' => 1,
  ),
  'good?' => 
  array (
    '' => 1,
    'From' => 1,
  ),
  'mice?' => 
  array (
    'The' => 1,
  ),
  'bristled.' => 
  array (
    '-' => 1,
  ),
  'idealism,' => 
  array (
    'yes' => 1,
  ),
  'dignity' => 
  array (
    'of' => 1,
  ),
  'pure' => 
  array (
    '' => 1,
  ),
  'pursuit' => 
  array (
    'of' => 1,
  ),
  'forms,' => 
  array (
    'but' => 1,
  ),
  'truth,' => 
  array (
    'it\'s' => 1,
  ),
  'multi-dimensional' => 
  array (
    'infinity' => 1,
  ),
  'maniacs.' => 
  array (
    'And' => 1,
  ),
  'choice' => 
  array (
    '' => 1,
  ),
  'spending' => 
  array (
    'yet' => 1,
  ),
  'exercise,' => 
  array (
    '-' => 1,
  ),
  'hopelessly.' => 
  array (
    '-' => 1,
  ),
  'matrix,' => 
  array (
    'right,' => 1,
  ),
  'penultimate' => 
  array (
    '' => 1,
  ),
  'configuration' => 
  array (
    'of' => 1,
  ),
  'programme,' => 
  array (
    '-' => 1,
  ),
  'lucidly' => 
  array (
    'he' => 1,
  ),
  'Right?' => 
  array (
    '-' => 1,
  ),
  'doubtfully.' => 
  array (
    'He' => 1,
  ),
  'Benji,' => 
  array (
    'steering' => 1,
    'crouching' => 1,
  ),
  'steering' => 
  array (
    'his' => 1,
  ),
  'vehicle' => 
  array (
    'right' => 1,
  ),
  'encoded' => 
  array (
    'in' => 1,
  ),
  'buy.' => 
  array (
    '-' => 1,
  ),
  'electronically,' => 
  array (
    '' => 1,
  ),
  'protested' => 
  array (
    'Ford.' => 1,
  ),
  'Treated,' => 
  array (
    '-' => 1,
  ),
  'Diced.' => 
  array (
    '-' => 1,
  ),
  'tipping' => 
  array (
    'up' => 1,
  ),
  'backing' => 
  array (
    '' => 1,
    'away' => 1,
  ),
  'replaced,' => 
  array (
    '-' => 1,
  ),
  'reasonably,' => 
  array (
    '' => 1,
  ),
  'brain,' => 
  array (
    '-' => 1,
  ),
  'suffice.' => 
  array (
    '-' => 1,
  ),
  'one!' => 
  array (
    '-' => 1,
  ),
  'wailed' => 
  array (
    'Arthur.' => 1,
  ),
  'tea?' => 
  array (
    '' => 1,
  ),
  'who\'d' => 
  array (
    'know' => 1,
  ),
  'difference?' => 
  array (
    '-' => 1,
  ),
  'further.' => 
  array (
    '-' => 1,
  ),
  'See' => 
  array (
    'what' => 1,
  ),
  'difference,' => 
  array (
    '-' => 1,
  ),
  'wouldn\'t,' => 
  array (
    '-' => 1,
  ),
  'lads,' => 
  array (
    '-' => 1,
  ),
  'deal.' => 
  array (
    '-' => 1,
  ),
  'deal,' => 
  array (
    '-' => 1,
  ),
  'chorus,' => 
  array (
    'all' => 1,
  ),
  'charm' => 
  array (
    'vanishing' => 1,
  ),
  'vanishing' => 
  array (
    'fro' => 1,
  ),
  'fro' => 
  array (
    'their' => 1,
  ),
  'piping' => 
  array (
    'little' => 1,
  ),
  'instant.' => 
  array (
    'With' => 1,
  ),
  'whining' => 
  array (
    'shriek' => 1,
  ),
  'shriek' => 
  array (
    'their' => 1,
  ),
  'transports' => 
  array (
    'lifted' => 1,
    'where' => 1,
  ),
  'stumbled' => 
  array (
    '' => 1,
  ),
  'blind' => 
  array (
    '' => 1,
  ),
  'drag' => 
  array (
    '' => 1,
  ),
  'airborne' => 
  array (
    '' => 1,
  ),
  'rodents' => 
  array (
    'swooping' => 1,
  ),
  'swooping' => 
  array (
    'towards' => 1,
  ),
  'yank,' => 
  array (
    'Ford' => 1,
  ),
  'pretty.' => 
  array (
    'They' => 1,
  ),
  'charged.' => 
  array (
    'So' => 1,
  ),
  'thugs' => 
  array (
    'a' => 1,
  ),
  'were.' => 
  array (
    'All' => 1,
  ),
  'fortunate' => 
  array (
    'that' => 1,
  ),
  'earsplitting' => 
  array (
    'din.' => 1,
  ),
  'din.' => 
  array (
    'Chapter' => 1,
  ),
  32 => 
  array (
    '-' => 1,
  ),
  'Emergency!' => 
  array (
    'Emergency!' => 1,
    '-' => 1,
  ),
  'blared' => 
  array (
    'the' => 1,
  ),
  'klaxons' => 
  array (
    'throughout' => 1,
  ),
  'Hostile' => 
  array (
    'ship' => 1,
  ),
  'Armed' => 
  array (
    'intruders' => 1,
  ),
  'intruders' => 
  array (
    'in' => 1,
  ),
  '8A.' => 
  array (
    '' => 1,
  ),
  'Defence' => 
  array (
    'stations,' => 1,
  ),
  'stations,' => 
  array (
    'defence' => 1,
  ),
  'stations!' => 
  array (
    'The' => 1,
  ),
  'sniffed' => 
  array (
    'irritably' => 1,
  ),
  'shattered' => 
  array (
    'on' => 1,
  ),
  'Damnation,' => 
  array (
    '-' => 1,
  ),
  'Earthling' => 
  array (
    'brain.' => 1,
  ),
  'flashing,' => 
  array (
    'his' => 1,
  ),
  'coat' => 
  array (
    'bristling' => 1,
  ),
  'bristling' => 
  array (
    'with' => 1,
  ),
  'static.' => 
  array (
    '-' => 1,
  ),
  'crouching' => 
  array (
    'and' => 1,
    '' => 1,
  ),
  'stroking' => 
  array (
    'his' => 1,
  ),
  'invent' => 
  array (
    'one' => 1,
  ),
  'plausible.' => 
  array (
    '-' => 1,
  ),
  'Difficult,' => 
  array (
    '-' => 1,
  ),
  'dangerous?' => 
  array (
    'Benji' => 1,
  ),
  'multiply' => 
  array (
    '' => 1,
  ),
  'seven?' => 
  array (
    '-' => 1,
  ),
  'literal,' => 
  array (
    '' => 1,
  ),
  'factual,' => 
  array (
    '' => 1,
  ),
  'sustain' => 
  array (
    'the' => 1,
  ),
  'punters\'' => 
  array (
    'interest.' => 1,
  ),
  'interest.' => 
  array (
    'Again' => 1,
  ),
  'roads' => 
  array (
    'must' => 2,
  ),
  'Aha,' => 
  array (
    'now' => 1,
  ),
  'promising!' => 
  array (
    '-' => 1,
  ),
  'little.' => 
  array (
    '-' => 1,
  ),
  'excellent!' => 
  array (
    '' => 1,
  ),
  'Sounds' => 
  array (
    'very' => 1,
  ),
  'tying' => 
  array (
    'you' => 1,
  ),
  'Forty-two.' => 
  array (
    'Excellent,' => 1,
  ),
  'Excellent,' => 
  array (
    'excellent,' => 1,
  ),
  'excellent,' => 
  array (
    'that\'ll' => 1,
  ),
  'that\'ll' => 
  array (
    'fox' => 1,
  ),
  'fox' => 
  array (
    '\'em.' => 1,
  ),
  '\'em.' => 
  array (
    'Frankie' => 1,
  ),
  'made!' => 
  array (
    'They' => 1,
  ),
  'performed' => 
  array (
    'a' => 1,
  ),
  'scampering' => 
  array (
    'dance' => 1,
  ),
  'dance' => 
  array (
    'in' => 1,
  ),
  'Near' => 
  array (
    'them' => 1,
  ),
  'Half' => 
  array (
    'a' => 1,
  ),
  'mile' => 
  array (
    'away,' => 1,
  ),
  'pounded' => 
  array (
    'up' => 1,
  ),
  'open-plan' => 
  array (
    '' => 1,
  ),
  'guess,' => 
  array (
    'I\'d' => 1,
  ),
  'Kill-O-Zap' => 
  array (
    'energy' => 1,
    'gun.' => 1,
    'hurled' => 1,
    '' => 1,
    'gun,' => 1,
  ),
  'bolt' => 
  array (
    'that' => 1,
    'after' => 1,
    'of' => 1,
  ),
  'adjacent' => 
  array (
    'wall.' => 1,
  ),
  'hailer' => 
  array (
    'said,' => 1,
    'again.' => 1,
  ),
  'covered.' => 
  array (
    '-' => 1,
  ),
  'Cops!' => 
  array (
    '-' => 1,
  ),
  'crouch.' => 
  array (
    '-' => 1,
  ),
  'gangway' => 
  array (
    'between' => 1,
    'appeared' => 1,
  ),
  'armoured' => 
  array (
    'and' => 1,
  ),
  'spacesuited' => 
  array (
    'figure' => 1,
  ),
  'Beeblebrox!' => 
  array (
    '-' => 1,
  ),
  'figure.' => 
  array (
    '-' => 1,
  ),
  'Suits' => 
  array (
    'me' => 1,
  ),
  'fine!' => 
  array (
    '-' => 1,
  ),
  'gap' => 
  array (
    'between' => 1,
  ),
  'units.' => 
  array (
    'The' => 1,
  ),
  'swerved' => 
  array (
    'in' => 1,
  ),
  'cornered.' => 
  array (
    'They' => 1,
  ),
  'bolts' => 
  array (
    'as' => 1,
  ),
  'cops' => 
  array (
    '' => 3,
  ),
  'ball,' => 
  array (
    '-' => 1,
  ),
  'dangerous' => 
  array (
    'moment.' => 1,
  ),
  'ducked' => 
  array (
    'again.' => 1,
  ),
  'replied,' => 
  array (
    '-' => 1,
  ),
  'cop!' => 
  array (
    '-' => 1,
  ),
  'cop.' => 
  array (
    '-' => 3,
  ),
  'listen!' => 
  array (
    'I' => 1,
  ),
  'laying' => 
  array (
    'your' => 1,
  ),
  'easier' => 
  array (
    'to' => 1,
  ),
  'cope!' => 
  array (
    'Another' => 1,
  ),
  'hailer,' => 
  array (
    '' => 1,
  ),
  'dealing' => 
  array (
    '' => 1,
  ),
  'dumb' => 
  array (
    '' => 1,
  ),
  'two-bit' => 
  array (
    '' => 1,
  ),
  'trigger-pumping' => 
  array (
    '' => 1,
  ),
  'morons' => 
  array (
    '' => 1,
  ),
  'hairlines,' => 
  array (
    'little' => 1,
  ),
  'conversation,' => 
  array (
    '' => 1,
  ),
  'caring' => 
  array (
    'guys' => 1,
  ),
  'socially!' => 
  array (
    'I' => 1,
  ),
  'gratuitously' => 
  array (
    'shooting' => 1,
    'and' => 1,
  ),
  'bragging' => 
  array (
    'about' => 1,
  ),
  'afterwards' => 
  array (
    'in' => 1,
    'for' => 1,
    'was' => 1,
  ),
  'seedy' => 
  array (
    'space-rangers' => 1,
  ),
  'space-rangers' => 
  array (
    'bars,' => 1,
  ),
  'bars,' => 
  array (
    'like' => 1,
  ),
  'mention!' => 
  array (
    'I' => 1,
  ),
  'agonize' => 
  array (
    'about' => 1,
  ),
  'girlfriend!' => 
  array (
    '-' => 1,
  ),
  'novels!' => 
  array (
    '-' => 1,
  ),
  'chimed' => 
  array (
    'in' => 1,
  ),
  'meeeean' => 
  array (
    'mood!' => 1,
  ),
  'mood!' => 
  array (
    'Ford\'s' => 1,
  ),
  'halfway' => 
  array (
    'out' => 1,
  ),
  'sockets.' => 
  array (
    '-' => 1,
  ),
  'preferred' => 
  array (
    '' => 1,
  ),
  'shooting.' => 
  array (
    '-' => 1,
  ),
  'out?' => 
  array (
    '-' => 1,
  ),
  'prefer?' => 
  array (
    '-' => 1,
  ),
  'millisecond' => 
  array (
    'later' => 1,
  ),
  'fusillade' => 
  array (
    'continued' => 1,
  ),
  'unbearable' => 
  array (
    'intensity.' => 1,
  ),
  'intensity.' => 
  array (
    'When' => 1,
  ),
  'quietness' => 
  array (
    '' => 1,
  ),
  'echoes' => 
  array (
    'died' => 1,
  ),
  'cops.' => 
  array (
    '-' => 1,
    'He' => 1,
  ),
  'tell,' => 
  array (
    '-' => 1,
  ),
  'good!' => 
  array (
    '-' => 1,
  ),
  'Because,' => 
  array (
    '-' => 1,
  ),
  'cop,' => 
  array (
    '-' => 2,
  ),
  'humane!' => 
  array (
    'Now' => 1,
  ),
  'beat' => 
  array (
    'you' => 1,
  ),
  'opposed' => 
  array (
    'to' => 1,
  ),
  'needless' => 
  array (
    'violence,' => 1,
  ),
  'violence,' => 
  array (
    'or' => 1,
  ),
  'here!' => 
  array (
    '-' => 1,
  ),
  'crazy!' => 
  array (
    '-' => 1,
  ),
  'liberal' => 
  array (
    'cop' => 1,
  ),
  'cop' => 
  array (
    'who' => 1,
    'shouted' => 1,
    'was' => 1,
  ),
  'sensitivity' => 
  array (
    'and' => 1,
  ),
  'everything!' => 
  array (
    '-' => 1,
  ),
  'other:' => 
  array (
    '-' => 1,
  ),
  'Shall' => 
  array (
    'we' => 1,
  ),
  'bit?' => 
  array (
    '-' => 1,
  ),
  'barrage.' => 
  array (
    'The' => 1,
  ),
  'heat' => 
  array (
    'and' => 1,
  ),
  'fantastic.' => 
  array (
    'Slowly,' => 1,
  ),
  'disintegrate.' => 
  array (
    'The' => 1,
  ),
  'melted' => 
  array (
    'away,' => 1,
  ),
  'rivulets' => 
  array (
    'of' => 1,
  ),
  'molten' => 
  array (
    'metal' => 1,
  ),
  'winding' => 
  array (
    'their' => 1,
  ),
  'squatting.' => 
  array (
    'They' => 1,
  ),
  'huddled' => 
  array (
    'further' => 1,
  ),
  33 => 
  array (
    'But' => 1,
  ),
  'came,' => 
  array (
    'at' => 1,
    '' => 1,
  ),
  'Quite' => 
  array (
    'suddenly' => 1,
  ),
  'barrage' => 
  array (
    'stopped,' => 1,
  ),
  'punctuated' => 
  array (
    'by' => 1,
  ),
  'strangled' => 
  array (
    'gurgles' => 1,
  ),
  'gurgles' => 
  array (
    'and' => 1,
  ),
  'thuds.' => 
  array (
    'The' => 1,
  ),
  'odd.' => 
  array (
    '-' => 1,
    'Slowly,' => 1,
  ),
  'trap.' => 
  array (
    '-' => 1,
  ),
  'wit.' => 
  array (
    '-' => 1,
  ),
  'thuds?' => 
  array (
    '-' => 1,
  ),
  'Dunno.' => 
  array (
    'They' => 1,
  ),
  'Right,' => 
  array (
    '-' => 1,
  ),
  'others.' => 
  array (
    '-' => 1,
    'He' => 1,
  ),
  'possibly,' => 
  array (
    'let' => 1,
  ),
  'heads.' => 
  array (
    '-' => 1,
  ),
  'billowing' => 
  array (
    'out' => 1,
  ),
  'burning' => 
  array (
    'computer.' => 1,
  ),
  'Cautiously' => 
  array (
    'he' => 1,
  ),
  'Twenty' => 
  array (
    '' => 1,
    'yards' => 1,
  ),
  'space-suited' => 
  array (
    'figure' => 1,
  ),
  'crumpled' => 
  array (
    'heap' => 1,
  ),
  'reassuringly' => 
  array (
    'still' => 2,
  ),
  'gun' => 
  array (
    '' => 1,
  ),
  'dangled' => 
  array (
    'from' => 1,
  ),
  'limp' => 
  array (
    'fingers.' => 1,
  ),
  'fingers.' => 
  array (
    'He' => 1,
  ),
  'resistance.' => 
  array (
    'The' => 1,
  ),
  'Blagulon' => 
  array (
    'Kappa' => 2,
    'ship.' => 1,
  ),
  'Kappa' => 
  array (
    '-' => 1,
    'policecraft,' => 1,
  ),
  'methane-breathing' => 
  array (
    'life' => 1,
  ),
  'dependent' => 
  array (
    'on' => 1,
  ),
  'oxygen' => 
  array (
    'atmosphere' => 1,
  ),
  'backpack' => 
  array (
    '' => 1,
  ),
  'blown' => 
  array (
    'up.' => 1,
  ),
  'miniature' => 
  array (
    'suit' => 1,
  ),
  'sub-etha.' => 
  array (
    '' => 1,
  ),
  'fail-safe' => 
  array (
    'in' => 1,
  ),
  'circumstances' => 
  array (
    '' => 1,
  ),
  'feedback' => 
  array (
    'malfunction,' => 1,
  ),
  'malfunction,' => 
  array (
    'which' => 1,
  ),
  'prone' => 
  array (
    '' => 1,
  ),
  'figure,' => 
  array (
    '' => 1,
  ),
  'shared' => 
  array (
    '' => 1,
  ),
  'astonishment,' => 
  array (
    'but' => 1,
  ),
  'curiosity.' => 
  array (
    '-' => 1,
    'Ford' => 1,
  ),
  'hole,' => 
  array (
    '-' => 1,
  ),
  'gun,' => 
  array (
    'blasted' => 1,
  ),
  'blasted' => 
  array (
    'a' => 1,
    'hell' => 1,
  ),
  'accounting' => 
  array (
    '' => 1,
  ),
  'empty,' => 
  array (
    '' => 1,
  ),
  'recognized' => 
  array (
    '' => 1,
  ),
  'belonging' => 
  array (
    '' => 1,
  ),
  'pinned' => 
  array (
    'to' => 1,
  ),
  'sparse' => 
  array (
    'instrument' => 1,
  ),
  'arrow' => 
  array (
    'drawn' => 1,
  ),
  'controls.' => 
  array (
    'It' => 1,
  ),
  34 => 
  array (
    'The' => 1,
  ),
  'speeds' => 
  array (
    'in' => 1,
  ),
  'excess' => 
  array (
    'of' => 1,
  ),
  'R17' => 
  array (
    'through' => 1,
    'is' => 1,
    'and' => 1,
  ),
  'lead' => 
  array (
    'out' => 1,
  ),
  'drear' => 
  array (
    'morning' => 1,
  ),
  'twilight.' => 
  array (
    'Ghastly' => 1,
  ),
  'Ghastly' => 
  array (
    'grey' => 1,
  ),
  'congealed' => 
  array (
    'on' => 1,
  ),
  'R' => 
  array (
    'is' => 1,
  ),
  'measure,' => 
  array (
    'defined' => 1,
  ),
  'reasonable' => 
  array (
    'speed' => 1,
  ),
  'consistent' => 
  array (
    'with' => 1,
  ),
  'health,' => 
  array (
    'mental' => 1,
  ),
  'wellbeing' => 
  array (
    'and' => 1,
  ),
  'infinitely' => 
  array (
    '' => 1,
  ),
  'variable' => 
  array (
    'figure' => 1,
  ),
  'circumstances,' => 
  array (
    'since' => 1,
  ),
  'factors' => 
  array (
    '' => 1,
  ),
  'vary' => 
  array (
    '' => 1,
  ),
  'absolute,' => 
  array (
    'but' => 1,
  ),
  'awareness' => 
  array (
    'of' => 1,
  ),
  'factor.' => 
  array (
    'Unless' => 1,
  ),
  'Unless' => 
  array (
    'handled' => 1,
  ),
  'tranquility' => 
  array (
    '' => 1,
  ),
  'equation' => 
  array (
    '' => 1,
  ),
  'ulcers' => 
  array (
    'and' => 1,
  ),
  'death.' => 
  array (
    'R17' => 1,
  ),
  'fixed' => 
  array (
    'velocity,' => 1,
  ),
  'velocity,' => 
  array (
    'but' => 1,
  ),
  'above,' => 
  array (
    '' => 1,
  ),
  'deposited' => 
  array (
    'them' => 1,
  ),
  'starkly' => 
  array (
    'on' => 1,
  ),
  'bleached' => 
  array (
    'bone,' => 1,
  ),
  'bone,' => 
  array (
    'and' => 1,
  ),
  'precipitately' => 
  array (
    'hurled' => 1,
  ),
  'own.' => 
  array (
    'Shivering,' => 1,
  ),
  'Shivering,' => 
  array (
    'the' => 1,
  ),
  'Beside' => 
  array (
    'it' => 1,
  ),
  'policecraft,' => 
  array (
    'a' => 1,
  ),
  'bulbous' => 
  array (
    '' => 1,
  ),
  'sharklike' => 
  array (
    '' => 1,
  ),
  'slate' => 
  array (
    'green' => 1,
  ),
  'smothered' => 
  array (
    '' => 1,
  ),
  'stencilled' => 
  array (
    '' => 1,
  ),
  'varying' => 
  array (
    'degrees' => 1,
  ),
  'unfriendliness.' => 
  array (
    'The' => 1,
  ),
  'informed' => 
  array (
    '' => 1,
  ),
  'from,' => 
  array (
    'what' => 1,
  ),
  'assigned' => 
  array (
    'to,' => 1,
  ),
  'connected.' => 
  array (
    'It' => 1,
  ),
  'unnaturally' => 
  array (
    'dark' => 1,
  ),
  'two-man' => 
  array (
    'crew' => 1,
  ),
  'smoke-filled' => 
  array (
    'chamber' => 1,
  ),
  'define,' => 
  array (
    'but' => 1,
  ),
  'spontaneously' => 
  array (
    'dead.' => 1,
  ),
  'bitter' => 
  array (
    'cold' => 1,
  ),
  'suffering' => 
  array (
    '' => 1,
  ),
  'acute' => 
  array (
    'attack' => 1,
  ),
  'stayed,' => 
  array (
    'and' => 1,
  ),
  'examine' => 
  array (
    'the' => 1,
  ),
  'walked,' => 
  array (
    '' => 1,
  ),
  'tripped' => 
  array (
    'over' => 1,
  ),
  'inert' => 
  array (
    'steel' => 1,
  ),
  'dust.' => 
  array (
    '-' => 1,
  ),
  'exclaimed.' => 
  array (
    '-' => 1,
  ),
  'muffled' => 
  array (
    'drone.' => 1,
  ),
  'drone.' => 
  array (
    '-' => 1,
  ),
  'metalman?' => 
  array (
    '-' => 1,
  ),
  'up?' => 
  array (
    '-' => 1,
  ),
  'shivering,' => 
  array (
    '-' => 1,
  ),
  'dust?' => 
  array (
    '-' => 1,
  ),
  'effective' => 
  array (
    'way' => 1,
  ),
  'wretched,' => 
  array (
    '-' => 1,
  ),
  'jacked' => 
  array (
    'himself' => 1,
  ),
  'resolutely' => 
  array (
    '' => 1,
  ),
  'facing' => 
  array (
    '' => 1,
  ),
  'dejectedly,' => 
  array (
    '' => 1,
  ),
  'indicating' => 
  array (
    '' => 1,
  ),
  'policecraft.' => 
  array (
    '-' => 1,
  ),
  'Simple.' => 
  array (
    'I' => 1,
  ),
  'bored' => 
  array (
    'and' => 1,
  ),
  'feed.' => 
  array (
    'I' => 1,
  ),
  'suicide,' => 
  array (
    '-' => 1,
  ),
  35 => 
  array (
    'That' => 1,
  ),
  'night,' => 
  array (
    'as' => 1,
  ),
  'putting' => 
  array (
    'a' => 1,
  ),
  'Nebula,' => 
  array (
    'Zaphod' => 1,
  ),
  'lounged' => 
  array (
    '' => 1,
  ),
  'Blasters;' => 
  array (
    'Ford' => 1,
  ),
  'discussing' => 
  array (
    'life' => 1,
  ),
  'matters' => 
  array (
    'arising' => 1,
  ),
  'arising' => 
  array (
    'from' => 1,
  ),
  'it;' => 
  array (
    'and' => 1,
  ),
  'bed' => 
  array (
    '' => 1,
  ),
  'place,' => 
  array (
    'he' => 1,
  ),
  'reasoned,' => 
  array (
    'he\'d' => 1,
  ),
  'entry.' => 
  array (
    'It' => 1,
  ),
  'History' => 
  array (
    'of' => 1,
  ),
  'Civilization' => 
  array (
    '' => 1,
  ),
  'phases,' => 
  array (
    'those' => 1,
  ),
  'Survival,' => 
  array (
    'Inquiry' => 1,
  ),
  'Inquiry' => 
  array (
    'and' => 1,
  ),
  'Sophistication,' => 
  array (
    'otherwise' => 1,
  ),
  'How,' => 
  array (
    'Why' => 1,
  ),
  'phases.' => 
  array (
    '-' => 1,
  ),
  'phase' => 
  array (
    'is' => 1,
  ),
  'characterized' => 
  array (
    'by' => 1,
  ),
  'eat?' => 
  array (
    'the' => 1,
    'and' => 1,
  ),
  'lunch?' => 
  array (
    'He' => 1,
  ),
  'intercom' => 
  array (
    'buzzed' => 1,
  ),
  'buzzed' => 
  array (
    'into' => 1,
  ),
  'hungry' => 
  array (
    'kid?' => 1,
  ),
  'peckish' => 
  array (
    'I' => 1,
  ),
  'suppose,' => 
  array (
    '-' => 1,
  ),
  'bite' => 
  array (
    'at' => 1,
  ),
  'Restaurant' => 
  array (
    'at' => 1,
  ),
); ?>