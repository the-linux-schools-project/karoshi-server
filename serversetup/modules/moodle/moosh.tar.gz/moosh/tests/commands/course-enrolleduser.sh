#!/bin/bash
#This command has been deprecated. Use user-list instead.

