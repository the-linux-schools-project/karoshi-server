---
title: tutorials
layout: default
---

Tutorials
=========

Moodle code generation
----------------------
<iframe width="560" height="315" src="//www.youtube.com/embed/pIaH3MDIZhU" frameborder="0" allowfullscreen></iframe>

Getting theme information
-------------------------
<iframe width="560" height="315" src="//www.youtube.com/embed/dXAFQOgoHfA" frameborder="0" allowfullscreen></iframe>

