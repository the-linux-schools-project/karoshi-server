- moosh version:
- moodle version:
    - database:
- php version:
- operating system:

### Actual behaviour

### Expected behaviour

### Steps to reproduce
