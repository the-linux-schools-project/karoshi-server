<?php 
$OC_Version = array(6,0,0,14);
$OC_VersionString = '6.0.0a';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_Build = '2013-12-14T19:49:13+00:00';
