OC.L10N.register(
    "settings",
    {
    "External Storage" : "Externer Speicher",
    "Saved" : "Gespeichert",
    "Delete" : "Löschen",
    "Very weak password" : "Sehr schwaches Passwort",
    "Weak password" : "Schwaches Passwort",
    "So-so password" : "Mittelstarkes Passwort",
    "Good password" : "Gutes Passwort",
    "Strong password" : "Starkes Passwort",
    "None" : "Keine(r)",
    "Enable encryption" : "Verschlüsselung aktivieren",
    "Port" : "Port",
    "Cancel" : "Abbrechen",
    "Password" : "Passwort",
    "Username" : "Benutzername"
},
"nplurals=2; plural=(n != 1);");
