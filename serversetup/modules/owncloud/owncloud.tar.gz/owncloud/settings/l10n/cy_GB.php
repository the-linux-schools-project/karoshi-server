<?php
$TRANSLATIONS = array(
"Authentication error" => "Gwall dilysu",
"Invalid request" => "Cais annilys",
"Error" => "Gwall",
"Saving..." => "Yn cadw...",
"undo" => "dadwneud",
"Groups" => "Grwpiau",
"Delete" => "Dileu",
"Security Warning" => "Rhybudd Diogelwch",
"Your web server is not yet properly setup to allow files synchronization because the WebDAV interface seems to be broken." => "Nid yw eich gweinydd wedi'i gyflunio eto i ganiatáu cydweddu ffeiliau oherwydd bod y rhyngwyneb WebDAV wedi torri.",
"Password" => "Cyfrinair",
"New password" => "Cyfrinair newydd",
"Email" => "E-bost",
"Encryption" => "Amgryptiad",
"Other" => "Arall",
"Username" => "Enw defnyddiwr"
);
$PLURAL_FORMS = "nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;";
