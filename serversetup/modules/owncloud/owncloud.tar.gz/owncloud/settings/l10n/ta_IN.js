OC.L10N.register(
    "settings",
    {
    "More" : "மேலும்"
},
"nplurals=2; plural=(n != 1);");
