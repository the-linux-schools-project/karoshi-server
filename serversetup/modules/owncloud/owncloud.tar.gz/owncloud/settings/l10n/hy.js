OC.L10N.register(
    "settings",
    {
    "Language changed" : "Լեզուն փոխվեց",
    "Delete" : "Ջնջել",
    "Very weak password" : "Շատ թույլ գաղտնաբառ",
    "Weak password" : "Թույլ գաղտնաբառ",
    "Good password" : "Լավ գաղտնաբառ",
    "Groups" : "Խմբեր",
    "never" : "երբեք",
    "add group" : "խումբ ավելացնել",
    "SSL" : "SSL",
    "TLS" : "TLS",
    "Cancel" : "Չեղարկել",
    "Email" : "Էլ. հասցե",
    "Password" : "Գաղտնաբառ",
    "New password" : "Նոր գաղտնաբառ",
    "Language" : "Լեզու",
    "Help translate" : "Օգնել թարգմանել",
    "Username" : "Օգտանուն",
    "Group" : "Խումբ",
    "Other" : "Այլ"
},
"nplurals=2; plural=(n != 1);");
