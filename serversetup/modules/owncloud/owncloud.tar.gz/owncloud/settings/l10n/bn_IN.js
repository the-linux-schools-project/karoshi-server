OC.L10N.register(
    "settings",
    {
    "Saved" : "সংরক্ষিত",
    "Delete" : "মুছে ফেলা",
    "Cancel" : "বাতিল করা",
    "Get the apps to sync your files" : "আপনার ফাইল সিঙ্ক করার অ্যাপ পান",
    "Username" : "ইউজারনেম"
},
"nplurals=2; plural=(n != 1);");
