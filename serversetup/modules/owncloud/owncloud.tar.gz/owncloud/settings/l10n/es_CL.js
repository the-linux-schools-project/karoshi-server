OC.L10N.register(
    "settings",
    {
    "Cancel" : "Cancelar",
    "Password" : "Clave",
    "Username" : "Usuario"
},
"nplurals=2; plural=(n != 1);");
