<?php
$TRANSLATIONS = array(
"Language changed" => "ਭਾਸ਼ਾ ਬਦਲੀ",
"Disable" => "ਬੰਦ",
"Enable" => "ਚਾਲੂ",
"Please wait...." => "...ਉਡੀਕੋ ਜੀ",
"Updating...." => "...ਅੱਪਡੇਟ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ",
"Error" => "ਗਲਤੀ",
"Updated" => "ਅੱਪਡੇਟ ਕੀਤਾ",
"Saving..." => "...ਸੰਭਾਲਿਆ ਜਾ ਰਿਹਾ ਹੈ",
"deleted" => "ਹਟਾਈ",
"undo" => "ਵਾਪਸ",
"Groups" => "ਗਰੁੱਪ",
"Group Admin" => "ਗਰੁੱਪ ਐਡਮਿਨ",
"Delete" => "ਹਟਾਓ",
"add group" => "ਗਰੁੱਪ ਸ਼ਾਮਲ",
"__language_name__" => "__ਭਾਸ਼ਾ_ਨਾਂ__",
"Security Warning" => "ਸੁਰੱਖਿਆ ਚੇਤਾਵਨੀ",
"Setup Warning" => "ਸੈਟਅੱਪ ਚੇਤਾਵਨੀ",
"Password" => "ਪਾਸਵਰ",
"Change password" => "ਪਾਸਵਰਡ ਬਦਲੋ",
"Username" => "ਯੂਜ਼ਰ-ਨਾਂ"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
