OC.L10N.register(
    "settings",
    {
    "Sharing" : "Түгээлт",
    "Cron" : "Крон",
    "Log" : "Лог бичилт",
    "Couldn't remove app." : "Апп-ыг устгаж чадсангүй",
    "Language changed" : "Хэл солигдлоо",
    "Invalid request" : "Буруу хүсэлт",
    "Authentication error" : "Нотолгооны алдаа",
    "Admins can't remove themself from the admin group" : "Админууд өөрсдийгөө Админ бүлгээс хасаж чадахгүй",
    "Wrong password" : "Нууц үг буруу",
    "Your full name has been changed." : "Таны бүтэн нэр солигдлоо.",
    "Unable to change full name" : "Бүтэн нэр солих боломжгүй байна",
    "All" : "Бүгд",
    "Email" : "И-мэйл",
    "Password" : "Нууц үг",
    "Username" : "Хэрэглэгчийн нэр"
},
"nplurals=2; plural=(n != 1);");
