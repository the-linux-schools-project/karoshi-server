<?php
$TRANSLATIONS = array(
"Delete" => "លុប"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
