<?php
$TRANSLATIONS = array(
"Language changed" => "Linguage cambiate",
"Invalid request" => "Requesta invalide",
"Error" => "Error",
"Update" => "Actualisar",
"Groups" => "Gruppos",
"Delete" => "Deler",
"__language_name__" => "Interlingua",
"Log" => "Registro",
"More" => "Plus",
"Add your App" => "Adder tu application",
"Select an App" => "Selectionar un app",
"Get the apps to sync your files" => "Obtene le apps (applicationes) pro synchronizar tu files",
"Password" => "Contrasigno",
"Unable to change your password" => "Non pote cambiar tu contrasigno",
"Current password" => "Contrasigno currente",
"New password" => "Nove contrasigno",
"Change password" => "Cambiar contrasigno",
"Email" => "E-posta",
"Your email address" => "Tu adresse de e-posta",
"Profile picture" => "Imagine de profilo",
"Language" => "Linguage",
"Help translate" => "Adjuta a traducer",
"Create" => "Crear",
"Other" => "Altere",
"Username" => "Nomine de usator"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
