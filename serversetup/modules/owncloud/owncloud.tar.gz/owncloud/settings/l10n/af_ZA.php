<?php
$TRANSLATIONS = array(
"Password" => "Wagwoord",
"New password" => "Nuwe wagwoord",
"Username" => "Gebruikersnaam"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
