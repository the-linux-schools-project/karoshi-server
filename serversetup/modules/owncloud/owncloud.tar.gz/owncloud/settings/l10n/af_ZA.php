<?php $TRANSLATIONS = array(
"Password" => "Wagwoord",
"New password" => "Nuwe wagwoord"
);
