<?php $TRANSLATIONS = array(
"Authentication error" => "Greška pri autentifikaciji",
"Language changed" => "Jezik je izmenjen",
"Invalid request" => "Neispravan zahtev",
"Groups" => "Grupe",
"Delete" => "Obriši",
"Select an App" => "Izaberite program",
"Password" => "Lozinka",
"Unable to change your password" => "Ne mogu da izmenim vašu lozinku",
"Current password" => "Trenutna lozinka",
"New password" => "Nova lozinka",
"Change password" => "Izmeni lozinku",
"Email" => "E-mail",
"Language" => "Jezik",
"Create" => "Napravi",
"Other" => "Drugo"
);
