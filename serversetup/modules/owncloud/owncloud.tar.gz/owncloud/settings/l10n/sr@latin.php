<?php
$TRANSLATIONS = array(
"Authentication error" => "Greška pri autentifikaciji",
"Language changed" => "Jezik je izmenjen",
"Invalid request" => "Neispravan zahtev",
"Error" => "Greška",
"Groups" => "Grupe",
"Delete" => "Obriši",
"Security Warning" => "Bezbednosno upozorenje",
"Select an App" => "Izaberite program",
"Password" => "Lozinka",
"Unable to change your password" => "Ne mogu da izmenim vašu lozinku",
"Current password" => "Trenutna lozinka",
"New password" => "Nova lozinka",
"Change password" => "Izmeni lozinku",
"Email" => "E-mail",
"Language" => "Jezik",
"Create" => "Napravi",
"Other" => "Drugo",
"Username" => "Korisničko ime"
);
$PLURAL_FORMS = "nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);";
