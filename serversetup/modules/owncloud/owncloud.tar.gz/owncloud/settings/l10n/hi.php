<?php
$TRANSLATIONS = array(
"Error" => "त्रुटि",
"Update" => "अद्यतन",
"Security Warning" => "सुरक्षा चेतावनी ",
"Password" => "पासवर्ड",
"New password" => "नया पासवर्ड",
"Abort" => "रद्द करना ",
"Username" => "प्रयोक्ता का नाम"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
