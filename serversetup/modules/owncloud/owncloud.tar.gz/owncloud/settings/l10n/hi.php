<?php $TRANSLATIONS = array(
"Password" => "पासवर्ड",
"New password" => "नया पासवर्ड"
);
