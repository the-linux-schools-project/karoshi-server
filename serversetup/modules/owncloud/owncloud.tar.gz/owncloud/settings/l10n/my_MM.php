<?php $TRANSLATIONS = array(
"Authentication error" => "ခွင့်ပြုချက်မအောင်မြင်",
"Invalid request" => "တောင်းဆိုချက်မမှန်ကန်ပါ",
"Security Warning" => "လုံခြုံရေးသတိပေးချက်",
"Password" => "စကားဝှက်",
"New password" => "စကားဝှက်အသစ်"
);
