<?php
$TRANSLATIONS = array(
"Delete" => "Ջնջել",
"Other" => "Այլ"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
