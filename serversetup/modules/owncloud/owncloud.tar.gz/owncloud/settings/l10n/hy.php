<?php $TRANSLATIONS = array(
"Delete" => "Ջնջել",
"Other" => "Այլ"
);
