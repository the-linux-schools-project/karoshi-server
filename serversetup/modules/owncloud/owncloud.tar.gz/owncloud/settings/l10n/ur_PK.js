OC.L10N.register(
    "settings",
    {
    "Invalid request" : "غلط درخواست",
    "Email sent" : "ارسال شدہ ای میل ",
    "Delete" : "حذف کریں",
    "Very weak password" : "بہت کمزور پاسورڈ",
    "Weak password" : "کمزور پاسورڈ",
    "So-so password" : "نص نص پاسورڈ",
    "Good password" : "اچھا پاسورڈ",
    "Strong password" : "مضبوط پاسورڈ",
    "More" : "مزید",
    "Less" : "کم",
    "Cheers!" : "واہ!",
    "Cancel" : "منسوخ کریں",
    "Password" : "پاسورڈ",
    "New password" : "نیا پاسورڈ",
    "Username" : "یوزر نیم",
    "Other" : "دیگر"
},
"nplurals=2; plural=(n != 1);");
