<?php $TRANSLATIONS = array(
"Password" => "پاسورڈ",
"New password" => "نیا پاسورڈ"
);
