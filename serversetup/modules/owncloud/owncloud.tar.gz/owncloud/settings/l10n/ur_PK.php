<?php
$TRANSLATIONS = array(
"Error" => "ایرر",
"Password" => "پاسورڈ",
"New password" => "نیا پاسورڈ",
"Username" => "یوزر نیم"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
