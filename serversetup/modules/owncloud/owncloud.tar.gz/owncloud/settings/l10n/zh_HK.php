<?php
$TRANSLATIONS = array(
"Error" => "錯誤",
"Groups" => "群組",
"Delete" => "刪除",
"Password" => "密碼",
"New password" => "新密碼",
"Email" => "電郵",
"Encryption" => "加密",
"Username" => "用戶名稱"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
