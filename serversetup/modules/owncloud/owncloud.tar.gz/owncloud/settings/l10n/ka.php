<?php $TRANSLATIONS = array(
"Password" => "პაროლი"
);
