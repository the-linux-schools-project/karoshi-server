<?php $TRANSLATIONS = array(
"Enable" => "چالاککردن",
"Error" => "هه‌ڵه",
"Saving..." => "پاشکه‌وتده‌کات...",
"Update" => "نوێکردنه‌وه",
"Password" => "وشەی تێپەربو",
"New password" => "وشەی نهێنی نوێ",
"Email" => "ئیمه‌یل"
);
