<?php
$TRANSLATIONS = array(
"Invalid request" => "داواکارى نادروستە",
"Enable" => "چالاککردن",
"Error" => "هه‌ڵه",
"Update" => "نوێکردنه‌وه",
"Saving..." => "پاشکه‌وتده‌کات...",
"Password" => "وشەی تێپەربو",
"New password" => "وشەی نهێنی نوێ",
"Email" => "ئیمه‌یل",
"Encryption" => "نهێنیکردن",
"Username" => "ناوی به‌کارهێنه‌ر"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
