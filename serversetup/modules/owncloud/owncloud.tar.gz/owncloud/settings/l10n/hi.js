OC.L10N.register(
    "settings",
    {
    "Email sent" : "ईमेल भेज दिया गया है ",
    "More" : "और अधिक",
    "Cancel" : "रद्द करें ",
    "Password" : "पासवर्ड",
    "New password" : "नया पासवर्ड",
    "Username" : "प्रयोक्ता का नाम"
},
"nplurals=2; plural=(n != 1);");
