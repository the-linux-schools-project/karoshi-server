OC.L10N.register(
    "settings",
    {
    "Password" : "Passcode"
},
"nplurals=2; plural=(n != 1);");
