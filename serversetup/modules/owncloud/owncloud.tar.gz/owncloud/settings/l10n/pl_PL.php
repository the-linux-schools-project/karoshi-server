<?php $TRANSLATIONS = array(
"Update" => "Uaktualnienie",
"Email" => "Email"
);
