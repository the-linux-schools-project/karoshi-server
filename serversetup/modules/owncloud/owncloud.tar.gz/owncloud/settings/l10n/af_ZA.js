OC.L10N.register(
    "settings",
    {
    "So-so password" : "So-so wagwoord",
    "Cancel" : "Kanseleer",
    "Password" : "Wagwoord",
    "New password" : "Nuwe wagwoord",
    "Username" : "Gebruikersnaam"
},
"nplurals=2; plural=(n != 1);");
