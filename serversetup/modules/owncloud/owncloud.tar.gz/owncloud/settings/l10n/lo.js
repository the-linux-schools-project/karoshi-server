OC.L10N.register(
    "settings",
    {
    "Sharing" : "ການແບ່ງປັນ",
    "Log" : "ບັນທຶກ",
    "Couldn't remove app." : "ບໍ່ສາມາດລຶບແອັບຯອອກໄດ້",
    "Unable to change full name" : "ບໍ່ສາມາດປ່ຽນຊື່ເຕັມໄດ້"
},
"nplurals=1; plural=0;");
