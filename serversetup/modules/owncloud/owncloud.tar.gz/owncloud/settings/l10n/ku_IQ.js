OC.L10N.register(
    "settings",
    {
    "Invalid request" : "داواکارى نادروستە",
    "All" : "هەمووی",
    "Enable" : "چالاککردن",
    "None" : "هیچ",
    "Login" : "چوونەژوورەوە",
    "Encryption" : "نهێنیکردن",
    "Server address" : "ناونیشانی ڕاژه",
    "Cancel" : "لابردن",
    "Email" : "ئیمه‌یل",
    "Password" : "وشەی تێپەربو",
    "New password" : "وشەی نهێنی نوێ",
    "Username" : "ناوی به‌کارهێنه‌ر"
},
"nplurals=2; plural=(n != 1);");
