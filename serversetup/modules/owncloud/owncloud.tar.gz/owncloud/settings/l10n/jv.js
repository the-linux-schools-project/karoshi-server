OC.L10N.register(
    "settings",
    {
    "Invalid request" : "Panjalukan salah"
},
"nplurals=2; plural=(n != 1);");
