OC.L10N.register(
    "settings",
    {
    "Invalid request" : "Fehlerhafte Anfrage",
    "Delete" : "Löschen",
    "never" : "niemals",
    "__language_name__" : "Deutsch (Österreich)",
    "Server address" : "Adresse des Servers",
    "Port" : "Port",
    "Cancel" : "Abbrechen",
    "Email" : "E-Mail",
    "Password" : "Passwort",
    "Change password" : "Passwort ändern",
    "Username" : "Benutzername",
    "Other" : "Anderes"
},
"nplurals=2; plural=(n != 1);");
