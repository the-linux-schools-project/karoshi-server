<?php
$TRANSLATIONS = array(
"Error" => "పొరపాటు",
"Delete" => "తొలగించు",
"More" => "మరిన్ని",
"Password" => "సంకేతపదం",
"New password" => "కొత్త సంకేతపదం",
"Email" => "ఈమెయిలు",
"Your email address" => "మీ ఈమెయిలు చిరునామా",
"Language" => "భాష",
"Username" => "వాడుకరి పేరు"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
