OC.L10N.register(
    "settings",
    {
    "Language changed" : "ਭਾਸ਼ਾ ਬਦਲੀ",
    "Please wait...." : "...ਉਡੀਕੋ ਜੀ",
    "Disable" : "ਬੰਦ",
    "Enable" : "ਚਾਲੂ",
    "Updating...." : "...ਅੱਪਡੇਟ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ",
    "Updated" : "ਅੱਪਡੇਟ ਕੀਤਾ",
    "Delete" : "ਹਟਾਓ",
    "Groups" : "ਗਰੁੱਪ",
    "undo" : "ਵਾਪਸ",
    "add group" : "ਗਰੁੱਪ ਸ਼ਾਮਲ",
    "__language_name__" : "__ਭਾਸ਼ਾ_ਨਾਂ__",
    "Login" : "ਲਾਗਇਨ",
    "Server address" : "ਸਰਵਰ ਐਡਰੈਸ",
    "Cancel" : "ਰੱਦ ਕਰੋ",
    "Password" : "ਪਾਸਵਰ",
    "Change password" : "ਪਾਸਵਰਡ ਬਦਲੋ",
    "Username" : "ਯੂਜ਼ਰ-ਨਾਂ"
},
"nplurals=2; plural=(n != 1);");
