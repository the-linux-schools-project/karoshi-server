OC.L10N.register(
    "settings",
    {
    "Invalid request" : "တောင်းဆိုချက်မမှန်ကန်ပါ",
    "Authentication error" : "ခွင့်ပြုချက်မအောင်မြင်",
    "Cancel" : "ပယ်ဖျက်မည်",
    "Password" : "စကားဝှက်",
    "New password" : "စကားဝှက်အသစ်",
    "Username" : "သုံးစွဲသူအမည်"
},
"nplurals=1; plural=0;");
