OC.L10N.register(
    "settings",
    {
    "Delete" : "తొలగించు",
    "Server address" : "సేవకి చిరునామా",
    "More" : "మరిన్ని",
    "Cancel" : "రద్దుచేయి",
    "Email" : "ఈమెయిలు",
    "Your email address" : "మీ ఈమెయిలు చిరునామా",
    "Password" : "సంకేతపదం",
    "New password" : "కొత్త సంకేతపదం",
    "Language" : "భాష",
    "Username" : "వాడుకరి పేరు"
},
"nplurals=2; plural=(n != 1);");
