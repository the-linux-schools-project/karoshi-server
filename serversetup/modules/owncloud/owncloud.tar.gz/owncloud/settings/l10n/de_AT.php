<?php
$TRANSLATIONS = array(
"__language_name__" => "Deutsch (Österreich)"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
