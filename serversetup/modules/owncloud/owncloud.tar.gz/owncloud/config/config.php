<?php
$CONFIG = array (
  'passwordsalt' => '61340fda79dbc76f1e804854a1221a',
  'datadirectory' => '/var/www/html/owncloud/data',
  'dbtype' => 'mysql',
  'version' => '4.90.0',
  'dbname' => 'owncloud',
  'dbhost' => 'localhost',
  'dbtableprefix' => 'oc_',
  'dbuser' => 'owncloud',
  'dbpassword' => 'owncloud',
  'installed' => true,
  'instanceid' => '5083e63e23b9c',
  'ldapIgnoreNamingRules' => false,
);
