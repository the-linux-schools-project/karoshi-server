<?php
$CONFIG = array (
  'instanceid' => 'CHANGETHISID',
  'passwordsalt' => 'tRc2z3ivPjwYlMXwXLmWEmN6wn2TbO',
  'secret' => 'jNQjnNlkpFde0b.Jzle3wM.eN8tB1okwWBWwezvG.9KyGcDQ',
  'trusted_domains' => 
  array (
    0 => 'CHANGETHISREALM',
  ),
  'datadirectory' => '/home/owncloud/data',
  'overwrite.cli.url' => 'https://CHANGETHISREALM/owncloud',
  'dbtype' => 'mysql',
  'version' => '8.0.2.0',
  'dbname' => 'owncloud',
  'dbhost' => 'localhost',
  'dbtableprefix' => 'oc_',
  'dbuser' => 'owncloud_user',
  'dbpassword' => 'CHANGETHISPASS',
  'installed' => true,
  'ldapIgnoreNamingRules' => false,
  'theme' => '',
  'maintenance' => false,
);
