<?php

namespace Owncloud\Updater\Tests;

interface StreamInterface{
	public function getContents();
}