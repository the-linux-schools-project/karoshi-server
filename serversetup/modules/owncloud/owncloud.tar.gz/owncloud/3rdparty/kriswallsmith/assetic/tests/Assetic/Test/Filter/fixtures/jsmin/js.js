var a = "abc";

// fsfafwe

;;
	var bbb = "u";
	