<?php
$TRANSLATIONS = array(
"_%n minute ago_::_%n minutes ago_" => array(""),
"_%n hour ago_::_%n hours ago_" => array(""),
"_%n day go_::_%n days ago_" => array(""),
"_%n month ago_::_%n months ago_" => array("")
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
