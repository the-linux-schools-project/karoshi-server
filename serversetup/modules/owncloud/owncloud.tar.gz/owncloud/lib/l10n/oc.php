<?php
$TRANSLATIONS = array(
"Help" => "Ajuda",
"Personal" => "Personal",
"Settings" => "Configuracion",
"Users" => "Usancièrs",
"Admin" => "Admin",
"web services under your control" => "Services web jos ton contraròtle",
"ZIP download is turned off." => "Avalcargar los ZIP es inactiu.",
"Files need to be downloaded one by one." => "Los fichièrs devan èsser avalcargats un per un.",
"Back to Files" => "Torna cap als fichièrs",
"Authentication error" => "Error d'autentificacion",
"Files" => "Fichièrs",
"seconds ago" => "segonda a",
"_%n minute ago_::_%n minutes ago_" => array("",""),
"_%n hour ago_::_%n hours ago_" => array("",""),
"today" => "uèi",
"yesterday" => "ièr",
"_%n day go_::_%n days ago_" => array("",""),
"last month" => "mes passat",
"_%n month ago_::_%n months ago_" => array("",""),
"last year" => "an passat",
"years ago" => "ans a"
);
$PLURAL_FORMS = "nplurals=2; plural=(n > 1);";
