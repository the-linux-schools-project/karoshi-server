<?php
$TRANSLATIONS = array(
"Help" => "Pomoć",
"Personal" => "Osobno",
"Settings" => "Postavke",
"Users" => "Korisnici",
"Admin" => "Administrator",
"web services under your control" => "web usluge pod vašom kontrolom",
"Authentication error" => "Greška kod autorizacije",
"Files" => "Datoteke",
"Text" => "Tekst",
"seconds ago" => "sekundi prije",
"_%n minute ago_::_%n minutes ago_" => array("","",""),
"_%n hour ago_::_%n hours ago_" => array("","",""),
"today" => "danas",
"yesterday" => "jučer",
"_%n day go_::_%n days ago_" => array("","",""),
"last month" => "prošli mjesec",
"_%n month ago_::_%n months ago_" => array("","",""),
"last year" => "prošlu godinu",
"years ago" => "godina"
);
$PLURAL_FORMS = "nplurals=3; plural=n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2;";
