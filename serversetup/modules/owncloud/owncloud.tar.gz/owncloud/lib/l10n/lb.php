<?php
$TRANSLATIONS = array(
"Help" => "Hëllef",
"Personal" => "Perséinlech",
"Settings" => "Astellungen",
"Users" => "Benotzer",
"Admin" => "Admin",
"Unknown filetype" => "Onbekannten Fichier Typ",
"Invalid image" => "Ongülteg d'Bild",
"web services under your control" => "Web-Servicer ënnert denger Kontroll",
"Authentication error" => "Authentifikatioun's Fehler",
"Files" => "Dateien",
"Text" => "SMS",
"seconds ago" => "Sekonnen hir",
"_%n minute ago_::_%n minutes ago_" => array("","%n Minutten hir"),
"_%n hour ago_::_%n hours ago_" => array("",""),
"today" => "haut",
"yesterday" => "gëschter",
"_%n day go_::_%n days ago_" => array("",""),
"last month" => "Läschte Mount",
"_%n month ago_::_%n months ago_" => array("",""),
"last year" => "Läscht Joer",
"years ago" => "Joren hier"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
