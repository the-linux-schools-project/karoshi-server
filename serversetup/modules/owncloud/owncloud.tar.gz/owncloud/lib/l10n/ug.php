<?php
$TRANSLATIONS = array(
"Help" => "ياردەم",
"Personal" => "شەخسىي",
"Settings" => "تەڭشەكلەر",
"Users" => "ئىشلەتكۈچىلەر",
"Authentication error" => "سالاھىيەت دەلىللەش خاتالىقى",
"Files" => "ھۆججەتلەر",
"Text" => "قىسقا ئۇچۇر",
"Images" => "سۈرەتلەر",
"Your web server is not yet properly setup to allow files synchronization because the WebDAV interface seems to be broken." => "سىزنىڭ تور مۇلازىمېتىرىڭىز ھۆججەت قەدەمداشلاشقا يول قويىدىغان قىلىپ توغرا تەڭشەلمەپتۇ، چۈنكى WebDAV نىڭ ئېغىزى بۇزۇلغاندەك تۇرىدۇ.",
"_%n minute ago_::_%n minutes ago_" => array(""),
"_%n hour ago_::_%n hours ago_" => array(""),
"today" => "بۈگۈن",
"yesterday" => "تۈنۈگۈن",
"_%n day go_::_%n days ago_" => array(""),
"_%n month ago_::_%n months ago_" => array("")
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
