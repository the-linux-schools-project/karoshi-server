<?php
$TRANSLATIONS = array(
"Help" => "幫助",
"Personal" => "個人",
"Settings" => "設定",
"Users" => "用戶",
"Admin" => "管理",
"Files" => "文件",
"Text" => "文字",
"_%n minute ago_::_%n minutes ago_" => array(""),
"_%n hour ago_::_%n hours ago_" => array(""),
"today" => "今日",
"yesterday" => "昨日",
"_%n day go_::_%n days ago_" => array(""),
"last month" => "前一月",
"_%n month ago_::_%n months ago_" => array("")
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
