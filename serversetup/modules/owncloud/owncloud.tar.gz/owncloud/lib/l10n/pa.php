<?php
$TRANSLATIONS = array(
"Settings" => "ਸੈਟਿੰਗ",
"Files" => "ਫਾਇਲਾਂ",
"seconds ago" => "ਸਕਿੰਟ ਪਹਿਲਾਂ",
"_%n minute ago_::_%n minutes ago_" => array("",""),
"_%n hour ago_::_%n hours ago_" => array("",""),
"today" => "ਅੱਜ",
"yesterday" => "ਕੱਲ੍ਹ",
"_%n day go_::_%n days ago_" => array("",""),
"last month" => "ਪਿਛਲੇ ਮਹੀਨੇ",
"_%n month ago_::_%n months ago_" => array("",""),
"last year" => "ਪਿਛਲੇ ਸਾਲ",
"years ago" => "ਸਾਲਾਂ ਪਹਿਲਾਂ"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
