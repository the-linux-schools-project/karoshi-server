<?php
$TRANSLATIONS = array(
"Help" => "Pomoć",
"Personal" => "Lično",
"Settings" => "Podešavanja",
"Users" => "Korisnici",
"Admin" => "Adninistracija",
"Authentication error" => "Greška pri autentifikaciji",
"Files" => "Fajlovi",
"Text" => "Tekst",
"seconds ago" => "Pre par sekundi",
"_%n minute ago_::_%n minutes ago_" => array("","",""),
"_%n hour ago_::_%n hours ago_" => array("","",""),
"today" => "Danas",
"yesterday" => "juče",
"_%n day go_::_%n days ago_" => array("","",""),
"last month" => "prošlog meseca",
"_%n month ago_::_%n months ago_" => array("","",""),
"last year" => "prošle godine",
"years ago" => "pre nekoliko godina"
);
$PLURAL_FORMS = "nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);";
