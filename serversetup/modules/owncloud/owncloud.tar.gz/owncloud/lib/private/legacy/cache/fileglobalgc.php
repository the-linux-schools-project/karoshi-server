<?php

class OC_Cache_FileGlobalGC extends OC\Cache\FileGlobalGC{
}
