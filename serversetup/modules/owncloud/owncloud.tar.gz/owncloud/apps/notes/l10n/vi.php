<?php
$TRANSLATIONS = array(
"Notes" => "Ghi chép"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
