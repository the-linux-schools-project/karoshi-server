<?php
$TRANSLATIONS = array(
"Notes" => "Poznámky",
"New note" => "Nová poznámka",
"Note is currently saving. Leaving " => "Poznámka je ukládána. Končím",
"_%n word_::_%n words_" => array("%n slovo","%n slova","%n slov"),
"Delete note" => "Smazat poznámku"
);
$PLURAL_FORMS = "nplurals=3; plural=(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2;";
