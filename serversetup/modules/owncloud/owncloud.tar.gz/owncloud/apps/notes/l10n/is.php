<?php
$TRANSLATIONS = array(
"Notes" => "Skýringar",
"New note" => "Nýr minnismiði",
"Note is currently saving. Leaving " => "Minnismiði er nú að vistast. Loka",
"Delete note" => "Eyða minnismiða"
);
$PLURAL_FORMS = "nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);";
