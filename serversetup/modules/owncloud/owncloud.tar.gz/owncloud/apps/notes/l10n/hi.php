<?php
$TRANSLATIONS = array(
"Notes" => "नोट्स",
"New note" => "नए नोट"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
