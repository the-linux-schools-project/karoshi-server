OC.L10N.register(
    "notes",
    {
    "Notes" : "Notas",
    "New note" : "Nove nota",
    "Delete note" : "Dele nota"
},
"nplurals=2; plural=(n != 1);");
