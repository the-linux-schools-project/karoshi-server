<?php
$TRANSLATIONS = array(
"Notes" => "Notat",
"New note" => "Nytt notat",
"Delete note" => "Slett notat"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
