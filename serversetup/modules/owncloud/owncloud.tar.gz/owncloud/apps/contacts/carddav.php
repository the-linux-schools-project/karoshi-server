<?php
if(!file_exists('../../lib/base.php')) {
	die('Please update the path to /lib/base.php in carddav.php or make use of /remote.php/carddav/');
}
require_once '../../lib/base.php';
require_once 'appinfo/remote.php';