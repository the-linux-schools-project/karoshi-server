<?php
$TRANSLATIONS = array(
"Cancel" => "বাতিল করা",
"Save" => "সেভ",
"Add" => "যোগ করা",
"Import" => "ইম্পোর্ট",
"Close" => "বন্ধ",
"No file was uploaded. Unknown error" => "কোন ফাইল আপলোড করা হয় নি।অজানা ত্রুটি",
"There is no error, the file uploaded with success" => "কোন ত্রুটি নেই,ফাইল সাফল্যের সঙ্গে আপলোড করা হয়েছে",
"The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form" => "আপলোড করা ফাইল HTML ফর্মের জন্য  MAX_FILE_SIZE নির্দেশ অতিক্রম করে",
"The uploaded file was only partially uploaded" => "আপলোড করা ফাইল শুধুমাত্র আংশিকভাবে আপলোড করা হয়েছে",
"No file was uploaded" => "কোন ফাইল আপলোড করা হয় নি",
"Missing a temporary folder" => "একটি অস্থায়ী ফোল্ডার পাওয়া যাচ্ছেনা",
"Failed to write to disk" => "ডিস্কে লিখতে ব্যর্থ",
"Not enough storage available" => "যথেষ্ট স্টোরেজ পাওয়া যায় না",
"Delete" => "মুছে ফেলা",
"Download" => "ডাউনলোড করুন",
"Address" => "ঠিকানা",
"Name" => "নাম",
"Title" => "পদবি",
"Share" => "শেয়ার",
"Export" => "এক্সপোর্ট",
"Edit" => "এডিট",
"Description" => "বর্ণনা",
"User" => "ব্যবহারকারী"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
