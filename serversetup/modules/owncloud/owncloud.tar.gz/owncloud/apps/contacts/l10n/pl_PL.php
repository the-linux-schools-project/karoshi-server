<?php $TRANSLATIONS = array(
"Save" => "Zapisz",
"Email" => "Email"
);
