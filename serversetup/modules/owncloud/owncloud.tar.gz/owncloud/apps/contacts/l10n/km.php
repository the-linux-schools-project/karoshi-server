<?php $TRANSLATIONS = array(
"Delete" => "លុប"
);
