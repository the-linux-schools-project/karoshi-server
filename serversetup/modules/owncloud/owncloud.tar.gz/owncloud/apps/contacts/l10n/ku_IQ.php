<?php
$TRANSLATIONS = array(
"Cancel" => "لابردن",
"Save" => "پاشکه‌وتکردن",
"OK" => "باشە",
"Add" => "زیادکردن",
"Import" => "هێنان",
"Importing..." => "ده‌هێنرێت...",
"Close" => "داخستن",
"No photo path was submitted." => "هیچ ڕێڕه‌وی وێنەیەک پێشکه‌ش نه‌کراوه.",
"Download" => "داگرتن",
"Email" => "ئیمه‌یل",
"Phone" => "تەلەفۆن",
"Address" => "ناونیشان",
"Name" => "ناو",
"Title" => "ناونیشان",
"Birthday" => "ڕۆژی لە دایک بوون",
"Instant Messaging" => "پەیامى خێرا",
"Note" => "تێبینی",
"Active" => "چالاکی",
"Share" => "هاوبەشی کردن",
"Export" => "هه‌ناردن",
"Edit" => "دەسکاریکردن",
"Description" => "پێناسه",
"Password" => "وشەی تێپەربو"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
