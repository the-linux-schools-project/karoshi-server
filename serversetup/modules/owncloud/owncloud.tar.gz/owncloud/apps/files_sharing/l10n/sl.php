<?php $TRANSLATIONS = array(
"Password" => "Geslo",
"Submit" => "Pošlji",
"%s shared the folder %s with you" => "%s je dal v souporabo z vami mapo %s",
"%s shared the file %s with you" => "%s je dal v souporabo z vami datoteko %s",
"Download" => "Prenesi",
"No preview available for" => "Predogled ni na voljo za",
"web services under your control" => "spletne storitve pod vašim nadzorom"
);
