<?php $TRANSLATIONS = array(
"Password" => "Password",
"Submit" => "Invia",
"%s shared the folder %s with you" => "%s ha condiviso la cartella %s con te",
"%s shared the file %s with you" => "%s ha condiviso il file %s con te",
"Download" => "Scarica",
"No preview available for" => "Nessuna anteprima disponibile per",
"web services under your control" => "servizi web nelle tue mani"
);
