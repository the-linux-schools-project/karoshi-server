<?php $TRANSLATIONS = array(
"Password" => "Lösenord",
"Submit" => "Skicka",
"%s shared the folder %s with you" => "%s delade mappen %s med dig",
"%s shared the file %s with you" => "%s delade filen %s med dig",
"Download" => "Ladda ner",
"No preview available for" => "Ingen förhandsgranskning tillgänglig för",
"web services under your control" => "webbtjänster under din kontroll"
);
