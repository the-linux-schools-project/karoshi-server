<?php $TRANSLATIONS = array(
"Password" => "密码",
"Submit" => "提交",
"Download" => "下载",
"No preview available for" => "没有预览可用于",
"web services under your control" => "您控制的网络服务"
);
