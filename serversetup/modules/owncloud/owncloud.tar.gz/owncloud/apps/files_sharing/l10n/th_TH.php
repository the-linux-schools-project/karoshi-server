<?php $TRANSLATIONS = array(
"Password" => "รหัสผ่าน",
"Submit" => "ส่ง",
"%s shared the folder %s with you" => "%s ได้แชร์โฟลเดอร์ %s ให้กับคุณ",
"%s shared the file %s with you" => "%s ได้แชร์ไฟล์ %s ให้กับคุณ",
"Download" => "ดาวน์โหลด",
"No preview available for" => "ไม่สามารถดูตัวอย่างได้สำหรับ",
"web services under your control" => "เว็บเซอร์วิสที่คุณควบคุมการใช้งานได้"
);
