<?php $TRANSLATIONS = array(
"Password" => "Contraseña",
"Submit" => "Enviar",
"%s shared the folder %s with you" => "%s compartió la carpeta %s contigo",
"%s shared the file %s with you" => "%s compartió el fichero %s contigo",
"Download" => "Descargar",
"No preview available for" => "No hay vista previa disponible para",
"web services under your control" => "Servicios web bajo su control"
);
