<?php
$TRANSLATIONS = array(
"Password" => "Senhal",
"Download" => "Avalcarga",
"Upload" => "Amontcarga",
"Cancel upload" => " Anulla l'amontcargar"
);
$PLURAL_FORMS = "nplurals=2; plural=(n > 1);";
