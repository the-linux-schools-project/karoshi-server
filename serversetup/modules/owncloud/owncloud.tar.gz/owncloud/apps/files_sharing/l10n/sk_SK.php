<?php $TRANSLATIONS = array(
"Password" => "Heslo",
"Submit" => "Odoslať",
"%s shared the folder %s with you" => "%s zdieľa s vami priečinok %s",
"%s shared the file %s with you" => "%s zdieľa s vami súbor %s",
"Download" => "Stiahnuť",
"No preview available for" => "Žiaden náhľad k dispozícii pre",
"web services under your control" => "webové služby pod Vašou kontrolou"
);
