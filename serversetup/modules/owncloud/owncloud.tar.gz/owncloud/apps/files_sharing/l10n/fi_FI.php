<?php $TRANSLATIONS = array(
"Password" => "Salasana",
"Submit" => "Lähetä",
"%s shared the folder %s with you" => "%s jakoi kansion %s kanssasi",
"%s shared the file %s with you" => "%s jakoi tiedoston %s kanssasi",
"Download" => "Lataa",
"No preview available for" => "Ei esikatselua kohteelle",
"web services under your control" => "verkkopalvelut hallinnassasi"
);
