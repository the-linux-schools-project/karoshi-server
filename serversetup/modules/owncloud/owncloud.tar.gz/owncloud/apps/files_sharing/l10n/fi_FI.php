<?php
$TRANSLATIONS = array(
"This share is password-protected" => "Tämä jako on suojattu salasanalla",
"The password is wrong. Try again." => "Väärä salasana. Yritä uudelleen.",
"Password" => "Salasana",
"Sorry, this link doesn’t seem to work anymore." => "Valitettavasti linkki ei vaikuta enää toimivan.",
"Reasons might be:" => "Mahdollisia syitä:",
"the item was removed" => "kohde poistettiin",
"the link expired" => "linkki vanheni",
"sharing is disabled" => "jakaminen on poistettu käytöstä",
"For more info, please ask the person who sent this link." => "Kysy lisätietoja henkilöltä, jolta sait linkin.",
"%s shared the folder %s with you" => "%s jakoi kansion %s kanssasi",
"%s shared the file %s with you" => "%s jakoi tiedoston %s kanssasi",
"Download" => "Lataa",
"Upload" => "Lähetä",
"Cancel upload" => "Peru lähetys",
"No preview available for" => "Ei esikatselua kohteelle",
"Direct link" => "Suora linkki"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
