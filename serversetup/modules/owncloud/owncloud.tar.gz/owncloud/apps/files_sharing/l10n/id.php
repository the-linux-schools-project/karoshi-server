<?php
$TRANSLATIONS = array(
"Password" => "Sandi",
"%s shared the folder %s with you" => "%s membagikan folder %s dengan Anda",
"%s shared the file %s with you" => "%s membagikan file %s dengan Anda",
"Download" => "Unduh",
"Upload" => "Unggah",
"Cancel upload" => "Batal pengunggahan",
"No preview available for" => "Tidak ada pratinjau tersedia untuk"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
