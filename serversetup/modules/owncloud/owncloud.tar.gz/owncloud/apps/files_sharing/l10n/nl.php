<?php $TRANSLATIONS = array(
"Password" => "Wachtwoord",
"Submit" => "Verzenden",
"%s shared the folder %s with you" => "%s deelt de map %s met u",
"%s shared the file %s with you" => "%s deelt het bestand %s met u",
"Download" => "Downloaden",
"No preview available for" => "Geen voorbeeldweergave beschikbaar voor",
"web services under your control" => "Webdiensten in eigen beheer"
);
