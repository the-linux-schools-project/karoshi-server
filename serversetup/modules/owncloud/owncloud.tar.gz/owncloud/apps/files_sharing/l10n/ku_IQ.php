<?php $TRANSLATIONS = array(
"Password" => "تێپه‌ڕه‌وشه",
"Submit" => "ناردن",
"%s shared the folder %s with you" => "%s دابه‌شی کردووه‌ بوخچه‌ی %s له‌گه‌ڵ تۆ",
"%s shared the file %s with you" => "%s دابه‌شی کردووه‌ په‌ڕگه‌یی %s له‌گه‌ڵ تۆ",
"Download" => "داگرتن",
"No preview available for" => "هیچ پێشبینیه‌ك ئاماده‌ نیه بۆ",
"web services under your control" => "ڕاژه‌ی وێب له‌ژێر چاودێریت دایه"
);
