<?php $TRANSLATIONS = array(
"Password" => "Senha",
"Submit" => "Submeter",
"%s shared the folder %s with you" => "%s compartilhou a pasta %s com você",
"%s shared the file %s with you" => "%s compartilhou o arquivo %s com você",
"Download" => "Baixar",
"No preview available for" => "Nenhuma visualização disponível para",
"web services under your control" => "web services sob seu controle"
);
