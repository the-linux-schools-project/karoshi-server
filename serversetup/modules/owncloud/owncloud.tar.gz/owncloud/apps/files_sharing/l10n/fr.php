<?php $TRANSLATIONS = array(
"Password" => "Mot de passe",
"Submit" => "Envoyer",
"%s shared the folder %s with you" => "%s a partagé le répertoire %s avec vous",
"%s shared the file %s with you" => "%s a partagé le fichier %s avec vous",
"Download" => "Télécharger",
"No preview available for" => "Pas d'aperçu disponible pour",
"web services under your control" => "services web sous votre contrôle"
);
