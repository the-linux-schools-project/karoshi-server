<?php $TRANSLATIONS = array(
"Password" => "ססמה",
"Submit" => "שליחה",
"Download" => "הורדה",
"No preview available for" => "אין תצוגה מקדימה זמינה עבור",
"web services under your control" => "שירותי רשת תחת השליטה שלך"
);
