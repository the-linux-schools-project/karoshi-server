<?php
$TRANSLATIONS = array(
"This share is password-protected" => "Esta partilha está protegida por palavra-chave",
"The password is wrong. Try again." => "Password errada, por favor tente de novo",
"Password" => "Palavra-passe",
"Sorry, this link doesn’t seem to work anymore." => "Desculpe, mas este link parece não estar a funcionar.",
"Reasons might be:" => "As razões poderão ser:",
"the item was removed" => "O item foi removido",
"the link expired" => "O link expirou",
"sharing is disabled" => "A partilha está desativada",
"For more info, please ask the person who sent this link." => "Para mais informações, por favor questione a pessoa que lhe enviou este link",
"%s shared the folder %s with you" => "%s partilhou a pasta %s consigo",
"%s shared the file %s with you" => "%s partilhou o ficheiro %s consigo",
"Download" => "Transferir",
"Upload" => "Carregar",
"Cancel upload" => "Cancelar envio",
"No preview available for" => "Não há pré-visualização para",
"Direct link" => "Link direto"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
