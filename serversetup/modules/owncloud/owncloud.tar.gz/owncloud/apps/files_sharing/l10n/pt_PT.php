<?php $TRANSLATIONS = array(
"Password" => "Palavra-Passe",
"Submit" => "Submeter",
"%s shared the folder %s with you" => "%s partilhou a pasta %s consigo",
"%s shared the file %s with you" => "%s partilhou o ficheiro %s consigo",
"Download" => "Descarregar",
"No preview available for" => "Não há pré-visualização para",
"web services under your control" => "serviços web sob o seu controlo"
);
