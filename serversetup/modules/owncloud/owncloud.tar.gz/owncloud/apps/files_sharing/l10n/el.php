<?php $TRANSLATIONS = array(
"Password" => "Συνθηματικό",
"Submit" => "Καταχώρηση",
"%s shared the folder %s with you" => "%s μοιράστηκε τον φάκελο %s μαζί σας",
"%s shared the file %s with you" => "%s μοιράστηκε το αρχείο %s μαζί σας",
"Download" => "Λήψη",
"No preview available for" => "Δεν υπάρχει διαθέσιμη προεπισκόπηση για",
"web services under your control" => "υπηρεσίες δικτύου υπό τον έλεγχό σας"
);
