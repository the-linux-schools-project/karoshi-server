<?php
$TRANSLATIONS = array(
"The password is wrong. Try again." => "Parola este incorectă. Încercaţi din nou.",
"Password" => "Parolă",
"%s shared the folder %s with you" => "%s a partajat directorul %s cu tine",
"%s shared the file %s with you" => "%s a partajat fișierul %s cu tine",
"Download" => "Descarcă",
"Upload" => "Încărcare",
"Cancel upload" => "Anulează încărcarea",
"No preview available for" => "Nici o previzualizare disponibilă pentru "
);
$PLURAL_FORMS = "nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));";
