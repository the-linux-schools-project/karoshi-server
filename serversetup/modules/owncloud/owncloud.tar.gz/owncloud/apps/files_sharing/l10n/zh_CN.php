<?php $TRANSLATIONS = array(
"Password" => "密码",
"Submit" => "提交",
"%s shared the folder %s with you" => "%s与您共享了%s文件夹",
"%s shared the file %s with you" => "%s与您共享了%s文件",
"Download" => "下载",
"No preview available for" => "没有预览",
"web services under your control" => "您控制的web服务"
);
