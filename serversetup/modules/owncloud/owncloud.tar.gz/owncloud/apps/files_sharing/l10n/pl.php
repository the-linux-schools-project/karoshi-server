<?php $TRANSLATIONS = array(
"Password" => "Hasło",
"Submit" => "Wyślij",
"%s shared the folder %s with you" => "%s współdzieli folder z tobą %s",
"%s shared the file %s with you" => "%s współdzieli z tobą plik %s",
"Download" => "Pobierz",
"No preview available for" => "Podgląd nie jest dostępny dla",
"web services under your control" => "Kontrolowane serwisy"
);
