<?php $TRANSLATIONS = array(
"Password" => "Contrasinal",
"Submit" => "Enviar",
"Download" => "Baixar",
"No preview available for" => "Sen vista previa dispoñible para ",
"web services under your control" => "servizos web baixo o seu control"
);
