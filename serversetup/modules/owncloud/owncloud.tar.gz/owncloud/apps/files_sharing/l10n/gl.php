<?php
$TRANSLATIONS = array(
"This share is password-protected" => "Esta compartición está protexida con contrasinal",
"The password is wrong. Try again." => "O contrasinal é incorrecto. Ténteo de novo.",
"Password" => "Contrasinal",
"Sorry, this link doesn’t seem to work anymore." => "Semella que esta ligazón non funciona.",
"Reasons might be:" => "As razóns poderían ser:",
"the item was removed" => "o elemento foi retirado",
"the link expired" => "a ligazón caducou",
"sharing is disabled" => "foi desactivada a compartición",
"For more info, please ask the person who sent this link." => "Para obter máis información, pregúntelle á persoa que lle enviou a ligazón.",
"%s shared the folder %s with you" => "%s compartiu o cartafol %s con vostede",
"%s shared the file %s with you" => "%s compartiu o ficheiro %s con vostede",
"Download" => "Descargar",
"Upload" => "Enviar",
"Cancel upload" => "Cancelar o envío",
"No preview available for" => "Sen vista previa dispoñíbel para",
"Direct link" => "Ligazón directa"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
