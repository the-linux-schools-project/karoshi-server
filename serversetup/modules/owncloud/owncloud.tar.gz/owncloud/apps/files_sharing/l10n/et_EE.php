<?php $TRANSLATIONS = array(
"Password" => "Parool",
"Submit" => "Saada",
"Download" => "Lae alla",
"No preview available for" => "Eelvaadet pole saadaval",
"web services under your control" => "veebitenused sinu kontrolli all"
);
