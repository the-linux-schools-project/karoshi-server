<?php $TRANSLATIONS = array(
"Password" => "Pasvorto",
"Submit" => "Sendi",
"Download" => "Elŝuti",
"No preview available for" => "Ne haveblas antaŭvido por",
"web services under your control" => "TTT-servoj regataj de vi"
);
