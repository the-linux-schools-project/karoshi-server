<?php $TRANSLATIONS = array(
"Size" => "Størrelse",
"Modified" => "Endret",
"Delete all" => "Slett alle",
"Delete" => "Slett"
);
