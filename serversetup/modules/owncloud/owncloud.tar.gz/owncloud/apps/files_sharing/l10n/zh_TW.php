<?php $TRANSLATIONS = array(
"Password" => "密碼",
"Submit" => "送出",
"Download" => "下載",
"No preview available for" => "無法預覽"
);
