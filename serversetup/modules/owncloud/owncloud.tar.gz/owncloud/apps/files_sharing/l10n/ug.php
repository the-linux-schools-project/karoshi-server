<?php
$TRANSLATIONS = array(
"Password" => "ئىم",
"Download" => "چۈشۈر",
"Upload" => "يۈكلە",
"Cancel upload" => "يۈكلەشتىن ۋاز كەچ"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
