<?php
$TRANSLATIONS = array(
"This share is password-protected" => "Diese Freigabe ist durch ein Passwort geschützt",
"The password is wrong. Try again." => "Bitte überprüfen sie Ihr Passwort und versuchen Sie es erneut.",
"Password" => "Passwort",
"Sorry, this link doesn’t seem to work anymore." => "Entschuldigung, dieser Link scheint nicht mehr zu funktionieren.",
"Reasons might be:" => "Gründe könnten sein:",
"the item was removed" => "Die Elemente wurden entfernt",
"the link expired" => "Der Link ist abgelaufen",
"sharing is disabled" => "Teilen ist deaktiviert",
"For more info, please ask the person who sent this link." => "Für mehr Informationen, frage bitte die Person, die dir diesen Link geschickt hat.",
"%s shared the folder %s with you" => "%s hat den Ordner %s mit Dir geteilt",
"%s shared the file %s with you" => "%s hat die Datei %s mit Dir geteilt",
"Download" => "Download",
"Upload" => "Hochladen",
"Cancel upload" => "Upload abbrechen",
"No preview available for" => "Es ist keine Vorschau verfügbar für",
"Direct link" => "Direkte Verlinkung"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
