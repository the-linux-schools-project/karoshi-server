<?php $TRANSLATIONS = array(
"Password" => "Passwort",
"Submit" => "Absenden",
"%s shared the folder %s with you" => "%s hat den Ordner %s für dich freigegeben",
"%s shared the file %s with you" => "%s hat die Datei %s für dich freigegeben",
"Download" => "Download",
"No preview available for" => "Es ist keine Vorschau verfügbar für",
"web services under your control" => "Web-Services unter Deiner Kontrolle"
);
