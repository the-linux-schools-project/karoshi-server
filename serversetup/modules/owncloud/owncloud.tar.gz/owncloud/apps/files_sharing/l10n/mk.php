<?php
$TRANSLATIONS = array(
"Password" => "Лозинка",
"%s shared the folder %s with you" => "%s ја сподели папката %s со Вас",
"%s shared the file %s with you" => "%s ја сподели датотеката %s со Вас",
"Download" => "Преземи",
"Upload" => "Подигни",
"Cancel upload" => "Откажи прикачување",
"No preview available for" => "Нема достапно преглед за"
);
$PLURAL_FORMS = "nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;";
