<?php $TRANSLATIONS = array(
"Password" => "Contraseña",
"Submit" => "Enviar",
"%s shared the folder %s with you" => "%s compartió la carpeta %s con vos",
"%s shared the file %s with you" => "%s compartió el archivo %s con vos",
"Download" => "Descargar",
"No preview available for" => "La vista preliminar no está disponible para",
"web services under your control" => "servicios web controlados por vos"
);
