<?php $TRANSLATIONS = array(
"Password" => "パスワード",
"Submit" => "送信",
"%s shared the folder %s with you" => "%s はフォルダー %s をあなたと共有",
"%s shared the file %s with you" => "%s はファイル %s をあなたと共有",
"Download" => "ダウンロード",
"No preview available for" => "プレビューはありません",
"web services under your control" => "管理下のウェブサービス"
);
