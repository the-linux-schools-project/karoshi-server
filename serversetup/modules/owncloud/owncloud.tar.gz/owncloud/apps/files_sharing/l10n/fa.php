<?php $TRANSLATIONS = array(
"Size" => "اندازه",
"Modified" => "تاریخ",
"Delete all" => "حذف همه",
"Delete" => "حذف"
);
