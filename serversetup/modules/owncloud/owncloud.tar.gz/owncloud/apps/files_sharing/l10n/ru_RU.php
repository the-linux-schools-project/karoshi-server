<?php $TRANSLATIONS = array(
"Password" => "Пароль",
"Submit" => "Передать",
"Download" => "Загрузка",
"No preview available for" => "Предварительный просмотр недоступен",
"web services under your control" => "веб-сервисы под Вашим контролем"
);
