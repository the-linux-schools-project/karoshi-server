<?php $TRANSLATIONS = array(
"Password" => "Пароль",
"Download" => "Завантажити"
);
