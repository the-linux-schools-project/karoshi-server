OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "Cancellar",
    "Share" : "Compartir",
    "Password" : "Contrasigno",
    "Name" : "Nomine",
    "Download" : "Discargar"
},
"nplurals=2; plural=(n != 1);");
