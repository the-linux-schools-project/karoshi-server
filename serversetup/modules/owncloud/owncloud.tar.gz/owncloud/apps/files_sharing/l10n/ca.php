<?php $TRANSLATIONS = array(
"Password" => "Contrasenya",
"Submit" => "Envia",
"%s shared the folder %s with you" => "%s ha compartit la carpeta %s amb vós",
"%s shared the file %s with you" => "%s ha compartit el fitxer %s amb vós",
"Download" => "Baixa",
"No preview available for" => "No hi ha vista prèvia disponible per a",
"web services under your control" => "controleu els vostres serveis web"
);
