<?php $TRANSLATIONS = array(
"Password" => "Kodeord",
"Submit" => "Send",
"%s shared the folder %s with you" => "%s delte mappen %s med dig",
"%s shared the file %s with you" => "%s delte filen %s med dig",
"Download" => "Download",
"No preview available for" => "Forhåndsvisning ikke tilgængelig for",
"web services under your control" => "Webtjenester under din kontrol"
);
