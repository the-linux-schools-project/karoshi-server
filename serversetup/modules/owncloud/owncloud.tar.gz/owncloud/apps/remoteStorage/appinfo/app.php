<?php
OCP\App::registerPersonal('remoteStorage','settings');
