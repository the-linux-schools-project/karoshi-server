<?php $TRANSLATIONS = array(
"Close" => "Închide",
"Share" => "a imparti",
"Cancel" => "Anulare",
"Create" => "Crează",
"Delete" => "Șterge",
"Loading" => "încărcare",
"OK" => "OK",
"Open" => "Deschide",
"Options" => "Opțiuni",
"Save" => "Salvează",
"Size" => "Dimensiune",
"Text" => "Text",
"Upload" => "Încărcare",
"Password" => "Parolă"
);
