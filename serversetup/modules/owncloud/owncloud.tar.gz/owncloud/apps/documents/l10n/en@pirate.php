<?php $TRANSLATIONS = array(
"Password" => "Secret Code"
);
