<?php $TRANSLATIONS = array(
"Share" => "Сделать общим",
"Cancel" => "Отмена",
"Create" => "Создать",
"Delete" => "Удалить",
"Family" => "Семья",
"OK" => "OK",
"Open" => "Открыть",
"Options" => "Опции",
"Save" => "Сохранить",
"Size" => "Размер",
"Text" => "Текст",
"Upload" => "Загрузка",
"Password" => "Пароль"
);
