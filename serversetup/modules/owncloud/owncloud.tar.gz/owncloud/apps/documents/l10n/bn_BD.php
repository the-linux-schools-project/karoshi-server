<?php $TRANSLATIONS = array(
"Close" => "বন্ধ",
"Share" => "ভাগাভাগি কর",
"Cancel" => "বাতির",
"Create" => "তৈরী কর",
"Delete" => "মুছে",
"OK" => "তথাস্তু",
"Open" => "খোল",
"Options" => "বিকল্পসমূহ",
"Save" => "সংরক্ষণ",
"Size" => "আকার",
"Text" => "টেক্সট",
"Upload" => "আপলোড",
"Password" => "কূটশব্দ"
);
