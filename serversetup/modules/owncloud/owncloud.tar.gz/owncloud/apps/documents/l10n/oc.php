<?php $TRANSLATIONS = array(
"Share" => "Parteja",
"Cancel" => "Annula",
"Create" => "Crea",
"Delete" => "Escafa",
"OK" => "D'accòrdi",
"Open" => "Dubrís",
"Save" => "Enregistra",
"Size" => "Talha",
"Upload" => "Amontcarga",
"Password" => "Senhal"
);
