<?php $TRANSLATIONS = array(
"Password" => "Wagwoord"
);
