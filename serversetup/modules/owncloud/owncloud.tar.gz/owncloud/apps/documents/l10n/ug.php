<?php $TRANSLATIONS = array(
"Close" => "ياپ",
"Share" => "ھەمبەھىر",
"Cancel" => "ۋاز كەچ",
"Create" => "قۇر",
"Delete" => "ئۆچۈر",
"Family" => "جەمەتىم",
"Loading" => "يۈكلەۋاتىدۇ",
"OK" => "جەزملە",
"Open" => "ئاچ",
"Options" => "تاللانما",
"Save" => "ساقلا",
"Size" => "چوڭلۇقى",
"Text" => "قىسقا ئۇچۇر",
"Upload" => "يۈكلە",
"Password" => "ئىم"
);
