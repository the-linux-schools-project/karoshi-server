<?php
$TRANSLATIONS = array(
"Saving..." => "ساقلاۋاتىدۇ…",
"Share" => "ھەمبەھىر",
"Save" => "ساقلا",
"Cancel" => "ۋاز كەچ",
"Close" => "ياپ",
"Create" => "قۇر",
"Delete" => "ئۆچۈر",
"Family" => "جەمەتىم",
"Loading" => "يۈكلەۋاتىدۇ",
"OK" => "جەزملە",
"Open" => "ئاچ",
"Options" => "تاللانما",
"Size" => "چوڭلۇقى",
"Text" => "قىسقا ئۇچۇر",
"Edit" => "تەھرىر",
"Upload" => "يۈكلە",
"Password" => "ئىم"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
