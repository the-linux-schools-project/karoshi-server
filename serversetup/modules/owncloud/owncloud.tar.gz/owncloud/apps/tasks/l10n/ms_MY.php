<?php $TRANSLATIONS = array(
"More" => "Lanjutan",
"Delete" => "Padam"
);
