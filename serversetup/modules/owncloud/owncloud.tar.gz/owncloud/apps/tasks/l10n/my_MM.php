<?php $TRANSLATIONS = array(
"Location" => "တည်နေရာ"
);
