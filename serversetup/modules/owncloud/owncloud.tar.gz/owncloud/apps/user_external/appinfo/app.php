<?php
OC::$CLASSPATH['OC_User_IMAP']='apps/user_external/lib/imap.php';
OC::$CLASSPATH['OC_User_SMB']='apps/user_external/lib/smb.php';
OC::$CLASSPATH['OC_User_FTP']='apps/user_external/lib/ftp.php';
