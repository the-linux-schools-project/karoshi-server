<?php
$TRANSLATIONS = array(
"WebDAV Authentication" => "Аутентифікація WebDAV",
"Address: " => "Адреса:",
"The user credentials will be sent to this address. This plugin checks the response and will interpret the HTTP statuscodes 401 and 403 as invalid credentials, and all other responses as valid credentials." => "Облікові дані користувача буде надіслано на цю адресу. Цей плагін перевіряє відповідь і буде інтерпретувати коди статусу HTTP 401 і 403, як неправильні облікові дані, а всі інші відповіді, вважатимуться правильними."
);
$PLURAL_FORMS = "nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);";
