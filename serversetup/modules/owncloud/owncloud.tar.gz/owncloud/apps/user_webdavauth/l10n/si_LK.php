<?php $TRANSLATIONS = array(
"WebDAV URL: http://" => "WebDAV යොමුව: http://"
);
