OC.L10N.register(
    "user_webdavauth",
    {
    "Address:" : "Հասցե՝",
    "Save" : "Պահպանել"
},
"nplurals=2; plural=(n != 1);");
