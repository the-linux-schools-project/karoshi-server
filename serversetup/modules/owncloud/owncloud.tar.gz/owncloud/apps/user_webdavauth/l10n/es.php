<?php
$TRANSLATIONS = array(
"WebDAV Authentication" => "Autenticación mediante WevDAV",
"Address: " => "Dirección:",
"The user credentials will be sent to this address. This plugin checks the response and will interpret the HTTP statuscodes 401 and 403 as invalid credentials, and all other responses as valid credentials." => "Las credenciales de usuario se enviarán a esta dirección. Este complemento verifica la respuesta e interpretará los códigos de respuesta HTTP 401 y 403 como credenciales inválidas y todas las otras respuestas como credenciales válidas."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
