<?php
$TRANSLATIONS = array(
"WebDAV Authentication" => "Uwierzytelnienie WebDAV",
"Address: " => "Adres:",
"The user credentials will be sent to this address. This plugin checks the response and will interpret the HTTP statuscodes 401 and 403 as invalid credentials, and all other responses as valid credentials." => "Dane uwierzytelniające użytkownika zostaną wysłane na ten adres. Wtyczka sprawdza odpowiedź i będzie interpretował status  HTTP 401 i 403 jako nieprawidłowe dane uwierzytelniające i wszystkie inne odpowiedzi jako prawidłowe uwierzytelnienie."
);
$PLURAL_FORMS = "nplurals=3; plural=(n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);";
