OC.L10N.register(
    "user_webdavauth",
    {
    "WebDAV Authentication" : "WebDAV প্রমাণীকরণ",
    "Address:" : "ঠিকানা",
    "Save" : "সেভ",
    "The user credentials will be sent to this address. This plugin checks the response and will interpret the HTTP statuscodes 401 and 403 as invalid credentials, and all other responses as valid credentials." : "ব্যবহারকারীর শংসাপত্র এই ঠিকানায় পাঠানো হবে।এই প্লাগিন প্রতিক্রিয়া পরীক্ষা করে এবং HTTP-statuscodes 401 এবং 403 কে অবৈধ প্রমাণপত্রাদি হিসাবে ব্যাখা করে,এবং সমস্ত অন্যান্য প্রত্যুত্তর বৈধ প্রমাণপত্রাদি হিসেবে ব্যাখ্যা করে।"
},
"nplurals=2; plural=(n != 1);");
