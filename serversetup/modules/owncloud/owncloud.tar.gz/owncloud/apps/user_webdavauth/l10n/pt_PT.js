OC.L10N.register(
    "user_webdavauth",
    {
    "WebDAV Authentication" : "Autenticação WebDAV",
    "Address:" : "Endereço:",
    "Save" : "Guardar",
    "The user credentials will be sent to this address. This plugin checks the response and will interpret the HTTP statuscodes 401 and 403 as invalid credentials, and all other responses as valid credentials." : "As credenciais do utilizador vão ser enviadas para endereço URL. Este plugin verifica a resposta e vai interpretar os códigos de estado HTTP 401 e 403 como credenciais inválidas, e todas as outras respostas como válidas."
},
"nplurals=2; plural=(n != 1);");
