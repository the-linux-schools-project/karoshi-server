<?php $TRANSLATIONS = array(
"Close" => "మూసివేయి",
"Save" => "భద్రపరచు",
"Delete" => "తొలగించు",
"Cancel" => "రద్దుచేయి",
"Address" => "చిరునామా",
"Add" => "చేర్చు",
"Settings" => "అమరికలు",
"Export" => "ఎగుమతించు",
"Import" => "దిగుమతించు"
);
