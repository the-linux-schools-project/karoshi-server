<?php $TRANSLATIONS = array(
"Close" => "Փակել",
"Save" => "Պահպանել",
"Delete" => "Ջնջել"
);
