<?php
$TRANSLATIONS = array(
"Close" => "Փակել",
"Save" => "Պահպանել",
"Delete" => "Ջնջել"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
