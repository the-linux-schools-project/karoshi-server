<?php $TRANSLATIONS = array(
"Encryption" => "Salaus",
"Exclude the following file types from encryption" => "Jätä seuraavat tiedostotyypit salaamatta",
"None" => "Ei mitään",
"Enable Encryption" => "Käytä salausta"
);
