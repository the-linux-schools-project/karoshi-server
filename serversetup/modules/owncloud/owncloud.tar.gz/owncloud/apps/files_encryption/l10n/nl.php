<?php $TRANSLATIONS = array(
"Encryption" => "Versleuteling",
"Exclude the following file types from encryption" => "Versleutel de volgende bestand types niet",
"None" => "Geen",
"Enable Encryption" => "Zet versleuteling aan"
);
