<?php $TRANSLATIONS = array(
"Encryption" => "Kryptering",
"Exclude the following file types from encryption" => "Ekskluder følgende filer fra kryptering",
"None" => "Ingen",
"Enable Encryption" => "Slå på kryptering"
);
