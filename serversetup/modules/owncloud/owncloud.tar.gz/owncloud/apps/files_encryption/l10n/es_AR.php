<?php $TRANSLATIONS = array(
"Encryption" => "Encriptación",
"Exclude the following file types from encryption" => "Exceptuar de la encriptación los siguientes tipos de archivo",
"None" => "Ninguno",
"Enable Encryption" => "Habilitar encriptación"
);
