<?php $TRANSLATIONS = array(
"Encryption" => "Шифрование",
"Exclude the following file types from encryption" => "Исключить шифрование следующих типов файлов",
"None" => "Ничего",
"Enable Encryption" => "Включить шифрование"
);
