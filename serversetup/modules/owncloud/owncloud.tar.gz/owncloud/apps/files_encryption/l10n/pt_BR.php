<?php $TRANSLATIONS = array(
"Encryption" => "Criptografia",
"Exclude the following file types from encryption" => "Excluir os seguintes tipos de arquivo da criptografia",
"None" => "Nenhuma",
"Enable Encryption" => "Habilitar Criptografia"
);
