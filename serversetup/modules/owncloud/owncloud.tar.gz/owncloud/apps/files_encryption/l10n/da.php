<?php $TRANSLATIONS = array(
"Encryption" => "Kryptering",
"Exclude the following file types from encryption" => "Ekskluder følgende filtyper fra kryptering",
"None" => "Ingen",
"Enable Encryption" => "Aktivér kryptering"
);
