<?php $TRANSLATIONS = array(
"Encryption" => "Шифрование",
"Exclude the following file types from encryption" => "Исключите следующие типы файлов из шифрования",
"None" => "Ни один",
"Enable Encryption" => "Включить шифрование"
);
