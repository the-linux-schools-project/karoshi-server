<?php $TRANSLATIONS = array(
"Encryption" => "نهێنیکردن",
"Exclude the following file types from encryption" => "به‌ربه‌ست کردنی ئه‌م جۆره‌ په‌ڕگانه له‌ نهێنیکردن",
"None" => "هیچ",
"Enable Encryption" => "چالاکردنی نهێنیکردن"
);
