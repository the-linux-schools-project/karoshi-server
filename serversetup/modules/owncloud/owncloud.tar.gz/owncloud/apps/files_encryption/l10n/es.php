<?php $TRANSLATIONS = array(
"Encryption" => "Cifrado",
"Exclude the following file types from encryption" => "Excluir del cifrado los siguientes tipos de archivo",
"None" => "Ninguno",
"Enable Encryption" => "Habilitar cifrado"
);
