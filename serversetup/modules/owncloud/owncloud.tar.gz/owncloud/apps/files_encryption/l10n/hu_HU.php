<?php $TRANSLATIONS = array(
"Encryption" => "Titkosítás",
"Exclude the following file types from encryption" => "A következő fájl típusok kizárása a titkosításból",
"None" => "Egyik sem",
"Enable Encryption" => "Titkosítás engedélyezése"
);
