<?php $TRANSLATIONS = array(
"Encryption" => "Krüpteerimine",
"Exclude the following file types from encryption" => "Järgnevaid failitüüpe ära krüpteeri",
"None" => "Pole",
"Enable Encryption" => "Luba krüpteerimine"
);
