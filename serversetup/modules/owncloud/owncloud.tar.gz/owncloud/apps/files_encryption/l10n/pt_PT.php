<?php $TRANSLATIONS = array(
"Encryption" => "Encriptação",
"Exclude the following file types from encryption" => "Excluir da encriptação os seguintes tipo de ficheiros",
"None" => "Nenhum",
"Enable Encryption" => "Activar Encriptação"
);
