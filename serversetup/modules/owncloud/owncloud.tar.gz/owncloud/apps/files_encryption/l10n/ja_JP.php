<?php $TRANSLATIONS = array(
"Encryption" => "暗号化",
"Exclude the following file types from encryption" => "暗号化から除外するファイルタイプ",
"None" => "なし",
"Enable Encryption" => "暗号化を有効にする"
);
