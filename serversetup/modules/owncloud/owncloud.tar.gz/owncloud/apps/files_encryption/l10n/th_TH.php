<?php $TRANSLATIONS = array(
"Encryption" => "การเข้ารหัส",
"Exclude the following file types from encryption" => "ไม่ต้องรวมชนิดของไฟล์ดังต่อไปนี้จากการเข้ารหัส",
"None" => "ไม่ต้อง",
"Enable Encryption" => "เปิดใช้งานการเข้ารหัส"
);
