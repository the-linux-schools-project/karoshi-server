<?php $TRANSLATIONS = array(
"Encryption" => "Verschlüsselung",
"Exclude the following file types from encryption" => "Die folgenden Dateitypen von der Verschlüsselung ausnehmen",
"None" => "Keine",
"Enable Encryption" => "Verschlüsselung aktivieren"
);
