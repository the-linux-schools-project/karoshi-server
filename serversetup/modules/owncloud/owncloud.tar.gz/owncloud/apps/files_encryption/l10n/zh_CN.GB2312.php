<?php $TRANSLATIONS = array(
"Encryption" => "加密",
"Exclude the following file types from encryption" => "从加密中排除如下文件类型",
"None" => "无",
"Enable Encryption" => "启用加密"
);
