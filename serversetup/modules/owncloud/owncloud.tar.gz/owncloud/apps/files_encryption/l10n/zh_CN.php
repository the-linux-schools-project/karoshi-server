<?php $TRANSLATIONS = array(
"Encryption" => "加密",
"Exclude the following file types from encryption" => "从加密中排除列出的文件类型",
"None" => "None",
"Enable Encryption" => "开启加密"
);
