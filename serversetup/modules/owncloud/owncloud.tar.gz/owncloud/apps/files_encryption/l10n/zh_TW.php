<?php $TRANSLATIONS = array(
"Encryption" => "加密",
"Exclude the following file types from encryption" => "下列的檔案類型不加密",
"None" => "無",
"Enable Encryption" => "啟用加密"
);
