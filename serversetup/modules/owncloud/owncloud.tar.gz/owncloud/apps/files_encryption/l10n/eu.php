<?php $TRANSLATIONS = array(
"Encryption" => "Enkriptazioa",
"Exclude the following file types from encryption" => "Ez enkriptatu hurrengo fitxategi motak",
"None" => "Bat ere ez",
"Enable Encryption" => "Gaitu enkriptazioa"
);
