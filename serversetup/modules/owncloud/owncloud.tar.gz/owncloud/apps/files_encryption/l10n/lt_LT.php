<?php $TRANSLATIONS = array(
"Encryption" => "Šifravimas",
"Exclude the following file types from encryption" => "Nešifruoti pasirinkto tipo failų",
"None" => "Nieko",
"Enable Encryption" => "Įjungti šifravimą"
);
