<?php $TRANSLATIONS = array(
"Encryption" => "Šifrovanie",
"Exclude the following file types from encryption" => "Vynechať nasledujúce súbory pri šifrovaní",
"None" => "Žiadne",
"Enable Encryption" => "Zapnúť šifrovanie"
);
