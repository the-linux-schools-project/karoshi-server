<?php $TRANSLATIONS = array(
"Encryption" => "Chiffrement",
"Exclude the following file types from encryption" => "Ne pas chiffrer les fichiers dont les types sont les suivants",
"None" => "Aucun",
"Enable Encryption" => "Activer le chiffrement"
);
