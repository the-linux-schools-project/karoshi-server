<?php $TRANSLATIONS = array(
"Encryption" => "Cifratura",
"Exclude the following file types from encryption" => "Escludi i seguenti tipi di file dalla cifratura",
"None" => "Nessuna",
"Enable Encryption" => "Abilita cifratura"
);
