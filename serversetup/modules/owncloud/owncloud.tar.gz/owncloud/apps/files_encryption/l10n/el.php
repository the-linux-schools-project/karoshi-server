<?php $TRANSLATIONS = array(
"Encryption" => "Κρυπτογράφηση",
"Exclude the following file types from encryption" => "Εξαίρεση των παρακάτω τύπων αρχείων από την κρυπτογράφηση",
"None" => "Καμία",
"Enable Encryption" => "Ενεργοποίηση Κρυπτογράφησης"
);
