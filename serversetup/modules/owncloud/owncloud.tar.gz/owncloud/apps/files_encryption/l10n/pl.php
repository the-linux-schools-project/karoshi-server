<?php $TRANSLATIONS = array(
"Encryption" => "Szyfrowanie",
"Exclude the following file types from encryption" => "Wyłącz następujące typy plików z szyfrowania",
"None" => "Brak",
"Enable Encryption" => "Włącz szyfrowanie"
);
