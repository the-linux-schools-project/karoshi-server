<?php $TRANSLATIONS = array(
"Encryption" => "Mã hóa",
"Exclude the following file types from encryption" => "Loại trừ các loại tập tin sau đây từ mã hóa",
"None" => "none",
"Enable Encryption" => "BẬT mã hóa"
);
