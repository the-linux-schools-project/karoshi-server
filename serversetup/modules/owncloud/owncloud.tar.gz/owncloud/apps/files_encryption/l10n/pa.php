<?php
$TRANSLATIONS = array(
"Saving..." => "...ਸੰਭਾਲਿਆ ਜਾ ਰਿਹਾ ਹੈ"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
