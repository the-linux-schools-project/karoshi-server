<?php $TRANSLATIONS = array(
"Encryption" => "Šifriranje",
"Exclude the following file types from encryption" => "Naslednje vrste datotek naj se ne šifrirajo",
"None" => "Brez",
"Enable Encryption" => "Omogoči šifriranje"
);
