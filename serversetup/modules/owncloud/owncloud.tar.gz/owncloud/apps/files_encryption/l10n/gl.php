<?php $TRANSLATIONS = array(
"Encryption" => "Encriptado",
"Exclude the following file types from encryption" => "Excluír os seguintes tipos de ficheiro da encriptación",
"None" => "Nada",
"Enable Encryption" => "Habilitar encriptación"
);
