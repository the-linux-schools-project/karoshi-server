<?php $TRANSLATIONS = array(
"Encryption" => "Încriptare",
"Exclude the following file types from encryption" => "Exclude următoarele tipuri de fișiere de la încriptare",
"None" => "Niciuna",
"Enable Encryption" => "Activare încriptare"
);
