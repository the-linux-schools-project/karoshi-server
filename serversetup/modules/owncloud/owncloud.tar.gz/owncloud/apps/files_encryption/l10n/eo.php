<?php $TRANSLATIONS = array(
"Encryption" => "Ĉifrado",
"Exclude the following file types from encryption" => "Malinkluzivigi la jenajn dosiertipojn el ĉifrado",
"None" => "Nenio",
"Enable Encryption" => "Kapabligi ĉifradon"
);
