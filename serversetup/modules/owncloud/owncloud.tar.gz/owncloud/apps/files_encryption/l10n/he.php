<?php
$TRANSLATIONS = array(
"Saving..." => "שמירה…",
"Encryption" => "הצפנה"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
