<?php $TRANSLATIONS = array(
"Encryption" => "Kryptering",
"Exclude the following file types from encryption" => "Exkludera följande filtyper från kryptering",
"None" => "Ingen",
"Enable Encryption" => "Aktivera kryptering"
);
