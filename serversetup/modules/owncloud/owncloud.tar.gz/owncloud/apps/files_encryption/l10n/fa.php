<?php $TRANSLATIONS = array(
"Encryption" => "رمزگذاری",
"None" => "هیچ‌کدام",
"Enable Encryption" => "فعال کردن رمزگذاری"
);
