<?php $TRANSLATIONS = array(
"Encryption" => "Šifrování",
"Exclude the following file types from encryption" => "Při šifrování vynechat následující typy souborů",
"None" => "Žádné",
"Enable Encryption" => "Povolit šifrování"
);
