<?php $TRANSLATIONS = array(
"Encryption" => "Encriptatge",
"Exclude the following file types from encryption" => "Exclou els tipus de fitxers següents de l'encriptatge",
"None" => "Cap",
"Enable Encryption" => "Activa l'encriptatge"
);
