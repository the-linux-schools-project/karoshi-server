<?php $TRANSLATIONS = array(
"Pictures" => "Lluniau",
"Shared by" => "Rhannwyd gan",
"Share" => "Rhannu",
"The \"Image Viewer\" application also need to be enabled to use this application." => "Mae angen galluogi pecyn \"Image Viewer\" i ddefnyddio'r pecyn hwn."
);
