<?php $TRANSLATIONS = array(
"Pictures" => "Εικόνες",
"Shared by" => "Διαμοιράστηκε από",
"Error loading slideshow template" => "Σφάλμα φόρτωσης προτύπου προβολής διαφανειών",
"Share" => "Διαμοιρασμός",
"The \"Image Viewer\" application also need to be enabled to use this application." => "Η εφαρμογή \"Προβολής Εικόνων\" πρέπει να είναι ενεργοποιημένη για την χρήση αυτής της εφαρμογής."
);
