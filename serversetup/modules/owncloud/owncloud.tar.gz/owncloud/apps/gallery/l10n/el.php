<?php
$TRANSLATIONS = array(
"Pictures" => "Εικόνες",
"Picture view" => "Προβολή εικονιδίων",
"Next" => "Επόμενο",
"Play" => "Αναπαραγωγή",
"Pause" => "Παύση",
"Previous" => "Προηγούμενο",
"Close" => "Κλείσιμο",
"Error loading slideshow template" => "Σφάλμα φόρτωσης προτύπου προβολής διαφανειών",
"Share" => "Διαμοιρασμός",
"No pictures found! If you upload pictures in the files app, they will be displayed here." => "Δεν βρέθηκαν εικόνες! Εάν μεταφορτώσετε εικόνες στην εφαρμογή αρχείων, θα εμφανιστούν εδώ.",
"shared by %s" => "διαμοιράστηκε από %s",
"File list" => "Λίστα αρχείων"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
