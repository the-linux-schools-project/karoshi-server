OC.L10N.register(
    "gallery",
    {
    "Pictures" : "Nuotraukos",
    "Picture view" : "Paveikslėlio rodymas",
    "Next" : "Kitas",
    "Play" : "Groti",
    "Pause" : "Pristabdyti",
    "Previous" : "Ankstesnis",
    "Close" : "Užverti",
    "Error loading slideshow template" : "Klaida pakraunant pristatymą",
    "Share" : "Dalintis",
    "shared by %s" : "pasidalino %s",
    "File list" : "Failų sąrašas"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && (n%100<10 || n%100>=20) ? 1 : 2);");
