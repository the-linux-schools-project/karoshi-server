<?php $TRANSLATIONS = array(
"Share" => "Compartir"
);
