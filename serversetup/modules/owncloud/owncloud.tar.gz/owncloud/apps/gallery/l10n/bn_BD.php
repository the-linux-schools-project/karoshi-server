<?php $TRANSLATIONS = array(
"Pictures" => "চিত্রসমূহ",
"Share" => "ভাগাভাগি কর"
);
