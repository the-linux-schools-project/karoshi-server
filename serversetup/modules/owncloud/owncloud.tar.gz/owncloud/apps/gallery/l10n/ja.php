<?php
$TRANSLATIONS = array(
"Pictures" => "ピクチャ",
"Picture view" => "ピクチャビュー",
"Next" => "次",
"Play" => "再生",
"Pause" => "一時停止",
"Previous" => "前",
"Close" => "閉じる",
"Error loading slideshow template" => "スライドショーのテンプレートの読み込みエラー",
"Share" => "共有",
"No pictures found! If you upload pictures in the files app, they will be displayed here." => "写真は見つかりませんでした！ファイルアプリでアップロードした写真は、ここに表示されます。",
"shared by %s" => "%s で共有中",
"File list" => "ファイルリスト"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
