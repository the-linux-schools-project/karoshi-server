<?php $TRANSLATIONS = array(
"Pictures" => "ピクチャ",
"Shared by" => "共有者：",
"Picture view" => "ピクチャビュー",
"Error loading slideshow template" => "スライドショーのテンプレートの読み込みエラー",
"Share" => "共有",
"The \"Image Viewer\" application also need to be enabled to use this application." => "このアプリケーションを利用するためには、\"画像ビューア\" も有効化する必要があります。",
"%s shared <strong>%s</strong> with you" => "%s が <strong>%s</strong> を共有しています",
"File list" => "ファイルリスト"
);
