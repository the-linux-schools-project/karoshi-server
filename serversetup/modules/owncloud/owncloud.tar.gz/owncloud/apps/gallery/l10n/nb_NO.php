<?php $TRANSLATIONS = array(
"Pictures" => "Bilder",
"Shared by" => "Delt av",
"Share" => "Del",
"The \"Image Viewer\" application also need to be enabled to use this application." => "\"Image Viewer\"-applikasjonen må være aktivert for å bruke denne applikasjonen."
);
