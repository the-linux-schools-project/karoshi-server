<?php
$TRANSLATIONS = array(
"Pictures" => "รูปภาพ",
"Share" => "แชร์"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
