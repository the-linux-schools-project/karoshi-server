<?php $TRANSLATIONS = array(
"Pictures" => "รูปภาพ",
"Shared by" => "ถูกแชร์โดย",
"Share" => "แชร์",
"The \"Image Viewer\" application also need to be enabled to use this application." => "แอพพลิเคชั่น \"ตัวเปิดดูรูปภาพ\" จำเป็นได้รับการเปิดใช้งานเพื่อใช้แอพพลิเคชั่นนี้ด้วยเช่นกัน"
);
