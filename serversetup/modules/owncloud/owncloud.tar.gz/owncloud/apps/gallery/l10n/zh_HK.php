<?php $TRANSLATIONS = array(
"Share" => "分享"
);
