<?php $TRANSLATIONS = array(
"Pictures" => "Bilder",
"Shared by" => "Delad av",
"Error loading slideshow template" => "Fel vid laddning av mallen för bildspelet",
"Share" => "Dela",
"The \"Image Viewer\" application also need to be enabled to use this application." => "Bildvisaren måste också ges möjlighet att använda denna applikation."
);
