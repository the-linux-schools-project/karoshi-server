<?php
$TRANSLATIONS = array(
"Pictures" => "Bilder",
"Picture view" => "Bildvy",
"Next" => "Nästa",
"Play" => "Spela",
"Pause" => "Paus",
"Previous" => "Föregående",
"Close" => "Stäng",
"Error loading slideshow template" => "Fel vid laddning av mallen för bildspelet",
"Share" => "Dela",
"No pictures found! If you upload pictures in the files app, they will be displayed here." => "Kan inte hitta några bilder! Om du har laddat upp bilderna med fil-appen, kan de visas här senare.",
"shared by %s" => "delad av %s",
"File list" => "Fillista"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
