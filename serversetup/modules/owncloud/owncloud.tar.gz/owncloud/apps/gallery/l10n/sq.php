<?php $TRANSLATIONS = array(
"Pictures" => "Foto",
"Shared by" => "Ndarë nga",
"Error loading slideshow template" => "Veprim i gabuar gjatë ngarkimit të modelit të shfaqjes së diapozitivave",
"Share" => "Nda",
"The \"Image Viewer\" application also need to be enabled to use this application." => "Për të përdorur këtë program duhet aktivizuar edhe programi \"Image Viewer\""
);
