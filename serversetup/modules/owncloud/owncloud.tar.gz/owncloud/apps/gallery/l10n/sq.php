<?php
$TRANSLATIONS = array(
"Pictures" => "Foto",
"Picture view" => "Vezhgo fotografine",
"Next" => "Mëpasshëm",
"Play" => "Luaj",
"Pause" => "Pauzë",
"Previous" => "Mëparshëm",
"Close" => "Mbyll",
"Error loading slideshow template" => "Veprim i gabuar gjatë ngarkimit të modelit të shfaqjes së diapozitivave",
"Share" => "Nda",
"No pictures found! If you upload pictures in the files app, they will be displayed here." => "Nuk u gjetën foto! Nëse ju ngarkoni foto në aplikacionin e skedarëve, ato do të shfaqen këtu.",
"shared by %s" => "ndarë nga %s",
"File list" => "Lista skedarëve"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
