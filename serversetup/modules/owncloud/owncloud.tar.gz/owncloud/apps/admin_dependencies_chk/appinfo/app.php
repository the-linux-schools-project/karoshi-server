<?php
$l=OC_L10N::get('admin_dependencies_chk');

OCP\App::registerAdmin('admin_dependencies_chk','settings');
