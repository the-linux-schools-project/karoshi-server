<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "Php-json modulis yra reikalingas duomenų keitimuisi tarp programų",
"The php-gd module is needed to create thumbnails of your images" => "Php-gd modulis yra naudojamas paveikslėlių miniatiūroms kurti.",
"The php-ldap module is needed connect to your ldap server" => "Php-ldap modulis yra reikalingas prisijungimui prie jūsų ldap serverio",
"The php-zip module is needed download multiple files at once" => "Php-zip modulis yra reikalingas kelių failų atsiuntimui iš karto.",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "Php-mb_multibyte modulis yra naudojamas apdoroti įvairius teksto kodavimo formatus.",
"The php-ctype module is needed validate data." => "Php-ctype modulis yra reikalingas duomenų tikrinimui.",
"The php-xml module is needed to share files with webdav." => "Php-xml modulis yra reikalingas failų dalinimuisi naudojant webdav.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "allow_url_fopen direktyva turėtų būti nustatyta į \"1\" jei norite automatiškai gauti žinių bazės informaciją iš OCS serverių.",
"The php-pdo module is needed to store owncloud data into a database." => "Php-pdo modulis yra reikalingas duomenų saugojimui į owncloud duomenų bazę.",
"Dependencies status" => "Priklausomybės",
"Used by :" => "Naudojama:"
);
