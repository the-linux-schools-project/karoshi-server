<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "php-json moodul on vajalik paljude rakenduse poolt omvahelise suhtlemise jaoks",
"The php-gd module is needed to create thumbnails of your images" => "php-gd moodul on vajalik sinu piltidest pisipiltide loomiseks",
"The php-ldap module is needed connect to your ldap server" => "php-ldap moodul on vajalik sinu ldap serveriga ühendumiseks",
"The php-zip module is needed download multiple files at once" => "php-zip moodul on vajalik mitme faili korraga alla laadimiseks",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "php-mb_multibyte moodul on vajalik kodeerimise korrektseks haldamiseks.",
"The php-ctype module is needed validate data." => "php-ctype moodul on vajalik andmete kontrollimiseks.",
"The php-xml module is needed to share files with webdav." => "php-xml moodul on vajalik failide jagamiseks webdav-iga.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "Sinu php.ini failis oleva direktiivi allow_url_fopen väärtuseks peaks määrama 1, et saaks tõmmata teadmistebaasi OCS-i serveritest",
"The php-pdo module is needed to store owncloud data into a database." => "php-pdo moodul on vajalik owncloudi andmete salvestamiseks andmebaasi.",
"The iconv module is needed to convert data into the correct charset." => "iconv moodul on vajalik, et konvertida andmed korrektsesse märgistikku.",
"Dependencies status" => "Sõltuvuse staatus",
"Used by :" => "Kasutab :"
);
