<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "php-json modülü bir çok uygulamanın birlikte çalışması için gereklidir",
"The php-curl module is needed to fetch the page title when adding a bookmark" => "php-curl modülü yer imi eklerken sayfa başlığının getirilmesi için gereklidir.",
"The php-gd module is needed to create thumbnails of your images" => "php-gd modülü resimlerinize önizlemeler hazırlamak için gereklidir",
"The php-ldap module is needed connect to your ldap server" => "php-ldap modülü ldap sunucunuza bağlanmak için gereklidir",
"The php-zip module is needed download multiple files at once" => "php-zip modülü bir seferde çoklu dosya indirmek için gereklidir",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "Php-mb_multibyte modülü karakter kodlamasını yönetebilmek için gereklidir.",
"The php-ctype module is needed validate data." => "php-ctype modülü veri doğrulamak için gereklidir.",
"The php-xml module is needed to share files with webdav." => "php-xml modülü dosyaları webdav ile paylaşmak için gereklidir.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "OCS sunucularından dökümanları getirebilmek için allow_url_fopen ayarı php.ini dosyanızda 1 olarak ayarlanmalıdır",
"The php-pdo module is needed to store owncloud data into a database." => "php-pdo modülü owncloud verisini bir veritabanında tutmak için gereklidir.",
"The iconv module is needed to convert data into the correct charset." => "Iconv modülü veriyi doğru karakter kümesine dönüştürmek için gereklidir.",
"Dependencies status" => "Bağımlılık durumu",
"Used by :" => "Kullanan :"
);
