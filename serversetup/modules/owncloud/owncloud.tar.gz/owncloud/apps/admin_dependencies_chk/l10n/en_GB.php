<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "The php-json module is needed by the many applications for inter communications",
"The php-curl module is needed to fetch the page title when adding a bookmark" => "The php-curl module is needed to fetch the page title when adding a bookmark",
"The php-gd module is needed to create thumbnails of your images" => "The php-gd module is needed to create thumbnails of your images",
"The php-ldap module is needed connect to your ldap server" => "The php-ldap module is needed connect to your ldap server",
"The php-zip module is needed download multiple files at once" => "The php-zip module is needed download multiple files at once",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "The php-mb_multibyte module is needed to correctly manage the encoding.",
"The php-ctype module is needed validate data." => "The php-ctype module is needed validate data.",
"The php-xml module is needed to share files with webdav." => "The php-xml module is needed to share files with webdav.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers",
"The php-pdo module is needed to store owncloud data into a database." => "The php-pdo module is needed to store owncloud data into a database.",
"The iconv module is needed to convert data into the correct charset." => "The iconv module is needed to convert data into the correct charset.",
"Dependencies status" => "Dependencies status",
"Used by :" => "Used by :"
);
