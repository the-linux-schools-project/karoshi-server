<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "De php-json module is voor veel andere applications nodig, het verzorgt de interne communicatie",
"The php-curl module is needed to fetch the page title when adding a bookmark" => "De php-curl module is nodig voor het ophalen van de pagina titel wanneer een bladwijzer wordt toegevoegd",
"The php-gd module is needed to create thumbnails of your images" => "The php-gd module is nodig om miniatuurvoorbeelden van uw plaatjes te maken",
"The php-ldap module is needed connect to your ldap server" => "De php-ldap module is nodig om een verbinding met uw ldap server te maken",
"The php-zip module is needed download multiple files at once" => "De php-module is nodig voor het ophalen van meerdere bestanden in één keer",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "De php-mb_multibyte module is nodig voor het beheren van de juiste encoding.",
"The php-ctype module is needed validate data." => "De php-ctype module is nodig voor het valideren van data.",
"The php-xml module is needed to share files with webdav." => "De php-xml module is nodig voor het delen van bestanden via webdav.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "De php.ini allow_url_fopen variabele moet op 1 worden gezet om informatie van OCS servers op te halen",
"The php-pdo module is needed to store owncloud data into a database." => "De php-pdo module is nodig voor het opslaan van data in de database.",
"The iconv module is needed to convert data into the correct charset." => "The iconv module is nodig voor het converteren van data naar de juiste character encoding.",
"Dependencies status" => "Afhankelijkheid status:",
"Used by :" => "Gebruikt door:"
);
