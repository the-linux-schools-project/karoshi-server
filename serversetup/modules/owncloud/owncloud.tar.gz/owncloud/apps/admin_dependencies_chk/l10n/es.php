<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "El módulo php-json se necesita por muchas aplicaciones para intercomunicaciones",
"The php-curl module is needed to fetch the page title when adding a bookmark" => "El módulo php-curl se necesita para obtener el título de la página cuando se añade un marcador",
"The php-gd module is needed to create thumbnails of your images" => "El módulo php-gd se necesita para crear miniaturas de tus imágenes",
"The php-ldap module is needed connect to your ldap server" => "El módulo php-ldap se necesita para conectar a tu servidor ldap",
"The php-zip module is needed download multiple files at once" => "El módulo php-zip se necesita para descargar múltiples archivos a la vez",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "El módulo php-mb_multibyte se necesita para gestionar correctamente la codificación.",
"The php-ctype module is needed validate data." => "El módulo php-ctype se necesita para validar datos.",
"The php-xml module is needed to share files with webdav." => "El módulo php-xml se necesita para compartir archivos con webdav.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "La directiva allow_url_fopen de tu archivo php.ini debe ser puesta a 1 para recuperar la base de conocimiento desde servidores OCS",
"The php-pdo module is needed to store owncloud data into a database." => "El módulo php-pdo se necesita para almacenar los datos de owncloud en una base de datos.",
"The iconv module is needed to convert data into the correct charset." => "El módulo iconv se necesita para convertir los datos en la codificación de caracteres correcta.",
"Dependencies status" => "Estado de las dependencias",
"Used by :" => "Usado por:"
);
