<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "O módulo php-json é necessário para a intercomunicação de várias aplicações",
"The php-curl module is needed to fetch the page title when adding a bookmark" => "O módulo php-curl é necessário para obter o título da página quando adicionar um favorito",
"The php-gd module is needed to create thumbnails of your images" => "O módulo php-gd é necessário para criar miniaturas das suas imagens",
"The php-ldap module is needed connect to your ldap server" => "O módulo php-ldap é necessário para conectar ao seu servidor ldap",
"The php-zip module is needed download multiple files at once" => "O módulo php-zip é necessário para baixar múltiplos arquivos de uma vez",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "O módulo php-mb_multibyte é necessário para gerencia corretamente a codificação.",
"The php-ctype module is needed validate data." => "O módulo php-ctype é necessário para validar dados.",
"The php-xml module is needed to share files with webdav." => "O módulo php-xml é necessário para compartilhar arquivos com WebDAV.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "A diretiva allow_url_fopen do seu php.ini deve ser definida para 1 para obter a base de conhecimento dos servidores OCS",
"The php-pdo module is needed to store owncloud data into a database." => "O módulo php-pdo é necessário para armazenar dados do ownCloud em um banco de dados.",
"The iconv module is needed to convert data into the correct charset." => "O módulo iconv é necessário para converter dados da cadeira de caracteres correta.",
"Dependencies status" => "Status da dependência",
"Used by :" => "Usado por:"
);
