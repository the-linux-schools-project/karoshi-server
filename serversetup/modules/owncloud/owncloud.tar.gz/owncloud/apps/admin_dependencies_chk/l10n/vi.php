<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "module php-json là cần thiết của rất nhiều các ứng dụng cho truyền thông ",
"The php-gd module is needed to create thumbnails of your images" => "module php-gd dùng để tạo ra các hình thu nhỏ cho hình ảnh",
"The php-ldap module is needed connect to your ldap server" => "module php-ldap dùng để kết nối tới máy chủ ldap",
"The php-zip module is needed download multiple files at once" => "module php-zip cần tải nhiều dữ liệu cùng một lúc",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "module php-mb_multibyte dùng để quản lý một cách chính xác các bộ mã hóa.",
"The php-ctype module is needed validate data." => "module php-ctype dùng để xác nhận dữ liệu.",
"The php-xml module is needed to share files with webdav." => "module php-xml dùng để chia sẻ tập tin với WebDAV.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "Các chỉ thị allow_url_fopen php.ini  nên được thiết lập là 1 để lấy từ máy chủ OCS",
"The php-pdo module is needed to store owncloud data into a database." => "module php-PDO dùng để lưu trữ dữ liệu owncloud vào một cơ sở dữ liệu.",
"The iconv module is needed to convert data into the correct charset." => "Các module iconv dùng để chuyển đổi dữ liệu vào các ký tự .",
"Dependencies status" => "Tình trạng",
"Used by :" => "Sử dụng bởi:"
);
