<?php $TRANSLATIONS = array(
"Dependencies status" => "Stav závislostí"
);
