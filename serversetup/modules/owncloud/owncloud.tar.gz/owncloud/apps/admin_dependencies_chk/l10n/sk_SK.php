<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "Modul php-json je potrebný na vzájomnú komunikáciu mnohých aplikácií.",
"The php-curl module is needed to fetch the page title when adding a bookmark" => "Modul php-curl je potrebný na získanie názvu stránky pri vytváraní záložky",
"The php-gd module is needed to create thumbnails of your images" => "Modul php-gd je potrebný na vytvorenie náhľadov obrázkov",
"The php-ldap module is needed connect to your ldap server" => "Modul php-ldap je potrebný pre pripojenie k vášmu ldap serveru",
"The php-zip module is needed download multiple files at once" => "Modul php-zip je potrebný pre sťahovanie viacerých súborov naraz",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "Modul php-mb_multibyte je potrebný na správnu funkciu kódovania.",
"The php-ctype module is needed validate data." => "Modul php-ctype je potrebný na validáciu údajov.",
"The php-xml module is needed to share files with webdav." => "Modul php-xml je potrebný pre zdieľanie súborov cez webdav.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "Premenná allow_url_fopen vo vašom súbore php.ini by mal byť nastavený na hodnotu 1 na získanie informácií z OCS serverov",
"The php-pdo module is needed to store owncloud data into a database." => "Modul php-pdo je potrebný na ukladanie údajov ownCloudu do databázy.",
"The iconv module is needed to convert data into the correct charset." => "Modul iconv je potrebný na prevod dát do správnej znakovej sady.",
"Dependencies status" => "Stav závislostí",
"Used by :" => "Používa:"
);
