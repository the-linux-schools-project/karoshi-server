<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "php-json-modulet er påkrævet for mange applikationer for at kunne kommunikere internt.",
"The php-curl module is needed to fetch the page title when adding a bookmark" => "php-curl-modulet er påkrævet for at kunne hente titelen på en side, når et bogmærke tilføjes.",
"The php-gd module is needed to create thumbnails of your images" => "php-gd-modulet er påkrævet for at at oprette miniaturer af dine billeder",
"The php-ldap module is needed connect to your ldap server" => "php-ldap-modulet er påkrævet for at kunne forbinde til en LDAP-server",
"The php-zip module is needed download multiple files at once" => "php-zip-modulet er påkrævet for at kunne downloade flere filer ad gangen.",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "php-mb_multibyte-modulet er påkrævet for at kunne administrere tegnkodning korrekt.",
"The php-ctype module is needed validate data." => "php-ctype-modulet er påkrævet for at kunne validere data.",
"The php-xml module is needed to share files with webdav." => "php-xml-modulet er påkrævet for at kunne dele filer over webdav.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "allow_url_fopen-direktivet i din php.ini skal sættes til 1 for at kunne hente vidensbasen fra OCS-servere",
"The php-pdo module is needed to store owncloud data into a database." => "php-pdo-modulet er påkrævet for at kunne gemme ownCloud-data i en database.",
"The iconv module is needed to convert data into the correct charset." => "iconv-modulet er påkrævet for at kunne konvertere dataene til det korrekte tegnsæt.",
"Dependencies status" => "Status for afhængigheder",
"Used by :" => "Bruges af:"
);
