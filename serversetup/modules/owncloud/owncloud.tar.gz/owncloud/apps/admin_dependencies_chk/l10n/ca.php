<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "El mòdul php-json és necessari per moltes aplicacions per comunicacions internes",
"The php-curl module is needed to fetch the page title when adding a bookmark" => "El mòdul php-curl és necessari per buscar el títol de la pàgina quan s'afegeix un marcador",
"The php-gd module is needed to create thumbnails of your images" => "El mòdul php-gd és necessari per generar miniatures d'imatges",
"The php-ldap module is needed connect to your ldap server" => "El mòdul php-ldap és necessari per connectar amb el servidor ldap",
"The php-zip module is needed download multiple files at once" => "El mòdul php-zip és necessari per baixar múltiples fitxers de cop",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "El mòdul php-mb_multibyte és necessari per gestionar correctament la codificació.",
"The php-ctype module is needed validate data." => "El mòdul php-ctype és necessari per validar dades.",
"The php-xml module is needed to share files with webdav." => "El mòdul php-xml és necessari per compatir els fitxers amb webdav.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "La directiva allow_url_fopen de php.ini hauria d'establir-se en 1 per accedir a la base de coneixements dels servidors OCS",
"The php-pdo module is needed to store owncloud data into a database." => "El mòdul php-pdo és necessari per desar les dades d'ownCloud en una base de dades.",
"The iconv module is needed to convert data into the correct charset." => "El módul iconv és necessari per convertir dades al codi de caràcters correcte.",
"Dependencies status" => "Estat de dependències",
"Used by :" => "Usat per:"
);
