<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "php-json modulua beharrezkoa dute aplikazio askok elkarren artean komunikatzekoallloadfasdfasdfasdfasd",
"The php-curl module is needed to fetch the page title when adding a bookmark" => "php-curl modulua beharrezkoa da laster marka bat gehitzerakoan orriaren izenburua lortzeko",
"The php-gd module is needed to create thumbnails of your images" => "php-gd modulua beharrezkoa da zure irudien iruditxoak sortzeko",
"The php-ldap module is needed connect to your ldap server" => "php-ldap modulua behar da zure ldap zerbitzarira konektatzeko",
"The php-zip module is needed download multiple files at once" => "php-zip modulua beharrezkoa da batean fitxategi anitz deskargatzeko",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "php-mb_multibyte modulua beharrezkoa da modu egoki batean kodeaketa kudeatzeko",
"The php-ctype module is needed validate data." => "php-ctype modulua beharrezkoa datuak egiaztatzeko.",
"The php-xml module is needed to share files with webdav." => "php-xml modulua beharrezkoa da webdav bidez fitxategiak partekatzeko",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "php.ini-ko allow_url_fopen direktiba 1 izan behar du OCS zerbitzarien informazioa lortzeko",
"The php-pdo module is needed to store owncloud data into a database." => "php-pdo modulua beharrezkoa da ownclouden datuak datu base batean gordetzeko",
"The iconv module is needed to convert data into the correct charset." => "iconv modulua beharrezkoa da datuak karaktere-sorta egokira bihurtzeko.",
"Dependencies status" => "Menpekotasunen egoera",
"Used by :" => "Honek erabilia:"
);
