<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "O módulo php-json is necessário para muitas aplicações para intercomunicações",
"The php-curl module is needed to fetch the page title when adding a bookmark" => "O módulo php-curl é necessário para guardar o titulo da página quando cria um marcador",
"The php-gd module is needed to create thumbnails of your images" => "O módulo php-gd é necessário para criar miniaturas das suas imagens",
"The php-ldap module is needed connect to your ldap server" => "O módulo php-ldap é necessário para ligar ao seu servidor ldap",
"The php-zip module is needed download multiple files at once" => "O módulo php-zip é necessário para descarregar vários ficheiros ao mesmo tempo",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "O módulo php-mb_multibyte é necessário para gerir correctamente a codificação.",
"The php-ctype module is needed validate data." => "O módulo php-ctype é necessário para validar dados.",
"The php-xml module is needed to share files with webdav." => "O módulo php-xml é necessário para partilhar ficheiros com webdav.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "A directiva allow_url_fopen do seu php.ini devia estar igual a 1 para ir buscar a base de conhecimento aos servidores OCS",
"The php-pdo module is needed to store owncloud data into a database." => "O módulo php-pdo é necessário para guardar dados owncloud na base de dados.",
"The iconv module is needed to convert data into the correct charset." => "O módulo iconv é necessário para converter dados para o charset correcto.",
"Dependencies status" => "Estado das dependências",
"Used by :" => "Usado por:"
);
