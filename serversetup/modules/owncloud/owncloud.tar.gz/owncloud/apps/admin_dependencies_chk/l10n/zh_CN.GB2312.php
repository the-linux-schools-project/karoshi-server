<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "许多应用都需要 php-json 模块以进行内部通讯",
"The php-curl module is needed to fetch the page title when adding a bookmark" => "需要 php-curl 模块以在添加书签时获取页面标题",
"The php-gd module is needed to create thumbnails of your images" => "需要 php-gd 模块以生成您相片的缩略图",
"The php-ldap module is needed connect to your ldap server" => "需要 php-ldap 模块以和您的 ldap 服务器连接",
"The php-zip module is needed download multiple files at once" => "需要 php-zip 模块以同时下载多个文件",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "需要 php-mb_multibyte 模块来正确加密。",
"The php-ctype module is needed validate data." => "需要 php-ctype 模块来校验数据。",
"The php-xml module is needed to share files with webdav." => "需要 php-xml 模块以通过 webdav 分享文件。",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "您 php.ini 中的 allow_url_fopen 选项应设置为 1 以从 OCS 服务器撷取知识库",
"The php-pdo module is needed to store owncloud data into a database." => "需要 php-pdo 模块来存储 ownCloud 数据到数据库。",
"The iconv module is needed to convert data into the correct charset." => "需要 iconv 模块以转换数据到正确的字符集。",
"Dependencies status" => "依赖状态",
"Used by :" => "被使用："
);
