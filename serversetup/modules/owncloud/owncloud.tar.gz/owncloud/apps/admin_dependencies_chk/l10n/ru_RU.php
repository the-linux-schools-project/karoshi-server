<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "Модуль php-json необходим многим приложениям для взаимосвязи",
"The php-curl module is needed to fetch the page title when adding a bookmark" => "Модуль php-curl необходим для извлечения заголовка страницы при добавлении закладки",
"The php-gd module is needed to create thumbnails of your images" => "Модуль php-gd необходим, чтобы создавать эскизы ваших изображений",
"The php-ldap module is needed connect to your ldap server" => "Модуль php-ldap необходим для соединения с Вашим ldap-сервером",
"The php-zip module is needed download multiple files at once" => "Модуль php-zip необходим для загрузки нескольких файлов одновременно",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "Модуль php-mb_multibyte необходим для правильного управления кодированием.",
"The php-ctype module is needed validate data." => "Модуль php-ctype необходим для проверки корректности данных",
"The php-xml module is needed to share files with webdav." => "Модуль php-xml необходим для общего доступа к файлам через webdav.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "Директива allow_url_fopen Вашего php.ini должна быть установлена в 1, чтобы получить базу знаний с серверов OCS",
"The php-pdo module is needed to store owncloud data into a database." => "Модуль php-pdo необходим для хранения данных owncloud в базе данных",
"The iconv module is needed to convert data into the correct charset." => "Модуль iconv необходим для конвертации данных в корректную кодировку.",
"Dependencies status" => "Статус зависимостей",
"Used by :" => "Используется:"
);
