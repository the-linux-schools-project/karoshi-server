<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "Daudzām lietotnēm komunikācijai ir vajadzīgs php-json modulis",
"The php-curl module is needed to fetch the page title when adding a bookmark" => "Lai, pievienojot grāmatzīmi, saņemtu lapas virsrakstu, ir vajadzīgs php-curl modulis.",
"The php-gd module is needed to create thumbnails of your images" => "Lai veidotu attēlu sīktēlus, ir vajadzīgs php-gd modulis",
"The php-ldap module is needed connect to your ldap server" => "Lai savienotos ar ldap serveri, ir vajadzīgs php-ldap modulis",
"The php-zip module is needed download multiple files at once" => "Lai lejupielādētu vairākas datnes vienlaicīgi, ir vajadzīgs php-zip modulis",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "Lai pareizi pārvaldītu kodējumu, ir vajadzīgs php-mb_multibyte modulis.",
"The php-ctype module is needed validate data." => "Lai pārbaudītu datus, ir vajadzīgs php-ctype moduis.",
"The php-xml module is needed to share files with webdav." => "Lai koplietotu datnes ar webdav, ir vajadzīgs php-xml modulis.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "Lai saņemtu zināšanu bāzi no OCS serveriem, php.ini datnes direktīva allow_url_fopen ir jāiestata uz 1.",
"The php-pdo module is needed to store owncloud data into a database." => "Lai saglabātu mākoņa datus datubāzē, ir vajadzīgs php-pdo modulis.",
"The iconv module is needed to convert data into the correct charset." => "Lai pārveidotu datus uz pareizu rakstzīmju kopu, ir vajadzīgs iconv modulis.",
"Dependencies status" => "Atkarību statuss",
"Used by :" => "Izmanto:"
);
