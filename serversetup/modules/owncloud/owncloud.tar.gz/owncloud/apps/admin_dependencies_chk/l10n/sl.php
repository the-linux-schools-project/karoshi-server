<?php $TRANSLATIONS = array(
"The php-json module is needed by the many applications for inter communications" => "Modul php-json je potreben za medsebojno komunikacijo veliko aplikacij.",
"The php-gd module is needed to create thumbnails of your images" => "Modul php-gd je potreben za ustvarjanje sličic za predogled.",
"The php-ldap module is needed connect to your ldap server" => "Modul php-ldap je potreben za povezavo z vašim ldap strežnikom.",
"The php-zip module is needed download multiple files at once" => "Modul php-zip je potreben za prenašanje večih datotek hkrati.",
"The php-mb_multibyte module is needed to manage correctly the encoding." => "Modul php-mb_multibyte je potreben za pravilno upravljanje kodiranja.",
"The php-ctype module is needed validate data." => "Modul php-ctype je potreben za preverjanje veljavnosti podatkov.",
"The php-xml module is needed to share files with webdav." => "Modul php-xml je potreben za izmenjavo datotek preko protokola WebDAV.",
"The allow_url_fopen directive of your php.ini should be set to 1 to retrieve knowledge base from OCS servers" => "Direktiva allow_url_fopen v vaši php.ini datoteki mora biti nastavljena na 1, če želite omogočiti dostop do zbirke znanja na strežnikih OCS.",
"The php-pdo module is needed to store owncloud data into a database." => "Modul php-pdo je potreben za shranjevanje ownCloud podatkov v podatkovno zbirko.",
"The iconv module is needed to convert data into the correct charset." => "Modul iconv je potreben za pretvarjanje podatkov v ustrezen nabor znakov.",
"Dependencies status" => "Stanje odvisnosti",
"Used by :" => "Uporablja:"
);
