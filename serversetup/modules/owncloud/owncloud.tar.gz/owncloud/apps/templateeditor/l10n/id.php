<?php
$TRANSLATIONS = array(
"Could not load template" => "Tidak dapat memuat templat",
"Saved" => "Disimpan",
"Reset" => "Atur Ulang",
"An error occurred" => "Terjadi kesalahan",
"Sharing email (HTML)" => "Berbagi email (HTML)",
"Sharing email (plain text fallback)" => "Berbagi email (teks biasa)",
"Lost password mail" => "Kehilangan sandi email",
"New user email (HTML)" => "Email pengguna baru (HTML)",
"New user email (plain text fallback)" => "Email pengguna baru (teks biasa)",
"Activity notification mail" => "Email pemberitahuan aktivitas",
"Mail Templates" => "Templat Email",
"Theme" => "Tema",
"Template" => "Templat",
"Please choose a template" => "Pilih sebuah templat",
"Save" => "Simpan"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
