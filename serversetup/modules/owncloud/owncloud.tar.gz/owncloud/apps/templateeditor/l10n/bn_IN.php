<?php
$TRANSLATIONS = array(
"Could not load template" => "টেমপ্লেট লোড করা যায়নি",
"Saved" => "সংরক্ষিত",
"Reset" => "রিসেট করুন",
"Lost password mail" => "হারানো পাসওয়ার্ডের জন্যে মেইল",
"Activity notification mail" => "কার্যকলাপের বিজ্ঞপ্তি মেইল",
"Theme" => "থিম",
"Template" => "টেম্পলেট ",
"Please choose a template" => "একটি টেম্পলেট বেছে নিন",
"Save" => "সেভ"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
