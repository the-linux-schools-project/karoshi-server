<?php
$TRANSLATIONS = array(
"Could not load template" => "Vorlage konnte nicht geladen werden",
"Saved" => "Gespeichert",
"Reset" => "Zurücksetzen",
"Sharing email (HTML)" => "E-Mail teilen (HTML)",
"Sharing email (plain text fallback)" => "E-Mail teilen (Nur-Text Ersatzfunktion)",
"Lost password mail" => "Passwort vergessen",
"New user email (HTML)" => "Neue Nutzer E-Mail (HTML)",
"New user email (plain text fallback)" => "Neue Nutzer E-Mail (Nur-Text Ersatzfunktion)",
"Activity notification mail" => "Mail-Benachrichtigung über die Aktivitäten",
"Mail Templates" => "Mail-Vorlagen",
"Theme" => "Theme",
"Template" => "Vorlage",
"Please choose a template" => "Bitte eine Vorlage wählen",
"Save" => "Speichern"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
