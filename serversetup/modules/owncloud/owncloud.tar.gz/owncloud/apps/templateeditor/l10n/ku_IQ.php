<?php
$TRANSLATIONS = array(
"Save" => "پاشکه‌وتکردن"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
