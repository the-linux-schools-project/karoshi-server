OC.L10N.register(
    "templateeditor",
    {
    "Could not load template" : "Ezin da txantiloia kargatu",
    "Saved" : "Gordeta",
    "Reset" : "Berrezarri",
    "Sharing email (HTML)" : "Partekatzeko eposta (HTML)",
    "Lost password mail" : "Postaren pasahitza galduta",
    "Activity notification mail" : "Jarduera jakinarazpen mezua",
    "Mail Templates" : "Posta Txantiloiak",
    "Theme" : "Gaia",
    "Template" : "Txantiloia",
    "Please choose a template" : "Aukeratu txantiloi bat",
    "Save" : "Gorde"
},
"nplurals=2; plural=(n != 1);");
