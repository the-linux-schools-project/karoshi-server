<?php
$TRANSLATIONS = array(
"Could not load template" => "Non foi posíbel cargar o modelo",
"Saved" => "Gardado",
"Reset" => "Restabelecer",
"An error occurred" => "Produciuse un erro",
"Sharing email (HTML)" => "Compartir por correo (HTML)",
"Sharing email (plain text fallback)" => "Compartir por correo (texto simple de reserva)",
"Lost password mail" => "Correo de contrasinal perdido",
"New user email (HTML)" => "Novo usuario do correo (HTML)",
"New user email (plain text fallback)" => "Novo usuario do correo (texto simple de reserva)",
"Activity notification mail" => "Correo de notificación de actividade",
"Mail Templates" => "Modelos de correo",
"Theme" => "Tema",
"Template" => "Modelo",
"Please choose a template" => "Escolla un modelo",
"Save" => "Gardar"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
