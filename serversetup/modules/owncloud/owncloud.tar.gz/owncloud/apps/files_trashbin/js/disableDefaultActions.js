/* disable download and sharing actions */
var disableDownloadActions = true;
var disableSharing = true;
var trashBinApp = true;