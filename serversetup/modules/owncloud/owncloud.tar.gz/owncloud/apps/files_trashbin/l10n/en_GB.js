OC.L10N.register(
    "files_trashbin",
    {
    "Couldn't delete %s permanently" : "Couldn't delete %s permanently",
    "Couldn't restore %s" : "Couldn't restore %s",
    "Deleted files" : "Deleted files",
    "Restore" : "Restore",
    "Delete permanently" : "Delete permanently",
    "Error" : "Error",
    "restored" : "restored",
    "No deleted files" : "No deleted files",
    "You will be able to recover deleted files from here" : "You will be able to recover deleted files from here",
    "No entries found in this folder" : "No entries found in this folder",
    "Select all" : "Select all",
    "Name" : "Name",
    "Deleted" : "Deleted",
    "Delete" : "Delete"
},
"nplurals=2; plural=(n != 1);");
