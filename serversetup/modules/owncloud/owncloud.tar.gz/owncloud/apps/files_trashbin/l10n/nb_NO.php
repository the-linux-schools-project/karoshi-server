<?php
$TRANSLATIONS = array(
"Couldn't delete %s permanently" => "Kunne ikke slette %s fullstendig",
"Couldn't restore %s" => "Kunne ikke gjenopprette %s",
"Error" => "Feil",
"Nothing in here. Your trash bin is empty!" => "Ingenting her. Søppelkassen din er tom!",
"Name" => "Navn",
"Restore" => "Gjenopprett",
"Deleted" => "Slettet",
"Delete" => "Slett",
"Deleted Files" => "Slettet filer"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
