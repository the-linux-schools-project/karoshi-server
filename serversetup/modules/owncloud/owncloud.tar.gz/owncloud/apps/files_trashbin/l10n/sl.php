<?php
$TRANSLATIONS = array(
"Couldn't delete %s permanently" => "Datoteke %s ni mogoče trajno izbrisati.",
"Couldn't restore %s" => "Ni mogoče obnoviti %s",
"Error" => "Napaka",
"restored" => "obnovljeno",
"Nothing in here. Your trash bin is empty!" => "Mapa smeti je prazna.",
"Name" => "Ime",
"Restore" => "Obnovi",
"Deleted" => "Izbrisano",
"Delete" => "Izbriši",
"Deleted Files" => "Izbrisane datoteke"
);
$PLURAL_FORMS = "nplurals=4; plural=(n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3);";
