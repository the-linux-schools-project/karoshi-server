<?php
$TRANSLATIONS = array(
"_%n folder_::_%n folders_" => array("",""),
"_%n file_::_%n files_" => array("","")
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
