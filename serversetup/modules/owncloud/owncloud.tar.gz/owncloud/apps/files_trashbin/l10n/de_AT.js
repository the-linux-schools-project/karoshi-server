OC.L10N.register(
    "files_trashbin",
    {
    "Error" : "Fehler",
    "Delete" : "Löschen"
},
"nplurals=2; plural=(n != 1);");
