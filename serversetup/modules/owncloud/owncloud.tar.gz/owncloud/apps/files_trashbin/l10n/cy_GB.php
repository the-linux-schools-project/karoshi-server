<?php
$TRANSLATIONS = array(
"Couldn't delete %s permanently" => "Methwyd dileu %s yn barhaol",
"Couldn't restore %s" => "Methwyd adfer %s",
"Error" => "Gwall",
"Nothing in here. Your trash bin is empty!" => "Does dim byd yma. Mae eich bin sbwriel yn wag!",
"Name" => "Enw",
"Restore" => "Adfer",
"Deleted" => "Wedi dileu",
"Delete" => "Dileu",
"Deleted Files" => "Ffeiliau Ddilewyd"
);
$PLURAL_FORMS = "nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;";
