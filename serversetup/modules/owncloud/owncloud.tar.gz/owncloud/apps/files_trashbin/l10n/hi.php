<?php
$TRANSLATIONS = array(
"Error" => "त्रुटि"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
