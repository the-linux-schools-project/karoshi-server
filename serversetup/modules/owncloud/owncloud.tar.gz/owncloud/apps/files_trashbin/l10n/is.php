<?php
$TRANSLATIONS = array(
"Error" => "Villa",
"Name" => "Nafn",
"Delete" => "Eyða"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
