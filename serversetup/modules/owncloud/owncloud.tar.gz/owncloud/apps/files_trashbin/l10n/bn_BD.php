<?php
$TRANSLATIONS = array(
"Error" => "সমস্যা",
"Name" => "রাম",
"Delete" => "মুছে"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
