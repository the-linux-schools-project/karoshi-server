OC.L10N.register(
    "files_trashbin",
    {
    "Couldn't delete %s permanently" : "無法永久刪除 %s",
    "Couldn't restore %s" : "無法還原 %s",
    "Deleted files" : "回收桶",
    "Restore" : "還原",
    "Delete permanently" : "永久刪除",
    "Error" : "錯誤",
    "restored" : "已還原",
    "No entries found in this folder" : "在此資料夾中沒有任何項目",
    "Select all" : "全選",
    "Name" : "名稱",
    "Deleted" : "已刪除",
    "Delete" : "刪除"
},
"nplurals=1; plural=0;");
