<?php
$TRANSLATIONS = array(
"Couldn't delete %s permanently" => "Không thể óa %s vĩnh viễn",
"Couldn't restore %s" => "Không thể khôi phục %s",
"Error" => "Lỗi",
"Nothing in here. Your trash bin is empty!" => "Không có gì ở đây. Thùng rác của bạn rỗng!",
"Name" => "Tên",
"Restore" => "Khôi phục",
"Deleted" => "Đã xóa",
"Delete" => "Xóa",
"Deleted Files" => "File đã xóa"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
