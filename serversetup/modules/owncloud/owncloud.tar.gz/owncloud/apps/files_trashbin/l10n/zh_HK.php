<?php
$TRANSLATIONS = array(
"Error" => "錯誤",
"Name" => "名稱",
"Delete" => "刪除"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
