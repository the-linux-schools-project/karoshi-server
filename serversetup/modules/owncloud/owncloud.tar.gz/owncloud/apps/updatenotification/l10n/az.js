OC.L10N.register(
    "updatenotification",
    {
    "Updater" : "Yeniləyici"
},
"nplurals=2; plural=(n != 1);");
