OC.L10N.register(
    "updatenotification",
    {
    "{version} is available. Get more information on how to update." : "{version} è disponibile. Ottieni ulteriori informazioni su come eseguire l'aggiornamento.",
    "Updater" : "Strumento di aggiornamento",
    "For security reasons the built-in ownCloud updater is using additional credentials. To visit the updater page please click the following button." : "Per ragioni di sicurezza, lo strumento di aggiornamento integrato di ownCloud utilizza credenziali aggiuntive. Per visitare la pagine dello strumento di aggiornamento, fai clic sul pulsante seguente.",
    "Open updater" : "Apri lo strumento di aggiornamento"
},
"nplurals=2; plural=(n != 1);");
