OC.L10N.register(
    "updatenotification",
    {
    "{version} is available. Get more information on how to update." : "{version} is available. Get more information on how to update.",
    "Updater" : "Updater",
    "For security reasons the built-in ownCloud updater is using additional credentials. To visit the updater page please click the following button." : "For security reasons the built-in ownCloud updater is using additional credentials. To visit the updater page please click the following button.",
    "Open updater" : "Open updater"
},
"nplurals=2; plural=(n != 1);");
