OC.L10N.register(
    "updatenotification",
    {
    "{version} is available. Get more information on how to update." : "Sürüm {version} hazır. Nasıl güncelleyeceğinizle ilgili daha fazla bilgi alın.",
    "Updater" : "Güncelleyici"
},
"nplurals=2; plural=(n > 1);");
