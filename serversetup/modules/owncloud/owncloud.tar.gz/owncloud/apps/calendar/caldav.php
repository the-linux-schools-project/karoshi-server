<?php
if(!file_exists('../../lib/base.php')) {
	die('Please update the path to /lib/base.php in caldav.php or make use of /remote.php/caldav/');
}
require_once'../../lib/base.php';
require_once'appinfo/remote.php';