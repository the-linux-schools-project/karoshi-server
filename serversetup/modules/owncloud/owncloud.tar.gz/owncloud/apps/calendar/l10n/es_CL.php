<?php
$TRANSLATIONS = array(
"Sunday" => "Domingo",
"Monday" => "Lunes",
"Tuesday" => "Martes",
"Wednesday" => "Miércoles",
"Thursday" => "Jueves",
"Friday" => "Viernes",
"Saturday" => "Sábado",
"January" => "Enero",
"February" => "Febrero",
"March" => "Marzo",
"April" => "Abril",
"May" => "Mayo",
"June" => "Junio",
"July" => "Julio",
"August" => "Agosto",
"September" => "Septiembre",
"October" => "Octubre",
"November" => "Noviembre",
"December" => "Diciembre",
"Personal" => "Personal",
"Daily" => "Diario",
"Weekly" => "Semanal",
"Download" => "Descargar",
"Share" => "Compartir",
"Import" => "Importar"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
