<?php $TRANSLATIONS = array(
"Calendar" => "Օրացույց",
"Other" => "Այլ",
"Month" => "Ամիս",
"Today" => "Այսօր",
"Download" => "Բեռնել",
"Delete" => "Ջնջել",
"Save" => "Պահպանել",
"Submit" => "Հաստատել",
"Description" => "Նկարագրություն"
);
