OC.L10N.register(
    "firstrunwizard",
    {
    "Welcome to %s" : "Benvenite a %s",
    "Your personal web services. All your files, contacts, calendar and more, in one place." : "Tu servicios personal de web. Omne tu files, contactos, calendario e alteres, in un placia.",
    "Get the apps to sync your files" : "Obtene le apps (applicationes) pro synchronizar tu files",
    "Connect your desktop apps to %s" : "Connecte tu apps de scriptorio a %s",
    "Connect your Calendar" : "Connecte tu calendario",
    "Connect your Contacts" : "Connecte tu  contactos",
    "Access files via WebDAV" : "Accede a files via WebDAV",
    "Documentation" : "Documentation",
    "There’s more information in the <a target=\"_blank\" href=\"%s\">documentation</a> and on our <a target=\"_blank\" href=\"http://owncloud.org\">website</a>." : "Il ha plure information in le <a target=\"_blank\" href=\"%s\">documentation</a> e sur nostre <a target=\"_blank\" href=\"http://owncloud.org\">sito web</a>."
},
"nplurals=2; plural=(n != 1);");
