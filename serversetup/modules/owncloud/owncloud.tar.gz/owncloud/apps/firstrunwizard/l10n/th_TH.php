<?php
$TRANSLATIONS = array(
"Documentation" => "เอกสารคู่มือประกอบการใช้งาน"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
