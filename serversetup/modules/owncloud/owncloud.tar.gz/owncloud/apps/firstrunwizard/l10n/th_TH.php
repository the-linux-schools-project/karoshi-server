<?php $TRANSLATIONS = array(
"First Run Wizard" => "หน้าจอวิซาร์ดนำทางครั้งแรก",
"Show First Run Wizard again" => "แสดงหน้าจอวิซาร์ดนำทางครั้งแรกอีกครั้ง"
);
