<?php $TRANSLATIONS = array(
"Welcome to ownCloud" => "歡迎來到ownCloud",
"Connect your Calendar" => "連接您的日曆"
);
