<?php $TRANSLATIONS = array(
"First Run Wizard" => "প্রথমবার চালানোর যাদুকর",
"Show First Run Wizard again" => "প্রথমবার চালানোর যাদুকর পূনরায় প্রদর্শন কর"
);
