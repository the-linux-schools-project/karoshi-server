<?php $TRANSLATIONS = array(
"Welcome to ownCloud" => "ownCloud에 오신 것을 환영합니다",
"Your personal web services. All your files, contacts, calendar and more, in one place." => "내 개인 웹 서비스입니다. 모든 파일, 연락처, 일정 등을 한 자리에 모을 수 있습니다.",
"Get the apps to sync your files" => "파일 동기화 앱 가져오기",
"Connect your desktop apps to ownCloud" => "데스크톱 앱을 ownCloud에 연결하기",
"Connect your Calendar" => "내 달력 연결하기",
"Connect your Contacts" => "내 연락처 연결하기",
"Access files via WebDAV" => "WebDAV로 파일에 접근하기",
"If you like ownCloud, <a href=\"mailto:?subject=ownCloud&body=ownCloud is a great open software to sync and share your files. You can freely get it from http://owncloud.org\">recommend it to your friends</a>!" => "ownCloud를 좋아하신다면 <a href=\"mailto:?subject=ownCloud&body=ownCloud는 내 파일을 공유하고 동기화할 수 있는 공개 소프트웨어입니다. http://owncloud.org 사이트에서 무료로 사용할 수 있습니다.\">친구들에게 알려 주세요</a>!"
);
