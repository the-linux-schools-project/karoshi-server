<?php
$TRANSLATIONS = array(
"Files" => "ਫਾਇਲਾਂ",
"Share" => "ਸਾਂਝਾ ਕਰੋ",
"Rename" => "ਨਾਂ ਬਦਲੋ",
"undo" => "ਵਾਪਸ",
"_%n folder_::_%n folders_" => array("",""),
"_%n file_::_%n files_" => array("",""),
"_Uploading %n file_::_Uploading %n files_" => array("",""),
"Error" => "ਗਲਤੀ",
"Upload" => "ਅੱਪਲੋਡ",
"Cancel upload" => "ਅੱਪਲੋਡ ਰੱਦ ਕਰੋ",
"Download" => "ਡਾਊਨਲੋਡ",
"Delete" => "ਹਟਾਓ"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
