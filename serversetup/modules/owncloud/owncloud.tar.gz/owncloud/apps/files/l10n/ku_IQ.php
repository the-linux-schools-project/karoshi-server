<?php
$TRANSLATIONS = array(
"Share" => "هاوبەشی کردن",
"_%n folder_::_%n folders_" => array("",""),
"_%n file_::_%n files_" => array("",""),
"_Uploading %n file_::_Uploading %n files_" => array("",""),
"Error" => "هه‌ڵه",
"Name" => "ناو",
"Upload" => "بارکردن",
"Save" => "پاشکه‌وتکردن",
"Folder" => "بوخچه",
"Download" => "داگرتن"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
