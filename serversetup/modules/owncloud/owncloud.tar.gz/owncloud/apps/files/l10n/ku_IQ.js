OC.L10N.register(
    "files",
    {
    "Files" : "په‌ڕگەکان",
    "Download" : "داگرتن",
    "Select" : "دیاریکردنی",
    "Error" : "هه‌ڵه",
    "Name" : "ناو",
    "_%n folder_::_%n folders_" : ["",""],
    "_%n file_::_%n files_" : ["",""],
    "_Uploading %n file_::_Uploading %n files_" : ["",""],
    "_matches '{filter}'_::_match '{filter}'_" : ["",""],
    "Save" : "پاشکه‌وتکردن",
    "Settings" : "ڕێکخستنه‌کان",
    "Folder" : "بوخچه",
    "Upload" : "بارکردن"
},
"nplurals=2; plural=(n != 1);");
