OC.L10N.register(
    "files",
    {
    "Files" : "په‌ڕگەکان",
    "Favorites" : "دڵخوازەکان",
    "Close" : "دابخه",
    "Download" : "داگرتن",
    "Select" : "دیاریکردنی",
    "Error" : "هه‌ڵه",
    "Name" : "ناو",
    "Upload" : "بارکردن",
    "Folder" : "بوخچه",
    "Save" : "پاشکه‌وتکردن",
    "Settings" : "ڕێکخستنه‌کان"
},
"nplurals=2; plural=(n != 1);");
