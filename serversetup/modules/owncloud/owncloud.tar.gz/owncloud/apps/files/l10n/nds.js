OC.L10N.register(
    "files",
    {
    "Files" : "Dateien",
    "Delete" : "Löschen",
    "Details" : "Details",
    "Name" : "Name",
    "New folder" : "Neuer Ordner",
    "Upload" : "Hochladen",
    "Settings" : "Einstellungen",
    "WebDAV" : "WebDAV"
},
"nplurals=2; plural=(n != 1);");
