OC.L10N.register(
    "files",
    {
    "Files" : "Dateien",
    "Delete" : "Löschen",
    "Name" : "Name",
    "Settings" : "Einstellungen",
    "WebDAV" : "WebDAV"
},
"nplurals=2; plural=(n != 1);");
