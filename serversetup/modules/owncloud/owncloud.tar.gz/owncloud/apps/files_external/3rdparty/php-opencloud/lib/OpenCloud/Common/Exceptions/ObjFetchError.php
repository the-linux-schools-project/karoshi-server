<?php

namespace OpenCloud\Common\Exceptions;

class ObjFetchError extends \Exception {}
