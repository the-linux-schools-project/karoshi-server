<?php
$TRANSLATIONS = array(
"Folder name" => "Dossiers Numm:",
"Groups" => "Gruppen",
"Users" => "Benotzer",
"Delete" => "Läschen"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
