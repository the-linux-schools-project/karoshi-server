<?php $TRANSLATIONS = array(
"External Sites" => "Ulkoiset sivustot",
"Name" => "Nimi",
"URL" => "Verkko-osoite",
"Remove site" => "Poista sivusto",
"Add" => "Lisää"
);
