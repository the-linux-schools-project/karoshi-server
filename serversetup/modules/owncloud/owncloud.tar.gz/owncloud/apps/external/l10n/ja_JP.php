<?php $TRANSLATIONS = array(
"External Sites" => "外部サイト",
"Name" => "名前",
"URL" => "URL",
"Remove site" => "サイトを削除",
"Add" => "追加"
);
