<?php $TRANSLATIONS = array(
"External Sites" => "Sites externes",
"Name" => "Nom",
"URL" => "URL",
"Remove site" => "Supprimer le site",
"Add" => "Ajouter"
);
