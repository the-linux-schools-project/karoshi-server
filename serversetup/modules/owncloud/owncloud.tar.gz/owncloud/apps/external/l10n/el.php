<?php $TRANSLATIONS = array(
"External Sites" => "Εξωτερικοί ιστότοποι",
"Name" => "Όνομα",
"URL" => "URL",
"Remove site" => "Αφαίρεση ιστότοπου",
"Add" => "Προσθήκη"
);
