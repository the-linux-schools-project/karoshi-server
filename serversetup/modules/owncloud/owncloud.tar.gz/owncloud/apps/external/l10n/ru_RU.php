<?php $TRANSLATIONS = array(
"External Sites" => "Внешние сайты",
"Name" => "Имя",
"URL" => "URL",
"Remove site" => "Удалить сайт",
"Add" => "Добавить"
);
