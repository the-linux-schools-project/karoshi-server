<?php $TRANSLATIONS = array(
"External Sites" => "Išoriniai serveriai",
"Name" => "Pavadinimas",
"URL" => "URL",
"Remove site" => "Pašalinti serverį",
"Add" => "Pridėti"
);
