<?php $TRANSLATIONS = array(
"External Sites" => "Páginas Externas",
"Name" => "Nome",
"URL" => "URL",
"Remove site" => "Remover página",
"Add" => "Acrescentar"
);
