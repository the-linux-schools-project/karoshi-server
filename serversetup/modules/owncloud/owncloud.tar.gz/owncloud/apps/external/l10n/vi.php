<?php $TRANSLATIONS = array(
"External Sites" => "URL bên ngoài",
"Name" => "Tên",
"URL" => "URL",
"Remove site" => "Xóa URL",
"Add" => "Địa chỉ"
);
