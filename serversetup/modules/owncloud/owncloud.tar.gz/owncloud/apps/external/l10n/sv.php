<?php $TRANSLATIONS = array(
"External Sites" => "Externa webbplatser",
"Name" => "Namn",
"URL" => "URL",
"Remove site" => "Ta bort webbplats",
"Add" => "Lägg till"
);
