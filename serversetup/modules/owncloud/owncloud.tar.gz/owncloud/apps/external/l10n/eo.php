<?php $TRANSLATIONS = array(
"External Sites" => "Malenaj ejoj",
"Name" => "Nomo",
"URL" => "URL",
"Remove site" => "Forigi ejon",
"Add" => "Aldoni"
);
