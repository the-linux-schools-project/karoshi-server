<?php $TRANSLATIONS = array(
"External Sites" => "外部站点",
"Name" => "名称",
"URL" => "网址",
"Remove site" => "移除站点",
"Add" => "添加"
);
