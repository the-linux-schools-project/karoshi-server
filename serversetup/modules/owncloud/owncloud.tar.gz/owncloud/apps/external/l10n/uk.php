<?php $TRANSLATIONS = array(
"Add" => "Додати"
);
