<?php $TRANSLATIONS = array(
"External Sites" => "Зовнішні сайти",
"Name" => "Ім'я",
"URL" => "URL",
"Remove site" => "Видалити сайт",
"Add" => "Додати"
);
