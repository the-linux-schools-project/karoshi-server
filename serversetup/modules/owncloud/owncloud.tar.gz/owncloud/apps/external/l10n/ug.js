OC.L10N.register(
    "external",
    {
    "Name" : "ئاتى",
    "URL" : "URL",
    "Add" : "قوش"
},
"nplurals=1; plural=0;");
