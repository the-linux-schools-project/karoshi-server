<?php $TRANSLATIONS = array(
"External Sites" => "Externe Seiten",
"Name" => "Name",
"URL" => "URL",
"Remove site" => "Seite entfernen",
"Add" => "Hinzufügen"
);
