<?php $TRANSLATIONS = array(
"External Sites" => "Kanpoko lekuak",
"Name" => "Izena",
"URL" => "URL",
"Remove site" => "Ezabatu lekua",
"Add" => "Gehitu"
);
