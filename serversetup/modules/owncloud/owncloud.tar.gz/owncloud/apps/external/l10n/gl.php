<?php $TRANSLATIONS = array(
"External Sites" => "Sitios externos",
"Name" => "Nome",
"URL" => "URL",
"Remove site" => "Quitar sitio",
"Add" => "Engadir"
);
