<?php $TRANSLATIONS = array(
"External Sites" => "אתרים חיצוניים",
"Name" => "שם",
"URL" => "כתובת",
"Remove site" => "הסרת אתר",
"Add" => "הוספה"
);
