<?php $TRANSLATIONS = array(
"External Sites" => "Zewnętrzne strony",
"Name" => "Nazwa",
"URL" => "URL",
"Remove site" => "Skasuj stronę",
"Add" => "Dodaj"
);
