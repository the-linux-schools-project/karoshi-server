<?php $TRANSLATIONS = array(
"External Sites" => "External Sites",
"Name" => "Name",
"URL" => "URL",
"Remove site" => "Remove site",
"Add" => "Add"
);
