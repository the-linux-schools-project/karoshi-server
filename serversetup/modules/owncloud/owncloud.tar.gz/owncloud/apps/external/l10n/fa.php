<?php $TRANSLATIONS = array(
"External Sites" => "سایت های خارجی",
"Name" => "نام",
"URL" => "آدرس",
"Remove site" => "حذف سایت",
"Add" => "افزودن"
);
