<?php $TRANSLATIONS = array(
"External Sites" => "Ekstern side",
"Name" => "Navn",
"URL" => "URL",
"Remove site" => "Fjern side",
"Add" => "Legg til"
);
