<?php $TRANSLATIONS = array(
"External Sites" => "ماڵپه‌ڕی ده‌ره‌کی",
"Name" => "ناو",
"URL" => "ناونیشانی به‌سته‌ر",
"Remove site" => "سڕینه‌وه‌ی ماڵپه‌ڕ",
"Add" => "زیادکردن"
);
