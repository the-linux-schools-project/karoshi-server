<?php $TRANSLATIONS = array(
"External Sites" => "Sites extèrnes",
"Name" => "Nom",
"URL" => "URL",
"Remove site" => "Escafa lo site",
"Add" => "Ajusta"
);
