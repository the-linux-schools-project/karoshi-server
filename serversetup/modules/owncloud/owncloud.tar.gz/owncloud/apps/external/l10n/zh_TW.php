<?php $TRANSLATIONS = array(
"External Sites" => "外部站台",
"Name" => "名稱",
"Remove site" => "移除站台",
"Add" => "新增"
);
