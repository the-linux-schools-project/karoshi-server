<?php $TRANSLATIONS = array(
"External Sites" => "Externe sites",
"Name" => "Naam",
"URL" => "URL",
"Remove site" => "Verwijder site",
"Add" => "Voeg toe"
);
