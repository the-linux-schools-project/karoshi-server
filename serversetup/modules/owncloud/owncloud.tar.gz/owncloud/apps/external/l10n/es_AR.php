<?php $TRANSLATIONS = array(
"External Sites" => "Sitios externos",
"Name" => "Nombre",
"URL" => "URL",
"Remove site" => "Borrar sitio",
"Add" => "Agregar"
);
