<?php $TRANSLATIONS = array(
"External Sites" => "Externí stránky",
"Name" => "Název",
"URL" => "URL",
"Remove site" => "Odstranit stránku",
"Add" => "Přidat"
);
