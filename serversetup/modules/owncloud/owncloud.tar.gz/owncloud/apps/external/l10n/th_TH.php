<?php $TRANSLATIONS = array(
"External Sites" => "เว็บไซต์ภายนอก",
"Name" => "ชื่อ",
"URL" => "URL",
"Remove site" => "ลบเว็บไซต์ออก",
"Add" => "เพิ่ม"
);
