<?php $TRANSLATIONS = array(
"External Sites" => "Externé stránky",
"Name" => "Meno",
"URL" => "URL",
"Remove site" => "Odstrániť stránku",
"Add" => "Pridať"
);
