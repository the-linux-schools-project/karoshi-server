<?php $TRANSLATIONS = array(
"External Sites" => "Externé stránky",
"Name" => "Názov",
"URL" => "URL",
"Remove site" => "Odstrániť stránku",
"Add" => "Pridať"
);
