<?php $TRANSLATIONS = array(
"External Sites" => "Siti esterni",
"Name" => "Nome",
"URL" => "URL",
"Remove site" => "Rimuovi il sito",
"Add" => "Aggiungi"
);
