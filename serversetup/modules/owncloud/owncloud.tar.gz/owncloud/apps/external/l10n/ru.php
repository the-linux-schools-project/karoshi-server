<?php $TRANSLATIONS = array(
"External Sites" => "Внешние сайты",
"Name" => "Имя",
"URL" => "Ссылка",
"Remove site" => "Удалить сайт",
"Add" => "Добавить"
);
