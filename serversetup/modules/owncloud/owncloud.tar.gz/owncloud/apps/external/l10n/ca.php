<?php $TRANSLATIONS = array(
"External Sites" => "Llocs web externs",
"Name" => "Nom",
"URL" => "URL",
"Remove site" => "Elimina el lloc",
"Add" => "Afegeix"
);
