<?php $TRANSLATIONS = array(
"External Sites" => "Sites externos",
"Name" => "Nome",
"URL" => "URL",
"Remove site" => "Remover site",
"Add" => "Adicionar"
);
