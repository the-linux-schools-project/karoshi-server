<?php $TRANSLATIONS = array(
"External Sites" => "Välised saidid",
"Name" => "Nimi",
"URL" => "URL",
"Remove site" => "Eemalda sait",
"Add" => "Lisa"
);
