<?php $TRANSLATIONS = array(
"External Sites" => "Eksterne sites",
"Name" => "Navn",
"URL" => "URL",
"Remove site" => "Fjern site",
"Add" => "Tilføj"
);
