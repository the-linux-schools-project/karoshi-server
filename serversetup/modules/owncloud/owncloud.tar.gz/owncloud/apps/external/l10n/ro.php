<?php $TRANSLATIONS = array(
"External Sites" => "Pagini externe",
"Name" => "Nume",
"URL" => "URL",
"Remove site" => "Înlătură pagina",
"Add" => "Adaugă"
);
