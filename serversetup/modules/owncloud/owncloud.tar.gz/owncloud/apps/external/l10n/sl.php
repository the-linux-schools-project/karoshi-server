<?php $TRANSLATIONS = array(
"External Sites" => "Zunanje strani",
"Name" => "Ime",
"URL" => "URL",
"Remove site" => "Odstrani stran",
"Add" => "Dodaj"
);
