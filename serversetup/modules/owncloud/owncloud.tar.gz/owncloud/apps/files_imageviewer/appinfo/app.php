<?php

OCP\Util::addscript( 'files_imageviewer', 'lightbox' );
OCP\Util::addscript('files_imageviewer', 'jquery.mousewheel-3.0.4.pack');
OCP\Util::addscript('files_imageviewer', 'jquery.fancybox-1.3.4.pack');
OCP\Util::addStyle( 'files_imageviewer', 'jquery.fancybox-1.3.4' );
