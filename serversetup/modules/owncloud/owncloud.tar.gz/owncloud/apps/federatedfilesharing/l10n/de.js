OC.L10N.register(
    "federatedfilesharing",
    {
    "Invalid Federated Cloud ID" : "Ungültige Federated-Cloud-ID",
    "Sharing %s failed, because this item is already shared with %s" : "Freigabe von %s fehlgeschlagen, da dieses Objekt schon mit %s geteilt wird",
    "Not allowed to create a federated share with the same user" : "Das Erstellen einer föderierten Freigabe mit dem gleichen Benutzer ist nicht erlaubt",
    "Sharing %s failed, could not find %s, maybe the server is currently unreachable." : "Freigabe von %s fehlgeschlagen, da %s nicht gefunden wurde. Möglicherweise ist der Server nicht erreichbar."
},
"nplurals=2; plural=(n != 1);");
