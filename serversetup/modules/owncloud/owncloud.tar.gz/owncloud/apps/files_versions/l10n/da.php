<?php
$TRANSLATIONS = array(
"Could not revert: %s" => "Kunne ikke genskabe: %s",
"Versions" => "Versioner",
"Failed to revert {file} to revision {timestamp}." => "Kunne ikke tilbagerulle {file} til den tidligere udgave: {timestamp}.",
"More versions..." => "Flere versioner...",
"No other versions available" => "Ingen andre versioner tilgængelig",
"Restore" => "Gendan"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
