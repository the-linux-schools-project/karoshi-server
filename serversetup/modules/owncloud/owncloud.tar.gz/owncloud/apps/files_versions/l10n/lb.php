<?php $TRANSLATIONS = array(
"History" => "Historique",
"Files Versioning" => "Fichier's Versionéierung ",
"Enable" => "Aschalten"
);
