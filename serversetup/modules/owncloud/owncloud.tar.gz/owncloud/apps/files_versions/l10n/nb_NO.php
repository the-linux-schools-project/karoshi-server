<?php
$TRANSLATIONS = array(
"Versions" => "Versjoner",
"Restore" => "Gjenopprett"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
