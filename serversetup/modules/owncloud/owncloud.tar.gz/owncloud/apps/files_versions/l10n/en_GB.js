OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Could not revert: %s",
    "Versions" : "Versions",
    "Failed to revert {file} to revision {timestamp}." : "Failed to revert {file} to revision {timestamp}.",
    "More versions..." : "More versions...",
    "No other versions available" : "No other versions available",
    "Restore" : "Restore"
},
"nplurals=2; plural=(n != 1);");
