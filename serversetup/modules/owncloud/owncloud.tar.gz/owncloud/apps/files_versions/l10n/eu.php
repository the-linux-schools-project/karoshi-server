<?php
$TRANSLATIONS = array(
"Could not revert: %s" => "Ezin izan da leheneratu: %s",
"Versions" => "Bertsioak",
"Failed to revert {file} to revision {timestamp}." => "Errore bat izan da {fitxategia} {timestamp} bertsiora leheneratzean.",
"More versions..." => "Bertsio gehiago...",
"No other versions available" => "Ez dago bertsio gehiago eskuragarri",
"Restore" => "Berrezarri"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
