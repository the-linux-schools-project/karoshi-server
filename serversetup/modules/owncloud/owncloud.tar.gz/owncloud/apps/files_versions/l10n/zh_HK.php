<?php
$TRANSLATIONS = array(
"Versions" => "版本"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
