<?php
$TRANSLATIONS = array(
"Versions" => "ভার্সন"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
