<?php $TRANSLATIONS = array(
"Help" => "Adjuta"
);
