<?php $TRANSLATIONS = array(
"Deletion failed" => "මකාදැමීම අසාර්ථකයි",
"Host" => "සත්කාරකය",
"You can omit the protocol, except you require SSL. Then start with ldaps://" => "SSL අවශ්‍යය වන විට පමණක් හැර, අන් අවස්ථාවන්හිදී ප්‍රොටොකෝලය අත් හැරිය හැක. භාවිතා කරන විට ldaps:// ලෙස ආරම්භ කරන්න",
"Password" => "මුර පදය",
"User Login Filter" => "පරිශීලක පිවිසුම් පෙරහන",
"User List Filter" => "පරිශීලක ලැයිස්තු පෙරහන",
"Group Filter" => "කණ්ඩායම් පෙරහන",
"Defines the filter to apply, when retrieving groups." => "කණ්ඩායම් සොයා ලබාගන්නා විට, යොදන පෙරහන නියම කරයි",
"Port" => "තොට",
"Use TLS" => "TLS භාවිතා කරන්න",
"Not recommended, use for testing only." => "නිර්දේශ කළ නොහැක. පරීක්ෂණ සඳහා පමණක් භාවිත කරන්න",
"Help" => "උදව්"
);
