<?php $TRANSLATIONS = array(
"Deletion failed" => "Бришењето е неуспешно",
"Host" => "Домаќин",
"You can omit the protocol, except you require SSL. Then start with ldaps://" => "Може да го скокнете протколот освен ако не ви треба SSL. Тогаш ставете ldaps://",
"Password" => "Лозинка",
"Help" => "Помош"
);
