OC.L10N.register(
    "user_ldap",
    {
    "Failed to clear the mappings." : "Xəritələnməni silmək mümkün olmadı",
    "Failed to delete the server configuration" : "Server configini silmək mümkün olmadı",
    "The configuration is valid and the connection could be established!" : "Configurasiya doğrudur və qoşulmaq mümkündür!",
    "The configuration is valid, but the Bind failed. Please check the server settings and credentials." : "Configurasiya doğrudur yalnız, birləşmədə səhv oldu. Xahiş olunur server quraşdırmalarını və daxil etdiyiniz verilənlərin düzgünlüyünü yoxlayasınız.",
    "The configuration is invalid. Please have a look at the logs for further details." : "Configurasiya dügün deyil. Əlavə detallar üçün xahiş edirik jurnal faylına baxasınız.",
    "No action specified" : "Heç bir iş təyin edilməyib",
    " Could not set configuration %s" : "%s configi təyin etmək mümkün olmadı",
    "Deletion failed" : "Silinmədə səhv baş verdi",
    "Keep settings?" : "Ayarlar qalsın?",
    "Cannot add server configuration" : "Server quraşdırmalarını əlavə etmək mümkün olmadı",
    "Error" : "Səhv",
    "_%s group found_::_%s groups found_" : ["",""],
    "_%s user found_::_%s users found_" : ["",""],
    "Save" : "Saxlamaq",
    "Help" : "Kömək",
    "Host" : "Şəbəkədə ünvan",
    "Password" : "Şifrə"
},
"nplurals=2; plural=(n != 1);");
