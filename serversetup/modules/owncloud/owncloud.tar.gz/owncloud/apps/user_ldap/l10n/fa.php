<?php $TRANSLATIONS = array(
"Failed to delete the server configuration" => "عملیات حذف پیکربندی سرور ناموفق ماند",
"The configuration is valid and the connection could be established!" => "پیکربندی معتبر است و ارتباط می تواند برقرار شود",
"Deletion failed" => "حذف کردن انجام نشد",
"Keep settings?" => "آیا تنظیمات ذخیره شود ؟",
"Connection test succeeded" => "تست اتصال با موفقیت انجام گردید",
"Connection test failed" => "تست اتصال ناموفق بود",
"Do you really want to delete the current Server Configuration?" => "آیا واقعا می خواهید پیکربندی کنونی سرور را حذف کنید؟",
"Confirm Deletion" => "تایید حذف",
"Server configuration" => "پیکربندی سرور",
"Add Server Configuration" => "افزودن پیکربندی سرور",
"Host" => "میزبانی",
"Password" => "رمز عبور",
"Port" => "درگاه",
"in bytes" => "در بایت",
"Help" => "راه‌نما"
);
