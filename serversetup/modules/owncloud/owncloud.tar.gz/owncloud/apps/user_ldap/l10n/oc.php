<?php $TRANSLATIONS = array(
"Deletion failed" => "Fracàs d'escafatge",
"Help" => "Ajuda"
);
