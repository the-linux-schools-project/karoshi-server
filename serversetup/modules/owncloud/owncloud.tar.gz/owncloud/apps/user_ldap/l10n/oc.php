<?php
$TRANSLATIONS = array(
"Deletion failed" => "Fracàs d'escafatge",
"Error" => "Error",
"_%s group found_::_%s groups found_" => array("",""),
"_%s user found_::_%s users found_" => array("",""),
"Save" => "Enregistra",
"Help" => "Ajuda",
"Password" => "Senhal"
);
$PLURAL_FORMS = "nplurals=2; plural=(n > 1);";
