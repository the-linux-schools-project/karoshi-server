<?php $TRANSLATIONS = array(
"Deletion failed" => "Pemadaman gagal",
"Help" => "Bantuan"
);
