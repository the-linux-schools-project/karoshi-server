<?php $TRANSLATIONS = array(
"Password" => "پاسورڈ",
"Help" => "مدد"
);
