<?php $TRANSLATIONS = array(
"Help" => "Pomoć"
);
