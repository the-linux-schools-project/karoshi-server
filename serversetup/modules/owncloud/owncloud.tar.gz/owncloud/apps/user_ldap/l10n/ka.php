<?php $TRANSLATIONS = array(
"Password" => "პაროლი",
"Help" => "შველა"
);
