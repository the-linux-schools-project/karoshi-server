<?php $TRANSLATIONS = array(
"Deletion failed" => "فشل الحذف",
"Password" => "كلمة المرور",
"Help" => "المساعدة"
);
