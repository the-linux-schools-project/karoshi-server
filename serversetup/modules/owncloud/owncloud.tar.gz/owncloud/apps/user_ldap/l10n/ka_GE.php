<?php $TRANSLATIONS = array(
"Deletion failed" => "წაშლის ველი",
"Help" => "დახმარება"
);
