<?php $TRANSLATIONS = array(
"Deletion failed" => "Ištrinti nepavyko",
"Password" => "Slaptažodis",
"Group Filter" => "Grupės filtras",
"Port" => "Prievadas",
"Use TLS" => "Naudoti TLS",
"Turn off SSL certificate validation." => "Išjungti SSL sertifikato tikrinimą.",
"Not recommended, use for testing only." => "Nerekomenduojama, naudokite tik testavimui.",
"Help" => "Pagalba"
);
