<?php $TRANSLATIONS = array(
"Password" => "Парола",
"Help" => "Помощ"
);
