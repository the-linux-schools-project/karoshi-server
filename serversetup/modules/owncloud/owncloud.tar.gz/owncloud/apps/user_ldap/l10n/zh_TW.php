<?php $TRANSLATIONS = array(
"Deletion failed" => "移除失敗",
"Host" => "主機",
"Password" => "密碼",
"Port" => "連接阜",
"Use TLS" => "使用TLS",
"Turn off SSL certificate validation." => "關閉 SSL 憑證驗證",
"Help" => "說明"
);
