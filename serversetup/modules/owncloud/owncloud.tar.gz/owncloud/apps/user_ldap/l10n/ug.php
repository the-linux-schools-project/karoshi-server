<?php
$TRANSLATIONS = array(
"Deletion failed" => "ئۆچۈرۈش مەغلۇپ بولدى",
"Error" => "خاتالىق",
"_%s group found_::_%s groups found_" => array(""),
"_%s user found_::_%s users found_" => array(""),
"Save" => "ساقلا",
"Help" => "ياردەم",
"Host" => "باش ئاپپارات",
"Port" => "ئېغىز",
"Password" => "ئىم",
"Connection Settings" => "باغلىنىش تەڭشىكى",
"Configuration Active" => "سەپلىمە ئاكتىپ"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
