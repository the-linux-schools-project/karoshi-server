<?php $TRANSLATIONS = array(
"Help" => "सहयोग"
);
