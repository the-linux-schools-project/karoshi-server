<?php
$TRANSLATIONS = array(
"Error" => "त्रुटि",
"_%s group found_::_%s groups found_" => array("",""),
"_%s user found_::_%s users found_" => array("",""),
"Save" => "सहेजें",
"Help" => "सहयोग",
"Password" => "पासवर्ड"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
