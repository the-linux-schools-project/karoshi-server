<?php $TRANSLATIONS = array(
"Host" => "Netþjónn",
"Password" => "Lykilorð",
"Help" => "Hjálp"
);
