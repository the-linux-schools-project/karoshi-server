<?php $TRANSLATIONS = array(
"Deletion failed" => "Konnt net läschen",
"Password" => "Passwuert",
"Help" => "Hëllef"
);
