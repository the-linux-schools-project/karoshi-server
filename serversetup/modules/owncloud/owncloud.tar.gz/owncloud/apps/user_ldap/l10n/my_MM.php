<?php $TRANSLATIONS = array(
"Password" => "စကားဝှက်",
"Help" => "အကူအညီ"
);
