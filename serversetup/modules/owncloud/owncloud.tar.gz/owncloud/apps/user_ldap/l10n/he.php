<?php $TRANSLATIONS = array(
"Deletion failed" => "מחיקה נכשלה",
"Host" => "מארח",
"User DN" => "DN משתמש",
"Password" => "סיסמא",
"For anonymous access, leave DN and Password empty." => "לגישה אנונימית, השאר את הDM והסיסמא ריקים.",
"User Login Filter" => "סנן כניסת משתמש",
"User List Filter" => "סנן רשימת משתמשים",
"Group Filter" => "סנן קבוצה",
"Port" => "פורט",
"in seconds. A change empties the cache." => "בשניות. שינוי מרוקן את המטמון.",
"in bytes" => "בבתים",
"Help" => "עזרה"
);
