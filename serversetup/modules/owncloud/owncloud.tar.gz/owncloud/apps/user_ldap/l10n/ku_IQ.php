<?php $TRANSLATIONS = array(
"Help" => "یارمەتی"
);
