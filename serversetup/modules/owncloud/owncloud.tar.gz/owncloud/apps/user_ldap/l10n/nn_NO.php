<?php
$TRANSLATIONS = array(
"Deletion failed" => "Feil ved sletting",
"Error" => "Feil",
"Select groups" => "Vel grupper",
"_%s group found_::_%s groups found_" => array("",""),
"_%s user found_::_%s users found_" => array("",""),
"Save" => "Lagra",
"Help" => "Hjelp",
"Host" => "Tenar",
"Password" => "Passord",
"Back" => "Tilbake",
"Continue" => "Gå vidare"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
