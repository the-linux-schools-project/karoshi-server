<?php $TRANSLATIONS = array(
"Help" => "Hjelp"
);
