<?php $TRANSLATIONS = array(
"Activity" => "活動",
"No more activities to load." => "沒有更多活動要讀取。",
"Loading older activities" => "讀取舊的活動中",
"RSS feed" => "RSS 來源",
"No activities yet." => "沒有正在活動的。",
"You will see a list of events here when you start to use your %s." => "當您開始使用您的 %s 時候，您將會在這看到事件列表。"
);
