<?php $TRANSLATIONS = array(
"Update" => "Cập nhật"
);
