<?php $TRANSLATIONS = array(
"Update" => "Ажурирај",
"Download" => "Преузми",
"Delete" => "Обриши"
);
