<?php $TRANSLATIONS = array(
"Update" => "Eguneratu"
);
