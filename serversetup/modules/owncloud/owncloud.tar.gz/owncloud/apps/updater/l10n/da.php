<?php $TRANSLATIONS = array(
"Update" => "Opdater"
);
