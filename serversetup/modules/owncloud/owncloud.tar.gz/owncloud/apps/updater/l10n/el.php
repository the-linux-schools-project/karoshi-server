<?php $TRANSLATIONS = array(
"Update" => "Αναβάθμιση"
);
