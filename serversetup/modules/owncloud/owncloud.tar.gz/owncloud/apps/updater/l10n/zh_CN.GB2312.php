<?php $TRANSLATIONS = array(
"Update" => "更新"
);
