<?php $TRANSLATIONS = array(
"Update" => "Päivitä"
);
