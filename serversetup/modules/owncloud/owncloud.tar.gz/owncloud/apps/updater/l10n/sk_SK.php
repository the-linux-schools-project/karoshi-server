<?php $TRANSLATIONS = array(
"Update" => "Aktualizovať"
);
