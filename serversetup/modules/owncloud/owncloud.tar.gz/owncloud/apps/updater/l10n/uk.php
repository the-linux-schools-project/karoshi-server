<?php $TRANSLATIONS = array(
"Update" => "Оновити"
);
