<?php $TRANSLATIONS = array(
"Download" => "Preuzmi",
"Delete" => "Obriši"
);
