<?php $TRANSLATIONS = array(
"Update" => "Atualizar"
);
