<?php $TRANSLATIONS = array(
"Update" => "Posodobi"
);
