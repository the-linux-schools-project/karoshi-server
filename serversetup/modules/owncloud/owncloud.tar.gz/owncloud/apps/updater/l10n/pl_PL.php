<?php $TRANSLATIONS = array(
"Update" => "Uaktualnienie"
);
