<?php $TRANSLATIONS = array(
"Update" => "Uppdatera"
);
