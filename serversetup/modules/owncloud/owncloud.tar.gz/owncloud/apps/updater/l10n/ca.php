<?php $TRANSLATIONS = array(
"Update" => "Actualitza"
);
