<?php $TRANSLATIONS = array(
"Download" => "Բեռնել",
"Delete" => "Ջնջել"
);
