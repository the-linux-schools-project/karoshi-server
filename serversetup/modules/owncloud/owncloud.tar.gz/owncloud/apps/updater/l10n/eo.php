<?php $TRANSLATIONS = array(
"Update" => "Ĝisdatigi"
);
