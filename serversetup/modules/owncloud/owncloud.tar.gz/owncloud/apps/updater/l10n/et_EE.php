<?php $TRANSLATIONS = array(
"Update" => "Uuenda"
);
