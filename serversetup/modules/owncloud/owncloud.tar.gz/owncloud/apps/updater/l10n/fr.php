<?php $TRANSLATIONS = array(
"Update" => "Mettre à jour"
);
