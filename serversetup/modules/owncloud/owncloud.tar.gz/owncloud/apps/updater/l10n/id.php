<?php $TRANSLATIONS = array(
"Update" => "Pembaruan"
);
