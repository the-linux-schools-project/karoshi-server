<?php $TRANSLATIONS = array(
"Update" => "อัพเดท"
);
