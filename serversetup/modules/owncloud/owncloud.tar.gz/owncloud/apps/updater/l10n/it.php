<?php $TRANSLATIONS = array(
"Update" => "Aggiorna"
);
