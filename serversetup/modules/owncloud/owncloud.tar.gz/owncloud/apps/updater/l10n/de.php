<?php $TRANSLATIONS = array(
"Update" => "Update durchführen"
);
