<?php $TRANSLATIONS = array(
"Update" => "Aktualizovat"
);
