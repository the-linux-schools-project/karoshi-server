<?php $TRANSLATIONS = array(
"Error" => "ایرر"
);
