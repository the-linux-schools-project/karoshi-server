<?php
$TRANSLATIONS = array(
"Download" => "ڈاؤن لوڈ،",
"Delete" => "حذف کریں"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
