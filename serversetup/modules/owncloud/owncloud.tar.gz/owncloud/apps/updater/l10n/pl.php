<?php $TRANSLATIONS = array(
"Update" => "Zaktualizuj"
);
