<?php $TRANSLATIONS = array(
"Update" => "نوێکردنه‌وه"
);
