<?php $TRANSLATIONS = array(
"Update" => "Bijwerken"
);
