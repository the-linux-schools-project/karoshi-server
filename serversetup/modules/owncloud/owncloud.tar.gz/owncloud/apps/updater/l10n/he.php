<?php $TRANSLATIONS = array(
"Update" => "עדכון"
);
