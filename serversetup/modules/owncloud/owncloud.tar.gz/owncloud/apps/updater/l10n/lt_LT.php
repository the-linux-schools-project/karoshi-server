<?php $TRANSLATIONS = array(
"Update" => "Atnaujinti"
);
