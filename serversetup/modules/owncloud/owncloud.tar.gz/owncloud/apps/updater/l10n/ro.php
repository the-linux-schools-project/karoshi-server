<?php $TRANSLATIONS = array(
"Update" => "Actualizare"
);
