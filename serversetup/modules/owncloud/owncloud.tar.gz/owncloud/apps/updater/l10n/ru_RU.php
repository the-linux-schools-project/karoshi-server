<?php $TRANSLATIONS = array(
"Update" => "Обновить"
);
