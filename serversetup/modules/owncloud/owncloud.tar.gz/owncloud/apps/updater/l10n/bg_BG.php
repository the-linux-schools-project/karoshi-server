<?php $TRANSLATIONS = array(
"Here is your backup: " => "Тук е Вашия архив:",
"Update" => "Обновяване",
"Download" => "Изтегляне",
"Delete" => "Изтриване"
);
