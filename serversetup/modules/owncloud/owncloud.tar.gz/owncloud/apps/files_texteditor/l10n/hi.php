<?php $TRANSLATIONS = array(
"Save" => "सहेजें",
"Close" => "बंद करें "
);
