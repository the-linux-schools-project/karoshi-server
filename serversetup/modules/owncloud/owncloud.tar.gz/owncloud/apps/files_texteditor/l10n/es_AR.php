<?php $TRANSLATIONS = array(
"Save" => "Guardar",
"Search" => "Buscar",
"Close" => "Cerrar",
"Next" => "Siguiente",
"Clear" => "Borrar",
"Saving..." => "Guardando...",
"Failed to save file" => "Error al intentar guardar el archivo",
"An error occurred!" => "¡Ocurrió un error!",
"There were unsaved changes, click here to go back" => "Hay cambios que no fueros guardados, hacé click aquí para volver"
);
