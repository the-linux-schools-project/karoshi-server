<?php $TRANSLATIONS = array(
"Save" => "Lưu",
"Search" => "Tìm kiếm",
"Close" => "Đóng",
"Next" => "Kế tiếp",
"Clear" => "Xóa",
"Saving..." => "Đang lưu...",
"Failed to save file" => "Lỗi khi lưu file",
"An error occurred!" => "Có một lỗi đã xảy ra!",
"There were unsaved changes, click here to go back" => "Thay đổi không được lưu, bấm vào đây để trở lại"
);
