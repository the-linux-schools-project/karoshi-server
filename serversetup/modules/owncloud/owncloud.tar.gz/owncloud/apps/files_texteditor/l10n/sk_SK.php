<?php $TRANSLATIONS = array(
"Save" => "Uložiť",
"Search" => "Hľadaj",
"Close" => "Zatvoriť",
"Next" => "Ďalšia",
"Clear" => "Vyčistiť",
"Saving..." => "Ukladám...",
"Failed to save file" => "Súbor sa nepodarilo uložiť",
"An error occurred!" => "Vyskytla sa chyba!",
"There were unsaved changes, click here to go back" => "Zostali neuložené zmeny. Kliknite sem pre návrat"
);
