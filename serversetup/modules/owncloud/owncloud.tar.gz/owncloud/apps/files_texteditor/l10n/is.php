<?php $TRANSLATIONS = array(
"Save" => "Vista",
"Close" => "Loka",
"Next" => "Næst",
"Clear" => "Hreinsa",
"Saving..." => "Er að vista ...",
"Failed to save file" => "Ekki tókst að vista skrána",
"An error occurred!" => "Villa kom upp!",
"There were unsaved changes, click here to go back" => "Það átti eftir að vista breytingar, smellti hér til að fara til baka"
);
