<?php $TRANSLATIONS = array(
"Save" => "Zapisz",
"Next" => "Następny"
);
