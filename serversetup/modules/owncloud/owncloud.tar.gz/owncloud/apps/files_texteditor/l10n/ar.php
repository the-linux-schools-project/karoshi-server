<?php $TRANSLATIONS = array(
"Save" => "حفظ",
"Search" => "البحث",
"Close" => "إغلاق",
"Next" => "التالي",
"Clear" => "محو",
"Saving..." => "جاري الحفظ...",
"Failed to save file" => "لقد فشل حفظ الملف",
"An error occurred!" => "حدث خطأ!",
"There were unsaved changes, click here to go back" => "هناك تغييرات غير محفوظة، اضغط هنا للعودة"
);
