<?php $TRANSLATIONS = array(
"Save" => "پاشکه‌وتکردن",
"Close" => "داخستن",
"Next" => "دوواتر",
"Saving..." => "پاشکه‌وتده‌کات...",
"An error occurred!" => "هه‌ڵه‌یه‌ك ڕوویدا!",
"There were unsaved changes, click here to go back" => "له‌وێ گۆڕانکاری پاشکه‌وت نه‌کراو هه‌بوو، تکایه کرته‌بکه‌ لێره‌ بۆ گه‌ڕانه‌وه"
);
