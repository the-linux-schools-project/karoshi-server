<?php

//some strings that are used in /lib but wont be translatable unless they are in /core too
$l=OC_L10N::get('core');
$l->t("Personal");
$l->t("Users");
$l->t("Apps");
$l->t("Admin");
$l->t("Help");
