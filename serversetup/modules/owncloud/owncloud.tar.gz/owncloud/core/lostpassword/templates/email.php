<?php
echo str_replace('{link}', $_['link'], $l->t('Use the following link to reset your password: {link}'));
