<ul>
	<li class='update'>
		<?php p($l->t('This %s instance is currently in maintenance mode, which may take a while.', array($theme->getName()))) ?><br><br>
		<?php p($l->t('This page will refresh itself when the %s instance is available again.', array($theme->getName()))) ?><br><br>
		<?php p($l->t('Contact your system administrator if this message persists or appeared unexpectedly.')) ?><br><br>
		<?php p($l->t('Thank you for your patience.')); ?><br><br>
	</li>
</ul>
