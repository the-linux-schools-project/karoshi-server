<ul>
	<li class='update'>
		<?php p($l->t('This ownCloud instance is currently being updated, which may take a while.')) ?><br/><br/>
		<?php p($l->t('Please reload this page after a short time to continue using ownCloud.')) ?><br/><br/>
		<?php p($l->t('Contact your system administrator if this message persists or appeared unexpectedly.')) ?><br/><br/>
		<?php p($l->t('Thank you for your patience.')); ?><br/><br/>
	</li>
</ul>
