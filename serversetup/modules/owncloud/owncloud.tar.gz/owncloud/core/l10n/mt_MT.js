OC.L10N.register(
    "core",
    {
    "_{count} file conflict_::_{count} file conflicts_" : ["","","",""],
    "_download %n file_::_download %n files_" : ["","","",""],
    "_{count} search result in other places_::_{count} search results in other places_" : ["","","",""]
},
"nplurals=4; plural=(n==1 ? 0 : n==0 || ( n%100>1 && n%100<11) ? 1 : (n%100>10 && n%100<20 ) ? 2 : 3);");
