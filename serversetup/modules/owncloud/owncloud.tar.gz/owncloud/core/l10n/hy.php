<?php
$TRANSLATIONS = array(
"Sunday" => "Կիրակի",
"Monday" => "Երկուշաբթի",
"Tuesday" => "Երեքշաբթի",
"Wednesday" => "Չորեքշաբթի",
"Thursday" => "Հինգշաբթի",
"Friday" => "Ուրբաթ",
"Saturday" => "Շաբաթ",
"January" => "Հունվար",
"February" => "Փետրվար",
"March" => "Մարտ",
"April" => "Ապրիլ",
"May" => "Մայիս",
"June" => "Հունիս",
"July" => "Հուլիս",
"August" => "Օգոստոս",
"September" => "Սեպտեմբեր",
"October" => "Հոկտեմբեր",
"November" => "Նոյեմբեր",
"December" => "Դեկտեմբեր",
"_%n minute ago_::_%n minutes ago_" => array("",""),
"_%n hour ago_::_%n hours ago_" => array("",""),
"_%n day ago_::_%n days ago_" => array("",""),
"_%n month ago_::_%n months ago_" => array("",""),
"_{count} file conflict_::_{count} file conflicts_" => array("",""),
"Delete" => "Ջնջել"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
