<?php
$TRANSLATIONS = array(
"Settings" => "Настройки",
"_%n minute ago_::_%n minutes ago_" => array("","",""),
"_%n hour ago_::_%n hours ago_" => array("","",""),
"_%n day ago_::_%n days ago_" => array("","",""),
"_%n month ago_::_%n months ago_" => array("","",""),
"Yes" => "Да",
"No" => "Нет",
"_{count} file conflict_::_{count} file conflicts_" => array("","",""),
"Cancel" => "Отмена",
"Share" => "Сделать общим",
"Error" => "Ошибка",
"Password" => "Пароль",
"can edit" => "возможно редактирование",
"Warning" => "Предупреждение",
"Delete" => "Удалить",
"Username" => "Имя пользователя",
"Help" => "Помощь"
);
$PLURAL_FORMS = "nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);";
