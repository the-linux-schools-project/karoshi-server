<?php
$LOCALIZATIONS = array(
	'jsdate' => "d 'de' MM 'de' yy",
	'date' => '%e de %B de %Y',
	'datetime' => '%e de %B de %Y %H:%M',
	'time' => '%H:%M:%S',
	'firstday' => 1 );
