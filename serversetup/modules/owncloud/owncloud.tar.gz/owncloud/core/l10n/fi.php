<?php
$TRANSLATIONS = array(
"Settings" => "asetukset",
"Username" => "Käyttäjätunnus"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
