<?php $TRANSLATIONS = array(
"Settings" => "Ustawienia",
"Username" => "Nazwa użytkownika"
);
