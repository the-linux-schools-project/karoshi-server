<?php $TRANSLATIONS = array(
"seconds ago" => "წამის წინ",
"1 minute ago" => "1 წუთის წინ",
"1 hour ago" => "1 საათის წინ",
"today" => "დღეს",
"yesterday" => "გუშინ",
"Password" => "პაროლი",
"Personal" => "პერსონა",
"Users" => "მომხმარებლები",
"Admin" => "ადმინისტრატორი",
"Help" => "შველა"
);
