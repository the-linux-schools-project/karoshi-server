<?php $TRANSLATIONS = array(
"You are logged out." => "你已登出。"
);
