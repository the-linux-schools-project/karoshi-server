OC.L10N.register(
    "core",
    {
    "Password" : "Passcode"
},
"nplurals=2; plural=(n != 1);");
