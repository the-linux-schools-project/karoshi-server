<?php
$LOCALIZATIONS = array(
	'jsdate' => 'dd.mm.yy',
	'date' => '%d.%m.%Y',
	'datetime' => '%d.%m.%Y %H:%M:%S',
	'time' => '%H:%M:%S',
	'firstday' => 0 );
