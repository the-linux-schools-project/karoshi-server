<?php
$LOCALIZATIONS = array(
	'jsdate' => 'MM d, yy',
	'date' => '%B %e, %Y',
	'datetime' => '%B %e, %Y %H:%M',
	'time' => '%H:%M:%S',
	'firstday' => 0 );
