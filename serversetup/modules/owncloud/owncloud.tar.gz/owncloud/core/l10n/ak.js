OC.L10N.register(
    "core",
    {
    "_{count} file conflict_::_{count} file conflicts_" : ["",""],
    "_download %n file_::_download %n files_" : ["",""],
    "_{count} search result in other places_::_{count} search results in other places_" : ["",""]
},
"nplurals=2; plural=n > 1;");
