<?php $TRANSLATIONS = array(
"Advanced" => "Дасведчаны",
"Finish setup" => "Завяршыць ўстаноўку.",
"prev" => "Папярэдняя",
"next" => "Далей"
);
