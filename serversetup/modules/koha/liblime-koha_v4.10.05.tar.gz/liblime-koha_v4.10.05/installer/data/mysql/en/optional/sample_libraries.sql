-- INSERT INTO branchcategories ( `categorycode`,`categoryname`,`codedescription`) VALUES

INSERT INTO branches ( `branchcode`,`branchname`,`branchaddress1`) VALUES

('MPL','Midway','372 Forest Street'),
('SPL','Springfield','Highland Boulevard'),
('RPL','Riverside','Johnson Terrace'),
('CPL','Centerville','Jefferson Summit'),
('FPL','Fairview','Hickory Squere'),
('FFL','Fairfield','River Station'),
('IPT','Institut Protestant de Théologie',''),
('PVL','Pleasant Valley','Meadow Grove'),
('TPL','Troy','Valley Way'),
('FRL','Franklin','Smith Heights'),
('LPL','Liberty','East Hills'),
('UPL','Union','Chestnut Hollow')
;

-- INSERT INTO branchrelations ( `branchcode`,`categorycode`) VALUES
