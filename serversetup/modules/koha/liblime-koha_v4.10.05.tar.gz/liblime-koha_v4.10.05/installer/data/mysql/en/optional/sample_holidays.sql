INSERT INTO `repeatable_holidays` VALUES 
(2,'',0,NULL,NULL,'','Sundays'),
(3,'',NULL,1,1,'','New Year\'s Day'),
(4,'',NULL,25,12,'','Christmas');
