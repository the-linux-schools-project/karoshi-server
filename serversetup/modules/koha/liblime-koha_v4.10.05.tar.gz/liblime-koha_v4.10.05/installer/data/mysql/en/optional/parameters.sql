INSERT INTO `currency` (currency, rate, symbol) VALUES
('USD', 1.0, '$'),
('GBP', 1.9929, '£'),
('CAD', 1.02207, '$'),
('EUR', .874003, '€');

