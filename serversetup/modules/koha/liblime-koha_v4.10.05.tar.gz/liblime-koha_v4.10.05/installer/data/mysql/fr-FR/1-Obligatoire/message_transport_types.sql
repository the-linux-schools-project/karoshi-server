INSERT INTO message_transport_types
(message_transport_type)
values
('email'),
('sms'),
('feed');
