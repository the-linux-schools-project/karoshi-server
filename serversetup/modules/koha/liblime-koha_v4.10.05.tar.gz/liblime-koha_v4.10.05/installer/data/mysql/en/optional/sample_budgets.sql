INSERT INTO `aqbudget` VALUES

('CHILD','2008-01-01','2008-12-31','5000.00',1,''),
('GEN','2008-01-01','2008-12-31','20000.00',2,''),
('REF','2008-01-01','2008-12-31','5000.00',3,'');

INSERT INTO `aqbookfund` VALUES

('CHILD','Children\'s Materials',NULL,''),
('GEN','General Stacks',NULL,''),
('REF','Reference Materials',NULL,'');
