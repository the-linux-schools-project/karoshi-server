INSERT INTO message_transport_types
(message_transport_type)
values
('email'),
('print'),
('print_billing'),
('sms');
