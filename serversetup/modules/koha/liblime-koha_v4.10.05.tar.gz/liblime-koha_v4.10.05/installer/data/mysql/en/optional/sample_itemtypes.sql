INSERT INTO `itemtypes` VALUES ('BK', 'Books',5,0,0,'bridge/book.gif','');
INSERT INTO `itemtypes` VALUES ('MX', 'Mixed Materials',5,0,0,'bridge/kit.gif','');
INSERT INTO `itemtypes` VALUES ('CF', 'Computer Files',5,0,0,'bridge/computer_file.gif','');
INSERT INTO `itemtypes` VALUES ('MP', 'Maps',5,0,0,'bridge/map.gif','');
INSERT INTO `itemtypes` VALUES ('VM', 'Visual Materials',5,0,1,'bridge/dvd.gif','');
INSERT INTO `itemtypes` VALUES ('MU', 'Music',5,0,0,'bridge/sound.gif','');
INSERT INTO `itemtypes` VALUES ('CR', 'Continuing Resources',5,0,0,'bridge/periodical.gif','');
INSERT INTO `itemtypes` VALUES ('REF', 'Reference',0,0,1,'','');
