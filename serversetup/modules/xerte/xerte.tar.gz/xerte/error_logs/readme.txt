Text file to ensure this folder is created on the server.

Error logs will be stored in this folder.