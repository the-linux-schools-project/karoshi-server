Timed Text Transcript Files can be created using the Transcripttool.air application

To install the application you must first install Adobe AIR (https://get.adobe.com/air/)
