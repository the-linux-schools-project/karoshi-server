Text file to ensure this folder is created on the server.

Imported files will be worked on in this folder (if you choose to use this folder).