<?php
$debug = false;
session_name('SMBWebClientID');
session_start();
require_once("config/config.php");
if( isset($_POST['txtUname']) && isset($_POST['txtPwd']) )
{
    //LDAP stuff here.
    $username = trim($_POST['txtUname']);
    $password = trim($_POST['txtPwd']);
    $ds = ldap_connect(_LDAPSERVER);

	//Set correct protocol
	ldap_set_option($ds,LDAP_OPT_PROTOCOL_VERSION,3);

    //Connection made -- bind anonymously and get dn for username.
    $bind = @ldap_bind($ds);

    //Check to make sure we're bound.
	if(!$debug)
	{
    	if( !$bind )
    	{
        	echo "Error in contacting the LDAP server:  "._LDAPSERVER."<br>";
        	echo "Error Message: Anon Bind Fail<br>Contact technical services on Ext. "._TSCONTACTNUM;
        	exit;
    	}
		else
		{
    		$search = ldap_search($ds, _SEARCH_OU_1, "cn=$username");
    		//Make sure only ONE result was returned -- if not, they might've thrown a * into the username.  Bad user!
    		if( ldap_count_entries($ds,$search) != 1 )
    		{
    			ldap_close($ds);	
				$goto = "Location: logon.php";
				header("$goto");
        		exit;
    		}		
			
    		$info = ldap_get_entries($ds, $search);
    		//Now, try to rebind with their full dn and password.
   			$bind = @ldap_bind($ds, $info[0]["dn"], $password);			
    		if( !$bind || !isset($bind))
    		{
    			ldap_close($ds);	
				$goto = "Location: logon.php";
				header("$goto");
				exit;
    		}
			
    		//Now verify the previous search using their credentials.
    		$search = ldap_search($ds, _SEARCH_OU_1, "cn=$username");
        
    		$info = ldap_get_entries($ds, $search);
			
			$groupid = $info[0][gidnumber][0];
			
    		//Now get group name.
    		$search = ldap_search($ds, _SEARCH_OU_2, "gidNumber=$groupid");
        
    		$info2 = ldap_get_entries($ds, $search);	
			
			$groupname = $info2[0][cn][0];
					

    		if( $username == $info[0][cn][0] )
    		{
        		//echo "Authenticated.";
				$_SESSION['login'] = "yes";
    			$_SESSION['username'] = $username;
				$_SESSION['swcUser'] = $username;
    			$_SESSION['swcPw'] = $password;	
        		$_SESSION['groupid'] = $info2[0][cn][0];	
        					
				//Select server depending on group
		$storagearea = `sed -n 1,1p /opt/karoshi/server_network/group_information/$groupname | cut -d= -f2`;
		$storagearea = trim ("CHANGETHISDOMAIN/".$storagearea);
		$_SESSION['server'] = $storagearea;	

				ldap_close($ds);
				
				$goto = "Location: smbwc.php";
				

				header("$goto");
    		}
   			 else
			 {
    			ldap_close($ds);
						
				$goto = "Location: logon.php";
				header("$goto");
			 }
    		 ldap_close($ds);						
		}
	}
	else
	{
	$goto = "Location: ".$_SESSION['url'];
	$_SESSION['login'] = "yes";
    $_SESSION['username'] = $username;	
	header("$goto");
	}
}
?>
