<?php
// System constants
define("_SITENAME",	"Karoshi");

//LDAP Server details
define("_LDAPSERVER",	"XEN");
define("_SEARCH_OU_1",		"ou=People,dc=karoshi,dc=local");
define("_SEARCH_OU_2",		"ou=Group,dc=karoshi,dc=local");

//Tech services info
define("_TSCONTACTNUM",	"252");


?>
