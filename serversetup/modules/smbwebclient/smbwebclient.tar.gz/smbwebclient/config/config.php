<?php
// System constants
define("_SITENAME",	"bedrock.com");

//LDAP Server details
define("_LDAPSERVER",	"betty.bedrock.com");
define("_SEARCH_OU_1",		"OU=People,DC=bedrock,DC=com");
define("_SEARCH_OU_2",		"OU=Groups,OU=People,DC=bedrock,DC=com");

//Tech services info
define("_TSCONTACTNUM",	"252");

//Share Access Permissions

$itadmingroup = array("itadmin","netlogon", "sysvol", "officeshare", "staffshare", "subjects");
$officestaffgroup = array("officeshare", "staffshare");
$staffgroup = array("staffshare", "subjects");
$studentsgroup = array("students", "subjects");


?>
