<?php
session_name('SMBWebClientID');
session_start();
session_destroy();
header("Location: logon.php");
?>
