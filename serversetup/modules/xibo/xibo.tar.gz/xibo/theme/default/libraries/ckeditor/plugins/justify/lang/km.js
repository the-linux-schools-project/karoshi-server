﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'km', {
	block: 'តំរឹមសងខាង',
	center: 'តំរឹមកណ្តាល',
	left: 'តំរឹមឆ្វេង',
	right: 'តំរឹមស្តាំ'
});
