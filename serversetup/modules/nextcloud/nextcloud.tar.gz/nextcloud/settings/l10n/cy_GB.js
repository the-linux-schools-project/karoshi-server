OC.L10N.register(
    "settings",
    {
    "Authentication error" : "Gwall dilysu",
    "Email sent" : "Anfonwyd yr e-bost",
    "Delete" : "Dileu",
    "Groups" : "Grwpiau",
    "undo" : "dadwneud",
    "never" : "byth",
    "None" : "Dim",
    "Login" : "Mewngofnodi",
    "Encryption" : "Amgryptiad",
    "Cancel" : "Diddymu",
    "Email" : "E-bost",
    "Password" : "Cyfrinair",
    "New password" : "Cyfrinair newydd",
    "Username" : "Enw defnyddiwr",
    "Other" : "Arall"
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");
