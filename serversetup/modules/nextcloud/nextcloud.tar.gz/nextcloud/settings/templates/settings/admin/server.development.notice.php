<div class="section">
	<p><?php include(__DIR__ . '/../../settings.development.notice.php'); ?></p>
</div>
