<?php

namespace OpenCloud\Common\Exceptions;

class InstanceUpdateError extends \Exception {}
