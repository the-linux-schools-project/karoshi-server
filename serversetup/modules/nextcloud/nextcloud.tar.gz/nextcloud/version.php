<?php 
$OC_Version = array(13,0,2,1);
$OC_VersionString = '13.0.2';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  'nextcloud' => 
  array (
    '12.0' => true,
    '13.0' => true,
  ),
  'owncloud' => 
  array (
  ),
);
$OC_Build = '2018-04-26T07:24:07+00:00 2495577a3be388d39b2850a70cd039866c9b09b4';
$vendor = 'nextcloud';
