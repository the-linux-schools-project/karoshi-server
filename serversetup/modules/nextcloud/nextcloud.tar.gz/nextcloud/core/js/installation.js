
$(document).ready(function() {
	$('#adminpass').showPassword().keyup();
	$('#dbpass').showPassword().keyup();
});
