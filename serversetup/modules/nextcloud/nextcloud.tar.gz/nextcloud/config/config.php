<?php
$CONFIG = array (
  'instanceid' => 'CHANGETHISID',
  'passwordsalt' => 'CHANGETHISCLOUDSALT',
  'secret' => 'CHANGETHISCLOUDSECRET',
  'trusted_domains' => 
  array (
    0 => 'CHANGETHISREALM',
  ),
  'datadirectory' => '/home/nextcloud/data',
  'overwrite.cli.url' => 'https://CHANGETHISREALM/nextcloud',
  'dbtype' => 'mysql',
  'version' => '12.0.0.29',
  'dbname' => 'nextcloud',
  'dbhost' => '127.0.0.1',
  'dbport' => '',
  'dbtableprefix' => 'oc_',
  'mysql.utf8mb4' => true,
  'dbuser' => 'nextcloud_user',
  'dbpassword' => 'CHANGETHISPASS',
  'installed' => true,
  'memcache.local' => '\\OC\\Memcache\\APCu',
  'ldapIgnoreNamingRules' => false,
  'ldapProviderFactory' => '\\OCA\\User_LDAP\\LDAPProviderFactory',
);
