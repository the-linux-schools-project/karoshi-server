<?php
$CONFIG = array (
  'instanceid' => 'CHANGETHISID',
  'passwordsalt' => 'CHANGETHISCLOUDSALT',
  'secret' => 'CHANGETHISCLOUDSECRET',
  'trusted_domains' => 
  array (
    0 => 'CHANGETHISREALM',
  ),
  'datadirectory' => '/home/nextcloud/data',
  'overwrite.cli.url' => 'https://CHANGETHISREALM/nextcloud',
  'dbtype' => 'mysql',
  'version' => '13.0.2.1',
  'dbname' => 'nextcloud',
  'dbhost' => '127.0.0.1',
  'dbport' => '',
  'dbtableprefix' => 'oc_',
  'mysql.utf8mb4' => true,
  'dbuser' => 'nextcloud_user',
  'dbpassword' => 'CHANGETHISPASS',
  'installed' => true,
  'memcache.local' => '\\OC\\Memcache\\APCu',
  'memcache.locking' => '\\OC\\Memcache\\Redis',
  'redis' => 
  array (
    'host' => 'localhost',
    'port' => 6379,
  ),
  'ldapIgnoreNamingRules' => false,
  'ldapProviderFactory' => '\\OCA\\User_LDAP\\LDAPProviderFactory',
  'updater.secret' => '$2y$10$0mxWQPmYyHOsQ1t7XDnkle0UHHAJ6xB8IwC3jpKLQSfcN7dMRCU3y',
  'maintenance' => false,
  'theme' => '',
  'loglevel' => 2,
);
