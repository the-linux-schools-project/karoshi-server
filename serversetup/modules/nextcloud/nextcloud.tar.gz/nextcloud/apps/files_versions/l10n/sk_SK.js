OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Nemožno obnoviť: %s",
    "Versions" : "Verzie",
    "Failed to revert {file} to revision {timestamp}." : "Zlyhalo obnovenie súboru {file} na verziu {timestamp}.",
    "_%n byte_::_%n bytes_" : ["%n bajt","%n bajtov","%n bajtov"],
    "Restore" : "Obnoviť",
    "No versions available" : "Žiadne verzie nie sú dostupné",
    "More versions..." : "Viac verzií...",
    "No other versions available" : "Žiadne ďalšie verzie nie sú dostupné"
},
"nplurals=3; plural=(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2;");
