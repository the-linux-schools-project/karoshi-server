OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Tidak dapat mengembalikan: %s",
    "Versions" : "Versi",
    "Failed to revert {file} to revision {timestamp}." : "Gagal mengembalikan {file} ke revisi {timestamp}.",
    "Restore" : "Pulihkan",
    "More versions..." : "Versi lainnya...",
    "No other versions available" : "Tidak ada versi lain yang tersedia"
},
"nplurals=1; plural=0;");
