OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Ei suuda taastada faili: %s",
    "Versions" : "Versioonid",
    "Failed to revert {file} to revision {timestamp}." : "Ebaõnnestus faili {file} taastamine revisjonile {timestamp}",
    "Restore" : "Taasta",
    "More versions..." : "Rohkem versioone...",
    "No other versions available" : "Muid versioone pole saadaval"
},
"nplurals=2; plural=(n != 1);");
