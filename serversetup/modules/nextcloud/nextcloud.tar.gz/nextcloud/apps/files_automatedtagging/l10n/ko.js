OC.L10N.register(
    "files_automatedtagging",
    {
    "Tags to assign…" : "태그 할당...",
    "No tags given" : "지정된 태그 없음",
    "Tag(s) could not be found: %s" : "태그를 찾을 수 없음: %s",
    "At least one of the given tags is invalid" : "지정된 태그 중 적어도 하나가 잘못되었습니다",
    "Files automated tagging" : "파일 자동 태그"
},
"nplurals=1; plural=0;");
