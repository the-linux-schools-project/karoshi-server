OC.L10N.register(
    "files",
    {
    "Storage not available" : "ບໍ່ມີພື້ນທີ່ເກັບຂໍ້ມູນ",
    "Storage invalid" : "ພື້ນທີ່ເກັບຂໍ້ມູນບໍ່ຖືກຕ້ອງ",
    "Unknown error" : "ຂໍ້ຜິດພາດທີ່ບໍ່ຮູ້ສາເຫດ",
    "The target folder has been moved or deleted." : "ໂຟນເດີທີ່ທ່ານເລືອກໄດ້ຖືກຍ້າຍ ຫຼື ລຶບອອກແລ້ວ"
},
"nplurals=1; plural=0;");
