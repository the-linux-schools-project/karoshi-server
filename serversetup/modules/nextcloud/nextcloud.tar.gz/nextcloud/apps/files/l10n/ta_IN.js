OC.L10N.register(
    "files",
    {
    "Files" : "கோப்புகள்",
    "Details" : "விவரங்கள்",
    "New folder" : "புதிய கோப்புறை",
    "Upload" : "பதிவேற்று",
    "A new file or folder has been <strong>created</strong>" : "ஒரு புதிய கோப்புறை அல்லது ஆவணம் <strong> உருவாக்கப்பட்டுள்ளது.</strong>",
    "A file or folder has been <strong>changed</strong>" : "ஒரு கோப்புறை அல்லது ஆவணம் <strong>மாற்றம் செய்யப்பட்டுள்ளது.</strong>",
    "A file or folder has been <strong>deleted</strong>" : "ஒரு கோப்புறை அல்லது ஆவணம்  <strong> நீக்கப்பட்டுள்ளது. </strong>",
    "You created %1$s" : "நீங்கள் %1$s 'ஐ உருவாக்கி உள்ளீர்கள். ",
    "%2$s created %1$s" : "%2$s , %1$s 'ஐ  உருவாக்கினார்.",
    "You changed %1$s" : "நீங்கள் %1$s 'ல் மாற்றம் செய்து உள்ளீர்கள். ",
    "%2$s changed %1$s" : "%2$s  %1$s 'ல் மாற்றம் செய்துள்ளார். ",
    "You deleted %1$s" : "நீங்கள் %1$s 'ஐ நீக்கி உள்ளீர்கள்.",
    "%2$s deleted %1$s" : "%2$s , %1$s 'ஐ நீக்கியுள்ளார்.",
    "Settings" : "அமைப்புகள்"
},
"nplurals=2; plural=(n != 1);");
