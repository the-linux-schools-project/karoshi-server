OC.L10N.register(
    "files",
    {
    "Files" : "ဖိုင်များ",
    "Download" : "ဒေါင်းလုတ်"
},
"nplurals=1; plural=0;");
