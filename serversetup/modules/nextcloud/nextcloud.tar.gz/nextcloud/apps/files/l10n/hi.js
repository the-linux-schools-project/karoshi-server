OC.L10N.register(
    "files",
    {
    "Files" : "फाइलें ",
    "Close" : "बंद करें ",
    "Details" : "विवरण ",
    "New folder" : "नया फ़ोल्डर",
    "Upload" : "अपलोड ",
    "Save" : "सहेजें",
    "Settings" : "सेटिंग्स"
},
"nplurals=2; plural=(n != 1);");
