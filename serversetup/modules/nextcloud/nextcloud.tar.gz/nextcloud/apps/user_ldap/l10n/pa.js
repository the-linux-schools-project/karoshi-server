OC.L10N.register(
    "user_ldap",
    {
    "Groups" : "ਗਰੁੱਪ",
    "Password" : "ਪਾਸਵਰ"
},
"nplurals=2; plural=(n != 1);");
