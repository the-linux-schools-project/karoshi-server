OC.L10N.register(
    "federatedfilesharing",
    {
    "Invalid Federated Cloud ID" : "Inválidu ID de Ñube Federada",
    "Sharing %s failed, because this item is already shared with %s" : "Compartir %s falló, porque esti elementu yá ta compartiéndose con %s",
    "Not allowed to create a federated share with the same user" : "Nun s'almite crear un recursu compartíu federáu col mesmu usuariu",
    "Sharing %s failed, could not find %s, maybe the server is currently unreachable." : "Compartir %s falló, nun pudo atopase %s, pue qu'el servidor nun seya anguaño algamable."
},
"nplurals=2; plural=(n != 1);");
