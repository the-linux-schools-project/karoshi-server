OC.L10N.register(
    "federatedfilesharing",
    {
    "Sharing %s failed, because this item is already shared with %s" : "%s elkarbanatzeak huts egin du, dagoeneko %s erabiltzailearekin elkarbanatuta dagoelako",
    "Sharing %s failed, could not find %s, maybe the server is currently unreachable." : "%s partekatzeak huts egin du, ezin da %s aurkitu, agian zerbitzaria orain ez dago eskuragarri.",
    "Federated Cloud Sharing" : "Federatutako Hodei Partekatzea",
    "Allow users on this server to send shares to other servers" : "Baimendu zerbitzari honetako erabiltzaileak beste zerbitzariekin partekatzera",
    "Allow users on this server to receive shares from other servers" : "Baimendu zerbitzari honetako erabiltzaileak beste zerbitzarietatik partekatutakoak jasotzen"
},
"nplurals=2; plural=(n != 1);");
