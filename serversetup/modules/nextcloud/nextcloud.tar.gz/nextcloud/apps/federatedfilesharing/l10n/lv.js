OC.L10N.register(
    "federatedfilesharing",
    {
    "Federated Cloud Sharing" : "Federatīva mākoņkoplietošana",
    "Open documentation" : "Atvērt dokumentāciju",
    "Allow users on this server to send shares to other servers" : "Atļaut šī servera lietotājiem sūtīt koplietotnes uz citiem serveriem",
    "Allow users on this server to receive shares from other servers" : "Atļaut šī servera lietotājiem saņem koplietotnes no citiem serveriem"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
