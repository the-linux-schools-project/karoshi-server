OC.L10N.register(
    "federatedfilesharing",
    {
    "Accept" : "قبول",
    "Open documentation" : "بازکردن مستند",
    "HTML Code:" : "کد HTML :"
},
"nplurals=1; plural=0;");
