OC.L10N.register(
    "federatedfilesharing",
    {
    "Sharing %s failed, because this item is already shared with %s" : "%s jagamine ebaõnnestus, kuna see üksus on juba jagatud %s",
    "Accept" : "Nõustu",
    "Decline" : "Lükka tagasi",
    "Open documentation" : "Ava dokumentatsioon",
    "Allow users on this server to send shares to other servers" : "Luba selle serveri kasutajatel saata faile teistesse serveritesse",
    "Allow users on this server to receive shares from other servers" : "Luba selle serveri kasutajatel võtta vastu jagamisi teistest serveritest",
    "Share it:" : "Jaga seda:",
    "Add to your website" : "Lisa oma veebisaidile",
    "Share with me via Nextcloud" : "Jaga minuga läbi Nextclouddiga",
    "HTML Code:" : "HTML kood:"
},
"nplurals=2; plural=(n != 1);");
