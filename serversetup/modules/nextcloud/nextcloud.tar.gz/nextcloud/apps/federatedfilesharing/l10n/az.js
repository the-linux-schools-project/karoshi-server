OC.L10N.register(
    "federatedfilesharing",
    {
    "Federated Cloud Sharing" : "Federal Cloud Paylaşım",
    "Open documentation" : "Sənədləri aç",
    "Allow users on this server to send shares to other servers" : "Bu serverdən digər serverlərə istifadəçilər tərəfindən paylaşımın göndərilməsinə izin vermək",
    "Allow users on this server to receive shares from other servers" : "Digər serverlərdən bu serverə istifadəçilər tərəfindən paylaşımın ötürülməsinə izin vermək"
},
"nplurals=2; plural=(n != 1);");
