OC.L10N.register(
    "federatedfilesharing",
    {
    "Open documentation" : "Dokumentatioun opmaachen"
},
"nplurals=2; plural=(n != 1);");
