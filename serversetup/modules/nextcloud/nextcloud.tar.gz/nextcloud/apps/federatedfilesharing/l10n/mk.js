OC.L10N.register(
    "federatedfilesharing",
    {
    "Accept" : "Прифати",
    "Decline" : "Одбиј",
    "Federated Cloud Sharing" : "Федерирано клауд споделување",
    "Open documentation" : "Отвори ја документацијата",
    "Federated Cloud" : "Федериран клауд",
    "Your Federated Cloud ID:" : "Вашиот федериран Cloud ID:",
    "Share it:" : "Сподели го:",
    "Add to your website" : "Додади на твојот веб сајт",
    "Share with me via Nextcloud" : "Сподели со мене преку Nextcloud",
    "HTML Code:" : "HTML код:"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
