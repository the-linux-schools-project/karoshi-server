OC.L10N.register(
    "federatedfilesharing",
    {
    "Federated sharing" : "Federa kunhavado",
    "Sharing %s failed, because this item is already shared with %s" : "Kunhavigo de %s malsukcesis, ĉar la ero jam kunhavatas kun %s",
    "Not allowed to create a federated share with the same user" : "Vi ne permesas krei federan kunhavon kun la sama uzanto",
    "Accept" : "Akcepti",
    "Decline" : "Malakcepti",
    "Share with me through my #Nextcloud Federated Cloud ID, see %s" : "Kunhavigi kun mi per mia identigilo de #Nextcloud-federnuba identigilo; vidu %s",
    "Share with me through my #Nextcloud Federated Cloud ID" : "Kunhavigi kun mi per mia #Nextcloud-federnuba identigilo",
    "Federated Cloud Sharing" : "Federnuba kunhavado",
    "Open documentation" : "Malfermi la dokumentaron",
    "Federated Cloud" : "Federa nubo",
    "Your Federated Cloud ID:" : "Via federnuba identigilo:",
    "Share it:" : "Kunhavigi ĝin:",
    "Add to your website" : "Aldoni al via TTT-ejo",
    "Share with me via Nextcloud" : "Kunhavigi kun mi per Nextcloud",
    "HTML Code:" : "HTML-kodo:"
},
"nplurals=2; plural=(n != 1);");
