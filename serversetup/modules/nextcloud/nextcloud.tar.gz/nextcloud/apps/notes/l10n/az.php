<?php
$TRANSLATIONS = array(
"Notes" => "Qeydlər",
"New note" => "Yeni qeyd",
"Note is currently saving. Leaving " => "Qeyd hal-hazırda saxlanılır. Tərk olunur",
"Delete note" => "Qeydi sil"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
