OC.L10N.register(
    "notes",
    {
    "Notes" : "Бележки",
    "New note" : "Нова бележка",
    "Note is currently saving. Leaving the page will delete all changes!" : "В момента промените се записват. Ако излезете от страницата направените промени ще бъдат загубени.",
    "_%n word_::_%n words_" : ["%n дума","%n думи"],
    "Delete note" : "Изтрий бележка",
    "Favorite" : "Любими"
},
"nplurals=2; plural=(n != 1);");
