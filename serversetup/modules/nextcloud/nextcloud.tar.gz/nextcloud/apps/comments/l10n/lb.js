OC.L10N.register(
    "comments",
    {
    "Cancel" : "Ofbriechen",
    "Save" : "Späicheren",
    "Comment" : "Kommentar"
},
"nplurals=2; plural=(n != 1);");
