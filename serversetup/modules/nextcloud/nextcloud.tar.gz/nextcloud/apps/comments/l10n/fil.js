OC.L10N.register(
    "comments",
    {
    "Cancel" : "I-cancel"
},
"nplurals=2; plural=(n > 1);");
