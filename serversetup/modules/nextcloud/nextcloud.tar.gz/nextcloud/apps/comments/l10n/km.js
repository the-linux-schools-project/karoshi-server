OC.L10N.register(
    "comments",
    {
    "Cancel" : "បោះបង់",
    "Save" : "រក្សាទុក"
},
"nplurals=1; plural=0;");
