OC.L10N.register(
    "comments",
    {
    "Cancel" : "Abbrechen"
},
"nplurals=2; plural=(n != 1);");
