OC.L10N.register(
    "comments",
    {
    "Cancel" : "இரத்து செய்க",
    "Save" : "சேமிக்க "
},
"nplurals=2; plural=(n != 1);");
