OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Notifikation",
    "No notifications" : "Inga notifikationer",
    "Dismiss" : "Avfärda"
},
"nplurals=2; plural=(n != 1);");
