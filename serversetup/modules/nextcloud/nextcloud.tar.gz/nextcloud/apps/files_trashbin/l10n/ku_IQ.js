OC.L10N.register(
    "files_trashbin",
    {
    "Error" : "هه‌ڵه",
    "Name" : "ناو"
},
"nplurals=2; plural=(n != 1);");
