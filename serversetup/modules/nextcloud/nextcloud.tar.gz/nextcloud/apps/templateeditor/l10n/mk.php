<?php
$TRANSLATIONS = array(
"Could not load template" => "Не можам да го вчитам шаблонот",
"Saved" => "Снимено",
"Reset" => "Поништи",
"Mail templates" => "Шаблони за електронска пошта",
"Theme" => "Теми",
"Template" => "Шаблон",
"Save" => "Сними"
);
$PLURAL_FORMS = "nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;";
