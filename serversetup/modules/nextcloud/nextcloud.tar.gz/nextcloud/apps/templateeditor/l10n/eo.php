<?php
$TRANSLATIONS = array(
"Saved" => "Konservita",
"Save" => "Konservi"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
