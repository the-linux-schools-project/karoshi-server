<?php
$TRANSLATIONS = array(
"Save" => "ساقلا"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
