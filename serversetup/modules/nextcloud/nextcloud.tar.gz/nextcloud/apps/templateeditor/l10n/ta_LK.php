<?php
$TRANSLATIONS = array(
"Save" => "சேமிக்க "
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
