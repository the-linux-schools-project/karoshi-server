OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "უარყოფა",
    "Shared by" : "აზიარებს",
    "Sharing" : "გაზიარება",
    "Password" : "პაროლი",
    "Name" : "სახელი",
    "Download" : "ჩამოტვირთვა"
},
"nplurals=1; plural=0;");
