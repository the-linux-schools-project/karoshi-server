<?php
$TRANSLATIONS = array(
"Pictures" => "Fotoen",
"Error loading slideshow template" => "Feeler beim Luede vun der Virlag fir d'Diashow",
"Share" => "Deelen"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
