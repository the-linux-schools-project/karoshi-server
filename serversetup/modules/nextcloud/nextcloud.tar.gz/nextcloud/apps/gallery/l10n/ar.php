<?php
$TRANSLATIONS = array(
"Pictures" => "الصور",
"Picture view" => "عرض الصورة",
"Error loading slideshow template" => "خطأ في تحميل قالب عرض الشرائح.",
"Share" => "شارك",
"No pictures found! If you upload pictures in the files app, they will be displayed here." => "لم يتم العثور على أية صور! سيتم عرض جميع الصور المضافة في هذا البرنامج هنا.",
"shared by %s" => "مشاركة من قبل %s",
"File list" => "قائمة الملفات"
);
$PLURAL_FORMS = "nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;";
