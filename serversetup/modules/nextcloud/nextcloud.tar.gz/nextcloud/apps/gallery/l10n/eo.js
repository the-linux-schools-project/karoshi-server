OC.L10N.register(
    "gallery",
    {
    "Pictures" : "Bildoj",
    "Picture view" : "Bilda vido",
    "Error loading slideshow template" : "Eraris ŝargo de ŝablono pri lumbilda prezento",
    "Share" : "Kunhavigi",
    "No pictures found! If you upload pictures in the files app, they will be displayed here." : "Neniu bildo troviĝis! Se vi alŝutos bildojn en la aplikaĵo Dosieroj, ili montriĝos ĉi tie.",
    "shared by %s" : "kunhavigita de %s",
    "File list" : "Listo de dosieroj"
},
"nplurals=2; plural=(n != 1);");
