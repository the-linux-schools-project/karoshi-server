<?php
$TRANSLATIONS = array(
"Pictures" => "ছবি",
"Picture view" => "ছবির ভিউ",
"Error loading slideshow template" => "স্লাইডশো টেমপ্লেট লোড করতে ত্রুটি ",
"Share" => "শেয়ার",
"No pictures found! If you upload pictures in the files app, they will be displayed here." => "কোন ছবি পাওয়া যায় নি!আপনি ফাইল অ্যাপসে ছবি আপলোড করলে, তাদের এখানে প্রদর্শিত করা হবে।",
"shared by %s" => "%s দ্বারা শেয়ার",
"File list" => "ফাইল লিস্ট"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
