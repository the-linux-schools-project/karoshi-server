OC.L10N.register(
    "gallery",
    {
    "Pictures" : "Зображення",
    "Picture view" : "Перегляд Зображення",
    "Error loading slideshow template" : "Помилка завантаження шаблона слайд-шоу",
    "Share" : "Поділитися",
    "No pictures found! If you upload pictures in the files app, they will be displayed here." : "Зображення не знайдено! Якщо ви завантажуєте зображення в додатку файли, вони будуть відображатися тут.",
    "shared by %s" : "поділяють %s",
    "File list" : "Список файлів"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
