<?php
$TRANSLATIONS = array(
"Share" => "Freigeben"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
