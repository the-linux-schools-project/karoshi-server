<?php
$TRANSLATIONS = array(
"Pictures" => "तस्वीरें",
"Picture view" => "तस्वीर देखें",
"Error loading slideshow template" => "स्लाइड शो टेम्पलेट लोड करने में त्रुटि है",
"Share" => "साझा करें",
"File list" => "फाइल सूची"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
