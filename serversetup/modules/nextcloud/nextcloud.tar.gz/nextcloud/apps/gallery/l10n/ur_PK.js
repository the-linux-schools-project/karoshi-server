OC.L10N.register(
    "gallery",
    {
    "Pictures" : "تصاویر",
    "Picture view" : "منظر تصویر",
    "Error loading slideshow template" : "سلائیڈ شو ٹمپلیٹ لوڈ ہونے میں خرابی",
    "Share" : "تقسیم",
    "shared by %s" : "%s سے اشتراک شدہ",
    "File list" : "فہرست فائل"
},
"nplurals=2; plural=(n != 1);");
