OC.L10N.register(
    "gallery",
    {
    "Pictures" : "Slike",
    "Picture view" : "Prikaz slika",
    "Error loading slideshow template" : "Pogrešan unos predloška za dijaprojekciju",
    "Share" : "Zajednički resurs (za raspodjelu)",
    "No pictures found! If you upload pictures in the files app, they will be displayed here." : "Nikakve slike nisu nađene! Ako slike učitate u aplikaciju \"Datoteke\", one će biti prikazane ovdje.",
    "shared by %s" : "Podijeljeno od strane %s",
    "File list" : "Popis datoteka"
},
"nplurals=3; plural=n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2;");
