<?php
$TRANSLATIONS = array(
"Pictures" => "تصاویر",
"Picture view" => "نمایش تصویر",
"Error loading slideshow template" => "خطا در بارگذاری قالب نمایش به صورت اسلاید",
"Share" => "اشتراک‌گذاری",
"No pictures found! If you upload pictures in the files app, they will be displayed here." => "تصویری یافت نشد ! تصاویر در اینجا به نمایش در خواهند آمد در صورتی که شما آن ها را در اپ files آپلود کنید .",
"shared by %s" => "به اشتراک گذاشته شده توسط %s",
"File list" => "لیست فایل ها"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
