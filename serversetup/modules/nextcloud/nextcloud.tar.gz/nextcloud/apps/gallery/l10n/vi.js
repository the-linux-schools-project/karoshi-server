OC.L10N.register(
    "gallery",
    {
    "Pictures" : "Hình ảnh",
    "Picture view" : "Xem h",
    "Error loading slideshow template" : "Lỗi khi tải mẫu Slidesh",
    "Share" : "Chia sẻ",
    "shared by %s" : " Được chia sẻ bởi %s",
    "File list" : "Danh sách tập t"
},
"nplurals=1; plural=0;");
