<?php
$TRANSLATIONS = array(
"Pictures" => "رەسىملەر",
"Share" => "ھەمبەھىر"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
