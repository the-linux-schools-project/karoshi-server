<?php
$TRANSLATIONS = array(
"Pictures" => "Bilder",
"Error loading slideshow template" => "Fehler beim Laden der Slideshow-Vorlage",
"Share" => "Teilen"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
