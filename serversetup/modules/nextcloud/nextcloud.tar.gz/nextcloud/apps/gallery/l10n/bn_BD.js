OC.L10N.register(
    "gallery",
    {
    "Pictures" : "চিত্রসমূহ",
    "Picture view" : "চিত্র দর্শন",
    "Error loading slideshow template" : "স্লাইডশো টেমপ্লেট লোড করতে সমস্যা হচ্ছে",
    "Share" : "ভাগাভাগি কর",
    "No pictures found! If you upload pictures in the files app, they will be displayed here." : "কোন চিত্র পাওয়া গেলনা! ফাইল অ্যাপে চিত্র আপলোড করলে তা এখানে প্রদর্শিত হবে।",
    "shared by %s" : "%s দ্বারা ভাগাভাগিকৃত",
    "File list" : "ফাইল তালিকা"
},
"nplurals=2; plural=(n != 1);");
