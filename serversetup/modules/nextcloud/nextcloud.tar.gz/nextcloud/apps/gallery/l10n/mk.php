<?php
$TRANSLATIONS = array(
"Pictures" => "Слики",
"Error loading slideshow template" => "Грешка при вчитувањето на шаблонот за прикажување на слајдови",
"Share" => "Сподели"
);
$PLURAL_FORMS = "nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;";
