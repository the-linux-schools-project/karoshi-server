<?php
$TRANSLATIONS = array(
"Pictures" => "Gambar",
"Error loading slideshow template" => "Ralat memuatkan templat persembahan slaid",
"Share" => "Kongsi"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
