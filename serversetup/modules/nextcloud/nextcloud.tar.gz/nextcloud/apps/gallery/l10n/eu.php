<?php
$TRANSLATIONS = array(
"Pictures" => "Argazkiak",
"Picture view" => "Irudi bistaratzea",
"Error loading slideshow template" => "Errorea aurkezpen txantiloia kargatzean",
"Share" => "Elkarbanatu",
"No pictures found! If you upload pictures in the files app, they will be displayed here." => "Ez da argazkirik aurkitu! Argazkiak fitxategi aplikazioan igoz gero, hemen argertuko dira.",
"shared by %s" => "%sk partekatuta",
"File list" => "Fitxategi zerrenda"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
