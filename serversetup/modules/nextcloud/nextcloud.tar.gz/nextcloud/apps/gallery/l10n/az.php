<?php
$TRANSLATIONS = array(
"Pictures" => "Şəkillər",
"Picture view" => "Şəkilə baxış",
"Error loading slideshow template" => "Slideshow şablonun yüklənməsində səhv baş verdi",
"Share" => "Yayımla",
"No pictures found! If you upload pictures in the files app, they will be displayed here." => "Şəkil tapılmadı! Əgər siz şəkillərinizi fayllar proqramına əlavə etmisinizsə, onlar burda göstəriləcək.",
"shared by %s" => "%s tərəfindən yayımlanıb",
"File list" => "Fayl siyahısı"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
