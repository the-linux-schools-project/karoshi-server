<?php
$TRANSLATIONS = array(
"Pictures" => "រូបភាព",
"Picture view" => "ទិដ្ឋភាពរូបភាព",
"Error loading slideshow template" => "មាន​កំហុស​ផ្ទុក​ពុម្ព​បញ្ចាំងស្លាយ",
"Share" => "ចែក​រំលែក",
"shared by %s" => "បាន​ចែក​រំលែក​ដោយ %s",
"File list" => "បញ្ជី​ឯកសារ"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
