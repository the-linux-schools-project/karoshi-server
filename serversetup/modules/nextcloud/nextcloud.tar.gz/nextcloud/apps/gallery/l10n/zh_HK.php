<?php
$TRANSLATIONS = array(
"Share" => "分享"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
