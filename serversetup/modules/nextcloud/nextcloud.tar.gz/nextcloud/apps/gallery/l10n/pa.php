<?php
$TRANSLATIONS = array(
"Share" => "ਸਾਂਝਾ ਕਰੋ"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
