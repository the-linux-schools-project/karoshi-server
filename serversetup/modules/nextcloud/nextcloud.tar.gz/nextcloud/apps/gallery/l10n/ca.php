<?php
$TRANSLATIONS = array(
"Pictures" => "Fotos",
"Picture view" => "Mostra fotos",
"Error loading slideshow template" => "Error en carregar la plantilla de presentació amb diapositives",
"Share" => "Comparteix",
"No pictures found! If you upload pictures in the files app, they will be displayed here." => "No s'han trobat imatges! Si pugeu imatges a l'aplicació de fitxers, es mostraran aquí.",
"shared by %s" => "compartit per %s",
"File list" => "Llista de fitxers"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
