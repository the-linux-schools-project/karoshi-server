OC.L10N.register(
    "twofactor_backupcodes",
    {
    "Generate backup codes" : "Generar códigos de respaldo",
    "Backup codes have been generated. {{used}} of {{total}} codes have been used." : "Los códigos de respaldo han sido generados. {{used}} de {{total}} códigos han sido usados.",
    "These are your backup codes. Please save and/or print them as you will not be able to read the codes again later" : "Estos son sus códigos de respaldo. Favor de resguardarlos y/o imprimirlos ya que no podrá leerlos otra vez después. ",
    "Save backup codes" : "Guardar códigos de respaldo",
    "Print backup codes" : "Imprimir códigos de respaldo",
    "Regenerate backup codes" : "Regenerar códigos de respaldo",
    "If you regenerate backup codes, you automatically invalidate old codes." : "Si usted regenera los códigos de respaldo, automáticamente invalidará los anteriores. ",
    "An error occurred while generating your backup codes" : "Se presentó un error al generar sus códigos de respaldo. ",
    "Nextcloud backup codes" : "Códigos de respaldo de Nextcloud",
    "Two-factor authentication" : "Autenticación de dos factores",
    "You successfully logged in using two-factor authentication (%1$s)" : "Usted ha iniciado sesión exitosamente usando autenticación de dos factores (%1$s)",
    "A login attempt using two-factor authentication failed (%1$s)" : "Un intento por ingresar usando autenticación de dos factores falló (%1$s)",
    "You created two-factor backup codes for your account" : "Usted ha creado códigos de respaldo de dos factores para su cuenta",
    "Backup code" : "Código de respaldo",
    "Use backup code" : "Use el código de respaldo",
    "Second-factor backup codes" : "Códigos de respaldo del segundo factor"
},
"nplurals=2; plural=(n != 1);");
