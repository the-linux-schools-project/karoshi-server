<?php

$tmpl = new \OCP\Template('twofactor_backupcodes', 'personal');

return $tmpl->fetchPage();
