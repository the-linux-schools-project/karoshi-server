<?php

script('twofactor_backupcodes', 'settingsview');
script('twofactor_backupcodes', 'settings');
style('twofactor_backupcodes', 'style');

?>

<div class="section">
    <h2 data-anchor-name="second-factor-backup-codes"><?php p($l->t('Second-factor backup codes')); ?></h2>
    <div id="twofactor-backupcodes-settings"></div>
</div>
