<?php

class ApcPrefixCollision_A_Foo
{
    public static $loaded = true;
}
