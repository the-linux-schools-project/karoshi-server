OC.L10N.register(
    "files_external",
    {
    "Personal" : "﻿ವೈಯಕ್ತಿಕ",
    "Saved" : "﻿ಉಳಿಸಿದ",
    "Username" : "﻿ಬಳಕೆಯ ಹೆಸರು",
    "Password" : "ಗುಪ್ತ ಪದ",
    "Save" : "﻿ಉಳಿಸಿ",
    "None" : "﻿ಯಾವುದೂ ಇಲ್ಲ",
    "Port" : "﻿ರೇವು",
    "WebDAV" : "﻿WebDAV",
    "URL" : "ಜಾಲದ ಕೊಂಡಿ",
    "Host" : "ಅತಿಥೆಯ-ಗಣಕ",
    "Local" : "ಸ್ಥಳೀಯ",
    "Share" : "﻿ಹಂಚಿಕೊಳ್ಳಿ",
    "Name" : "﻿ಹೆಸರು",
    "Delete" : "﻿ಅಳಿಸಿ"
},
"nplurals=1; plural=0;");
