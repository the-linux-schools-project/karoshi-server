OC.L10N.register(
    "files_external",
    {
    "External storage" : "سىرتقى ساقلىغۇچ",
    "Personal" : "شەخسىي",
    "Username" : "ئىشلەتكۈچى ئاتى",
    "Password" : "ئىم",
    "Save" : "ساقلا",
    "None" : "يوق",
    "Port" : "ئېغىز",
    "WebDAV" : "WebDAV",
    "URL" : "URL",
    "Host" : "باش ئاپپارات",
    "Location" : "ئورنى",
    "ownCloud" : "ownCloud",
    "Share" : "ھەمبەھىر",
    "Name" : "ئاتى",
    "Folder name" : "قىسقۇچ ئاتى",
    "Configuration" : "سەپلىمە",
    "Delete" : "ئۆچۈر"
},
"nplurals=1; plural=0;");
