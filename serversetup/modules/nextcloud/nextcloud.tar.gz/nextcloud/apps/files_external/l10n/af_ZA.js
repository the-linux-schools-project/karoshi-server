OC.L10N.register(
    "files_external",
    {
    "Personal" : "Persoonlik",
    "Username" : "Gebruikersnaam",
    "Password" : "Wagwoord",
    "Share" : "Deel"
},
"nplurals=2; plural=(n != 1);");
