OC.L10N.register(
    "files_external",
    {
    "Location" : "Papan panggonan"
},
"nplurals=2; plural=(n != 1);");
