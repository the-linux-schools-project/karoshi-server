OC.L10N.register(
    "files_external",
    {
    "Personal" : "Personleg",
    "Username" : "Brukarnamn",
    "Password" : "Passord",
    "Save" : "Lagra",
    "Region" : "Region/fylke",
    "WebDAV" : "WebDAV",
    "URL" : "Nettstad",
    "Host" : "Tenar",
    "Location" : "Stad",
    "ownCloud" : "ownCloud",
    "Share" : "Del",
    "Name" : "Namn",
    "Folder name" : "Mappenamn",
    "Configuration" : "Innstillingar",
    "Delete" : "Slett"
},
"nplurals=2; plural=(n != 1);");
