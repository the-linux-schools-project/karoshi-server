<?php $TRANSLATIONS = array(
"Save" => "Сними",
"Search" => "Барај",
"Close" => "Затвои",
"Next" => "Следно",
"Clear" => "Исчисти",
"Saving..." => "Снимам...",
"Failed to save file" => "Снимањето на датотеката не успеа",
"An error occurred!" => "Се случи грешка",
"There were unsaved changes, click here to go back" => "Имаше неснимени промени, кликнете тука за да се вратите"
);
