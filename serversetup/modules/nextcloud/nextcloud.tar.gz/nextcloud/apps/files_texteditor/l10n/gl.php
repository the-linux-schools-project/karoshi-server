<?php
$TRANSLATIONS = array(
"Invalid file path supplied." => "Forneceu unha ruta incorrecta.",
"Cannot save file as it has been modified since opening" => "Non é posíbel gardar o ficheiro, xa que foi modificado trala súa apertura",
"Insufficient permissions" => "Non ten permisos abondo",
"File path not supplied" => "Non forneceu unha ruta de ficheiro",
"File mtime not supplied" => "Non forneceu o ficheiro mtime",
"Save" => "Gardar",
"Search" => "Buscar",
"Next" => "Seguinte",
"Clear" => "Limpar",
"Saving..." => "Gardando...",
"An error occurred!" => "Produciuse un erro!",
"There are unsaved changes in the text editor" => "Hai cambios sen gardar no editor de textos",
"There were unsaved changes, click here to go back" => "Hai cambios sen gardar, prema aquí para ir cara atrás"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
