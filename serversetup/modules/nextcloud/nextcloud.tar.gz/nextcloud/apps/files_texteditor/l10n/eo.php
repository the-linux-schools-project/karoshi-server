<?php $TRANSLATIONS = array(
"Save" => "Konservi",
"Search" => "Serĉi",
"Close" => "Fermi",
"Next" => "Jena",
"Clear" => "Forviŝi",
"Saving..." => "Konservante...",
"Failed to save file" => "Malsukcesis konservo de dosiero",
"An error occurred!" => "Eraro okazis!",
"There were unsaved changes, click here to go back" => "Estas nekonservitaj ŝanĝoj, klaku ĉi tie por iri antaŭen"
);
