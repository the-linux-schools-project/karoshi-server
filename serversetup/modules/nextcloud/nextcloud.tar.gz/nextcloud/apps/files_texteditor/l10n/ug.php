<?php $TRANSLATIONS = array(
"Save" => "ساقلا",
"Search" => "ئىزدە",
"Close" => "ياپ",
"Next" => "كېيىنكى",
"Clear" => "تازىلا",
"Saving..." => "ساقلاۋاتىدۇ…",
"Failed to save file" => "ھۆججەتنى ساقلىيالمىدى",
"An error occurred!" => "خاتالىق كۆرۈلدى!",
"There were unsaved changes, click here to go back" => "ساقلانمىغان ئۆزگىرىشلەر بار، چېكىلسە قايتىدۇ"
);
