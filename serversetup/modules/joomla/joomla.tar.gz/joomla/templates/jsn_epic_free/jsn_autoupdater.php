<?php
/**
 * @author    JoomlaShine.com http://www.joomlashine.com
 * @copyright Copyright (C) 2008 - 2011 JoomlaShine.com. All rights reserved.
 * @license   GNU/GPL v2 http://www.gnu.org/licenses/gpl-2.0.html
 * @version   $Id: jsn_autoupdater.php 12145 2012-04-13 08:37:37Z giangnd $
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
//@ini_set('display_errors', 0);

require_once('includes'.DS.'jsn_defines.php');
require_once('includes'.DS.'lib'.DS.'jsn_utils.php');
require_once('includes'.DS.'lib'.DS.'jsn_readxmlfile.php');
require_once('includes'.DS.'lib'.DS.'jsn_auto_updater_helper.php');
$session			=& JFactory::getSession();
$obj_read_xml_file 	= new JSNReadXMLFile();
$obj_utils			= new JSNUtils();
$obj_updater_helper	= new JSNAutoUpdaterHelper();
$template_manifest	= $obj_read_xml_file->getTemplateManifestFileInformation();
$manifest_cache		= $obj_utils->getTemplateManifestCache();
$manifest_cache		= json_decode($manifest_cache);
if ($template_manifest['edition'] != '' && $template_manifest['edition'] != 'free')
{
	$edition = $template_manifest['edition'];
}
else
{
	$edition = 'free';
}
$template_style_id			= JRequest::getInt('template_style_id', 0, 'GET');
$task 						= JRequest::getWord('task', '', 'POST');
$login_identifier 			= md5('state_update_login_'.strtolower($template_manifest['full_name']));
$customer_info_identifier 	= md5('state_update_customer_info_'.strtolower($template_manifest['full_name']));
$authentication				= false;
$login						= false;
switch ($task)
{
	case 'login':
		JRequest::checkToken() or jexit('Invalid Token');
		$post 		= JRequest::get('post');
		$username 	= JRequest::getVar('username', '', 'post', 'username');
		$password 	= JRequest::getString('password', '', 'post', JREQUEST_ALLOWRAW);
		$login		= $obj_updater_helper->login($username, $password);
		$canDo		= $obj_updater_helper->getUserActions();
		if ($login && $canDo->get('core.manage'))
		{
			if ($edition != 'free')
			{
				$authentication = $obj_updater_helper->authenticateCustomerInfo();
				if ($authentication)
				{
					$customer_password 	= JRequest::getString('customer_password', '', 'post', JREQUEST_ALLOWRAW);
					$customer_info		= array('username'=>$post['customer_username'], 'password'=>$customer_password);
					$session->set($login_identifier, true, 'jsntemplatesession');
					$session->set($customer_info_identifier, $customer_info, 'jsntemplatesession');
				}
			}
			else
			{
				$customer_info		= array('username'=>'', 'password'=>'');
				$session->set($login_identifier, true, 'jsntemplatesession');
				$session->set($customer_info_identifier, $customer_info, 'jsntemplatesession');
				$authentication		= true;
			}
		}
		break;
	case 'download_modified_file':
		$file_name 		= JRequest::getCmd('modified_file_name', '', 'POST');
		if ($obj_updater_helper->downloadFile('zip', $file_name))
		{
			jexit();
		}
		else
		{
			JError::raiseWarning('SOME_ERROR_CODE', 'File not found');
		}
		break;
	default:
	break;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
	<head>
		<title>Updater</title>
		<link rel="stylesheet" href="<?php echo JURI::base(true); ?>/templates/<?php echo $this->template; ?>/admin/css/jsn_admin.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo JURI::base(true); ?>/templates/system/css/system.css" type="text/css" />
		<?php echo JSN_TEMPLATE_JAVASCRIPT_MOOTOOL_CORE; ?>
		<?php echo JSN_TEMPLATE_JAVASCRIPT_MOOTOOL_MORE; ?>
		<script type="text/javascript" src="<?php echo JURI::base(true); ?>/templates/<?php echo $this->template; ?>/admin/js/jsn_updater.js"></script>
	</head>
	<body id="jsn-auto-updater">
		<div id="jsn-container">
			<div id="jsn-wrapper">
				<?php
					$latest_version = $obj_utils->getLatestVersion(str_replace('_', '-', $template_manifest['name']));
				?>
				<h1><?php echo $template_manifest['name_uppercase']; ?> Updater <span id="jsn-from-version-to-version">(<?php echo $manifest_cache->version; ?> -&gt; <?php echo $latest_version; ?>)</span>
					<span class="action-cancel"><a id="jsn-updater-cancel" class="link-action" href="javascript: void(0);" onclick="window.top.setTimeout('SqueezeBox.close();', 100);">Cancel</a></span>
				</h1>
				<?php if (!$authentication || !$login) { ?>
				<?php
					$session->set($login_identifier, false, 'jsntemplatesession');
					$session->set($customer_info_identifier, array(), 'jsntemplatesession');
				?>
				<div id="page-1">
					<p>This updater will guide you through the process of updating your template to the latest version.</p>
					<div class="text-info">
						<span class="title">Important information</span>
						<ul>
							<li>All website content and template parameters remain the same after the update.</li>
							<li>If you made changes to template files, then you will have to port those changes to new template manually after the update process. Detailed instructions will be provided.</li>
						</ul>
					</div>
					<jdoc:include type="message" />
					<form method="post" action="index.php?template=<?php echo $this->template; ?>&amp;tmpl=jsn_autoupdater&amp;template_style_id=<?php echo $template_style_id ?>" id="frm_update" name="frm_update" autocomplete="off" enctype="multipart/form-data">
					<?php if  ($edition != 'free') { ?>
					<div class="step-1">
						<h2>Step 1.</h2>
						<p>For verification, please input the <strong>JoomlaShine customer account</strong> that you created when making purchase.</p>
						<div class="jsn-login-form">
							<p class="clearafter">
								<span>Username:<input name="customer_username" id="customer-username" type="text" /></span>
								<span>Password:<input name="customer_password" id="customer-password" type="password" /></span>
							</p>
						</div>
					</div>
					<hr class="jsn-horizontal-line" />
					<?php } ?>
					<div class="step-2">
						<?php if  ($edition != 'free') { ?>
						<h2>Step 2.</h2>
						<?php } ?>
						<p>For security reason, please input the <strong>Super Administrator account</strong> that you are using to access to your Joomla! website administration.</p>
						<div class="jsn-login-form">
							<p class="clearafter">
								<span>Username:<input name="username" id="username" type="text" /></span>
								<span>Password:<input name="password" id="password" type="password" /></span>
							</p>
						</div>
					</div>
					<hr class="jsn-horizontal-line" />
					<div class="jsn-button">
						<button class="action-submit" type="submit" id="jsn-update-button" name="installation_button">Update template</button>
					</div>
					<input type="hidden" name="task" value="login" />
					<?php echo JHTML::_('form.token'); ?>
					</form>
				</div>
				<?php } else { ?>
				<?php
					$customer_info = $session->get($customer_info_identifier, array(), 'jsntemplatesession');
					$product_info  = array('customer_username'=>$customer_info['username'], 'customer_password'=>$customer_info['password']);
				?>
				 <script type="text/javascript">
						var options = <?php echo json_encode($product_info); ?>;
			 			var objJSNUpdater = new JSNUpdater(options);
						window.addEvent('domready', function() {
							objJSNUpdater.toggleCancelButton(false);
							objJSNUpdater.dowloadTemplatePackage('<?php echo strtolower($template_manifest['full_name']);?>', '<?php echo JURI::root();?>', <?php echo $template_style_id; ?>);
						});
				</script>
					<div id="page-2">
						<p>There are several stages involved in the process. Please be patient.</p>
						<ul>
							<li id="jsn-download-package-li"><span id="jsn-download-package-subtitle">Download template installation package.</span>
								<span id="jsn-download-package"></span>
								<span id="jsn-download-package-message" class="jsn-message"></span>
							</li>
							<li id="jsn-create-modified-list-li" class="jsn-updater-display-none"><span id="jsn-create-modified-list-subtitle">Create list of user modified files.</span><span id="jsn-create-modified-list"></span></li>
							<li id="jsn-update-template-li" class="jsn-updater-display-none"><span id="jsn-update-template-subtitle">Update template files.</span>
								<span id="jsn-update-template"></span>
								<span id="jsn-update-template-message" class="jsn-message"></span>
							</li>
						</ul>
						<div id="jsn-download-package-manual-update" class="jsn-updater-display-none">
							<form method="post" action="index.php?template=<?php echo $this->template; ?>&amp;tmpl=jsn_manualupdater&amp;template_style_id=<?php echo $template_style_id ?>" id="frm_manual_update" name="frm_manual_update" autocomplete="off" enctype="multipart/form-data">
								 <input type="file" name="package" id="package" size="35" />
								<input name="username" type="hidden" value="<?php echo @$username; ?>" />
								<input name="password" type="hidden" value="<?php echo @$password; ?>" />
								<input type="hidden" name="task" value="login" />
								<?php echo JHTML::_('form.token'); ?>
								<hr class="jsn-horizontal-line" />
								<div class="jsn-button">
									<button class="action-submit" type="submit" id="jsn-update-button" name="installation_button">Try again</button>
								</div>
							</form>
						</div>
						<div id="jsn-update-succesfully-container" class="jsn-updater-display-none">
							<hr class="jsn-horizontal-line" />
							<div id="jsn-update-succesfully-wrapper" class="jsn-updater-display-none">
								<h3 class="jsn-green-heading">Template is successfully updated</h3>
								<p>Congratulations, your template is now updated to the latest version.</p>
								<div class="text-alert-1 jsn-updater-display-none" id="text-alert-attention">
									<span class="title">Attention!</span>
									<p>You made changes to template files, which need to be ported to new template manually. </p>
									<ul>
										<li><a href="javascript: void(0);" onclick="document.frm_download.submit();" class="link-action">Download your modified files</a></li>
										<li><a href="http://www.joomlashine.com/docs/joomla-templates/how-to-update-template.html" target="_blank" class="link-action">Read instructions about how to process them</a></li>
									</ul>
								</div>
							</div>
							<div class="jsn-button">
								<button class="action-submit" type="button" id="jsn-update-button" name="jsn_finish_button" onclick="window.top.location.reload(true);">Finish</button>
							</div>
						</div>
					</div>
					<form method="post" action="index.php?template=<?php echo $this->template; ?>&amp;tmpl=jsn_autoupdater&amp;template_style_id=<?php echo $template_style_id ?>" id="frm_download" name="frm_download" autocomplete="off">
						<input type="hidden" name="task" value="download_modified_file" />
						<input type="hidden" name="modified_file_name" id="modified_file_name" value="" />
						<?php echo JHTML::_( 'form.token' ); ?>
					</form>
				<?php } ?>
			</div>
		</div>
	</body>
</html>