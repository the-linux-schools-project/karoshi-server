/**
* @author    JoomlaShine.com http://www.joomlashine.com
* @copyright Copyright (C) 2008 - 2011 JoomlaShine.com. All rights reserved.
* @license   GNU/GPL v2 http://www.gnu.org/licenses/gpl-2.0.html
*/

var JSNSampleData = {
	
	init: function() {},
	
	setInstallationButtonState: function (form)
	{
		var username = form.username.value;
		var password = form.password.value;
		var agree = form.agree.checked;
		if (username != '' && password != '' && agree)
		{
			form.installation_button.disabled = false;

		}
		else
		{
			form.installation_button.disabled = true;
		}	
	},
	
	installSampleData: function(template_name, url, style_id)
	{
		$('jsn-installing-sampledata').addClass('jsn-installsample-display-block');
		$('jsn-install-sample-data-package-title').removeClass('jsn-installsample-display-list');	
		JSNSampleData.downloadPackage(template_name, url, style_id);
	},
	
	downloadPackage: function(template_name, url, style_id)
	{
		$('jsn-span-downloading-sampledata-state').addClass('jsn-installsample-display-inline');
		$('jsn-span-unsuccessful-downloading-sampledata-message').set('html', '');
		$('jsn-install-cancel').setStyle('display', 'none');
		$('jsn-span-successful-downloading-sampledata').removeClass('jsn-installsample-display-inline');
		$('jsn-span-unsuccessful-downloading-sampledata').removeClass('jsn-installsample-display-inline');
		$('jsn-span-unsuccessful-downloading-sampledata-message').removeClass('jsn-installsample-display-block');
		$('jsn-install-sample-data-package-title').removeClass('jsn-installsample-display-list');
		
		var subtileElement 	= $('jsn-download-sample-data-package-subtitle');
		var tmpsubtitle 	= subtileElement.get('html').replace('<strike>','');	
		tmpsubtitle 		= tmpsubtitle.replace('</strike>','');		
		subtileElement.set('html', tmpsubtitle);
		subtileElement.removeClass('jsn-installsample-done');
		
		var link = url + 'index.php';
		var jsonRequest = new Request.JSON({url: link, onSuccess: function(jsonObj){
		if(jsonObj.download)
		{
			$('jsn-span-downloading-sampledata-state').removeClass('jsn-installsample-display-inline');
			$('jsn-span-successful-downloading-sampledata').addClass('jsn-installsample-display-inline');
			$('jsn-install-sample-data-package-title').addClass('jsn-installsample-display-list');
			var subtitle = subtileElement.get('html');
			subtileElement.set('html', '');
			subtileElement.addClass('jsn-installsample-done');
			var strike = new Element('strike', {html: subtitle});
			strike.inject(subtileElement);
			var file_name = jsonObj.file_name;
			JSNSampleData.installPackage(template_name, file_name, url);
		}
		else
		{
			$('jsn-span-downloading-sampledata-state').removeClass('jsn-installsample-display-inline');
			$('jsn-span-unsuccessful-downloading-sampledata').addClass('jsn-installsample-display-inline');
			$('jsn-install-cancel').setStyle('display', 'block');
			$('jsn-span-unsuccessful-downloading-sampledata-message').set('html', jsonObj.message);
			$('jsn-span-unsuccessful-downloading-sampledata-message').addClass('jsn-installsample-display-block');
			if (!jsonObj.connection)
			{
				$('jsn-span-unsuccessful-downloading-sampledata-inline-manually').addClass('jsn-installsample-display-block');
			}
		}
		}}).get({'template': template_name, 'tmpl': 'jsn_runajax', 'task': 'downloadSampleDataPackage', 'template_style_id': style_id});
	},
	
	installPackage: function(template_name, file_name, url) 
	{
		$('jsn-span-installing-sampledata-state').addClass('jsn-installsample-display-inline');
		$('jsn-span-unsuccessful-installing-sampledata-message').set('html', '');
		$('jsn-span-unsuccessful-installing-sampledata-message').removeClass('jsn-installsample-display-block');	
		$('jsn-span-successful-installing-sampledata').removeClass('jsn-installsample-display-inline');	
		$('jsn-span-unsuccessful-installing-sampledata').removeClass('jsn-installsample-display-inline');
		
		var subtileElement 	= $('jsn-install-sample-data-package-subtitle');
		var tmpsubtitle 	= subtileElement.get('html').replace('<strike>','');	
		tmpsubtitle 		= tmpsubtitle.replace('</strike>','');		
		subtileElement.set('html', tmpsubtitle);
		subtileElement.removeClass('jsn-installsample-done');
		
		var link = url + 'index.php';
		var jsonRequest = new Request.JSON({url: link, onSuccess: function(jsonObj){
		if(jsonObj.install)
		{
			$('jsn-span-installing-sampledata-state').removeClass('jsn-installsample-display-inline');	
			$('jsn-span-successful-installing-sampledata').addClass('jsn-installsample-display-inline');	
			$('jsn-installing-sampledata-successfully').addClass('jsn-installsample-display-block');
			var subtitle = subtileElement.get('html');
			subtileElement.set('html', '');
			subtileElement.addClass('jsn-installsample-done');
			var strike = new Element('strike', {html: subtitle});
			strike.inject(subtileElement);
			var count = jsonObj.warnings.length;
			if (count)
			{
				$('jsn-warnings').addClass('jsn-installsample-display-block');
				JSNSampleData.renderWarning(jsonObj.warnings);			
			}
		}	
		else
		{
			$('jsn-span-installing-sampledata-state').removeClass('jsn-installsample-display-inline');	
			$('jsn-span-unsuccessful-installing-sampledata').addClass('jsn-installsample-display-inline');			
			$('jsn-span-unsuccessful-installing-sampledata-message').set('html', jsonObj.message);
			$('jsn-span-unsuccessful-installing-sampledata-message').addClass('jsn-installsample-display-block');
			$('jsn-install-cancel').setStyle('display', 'block');
			if (jsonObj.manual != undefined)
			{
				if (jsonObj.manual)
				{
					$('jsn-span-unsuccessful-installing-sampledata-inline-manually').addClass('jsn-installsample-display-block');
				}	
			}
		}
		}}).get({'template': template_name, 'tmpl': 'jsn_runajax', 'task': 'installSampleData', 'file_name': file_name});
	},
	
	renderWarning: function(data)
	{
		var warnings = data;
		var count	 = warnings.length;
		var ul 		 = $('jsn-ul-warnings');
		if (count)
		{
			for(var i=0; i < count; i++)
			{
				var li = new Element('li', {html: warnings[i]});
				li.inject(ul);
			}
		}
	},
	
	setInlineInstallationButtonState:function(form)
	{
		if (form.install_package.value == "")
		{
			form.jsn_inline_install_manual_button.disabled = true;
		}
		else 
		{
			form.jsn_inline_install_manual_button.disabled = false;
		}
	}
};