/**
* @author    JoomlaShine.com http://www.joomlashine.com
* @copyright Copyright (C) 2008 - 2011 JoomlaShine.com. All rights reserved.
* @license   GNU/GPL v2 http://www.gnu.org/licenses/gpl-2.0.html
*/

	var JSNTemplate = {
		_templateParams:		{},

		initOnDomReady: function()
		{
			if (!_templateParams.enableMobile) {
					// Menu dropdown setup
					JSNUtils.setDropdownMenu("menu-mainmenu", 0, {}, false);

				// General layout setup
				JSNUtils.setInnerLayout(["jsn-content_inner3", "jsn-leftsidecontent", "jsn-rightsidecontent", "jsn-pos-innerleft", "jsn-pos-innerright"]);

				// Typography setup
				JSNUtils.createGridLayout("DIV", "grid-layout", "grid-col", "grid-lastcol");
			}
		},

		initOnLoad: function()
		{
			if (!_templateParams.enableMobile) {
				// Setup vertical positions of stickleft, stickright positions
				JSNUtils.setVerticalPosition("jsn-pos-stick-leftmiddle", 'middle');
				JSNUtils.setVerticalPosition("jsn-pos-stick-rightmiddle", 'middle');
				
				if (_templateParams.enableEqualHeight) JSNTemplate.setEqualHeight();
			}
		},

		initTemplate: function(templateParams)
		{
			// Store template parameters
			_templateParams = templateParams;
			
			// Init template on "domready" event
				window.addEvent('domready', JSNTemplate.initOnDomReady);

			// Init template on "load" event
			JSNUtils.addEvent(window, 'load', JSNTemplate.initOnLoad);
		},
		
		setAttribute: function(attributeName, attributeValue) {
			JSNUtils.setTemplateAttribute(_templateParams.templatePrefix, attributeName, attributeValue);
		},

		setEqualHeight: function() {
			var containerClass 	= "jsn-horizontallayout";
			var columnClass 	= "jsn-modulecontainer_inner";
			var horizontallayoutObjs = $$('.'+containerClass);
			var maxHeight = 0;
			Array.each(horizontallayoutObjs, function(item) {
				var columns = item.getElements('.'+columnClass);
				maxHeight = 0;
				Array.each(columns, function(col) {
					var coordinates = col.getCoordinates();
					if (coordinates.height > maxHeight) maxHeight = coordinates.height;
				});
				Array.each(columns, function(col) {
					col.setStyle('height',maxHeight);
				});
			});
		}
	}; /* must have ; to prevent syntax error when compress */