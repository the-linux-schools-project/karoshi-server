<?php
/**
 * @author    JoomlaShine.com http://www.joomlashine.com
 * @copyright Copyright (C) 2008 - 2011 JoomlaShine.com. All rights reserved.
 * @license   GNU/GPL v2 http://www.gnu.org/licenses/gpl-2.0.html
 * @version   $Id$
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
//@ini_set('display_errors', 0);

require_once('includes'.DS.'jsn_defines.php');
require_once('includes'.DS.'lib'.DS.'jsn_utils.php');
require_once('includes'.DS.'lib'.DS.'jsn_backup.php');
require_once('includes'.DS.'lib'.DS.'jsn_readxmlfile.php');
require_once('includes'.DS.'lib'.DS.'jsn_sampledata_helper.php');

global $error;
$obj_read_xml_file 	= new JSNReadXMLFile();
$template_manifest	= $obj_read_xml_file->getTemplateManifestFileInformation();
$backup_obj			= JSNBackup::getInstance();
$obj_utils			= new JSNUtils();
$joomla_version		= $obj_utils->getJoomlaVersion();
define("JSN_SAMPLE_DATA_FILE_URL",'http://www.joomlashine.com/joomla-templates/'.strtolower(str_replace('_', '-', $template_manifest['full_name'])).'-sample-data-j'.$joomla_version.'.zip');
/////////////////////////////////////////////////////////////////////////////////////MAIN//////////////////////////////////////////////////////////////////////////////////////////////////
$strLiveDemo				= '<p>This installer will make your website looks the same as <a href="http://demo.joomlashine.com/joomla-templates/'.$template_manifest['name'].'/index.php" target="_blank">'.$template_manifest['name_uppercase'].' live demo website.</a></p>';
$strImportantInformation	= '<div class="text-alert"><strong style="color: #cc0000">Important information</strong><ul><li>Installing sample data will delete all data on this website.</li><li>It is NOT recommended to install sample data on production website.</li></ul></div>';
$strLogin					= '<p>For security reason, please input the Super Administrator account that you are using to access to your Joomla! website administration.</p>';
$identifier 				= md5('state_installation_'.strtolower($template_manifest['full_name']));
$login_identifier 			= md5('state_login_'.strtolower($template_manifest['full_name']));
$session					= JFactory::getSession();

$template_style_id		= JRequest::getInt('template_style_id', 0, 'GET');
$task 					= JRequest::getWord('task', '', 'POST');
$type 					= JRequest::getWord('type', '', 'POST');
$backup_file_name		= JRequest::getCmd('backup_file_name', '', 'POST');
$jsn_layout				= JRequest::getCmd('jsn_layout', '', 'GET');

$obj_sampledata_helper	= new JSNSampleDataHelper();
$isWriteable			= $obj_sampledata_helper->checkTmpFolderPermission();
$login					= false;
$result_install		    = false;
$manual 				= false;
if (!$obj_utils->cURLCheckFunctions() && !$obj_utils->fOPENCheck() && !$obj_utils->fsocketopenCheck())
{
	$manual	= true;
}

if ($jsn_layout != '' && $jsn_layout == 'manual') $manual = true;

switch ($task)
{
	case 'login':
		JRequest::checkToken() or jexit('Invalid Token');
		$username 	= JRequest::getVar('username', '', 'post', 'username');
		$password 	= JRequest::getString('password', '', 'post', JREQUEST_ALLOWRAW);
		$login		= $obj_sampledata_helper->login($username, $password);
		$canDo		= $obj_sampledata_helper->getUserActions();
		if ($login && $canDo->get('core.manage'))
		{
			if ($type == 'auto' && !$manual)
			{
				$session->set($login_identifier, true, 'jsntemplatesession');
			}
			else
			{
				$result_install = $obj_sampledata_helper->installSampleDataManually();
			}
		}
		break;
	case 'manual':
		JRequest::checkToken() or jexit('Invalid Token');
		if ($session->get($login_identifier, false, 'jsntemplatesession'))
		{
			$session->set($login_identifier, false, 'jsntemplatesession');
			$result_install = $obj_sampledata_helper->installSampleDataManually();
		}
		break;
	default:
	break;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
	<head>
		<title>Install Sample Data</title>
		<link rel="stylesheet" href="<?php echo JURI::base(true); ?>/templates/<?php echo $this->template; ?>/admin/css/jsn_admin.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo JURI::base(true); ?>/templates/system/css/system.css" type="text/css" />
		<?php echo JSN_TEMPLATE_JAVASCRIPT_MOOTOOL_CORE; ?>
		<?php echo JSN_TEMPLATE_JAVASCRIPT_MOOTOOL_MORE; ?>
		<script type="text/javascript" src="<?php echo JURI::base(true); ?>/templates/<?php echo $this->template; ?>/admin/js/jsn_sampledata.js"></script>
	</head>
	<body id="jsn-sampledata">
		<div id="jsn-page">
			<div id="jsn-page_inner1">
				<div id="jsn-page_inner2">
					<h1><?php echo $template_manifest['name_uppercase']; ?>
						Sample Data Installation
						<span class="action-cancel"><a id="jsn-install-cancel" class="link-action" href="javascript: void(0);" onclick="window.top.setTimeout('SqueezeBox.close();', 100);">Cancel</a></span>
					</h1>
					<?php if (!$manual) { ?>
					<div id="jsn-auto-install">
						<?php if (!$session->get($identifier, false, 'jsntemplatesession')) { ?>
								<?php if (!$login) { ?>
								<?php $session->set($login_identifier, false, 'jsntemplatesession'); ?>
								<?php echo $strLiveDemo; ?>
								<?php echo $strImportantInformation; ?>
								<?php echo $strLogin; ?>
								<jdoc:include type="message" />
								<form method="post" action="index.php?template=<?php echo $this->template; ?>&amp;tmpl=jsn_installsampledata&amp;template_style_id=<?php echo $template_style_id ?>&amp;jsn_layout=<?php echo $jsn_layout; ?>" id="frm-login" name="frm_login" class="installSampleDataFrom" autocomplete="off">
									<div id="jsn-wrap-installation-content">
										<div id="jsn-sampledata-login">
											<div class="jsn-install-admin-info">
												<p class="clearafter">
												<span>Username:<input name="username" id="username" type="text" onchange="JSNSampleData.setInstallationButtonState(this.form);" onkeyup="JSNSampleData.setInstallationButtonState(this.form);" /></span>
												<span>Password:<input name="password" id="password" type="password" onchange="JSNSampleData.setInstallationButtonState(this.form);" onkeyup="JSNSampleData.setInstallationButtonState(this.form);" /></span>
												</p>
											</div>
											<hr class="jsn-horizontal-line" />
											<div class="jsn-install-admin-check">
												<p>
													<label for="local_rules_agree" class="input-label"><input type="checkbox" value="1" id="local_rules_agree" name="agree" onclick="JSNSampleData.setInstallationButtonState(this.form);" />
													<strong>I agree that installing sample data will delete all content on this website</strong></label>
												</p>
												<div class="jsn-install-admin-navigation">
													<button class="action-submit" type="submit" id="jsn-install-button" name="installation_button" disabled="disabled">Install sample data</button>
												</div>
											</div>
											<input type="hidden" name="task" value="login" />
											<input type="hidden" name="type" value="auto" />
											<?php echo JHTML::_('form.token'); ?>
										</div>
									</div>
								</form>
								<?php } else { ?>
									<div id="jsn-sampledata-installation">
										<div class="jsn-install-admin-info">
											<p>There are several stages involved in the process. Please be patient.</p>
										</div>
										<script type="text/javascript">
											window.addEvent('domready', function() {
												JSNSampleData.installSampleData('<?php echo strtolower($template_manifest['full_name']);?>', '<?php echo JURI::root();?>', <?php echo $template_style_id; ?>);
											});
										</script>
										<div id="jsn-sampledata-start-updating-process">
											<div id="jsn-installing-sampledata">
												<ul>
													<li id="jsn-download-sample-data-package-title"><span id="jsn-download-sample-data-package-subtitle">Download sample data package.</span><span class="jsn-sampledata-icon-small-loader" id="jsn-span-downloading-sampledata-state"></span><span class="jsn-sampledata-icon-small-successful" id="jsn-span-successful-downloading-sampledata"></span><span class="jsn-sampledata-icon-small-error" id="jsn-span-unsuccessful-downloading-sampledata">&nbsp;</span><br />
													<span id="jsn-span-unsuccessful-downloading-sampledata-message"></span>
													<span id="jsn-span-unsuccessful-downloading-sampledata-inline-manually">
														<form method="post" action="index.php?template=<?php echo $this->template; ?>&amp;tmpl=jsn_installsampledata&amp;template_style_id=<?php echo $template_style_id ?>&amp;jsn_layout=manual" id="frm-inline-install-manual" name="frm-inline-install-manual" class="installSampleDataFrom" autocomplete="off" enctype="multipart/form-data">
															<p class="clearafter"><a class="link-action" href="<?php echo JSN_SAMPLE_DATA_FILE_URL; ?>">Download sample data package</a>, then select it: </p><p><input type="file" name="install_package" id="jsn-inline-install-manual-package" size="35" onchange="return JSNSampleData.setInlineInstallationButtonState(this.form);"/></p>
															<input type="hidden" name="task" value="manual" />
															<input type="hidden" name="type" value="manual" />
															<?php echo JHTML::_('form.token'); ?>
															<div class="jsn-install-admin-navigation">
																<button class="action-submit" type="submit" id="jsn_inline_install_manual_button" name="jsn_inline_install_manual_button" disabled="disabled">Install sample data</button>
															</div>
														</form>
													</span>
													</li>
													<li id="jsn-install-sample-data-package-title"><span id="jsn-install-sample-data-package-subtitle">Install sample data.</span><span class="jsn-sampledata-icon-small-loader" id="jsn-span-installing-sampledata-state"></span><span class="jsn-sampledata-icon-small-successful" id="jsn-span-successful-installing-sampledata"></span><span class="jsn-sampledata-icon-small-error" id="jsn-span-unsuccessful-installing-sampledata">&nbsp;</span><br />
														<span id="jsn-span-unsuccessful-installing-sampledata-message"></span>
														<span id="jsn-span-unsuccessful-installing-sampledata-inline-manually">
															<form method="post" action="index.php?template=<?php echo $this->template; ?>&amp;tmpl=jsn_installsampledata&amp;template_style_id=<?php echo $template_style_id ?>&amp;jsn_layout=manual" id="installing-frm-inline-install-manual" name="installing-frm-inline-install-manual" class="installSampleDataFrom" autocomplete="off" enctype="multipart/form-data">
																<p class="clearafter"><a class="link-action" href="<?php echo JSN_SAMPLE_DATA_FILE_URL; ?>">Download sample data package</a>, then select it: </p><p><input type="file" name="install_package" id="jsn-inline-install-manual-package" size="35" onchange="return JSNSampleData.setInlineInstallationButtonState(this.form);"/></p>
																<input type="hidden" name="task" value="manual" />
																<input type="hidden" name="type" value="manual" />
																<?php echo JHTML::_('form.token'); ?>
																<div class="jsn-install-admin-navigation">
																	<button class="action-submit" type="submit" id="jsn_inline_install_manual_button_installing" name="jsn_inline_install_manual_button" disabled="disabled">Install sample data</button>
																</div>
															</form>
														</span>
													</li>
												</ul>
											</div>
											<div id="jsn-installing-sampledata-successfully">
												<hr />
												<div>
													<h3 class="jsnis-element-green-heading"><span id="jsn-sampledata-success-message">Sample data is successfully installed</span></h3>
													<p>Congratulations, your website now looks the same as <?php echo $template_manifest['name_uppercase']; ?> live demo website.</p>
												</div>
												<div class="text-alert-1" id="jsn-warnings"><strong style="color: #cc0000">Attention!</strong>
													<p>Sample data for following extensions could NOT be installed:</p>
													<ul id="jsn-ul-warnings">
													</ul>
												</div>
												<div class="jsn-install-admin-navigation jsn-content-installing-sampledata-successfully">
													<button class="action-submit" type="button" id="jsn-finish-button" name="finish_button" onclick="window.top.location.reload(true);">Finish</button>
												</div>
											</div>
										</div>
									</div>
								<?php } ?>
						<?php } ?>
					</div>
					<?php } else { ?>
					<div id="jsn-manual-install">
					<?php if (!$result_install) { ?>
						<?php echo $strLiveDemo; ?>
						<?php echo $strImportantInformation; ?>
						<form method="post" action="index.php?template=<?php echo $this->template; ?>&amp;tmpl=jsn_installsampledata&amp;template_style_id=<?php echo $template_style_id ?>&amp;jsn_layout=<?php echo $jsn_layout; ?>" id="frm-login" name="frm_login" class="installSampleDataFrom" autocomplete="off" enctype="multipart/form-data">
							<div class="jsn-manual-install-select-file">
								<h2>Step 1.</h2>
								<p class="clearafter"><a class="link-action" href="<?php echo JSN_SAMPLE_DATA_FILE_URL; ?>">Download sample data package</a>, then select it: <input type="file" name="install_package" id="install_package" size="35" /></p>
							</div>
							<hr class="jsn-horizontal-line" />
							<div class="jsn-manual-install-login">
								<h2>Step 2.</h2>
								<?php echo $strLogin; ?>
								<jdoc:include type="message" />
								<div id="jsn-wrap-installation-content">
									<div id="jsn-sampledata-login">
										<div class="jsn-install-admin-info">
											<p class="clearafter">
											<span>Username:<input name="username" id="username" type="text" onchange="JSNSampleData.setInstallationButtonState(this.form);" onkeyup="JSNSampleData.setInstallationButtonState(this.form);" /></span>
											<span>Password:<input name="password" id="password" type="password" onchange="JSNSampleData.setInstallationButtonState(this.form);" onkeyup="JSNSampleData.setInstallationButtonState(this.form);" /></span>
											</p>
										</div>
										<hr class="jsn-horizontal-line" />
										<div class="jsn-install-admin-check">
											<p>
												<label for="local_rules_agree" class="input-label"><input type="checkbox" value="1" id="local_rules_agree" name="agree" onclick="JSNSampleData.setInstallationButtonState(this.form);" />
												<strong>I agree that installing sample data will delete all content on this website</strong></label>
											</p>
											<div class="jsn-install-admin-navigation">
												<button class="action-submit" type="submit" id="jsn-install-button" name="installation_button" disabled="disabled">Install sample data</button>
											</div>
										</div>
										<input type="hidden" name="task" value="login" />
										<input type="hidden" name="type" value="manual" />
										<?php echo JHTML::_('form.token'); ?>
									</div>
								</div>
							</div>
						</form>
						<?php } else { ?>
							<div id="jsn-manual-install-successfully">
								<hr />
								<div>
									<h3 class="jsnis-element-green-heading"><span id="jsn-sampledata-success-message">Sample data is successfully installed</span></h3>
									<p>Congratulations, your website now looks the same as <?php echo $template_manifest['name_uppercase']; ?> live demo website.</p>
								</div>
								<?php if (count($error)) { ?>
								<div class="text-alert-1"><strong style="color: #cc0000">Attention!</strong>
									<p>Sample data for following extensions could NOT be installed:</p>
									<ul id="jsn-ul-warnings">
									<?php $obj_sample_data_helper = new JSNSampleDataHelper(); ?>
									<?php foreach ($error as $value) { ?>
										<li><?php echo $value; ?></li>
									<?php } ?>
									</ul>
								</div>
								<?php } ?>
								<div class="jsn-install-admin-navigation jsn-content-installing-sampledata-successfully">
									<button class="action-submit" type="button" id="jsn-finish-button" name="finish_button" onclick="window.top.location.reload(true);">Finish</button>
								</div>
							</div>
						<?php } ?>
					</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</body>
</html>