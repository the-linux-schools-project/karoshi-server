    <div id="container">  
        <ul class="menutabs">  
            <li id="news" class="active">News 1</li>  
            <li id="tutorials">News 2</li>  
            <li id="links">News 3</li>  
        </ul>  
        <span class="clear"></span>  
        <div class="content news">  
		<jdoc:include type="modules" name="tab1" style="xhtml" />  
        </div>  
        <div class="content tutorials">  
		<jdoc:include type="modules" name="tab2" style="xhtml" /> 
        </div>  
        <div class="content links">  
		<jdoc:include type="modules" name="tab3" style="xhtml" />
        </div>  
    </div>  