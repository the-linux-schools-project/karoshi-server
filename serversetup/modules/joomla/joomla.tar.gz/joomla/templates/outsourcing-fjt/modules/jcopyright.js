jQuery(document).ready(function(){
jQuery(".flip").click(function(){
    jQuery(".panelz").slideToggle("slow");
  });
});