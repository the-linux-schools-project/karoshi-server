<?php defined('_JEXEC') or die;
$app = JFactory::getApplication();
$yjsg_params = $app->getTemplate(true)->params;
?>