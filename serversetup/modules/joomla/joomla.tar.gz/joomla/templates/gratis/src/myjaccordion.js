/*======================================================================*\
|| #################################################################### ||
|| # Package - Joomla Template based on YJSimpleGrid Framework          ||
|| # Copyright (C) 2010  Youjoomla LLC. All Rights Reserved.            ||
|| # Authors - Dragan Todorovic and Constantin Boiangiu                 ||
|| # license - PHP files are licensed under  GNU/GPL V2                 ||
|| # license - CSS  - JS - IMAGE files  are Copyrighted material        ||
|| # bound by Proprietary License of Youjoomla LLC                      ||
|| # for more information visit http://www.youjoomla.com/license.html   ||
|| # Redistribution and  modification of this software                  ||
|| # is bounded by its licenses                                         ||
|| # websites - http://www.youjoomla.com | http://www.yjsimplegrid.com  ||
|| #################################################################### ||
\*======================================================================*/
eval(function(p,a,c,k,e,r){e=function(c){return c.toString(a)};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('2 8={5:0(){2 3=$$(".i");2 6=$$(".j");2 9=k l(3,6,{m:a,n:a,5:"o",p:0(4,b){4.c("d");6.q("e","r")},s:0(4,b){4.f("d")}});3.7("t",0(){g.c("h")});3.7("u",0(){g.f("h")});9.e(-1)}};v.7("w",8.5);',33,33,'function||var|togglers|toggler|start|toggled|addEvent|YJMAccordion|accordion|true|element|addClass|YJ_mtoggler_active|display|removeClass|this|YJ_mtoggler_hover|YJ_mtoggler|YJ_mparams|new|Accordion|alwaysHide|opacity|close|onActive|setStyle|block|onBackground|mouseenter|mouseleave|window|domready'.split('|'),0,{}))

