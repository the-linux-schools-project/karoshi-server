ALTER TABLE [#__update_sites] ADD [extra_query] [nvarchar](1000) NULL DEFAULT '';
ALTER TABLE [#__updates] ADD [extra_query] [nvarchar](1000) NULL DEFAULT '';
