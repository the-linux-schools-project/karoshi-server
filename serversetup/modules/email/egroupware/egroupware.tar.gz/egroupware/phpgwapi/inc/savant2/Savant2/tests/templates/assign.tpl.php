<?php
/**
* 
* Template for testing token references.
* 
* @version $Id: assign.tpl.php 18360 2005-05-26 19:38:09Z mipmip $
*
*/

?>
<h1>Change reference values from template</h1>
<p>Before: <?php echo $this->reference; $this->reference = "Changed Value From Template!" ?></p>
