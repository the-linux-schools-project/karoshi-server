<?php
/**
* 
* Tests the default and example filters for Savant.
* 
* @version $Id: filters.tpl.php 18360 2005-05-26 19:38:09Z mipmip $
*
*/
?>


<h1>Filters</h1>





<p>This and that</p>






<p>And the other</p>



<pre><code>
<php>
	// this is a test of PHP colorizing
	echo "some text";
	highlight_string("something");
	$variable = 'value';
	
	function fester()
	{
		// does nothing
	}
</php>
</code></pre>


<!-- end -->