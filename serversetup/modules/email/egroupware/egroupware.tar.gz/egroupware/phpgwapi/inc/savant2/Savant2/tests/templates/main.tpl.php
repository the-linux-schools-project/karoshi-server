<?php
/**
* 
* Test includes and loadTemplate()
* 
* @version $Id: main.tpl.php 18360 2005-05-26 19:38:09Z mipmip $
*
*/
?>

<?php include $this->loadTemplate('header.tpl.php') ?>

<?php include $this->loadTemplate('plugins.tpl.php') ?>

<?php include $this->loadTemplate('footer.tpl.php') ?>