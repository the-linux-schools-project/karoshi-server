<?php

/**
  * SquirrelMail Calendar Plugin File Backend
  * Copyright (C) 2004-2005 Paul Lesneiwski <pdontthink@angrynerds.com>
  * This program is licensed under GPL. See COPYING for details
  *
  */


   global $data_dir, $MAIN_CAL_DIR, $PUBLIC_CAL_DIR, 
          $SHARED_CAL_DIR, $PRIVATE_CAL_DIR, $CAL_FILE_EXTENSION,
          $EVENT_DIR, $HOLIDAY_DIR, $CAL_HOLIDAY_DIR_NAME;


   // it is possible to change this value, but make sure that
   // the web server will have read/write access to whatever
   // location it is pointing to
   //
   $base_calendar_dir = $data_dir;


   $MAIN_CAL_DIR    = $base_calendar_dir . 'calendar_data';


   $PUBLIC_CAL_DIR  = "$MAIN_CAL_DIR/public_calendars";
   $SHARED_CAL_DIR  = "$MAIN_CAL_DIR/shared_calendars";
   $PRIVATE_CAL_DIR = "$MAIN_CAL_DIR/private_calendars";


   $EVENT_DIR = "$MAIN_CAL_DIR/events";


   $HOLIDAY_DIR = "$MAIN_CAL_DIR/holidays";
   $CAL_HOLIDAY_DIR_NAME = "holidays";

   $CAL_FILE_EXTENSION = '.ics';



?>
